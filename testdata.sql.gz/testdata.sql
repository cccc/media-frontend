PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE "active_admin_comments" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "namespace" varchar(255), "body" text, "resource_id" varchar(255) NOT NULL, "resource_type" varchar(255) NOT NULL, "author_id" integer, "author_type" varchar(255), "created_at" datetime, "updated_at" datetime);
CREATE TABLE "admin_users" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "email" varchar(255) DEFAULT '' NOT NULL, "encrypted_password" varchar(255) DEFAULT '' NOT NULL, "reset_password_token" varchar(255), "reset_password_sent_at" datetime, "remember_created_at" datetime, "sign_in_count" integer DEFAULT 0, "current_sign_in_at" datetime, "last_sign_in_at" datetime, "current_sign_in_ip" varchar(255), "last_sign_in_ip" varchar(255), "created_at" datetime, "updated_at" datetime);
INSERT INTO "admin_users" VALUES(1,'admin@example.org','$2a$10$jyYFxFAi58dhDz.qF2H2h.xXjmy5yU7sqRfWp2Pg4kLywLD6j4.Um',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2014-07-12 11:43:37.401665','2014-07-12 11:43:37.401665');
CREATE TABLE "api_keys" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "key" varchar(255), "description" varchar(255), "created_at" datetime, "updated_at" datetime);
CREATE TABLE "conferences" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "acronym" varchar(255), "recordings_path" varchar(255), "images_path" varchar(255), "webgen_location" varchar(255), "aspect_ratio" varchar(255), "created_at" datetime, "updated_at" datetime, "title" varchar(255), "schedule_url" varchar(255), "schedule_xml" text(4294967295), "schedule_state" varchar(255) DEFAULT 'not_present' NOT NULL, "logo" varchar(255));
INSERT INTO "conferences" VALUES(4,'camp2011','events/camp2011','conferences/camp2011','conferences/camp2011','4:3','2014-05-10 13:26:08.758635','2014-06-29 00:03:40.723209','Chaos Communication Camp 2011','',NULL,'not_present','folder-camp-2011.png');
INSERT INTO "conferences" VALUES(19,'sigint13','events/sigint13','conferences/sigint13','conferences/sigint13','4:3','2014-05-10 13:26:09.260535','2014-05-13 19:08:08.841285','sigint13',NULL,NULL,'not_present','folder-sigint-2013.png');
INSERT INTO "conferences" VALUES(23,'20c3','congress/2003','congress/2003','congress/2003','4:3','2014-05-10 13:26:09.324424','2014-05-13 19:08:08.90767','20C3: Not a Number',NULL,NULL,'not_present','folder-20c3.png');
INSERT INTO "conferences" VALUES(33,'30c3','congress/2013','congress/2013','congress/2013','16:9','2014-05-10 13:26:10.192394','2014-05-13 19:21:36.434523','30C3',NULL,NULL,'not_present','folder-30c3.png');
CREATE TABLE "delayed_jobs" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "priority" integer DEFAULT 0 NOT NULL, "attempts" integer DEFAULT 0 NOT NULL, "handler" text NOT NULL, "last_error" text, "run_at" datetime, "locked_at" datetime, "failed_at" datetime, "locked_by" varchar(255), "queue" varchar(255), "created_at" datetime, "updated_at" datetime);
CREATE TABLE "events" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "guid" varchar(255), "gif_filename" varchar(255), "poster_filename" varchar(255), "conference_id" integer, "created_at" datetime, "updated_at" datetime, "title" varchar(255), "thumb_filename" varchar(255), "date" date, "description" text, "link" varchar(255), "persons" text, "slug" varchar(255), "subtitle" varchar(255), "tags" text, "release_date" date, "promoted" boolean, "view_count" integer DEFAULT 0);
INSERT INTO "events" VALUES(124,'import-4ef0accbc71134a330','cccamp11-4500-reviving_smart_card_analysis-en.gif','cccamp11-4500-reviving_smart_card_analysis-en_preview.jpg',4,'2014-05-10 13:26:12.355697','2014-06-26 22:16:22.503987','Reviving smart card analysis','cccamp11-4500-reviving_smart_card_analysis-en.jpg','2011-08-12','Smart cards chips – originally invented as a protection for cryptographic keys – are increasingly used to keep protocols secret. This talk challenges the chips'' security measures to unlock the protocols for public analysis.
','http://events.ccc.de/camp/2011/Fahrplan/events/4500.en.html','---
- Karsten Nohl
','cccamp11-4500-reviving_smart_card_analysis-en',NULL,'---
- camp2011
- '' Hacking''
','2011-08-30','f',1);
INSERT INTO "events" VALUES(125,'import-94efdacada20c130ed','cccamp11-4597-moonbounce_radio_communication-en.gif','cccamp11-4597-moonbounce_radio_communication-en_preview.jpg',4,'2014-05-10 13:26:12.384817','2014-05-10 13:26:12.384817','Moonbounce Radio Communication','cccamp11-4597-moonbounce_radio_communication-en.jpg','2011-08-13','Moon bounce, also known as EME (Earth-Moon-Earth), is a technique that allows two earth-based radio stations to communicate directly by using the moon as passive reflector.

It is the longest path two stations on Earth can use to establish direct connection with each other. First developed the late 1940s by the United States Navy it was used as a revolutionary way to communicate without the uncertainties of shortwave radio propagation. The development of artificial satellites completely obsoleted this usecase only a few years later but the technique itself is still one of the most challenging tasks in radio communication. Today it''s Amateur Radio stations that are practising the art of Moon bounce. We are here to tell and to show you how it is done.
','http://events.ccc.de/camp/2011/Fahrplan/events/4597.en.html','---
- Andreas Schreiner
- Clemens Hopfer
- Patrick Strasser
','cccamp11-4597-moonbounce_radio_communication-en','To the Moon and back in two seconds. The joy of light speed information travel','---
- camp2011
- '' Hacker Space Program''
','2011-08-14','f',0);
INSERT INTO "events" VALUES(126,'import-176ad1853fc7e8cdd1','cccamp11-4487-she_hackers-en.gif','cccamp11-4487-she_hackers-en_preview.jpg',4,'2014-05-10 13:26:12.413841','2014-06-27 05:01:45.239593','She-Hackers: Millennials and Gender in European F/LOSS Subcultures','cccamp11-4487-she_hackers-en.jpg','2011-08-12','In 2002, Ghosh et al released a study which found that in F/LOSS coder/hacker communities, only 1.5% of members were female. This participation-heavy session is about the challenges of immersive ethnographic research in a time of gender transformation.
','http://events.ccc.de/camp/2011/Fahrplan/events/4487.en.html','---
- Kat Braybrooke
','cccamp11-4487-she_hackers-en',' A Presentation of Research and Invitation for Debate','---
- camp2011
- '' Society''
','2011-08-21','f',3);
INSERT INTO "events" VALUES(127,'import-d76d60d0cb3b8ff53f','cccamp11-4418-cyberpeace_and_datalove-en.gif','cccamp11-4418-cyberpeace_and_datalove-en_preview.jpg',4,'2014-05-10 13:26:12.522408','2014-05-10 13:26:12.522408','Cyberpeace and Datalove','cccamp11-4418-cyberpeace_and_datalove-en.jpg','2011-08-10','Governments and corporations craft powerful memes to justify their repressive policies, it is time for us to provide with solid countermeasures. Will we get "cyberwar", censorship, and repression of sharing, or impose that Internet remains the instrument of (cyber)Peace, (data)Love and (hackers)Unity? 
','http://events.ccc.de/camp/2011/Fahrplan/events/4418.en.html','---
- Jérémie Zimmermann
','cccamp11-4418-cyberpeace_and_datalove-en','How do we counter the memes of control?','---
- camp2011
- '' Society''
','2011-10-25','f',0);
INSERT INTO "events" VALUES(128,'import-27ad057a197e5d9e76','cccamp11-4467-design_and_implementation_of_flight_electronics-en.gif','cccamp11-4467-design_and_implementation_of_flight_electronics-en_preview.jpg',4,'2014-05-10 13:26:12.551947','2014-05-10 13:26:12.551947','Avionics','cccamp11-4467-design_and_implementation_of_flight_electronics-en.jpg','2011-08-13','Flying hardware must perform its intended function under harsh environmental conditions while fulfilling strict requirements due to boundary conditions like weight, size, and power consumption. The design must exhibit redundancy and resilience against adversary conditions and special care has to be given to thermal management and energy sources. We will discuss design rules to cope with specific problems and present a prototype system based on the multicore chip P8X32A.
','http://events.ccc.de/camp/2011/Fahrplan/events/4467.en.html','--- []
','cccamp11-4467-design_and_implementation_of_flight_electronics-en','Design and implementation of flight electronics','---
- camp2011
- '' Hacker Space Program''
','2011-08-14','f',0);
INSERT INTO "events" VALUES(129,'import-030c0d0c772923374e','cccamp11-4428-the_joy_of_intellectual_vampirism-en.gif','cccamp11-4428-the_joy_of_intellectual_vampirism-en_preview.jpg',4,'2014-05-10 13:26:12.581128','2014-06-24 01:03:32.93563','The Joy of Intellectual Vampirism','cccamp11-4428-the_joy_of_intellectual_vampirism-en.jpg','2011-08-13','What makes us gravitate towards other people? In Intellectual Vampires it is the craving for fresh ideas, and in Intellectual Fangbangers it is the joy of sharing them. A talk on the fine art of communication, channels, contexts, and language.
','http://events.ccc.de/camp/2011/Fahrplan/events/4428.en.html','---
- Christiane Ruetten
','cccamp11-4428-the_joy_of_intellectual_vampirism-en','Mindfucking with Shared Information','---
- camp2011
- '' Culture''
','2011-08-14','f',1);
INSERT INTO "events" VALUES(130,'import-088d6fa7916eb5736e','cccamp11-4427-the_blackbox_in_your_phone-en.gif','cccamp11-4427-the_blackbox_in_your_phone-en_preview.jpg',4,'2014-05-10 13:26:12.610045','2014-05-10 13:26:12.610045','The blackbox in your phone','cccamp11-4427-the_blackbox_in_your_phone-en.jpg','2011-08-10','This talk sheds some light on a cellphone-component, that''s inevitable, virtually unclonable and as closed as it gets: the SIM. The SIM can do a lot more than just user-authentication nowadays: the SIM Application Toolkit gives it control over your phone
','http://events.ccc.de/camp/2011/Fahrplan/events/4427.en.html','---
- hunz
','cccamp11-4427-the_blackbox_in_your_phone-en','Some details about SIM cards','---
- camp2011
- '' Hacking''
','2011-08-12','f',0);
INSERT INTO "events" VALUES(131,'import-43791f22a53f559498','camp-2011-trailer.gif','',4,'2014-05-10 13:26:12.63843','2014-06-26 06:07:12.607641','Camp 2011 Trailer','camp-2011-trailer.jpg','2011-01-01','
','http://ccc.de','--- []
','camp-2011-trailer',NULL,'---
- camp2011
','2011-07-20','f',3);
INSERT INTO "events" VALUES(132,'import-70c4ab3f80c7c7f4aa','cccamp11-4491-rethinking_online_news-en.gif','cccamp11-4491-rethinking_online_news-en_preview.jpg',4,'2014-05-10 13:26:12.655449','2014-06-27 06:34:37.76267','Rethinking online news','cccamp11-4491-rethinking_online_news-en.jpg','2011-08-13','Journalism needs hackers to survive.
We present our project to revolutionize online news and encourage you to start your own.
','http://events.ccc.de/camp/2011/Fahrplan/events/4491.en.html','---
- Christopher Clay / c3o
- fin
','cccamp11-4491-rethinking_online_news-en','Journalism needs hackers to survive','---
- camp2011
- '' Society''
','2011-08-21','f',1);
INSERT INTO "events" VALUES(133,'import-68a0bc786541d30fa0','cccamp11-4458-inertial_navigation-en.gif','cccamp11-4458-inertial_navigation-en_preview.jpg',4,'2014-05-10 13:26:12.683944','2014-06-25 08:52:57.203504','Inertial navigation','cccamp11-4458-inertial_navigation-en.jpg','2011-08-11','The motion of objects through space can be observed in everyday life and the analysis of their dynamics leads to a fundamental notion of theoretical mechanics, the rigid body. Inertial navigation is based on continuous measurement of acceleration and angular velocities and the inversion of the rigid body''s equations of motion. Additionally, the modeling of noise and error propagation is essential to correctly estimate position and attitude.
','http://events.ccc.de/camp/2011/Fahrplan/events/4458.en.html','--- []
','cccamp11-4458-inertial_navigation-en','Rigid body dynamics and its application to dead reckoning','---
- camp2011
- '' Hacker Space Program''
','2011-08-12','f',1);
INSERT INTO "events" VALUES(134,'import-688feecb9bc799c478','cccamp11-4455-the-arguna-rocket-family-en.gif','cccamp11-4455-the-arguna-rocket-family-en_preview.jpg',4,'2014-05-10 13:26:12.71226','2014-07-05 17:25:56.125623','The "Arguna" rocket family','cccamp11-4455-the-arguna-rocket-family-en.jpg','2011-08-14','The "Arguna" rocket family consist of four one-stage sounding rockets that can reach altitudes up to 10km. We will present the designs of these rockets and discuss the performed flights and results from avionics experiments.
','http://events.ccc.de/camp/2011/Fahrplan/events/4455.en.html','--- []
','cccamp11-4455-the-arguna-rocket-family-en','An overview of our recent sounding rocket campaigns','---
- camp2011
- " Hacker Space Program"
','2011-08-21','f',1);
INSERT INTO "events" VALUES(135,'import-0090bd639de5cf7498','cccamp11-4459-transition_telecom-en.gif','cccamp11-4459-transition_telecom-en_preview.jpg',4,'2014-05-10 13:26:12.740523','2014-06-27 14:16:44.116466','Transition Telecom','cccamp11-4459-transition_telecom-en.jpg','2011-08-10','We''ll need to come to grips with the challenges that declining oil production and increasing temperatures present. This talk explores positive future scenarios for the world of networking and communications past the great global energy free-for-all.
','http://events.ccc.de/camp/2011/Fahrplan/events/4459.en.html','---
- Frank Rieger
- Rop Gonggrijp
','cccamp11-4459-transition_telecom-en','Telecommunications and networking during energy descent','---
- camp2011
- '' Society''
','2011-10-25','f',5);
INSERT INTO "events" VALUES(136,'import-3b7a6a721fea3ac23d','cccamp11-4591-financing_the_revolution-en.gif','cccamp11-4591-financing_the_revolution-en_preview.jpg',4,'2014-05-10 13:26:12.768785','2014-06-27 01:25:21.107404','Financing The Revolution','cccamp11-4591-financing_the_revolution-en.jpg','2011-08-12','Financing The Revolution is a discussion about digital currencies with a particular emphasis on Bitcoin, a new distributed peer-to-peer electronic currency.  Digital cash and Bitcoin in particular have caused many new and interesting markets to appear, and these are examined as well as the link between economic freedom and the expression of other basic rights.

Keywords: digital cash, cryptography, bitcoin, dgc, darknets, markets, civil liberties
','http://events.ccc.de/camp/2011/Fahrplan/events/4591.en.html','---
- Jeffrey Paul (sneak)
','cccamp11-4591-financing_the_revolution-en','Secure, private value transactions using digital cash','---
- camp2011
- '' Society''
','2011-08-14','f',1);
INSERT INTO "events" VALUES(137,'import-09be6c4dcd22a304d3','cccamp11-4453-stuff_you_dont_see_every_day-en.gif','cccamp11-4453-stuff_you_dont_see_every_day-en_preview.jpg',4,'2014-05-10 13:26:12.796981','2014-06-27 05:06:24.295361','Stuff you don''t see - every day','cccamp11-4453-stuff_you_dont_see_every_day-en.jpg','2011-08-10','Software Defined Radio defines a new approach to analyze signals with software. With the flexibility of software SDR literally opened a new spectrum of hacking. 
','http://events.ccc.de/camp/2011/Fahrplan/events/4453.en.html','---
- Marius Ciepluch
','cccamp11-4453-stuff_you_dont_see_every_day-en','GNU Radio Internals - how to use the Framework','---
- camp2011
- '' Science''
','2011-08-30','f',3);
INSERT INTO "events" VALUES(138,'import-f39d376e3dc40b8826','cccamp11-4495-introduction_to_multicast_security-en.gif','cccamp11-4495-introduction_to_multicast_security-en_preview.jpg',4,'2014-05-10 13:26:12.825006','2014-06-22 13:07:14.79223','Introduction to Multicast Security','cccamp11-4495-introduction_to_multicast_security-en.jpg','2011-08-14','For scaling real time applications multicast transport is the enabling technology. This event will present solutions for multicast security, that can be used for group conferencing and scaling data distribution services as transport layer security. Keywords: SRTP, AES-CM, Keystream, Multimedia Internet KEYing
','http://events.ccc.de/camp/2011/Fahrplan/events/4495.en.html','---
- frehberg
','cccamp11-4495-introduction_to_multicast_security-en','Beyond SSL/TLS','---
- camp2011
- '' Science''
','2011-08-21','f',1);
INSERT INTO "events" VALUES(139,'import-a1179a0b9f7d1fd3d8','cccamp11-4450-imagine_the_future_of_money-en.gif','cccamp11-4450-imagine_the_future_of_money-en_preview.jpg',4,'2014-05-10 13:26:12.853096','2014-07-09 17:36:20.580696','Imagine the Future of Money','cccamp11-4450-imagine_the_future_of_money-en.jpg','2011-08-11','What comes after capitalism? We will give an overview on the development of complementary and alternative monetary systems: Which ones are there to stay, how they influence social development, how they can be improved and why hackers should really care.

','http://events.ccc.de/camp/2011/Fahrplan/events/4450.en.html','---
- Jaromil
- radium
','cccamp11-4450-imagine_the_future_of_money-en','Economic transformations, hacker culture and why we should be so lucky','---
- camp2011
- " Society"
','2011-08-12','f',6);
INSERT INTO "events" VALUES(140,'import-f7fb9bcdd441658463','cccamp11-4439-maching_to_machine_security-en.gif','cccamp11-4439-maching_to_machine_security-en_preview.jpg',4,'2014-05-10 13:26:12.881179','2014-06-22 16:27:58.216496','Machine-to-machine (M2M) security','cccamp11-4439-maching_to_machine_security-en.jpg','2011-08-13','Today, more and more real-world things and machines are equipped with some kind of connection back home to the vendor. Such machine-to-machine (M2M) communication is often poorly secured and some day, the shit will hit the fan!
','http://events.ccc.de/camp/2011/Fahrplan/events/4439.en.html','---
- hunz
','cccamp11-4439-maching_to_machine_security-en','When physical security depends on IT security','---
- camp2011
- '' Hacking''
','2011-08-21','f',1);
INSERT INTO "events" VALUES(141,'import-806d5c23f700a7a18c','cccamp11-4438-mehrseitig_sichere_web_20_umfragen-de.gif','cccamp11-4438-mehrseitig_sichere_web_20_umfragen-de_preview.jpg',4,'2014-05-10 13:26:12.909238','2014-06-27 01:22:04.506615','Dudle','cccamp11-4438-mehrseitig_sichere_web_20_umfragen-de.jpg','2011-08-14','In diesem Vortrag wird eine Web-2.0-Applikation vorgestellt, mit der Umfragen durchgeführt werden können. Im Gegensatz zu anderen Anwendungen muss bei dieser dem Serveradministrator nicht vertraut werden. Die notwendigen kryptographischen Protokolle, welche für die Vertrauensreduktion nötig sind, werden mit JavaScript durchgeführt, was keinerlei clientseitige Installation nötig macht (zero-footprint).
','http://events.ccc.de/camp/2011/Fahrplan/events/4438.en.html','---
- Benjamin Kellermann
','cccamp11-4438-mehrseitig_sichere_web_20_umfragen-de','Mehrseitig sichere Web 2.0-Umfragen','---
- camp2011
- '' Science''
','2011-08-21','f',2);
INSERT INTO "events" VALUES(142,'import-7d63d7d1fa5df84770','cccamp11-4560-post_hacker_ethics_cyberwar-en.gif','cccamp11-4560-post_hacker_ethics_cyberwar-en_preview.jpg',4,'2014-05-10 13:26:12.937294','2014-07-08 16:17:41.727305','Legal, illegal, decentral: Post-hacker-ethics cyberwar','cccamp11-4560-post_hacker_ethics_cyberwar-en.jpg','2011-08-11','Several newly formed hacker groups were in the press, like Anonymous and lulzsec. We will analyze and discuss how these fit into the world, and how the different groups (politics, press, media, hackers) react to this new movement. Set sail for fail!
','http://events.ccc.de/camp/2011/Fahrplan/events/4560.en.html','---
- Hannes
- Jens Ohlig
','cccamp11-4560-post_hacker_ethics_cyberwar-en','Applied loss of control to hacker-ethics?','---
- camp2011
- " Culture"
','2011-08-12','f',4);
INSERT INTO "events" VALUES(143,'import-d13f2e3804b7dc1690','cccamp11-4552-openleaks-en.gif','cccamp11-4552-openleaks-en_preview.jpg',4,'2014-05-10 13:26:12.965486','2014-07-01 21:10:54.397569','OpenLeaks','cccamp11-4552-openleaks-en.jpg','2011-08-10','This talk will introduce the next phase of the OpenLeaks project. We will present a more detailed insight into the project and take you on a tour around the different OL subprojects. We will also announce the activities we are planning for this years camp.
','http://events.ccc.de/camp/2011/Fahrplan/events/4552.en.html','---
- OpenLeaks
','cccamp11-4552-openleaks-en','where leaking meets engineering','---
- camp2011
- " Society"
','2011-08-12','f',1);
INSERT INTO "events" VALUES(144,'import-f37e2ca7a1893fa316','cccamp11-4411-space_debris-en.gif','cccamp11-4411-space_debris-en_preview.jpg',4,'2014-05-10 13:26:12.993993','2014-05-10 13:26:12.993993','Space Debris','cccamp11-4411-space_debris-en.jpg','2011-08-14','This talk is about different sources of space debris and how they are a problem for current and future space travel. I''ll introduce some of the computational models that are used to simulate space debris objects and some ideas to prevent them.
','http://events.ccc.de/camp/2011/Fahrplan/events/4411.en.html','---
- Marek Möckel
','cccamp11-4411-space_debris-en','Simulation of orbital debris and its impacts on space travel','---
- camp2011
- '' Hacker Space Program''
','2011-08-30','f',0);
INSERT INTO "events" VALUES(145,'import-38af0f45219fff06fd','cccamp11-4421-strong_encryption_of_credit_card_information-en.gif','cccamp11-4421-strong_encryption_of_credit_card_information-en_preview.jpg',4,'2014-05-10 13:26:13.107227','2014-06-23 11:03:27.467555','Strong encryption of credit card information','cccamp11-4421-strong_encryption_of_credit_card_information-en.jpg','2011-08-10','The PCI DSS standard require strong cryptography or secure hashing as ways to protect cardholder information. But one important factor is missing; detailed instructions for how to correctly apply cryptography to credit card numbers.
','http://events.ccc.de/camp/2011/Fahrplan/events/4421.en.html','---
- Torbjörn Lofterud
','cccamp11-4421-strong_encryption_of_credit_card_information-en','Attacks on common failures when encrypting credit card information','---
- camp2011
- '' Hacking''
','2011-08-12','f',1);
INSERT INTO "events" VALUES(146,'import-1c1453a65749c731f6','cccamp11-4471-who_is_snitching_my_milk-en.gif','cccamp11-4471-who_is_snitching_my_milk-en_preview.jpg',4,'2014-05-10 13:26:13.137873','2014-06-27 13:16:39.715028','Who''s snitching my milk?','cccamp11-4471-who_is_snitching_my_milk-en.jpg','2011-08-11','Nowadays many office environments offer small tea kitchens for their employees. From subjective experiences there seems to be a milk drain in these environments. However, fundamentel research is still missing.
','http://events.ccc.de/camp/2011/Fahrplan/events/4471.en.html','---
- André Franz
','cccamp11-4471-who_is_snitching_my_milk-en','Nonlinear dynamics/analysis of vanishing bovine products in an office environment.','---
- camp2011
- '' Science''
','2011-08-14','f',3);
INSERT INTO "events" VALUES(147,'import-8fc3552b8dc23b5f8d','cccamp11-4472-hacking_dna-en.gif','cccamp11-4472-hacking_dna-en_preview.jpg',4,'2014-05-10 13:26:13.168101','2014-06-27 02:27:58.992066','Hacking DNA','cccamp11-4472-hacking_dna-en.jpg','2011-08-11','Genetic modification is getting cheaper and biohackers are making it more accessible. This talk outlines the state of DIYbio and institutional synthetic biology; current challenges in biological programming and why you should be hacking biology.
','http://events.ccc.de/camp/2011/Fahrplan/events/4472.en.html','---
- Marc Juul
','cccamp11-4472-hacking_dna-en','Compiling code for living systems','---
- camp2011
- '' Science''
','2011-08-14','f',4);
INSERT INTO "events" VALUES(148,'import-633868694666482e9f','cccamp11-4549-sport_fuer_nerds-en.gif','cccamp11-4549-sport_fuer_nerds-en_preview.jpg',4,'2014-05-10 13:26:13.197439','2014-06-24 11:52:10.149408','Sport für Nerds','cccamp11-4549-sport_fuer_nerds-en.jpg','2011-08-12','Viele von uns sitzen länger vorm Rechner als es ihnen gut tut, irgendwann geht dann die Suche nach einer geeigneten Sportart los …
','http://events.ccc.de/camp/2011/Fahrplan/events/4549.en.html','---
- Michael Schwab
','cccamp11-4549-sport_fuer_nerds-en','discover your body','---
- camp2011
- '' Community''
','2011-08-21','f',2);
INSERT INTO "events" VALUES(149,'import-0d918639428ada8d25','cccamp11-4406-giving_great_workshops-en.gif','cccamp11-4406-giving_great_workshops-en_preview.jpg',4,'2014-05-10 13:26:13.22635','2014-06-24 11:55:36.125131','Giving Great Workshops','cccamp11-4406-giving_great_workshops-en.jpg','2011-08-11','Mitch Altman has taught well over 10,000 people to solder and make cool things at workshops around the world. Drawing from his experiences, this lecture will show you how to create and give your own successful workshops about what you know.
','http://events.ccc.de/camp/2011/Fahrplan/events/4406.en.html','---
- Mitch
','cccamp11-4406-giving_great_workshops-en','You can create your own successful workshop','---
- camp2011
- '' Community''
','2011-08-12','f',1);
INSERT INTO "events" VALUES(150,'import-c6f888938ae607a87c','cccamp11-4502-is_this_the_mobile_gadget_world_we_created-en.gif','cccamp11-4502-is_this_the_mobile_gadget_world_we_created-en_preview.jpg',4,'2014-05-10 13:26:13.254897','2014-06-27 12:02:09.989895','Is this the Mobile Gadget World We Created?','cccamp11-4502-is_this_the_mobile_gadget_world_we_created-en.jpg','2011-08-10','  The most ubiquitous device on the planet is arguably the mobile phone. Tragically, it is also a device built under some of the worst living and working conditions in the world. This is the story of a mission - To build the world''s first ethical phone. 
','http://events.ccc.de/camp/2011/Fahrplan/events/4502.en.html','---
- Bicyclemark
','cccamp11-4502-is_this_the_mobile_gadget_world_we_created-en','The story of the world''s first socially responsible mobile phone.','---
- camp2011
- '' Society''
','2011-08-30','f',1);
INSERT INTO "events" VALUES(151,'import-f3eb0efb1170c03699','cccamp11-4449-digitale_gesellschaft_ev-de.gif','cccamp11-4449-digitale_gesellschaft_ev-de_preview.jpg',4,'2014-05-10 13:26:13.283539','2014-05-10 13:26:13.283539','"Digitale Gesellschaft e.V." ','cccamp11-4449-digitale_gesellschaft_ev-de.jpg','2011-08-11','Im April 2011 wurde mit "Digitale Gesellschaft" ein neuer Verein zum Erhalt und Ausbau von digitalen Bürgerrechten präsentiert. 
','http://events.ccc.de/camp/2011/Fahrplan/events/4449.en.html','---
- Markus Beckedahl
','cccamp11-4449-digitale_gesellschaft_ev-de','Ein neuer Ansatz, um digitale Bürgerrechte zu erhalten','---
- camp2011
- '' Society''
','2011-08-12','f',0);
INSERT INTO "events" VALUES(152,'import-16596d6b5ccd3bc54e','cccamp11-4399-runtine_reconfigurable_processors-en.gif','cccamp11-4399-runtine_reconfigurable_processors-en_preview.jpg',4,'2014-05-10 13:26:13.31238','2014-05-10 13:26:13.31238','Runtime Reconfigurable Processors','cccamp11-4399-runtine_reconfigurable_processors-en.jpg','2011-08-12','The talk will give the audience an introduction to the world of runtime reconfigurable processors.
','http://events.ccc.de/camp/2011/Fahrplan/events/4399.en.html','---
- Dominik Meyer
','cccamp11-4399-runtine_reconfigurable_processors-en',NULL,'---
- camp2011
- '' Science''
','2011-08-14','f',0);
INSERT INTO "events" VALUES(153,'import-4620b76ff7f8dbd8be','cccamp11-4503-ich_und_23-de.gif','cccamp11-4503-ich_und_23-de_preview.jpg',4,'2014-05-10 13:26:13.340807','2014-06-27 05:29:07.998215','Ich und 23','cccamp11-4503-ich_und_23-de.jpg','2011-08-11','Der Vortrag wird zunächst die Grundlagen des DNA-Fingerprinting auf unseren 23 Chromosomenpaaren zusammenfassen. Dabei wird besprochen, wie ein genetischer Fingerabdruck praktisch für die Verwendung in der Forensik entsteht und in welcher Form die Speicherung in einer Datenbank vorgenommen wird. Darauf aufbauend werden Stärken und Risiken der Technologie erörtert.  
','http://events.ccc.de/camp/2011/Fahrplan/events/4503.en.html','---
- Mirko Swillus
','cccamp11-4503-ich_und_23-de','Fingerabdrücke der DNA','---
- camp2011
- '' Science''
','2011-08-12','f',3);
INSERT INTO "events" VALUES(154,'import-270ff2cce2f048ca85','cccamp11-4594-from_oscar_1_to_mars_and_beyond-en.gif','cccamp11-4594-from_oscar_1_to_mars_and_beyond-en_preview.jpg',4,'2014-05-10 13:26:13.369217','2014-06-23 16:51:43.886871','From OSCAR 1 to Mars and beyond','cccamp11-4594-from_oscar_1_to_mars_and_beyond-en.jpg','2011-08-13','Radio amateurs have been building and operating satellites for almost fifty years now, and we are aiming for more.
In this talk, I''ll present who AMSAT is, what we have achieved in the last fifty years, and what we are working on now.
','http://events.ccc.de/camp/2011/Fahrplan/events/4594.en.html','---
- Mario Lorenz
','cccamp11-4594-from_oscar_1_to_mars_and_beyond-en','Amateur Space Exploration – The last 50 years, now, and the future','---
- camp2011
- '' Hacker Space Program''
','2011-08-14','f',1);
INSERT INTO "events" VALUES(155,'import-0b5b1fe8443b7a4274','cccamp11-4506-wie_finanziere_ich_eine_mondmission-de.gif','cccamp11-4506-wie_finanziere_ich_eine_mondmission-de_preview.jpg',4,'2014-05-10 13:26:13.397672','2014-07-09 18:20:09.885438','Wie finanziere ich eine Mondmission?','cccamp11-4506-wie_finanziere_ich_eine_mondmission-de.jpg','2011-08-13','Jeder von uns kennt das Problem: Da hat man ein motiviertes Team an der Hand und einen fertigen Mondrover in der Garage stehen, aber wie immer fehlt das Geld für die Rakete, mit welcher der Rover auf den Mond befördert werden soll!
','http://events.ccc.de/camp/2011/Fahrplan/events/4506.en.html','---
- Robert Böhme
','cccamp11-4506-wie_finanziere_ich_eine_mondmission-de','Von Würstchen verkaufen bis Ballonflüge – ein Erfahrungsbericht.','---
- camp2011
- " Hacker Space Program"
','2011-08-14','f',3);
INSERT INTO "events" VALUES(156,'import-c7e7d888608d4936d1','cccamp11-4561-hacker_jeopardy-en.gif','cccamp11-4561-hacker_jeopardy-en_preview.jpg',4,'2014-05-10 13:26:13.425942','2014-06-27 13:41:44.501865','Hacker Jeopardy','cccamp11-4561-hacker_jeopardy-en.jpg','2011-08-13','The Hacker Jeopardy is a quiz show.
','http://events.ccc.de/camp/2011/Fahrplan/events/4561.en.html','---
- Ray
- Stefan ''Sec'' Zehl
','cccamp11-4561-hacker_jeopardy-en','Number guessing for geeks','---
- camp2011
- '' Misc''
','2011-08-14','f',6);
INSERT INTO "events" VALUES(157,'import-0ac93750a395b0f59f','cccamp11-4478-die_psychologischen_grundlagen_des_social_engineerings-de.gif','cccamp11-4478-die_psychologischen_grundlagen_des_social_engineerings-de_preview.jpg',4,'2014-05-10 13:26:13.453929','2014-07-02 12:22:51.430167','Die psychologischen Grundlagen des Social Engineerings','cccamp11-4478-die_psychologischen_grundlagen_des_social_engineerings-de.jpg','2011-08-11','Dieser Vortrag zeigt, wie Social-Engineering funktioniert und erklärt die zugrundeliegenden Tricks und Kniffe anhand sozialpsychologischer Studien und Experimente. Außerdem werden Beispiele, Warnsignale und Gegenmaßnahmen vorgestellt.
','http://events.ccc.de/camp/2011/Fahrplan/events/4478.en.html','---
- Stefan Schumacher
','cccamp11-4478-die_psychologischen_grundlagen_des_social_engineerings-de',NULL,'---
- camp2011
- " Science"
','2011-08-30','f',9);
INSERT INTO "events" VALUES(158,'import-a3f25884980707cd5c','cccamp11-4488-steal_everything_kill_everyone_cause_financial_ruin-en.gif','cccamp11-4488-steal_everything_kill_everyone_cause_financial_ruin-en_preview.jpg',4,'2014-05-10 13:26:13.482284','2014-07-09 18:18:51.991334','Steal Everything, Kill Everyone, Cause Total Financial Ruin!','cccamp11-4488-steal_everything_kill_everyone_cause_financial_ruin-en.jpg','2011-08-11','This  is not a presentation where I talk about how I would get in or the  things 
I might be able to do. This is a talk where I am already in and I  show you 
pictures from actual engagements that I have been on. 
','http://events.ccc.de/camp/2011/Fahrplan/events/4488.en.html','---
- Jayson E. Street
','cccamp11-4488-steal_everything_kill_everyone_cause_financial_ruin-en','Or: How I walked  in and misbehaved','---
- camp2011
- " Hacking"
','2011-08-12','f',2);
INSERT INTO "events" VALUES(159,'import-ab478ca0d3df4201d0','cccamp11-4389-decentralized_clustering-en.gif','cccamp11-4389-decentralized_clustering-en_preview.jpg',4,'2014-05-10 13:26:13.510367','2014-07-07 22:28:34.043417','Decentralized clustering','cccamp11-4389-decentralized_clustering-en.jpg','2011-08-12','In January 2011 the fear of all internauts became bitter truth. A whole country was kill-switched by the government. The flow of data was interrupted, communication laid waste. Not only the Internets was taken down, other means of communication were interrupted too. Cell Phone  providers took down their services. So, there was no Internets in Egypt. Internauts had no chance to  communicate what is happening, mothers and fathers could not send emails to theire relatives. No data was flowing. As the phone lines were  working, this was the solutions: Modems.
','http://events.ccc.de/camp/2011/Fahrplan/events/4389.en.html','---
- Herr Urbach
','cccamp11-4389-decentralized_clustering-en','Making the net - even if your local dicators hate it!','---
- camp2011
- " Society"
','2011-08-14','f',2);
INSERT INTO "events" VALUES(160,'import-f5bd0d62d5a0979e95','cccamp11-4412-latest_developments_around_the_milkymist_system_on_chip-en.gif','cccamp11-4412-latest_developments_around_the_milkymist_system_on_chip-en_preview.jpg',4,'2014-05-10 13:26:13.538635','2014-07-01 21:59:30.442775','Latest developments around the Milkymist System-on-Chip','cccamp11-4412-latest_developments_around_the_milkymist_system_on_chip-en.jpg','2011-08-11','Milkymist develops a comprehensive solution for the live synthesis of interactive visual effects. It features one of the first open source system-on-chip designs. This talk gives a roundup of what has happened during the last 1.5 year in this project.
','http://events.ccc.de/camp/2011/Fahrplan/events/4412.en.html','---
- Sébastien Bourdeauducq
','cccamp11-4412-latest_developments_around_the_milkymist_system_on_chip-en','A roundup of one the most advanced open hardware projects','---
- camp2011
- " Hacking"
','2011-08-12','f',2);
INSERT INTO "events" VALUES(161,'import-7c76283184078af1b1','cccamp11-4554-closing_event-en.gif','cccamp11-4554-closing_event-en_preview.jpg',4,'2014-05-10 13:26:13.5668','2014-05-10 13:26:13.5668','Closing Event','cccamp11-4554-closing_event-en.jpg','2011-08-14','
','http://events.ccc.de/camp/2011/Fahrplan/events/4554.en.html','--- []
','cccamp11-4554-closing_event-en','Good Bye and have a safe trip home!','---
- camp2011
- '' Misc''
','2011-08-21','f',0);
INSERT INTO "events" VALUES(162,'import-c103a561a60405ea5c','cccamp11-4497-a_short_history_of_ipv4-en.gif','cccamp11-4497-a_short_history_of_ipv4-en_preview.jpg',4,'2014-05-10 13:26:13.679646','2014-06-24 00:20:20.872471','A short history of IPv4','cccamp11-4497-a_short_history_of_ipv4-en.jpg','2011-08-13','A few short weeks ago, APNIC''s supply of IPv4 address space reached depletion. ARIN and the RIPE NCC will follow soon, most likely somewhere this year. In this talk I will discuss the history of the internet as seen from the point of view of the RIRs.
','http://events.ccc.de/camp/2011/Fahrplan/events/4497.en.html','---
- Djinh
','cccamp11-4497-a_short_history_of_ipv4-en',NULL,'---
- camp2011
- '' Hacking''
','2011-08-21','f',1);
INSERT INTO "events" VALUES(163,'import-650754e20b27a3d0c5','cccamp11-4447-hybrid_rocket_engines-en.gif','cccamp11-4447-hybrid_rocket_engines-en_preview.jpg',4,'2014-05-10 13:26:13.709262','2014-07-08 13:02:26.614855','Hybrid rocket engines','cccamp11-4447-hybrid_rocket_engines-en.jpg','2011-08-12','
','http://events.ccc.de/camp/2011/Fahrplan/events/4447.en.html','--- []
','cccamp11-4447-hybrid_rocket_engines-en','Design and implementation of rocket engines with two-phase propellants','---
- camp2011
- " Hacker Space Program"
','2011-08-21','f',12);
INSERT INTO "events" VALUES(164,'import-36dbb5c49c18934cd7','cccamp11-4442-introduction-to-satellite_communications-en.gif','cccamp11-4442-introduction-to-satellite_communications-en_preview.jpg',4,'2014-05-10 13:26:13.738368','2014-05-10 13:26:13.738368','Introduction to Satellite Communications','cccamp11-4442-introduction-to-satellite_communications-en.jpg','2011-08-10','In this lecture, I''ll cover some satellite communication basics like pros and cons of different orbits, the characteristics of a satellite communications link and the difficulties regarding noise and attenuation when handling high frequency satellite communication systems.
','http://events.ccc.de/camp/2011/Fahrplan/events/4442.en.html','---
- Irmi Meister
','cccamp11-4442-introduction-to-satellite_communications-en','the joy and challange of operating satellite communication systems; illustrated with postage stamps','---
- camp2011
- '' Hacker Space Program''
','2011-08-14','f',0);
INSERT INTO "events" VALUES(165,'import-5ca925d47840ae0d48','cccamp11-4492-die-strugazki-brueder-oder-das-homoeostatische-weltbild-de.gif','cccamp11-4492-die-strugazki-brueder-oder-das-homoeostatische-weltbild-de_preview.jpg',4,'2014-05-10 13:26:13.761825','2014-07-05 21:34:38.107002','Die Strugazki-Brüder oder das homöostatische Weltbild','cccamp11-4492-die-strugazki-brueder-oder-das-homoeostatische-weltbild-de.jpg','2011-08-12','Die atomar verstrahlten Ruinen eines ehemaligen Kernkraftwerkes sind Symbole für das bevorstehende Ende der Zivilisation, aber gleichzeitig die Wunschmaschine, die alle Sehnsüchte stillen kann. Dieser Ort ist nicht Fukushima und auch nicht Tschernobyl, sondern der Zielort der Protagonisten im Roman „Picknick am Wegesrand“ der russischen Autorenbrüder Arkadi und Boris Strugazki. 
','http://events.ccc.de/camp/2011/Fahrplan/events/4492.en.html','---
- Agata Królikowski
- Ina  Kwasniewski
- Jens-Martin Loebel
- Kai Kittler
- Marcus Mews
- Marcus  Richter
','cccamp11-4492-die-strugazki-brueder-oder-das-homoeostatische-weltbild-de','Ein audiovisuelles Live-Hörspiel','---
- camp2011
- " Culture"
','2011-08-14','f',2);
INSERT INTO "events" VALUES(166,'import-ec91769597df706720','cccamp11-4588-what_is_brewing_in_brussels-en.gif','cccamp11-4588-what_is_brewing_in_brussels-en_preview.jpg',4,'2014-05-10 13:26:13.790767','2014-05-10 13:26:13.790767','What is brewing in Brussels? ','cccamp11-4588-what_is_brewing_in_brussels-en.jpg','2011-08-11','Right now the European Union is in a bit of a lawmaking frenzy on areas 
that are relevant to the internet in general. 
','http://events.ccc.de/camp/2011/Fahrplan/events/4588.en.html','---
- Walter van Holst
','cccamp11-4588-what_is_brewing_in_brussels-en',NULL,'---
- camp2011
- '' Society''
','2011-08-12','f',0);
INSERT INTO "events" VALUES(167,'import-d63cd6cea16bfd6af0','cccamp11-4424-poker_bots-en.gif','cccamp11-4424-poker_bots-en_preview.jpg',4,'2014-05-10 13:26:13.819436','2014-07-08 13:46:03.258266','Poker bots','cccamp11-4424-poker_bots-en.jpg','2011-08-13','For a few years I was part of a team that developed and ran autonomous poker playing robots on commercial Internet poker sites; playing poker with real money against real people in real time. The project failed...
','http://events.ccc.de/camp/2011/Fahrplan/events/4424.en.html','---
- Torbjörn Lofterud
','cccamp11-4424-poker_bots-en','Developing and running autonomous pokerbots at online casinos','---
- camp2011
- " Science"
','2011-08-14','f',3);
INSERT INTO "events" VALUES(168,'import-007ef07bf3c6b624be','cccamp11-4426-certified_programming_with_dependent_types-en.gif','cccamp11-4426-certified_programming_with_dependent_types-en_preview.jpg',4,'2014-05-10 13:26:13.848076','2014-06-27 13:01:41.449176','Certified programming with dependent types','cccamp11-4426-certified_programming_with_dependent_types-en.jpg','2011-08-12','Dependent types expand the concept of types in programming languages by arbitrary predicates depending on the value of the type. This lecture will introduce the concept and show how it can be used to develop formally verified code.
','http://events.ccc.de/camp/2011/Fahrplan/events/4426.en.html','---
- Andreas Bogk
','cccamp11-4426-certified_programming_with_dependent_types-en','Because the future of defense is liberal application of math','---
- camp2011
- '' Science''
','2011-08-14','f',2);
INSERT INTO "events" VALUES(169,'import-3eee1d460ed0c3da7c','cccamp11-4555-black_ops_of_tcpip_2011-en.gif','cccamp11-4555-black_ops_of_tcpip_2011-en_preview.jpg',4,'2014-05-10 13:26:13.876643','2014-06-30 20:57:16.494582','Black Ops of TCP/IP 2011','cccamp11-4555-black_ops_of_tcpip_2011-en.jpg','2011-08-12','Remember when networks represented interesting targets, when TCP/IP was itself a vector for messiness, when packet crafting was a required skill?
','http://events.ccc.de/camp/2011/Fahrplan/events/4555.en.html','---
- Dan Kaminsky
','cccamp11-4555-black_ops_of_tcpip_2011-en',NULL,'---
- camp2011
- " Hacking"
','2011-08-14','f',2);
INSERT INTO "events" VALUES(170,'import-7592b418458bcc0908','cccamp11-4493-space_federation-en.gif','cccamp11-4493-space_federation-en_preview.jpg',4,'2014-05-10 13:26:13.905334','2014-06-23 19:13:12.015956','Space Federation','cccamp11-4493-space_federation-en.jpg','2011-08-10','Our mission is to provide financial and organizational support to open communities in shared physical spaces who use innovative methods and technology in hands-on education. We''ll speak to the global community about the progress in America.
','http://events.ccc.de/camp/2011/Fahrplan/events/4493.en.html','---
- willowbl00
','cccamp11-4493-space_federation-en','Linking and Launching Earth-Based Hackerspaces','---
- camp2011
- '' Community''
','2011-10-25','f',2);
INSERT INTO "events" VALUES(171,'import-7db8885a836120d0dd','cccamp11-4436-rocket_propulsion_basics-en.gif','cccamp11-4436-rocket_propulsion_basics-en_preview.jpg',4,'2014-05-10 13:26:13.935275','2014-06-27 12:57:55.783137','Rocket propulsion basics','cccamp11-4436-rocket_propulsion_basics-en.jpg','2011-08-10','We will discuss the basic principles of thermochemical engines and their application for rocket propulsion. The three main types of chemical rocket engines, i.e. solid, liquid, and hybrid, will be presented and compared.
','http://events.ccc.de/camp/2011/Fahrplan/events/4436.en.html','--- []
','cccamp11-4436-rocket_propulsion_basics-en','An introduction to rocket engines and their application for space travel','---
- camp2011
- '' Hacker Space Program''
','2011-08-12','f',2);
INSERT INTO "events" VALUES(172,'import-45f24173d01b67a62c','cccamp11-4451-a_modern_manifest_of_cyberspace-en.gif','cccamp11-4451-a_modern_manifest_of_cyberspace-en_preview.jpg',4,'2014-05-10 13:26:13.964389','2014-06-25 07:39:19.911883','A modern manifest of cyberspace','cccamp11-4451-a_modern_manifest_of_cyberspace-en.jpg','2011-08-12','The internet is increasingly falling under the control and restrictions of governments and multinational corporations. Internet connections are filtered and censored, not only in China but blatantly so in ''western'' countries such as Australia and Canada. The content industry is clamping down on infringement on intellectual property and calls for ever more far-fetching and over-reaching laws to be put into effect. Meanwhile, telco''s are making deals with content providers to decide how gets premium access and who gets degraded access to their networks.
','http://events.ccc.de/camp/2011/Fahrplan/events/4451.en.html','---
- gmc
','cccamp11-4451-a_modern_manifest_of_cyberspace-en','The internet is dead, long live the internet','---
- camp2011
- '' Hacker Space Program''
','2011-08-14','f',2);
INSERT INTO "events" VALUES(173,'import-bd84ce27a6c54f674b','cccamp11-4445-data_mining_your_city-en.gif','cccamp11-4445-data_mining_your_city-en_preview.jpg',4,'2014-05-10 13:26:13.993101','2014-05-10 13:26:13.993101','Data Mining Your City','cccamp11-4445-data_mining_your_city-en.jpg','2011-08-14','Philadelphia (USA) recently launched an initiative to open up tons of city records and municipal data.  This talk will review some of the things people are using it for, and show how open city data is useful to many kinds of people.
','http://events.ccc.de/camp/2011/Fahrplan/events/4445.en.html','---
- Steph Alarcon
','cccamp11-4445-data_mining_your_city-en','Early lessons in open city data from Philadelphia, PA, USA','---
- camp2011
- '' Society''
','2011-08-21','f',0);
INSERT INTO "events" VALUES(174,'import-8b9acbb013dda29c4d','cccamp11-4435-windkraftanlagen-de.gif','cccamp11-4435-windkraftanlagen-de_preview.jpg',4,'2014-05-10 13:26:14.022188','2014-07-02 16:13:55.994086','Windkraftanlagen','cccamp11-4435-windkraftanlagen-de.jpg','2011-08-12','Windenergie ist momentan noch interessanter geworden, aber kaum jemand weiß über die eingesetzte Technik Bescheid.
Daher soll sowohl der Aufbau als auch der Betrieb erklärt werden. Zusätzlich wird auf potentielle Probleme eingegangen.
','http://events.ccc.de/camp/2011/Fahrplan/events/4435.en.html','---
- luky
','cccamp11-4435-windkraftanlagen-de','Aufbau, Betrieb, Probleme','---
- camp2011
- " Science"
','2011-08-14','f',5);
INSERT INTO "events" VALUES(175,'import-11a4960b631b325714','cccamp11-4462-counter-lobbying_in_the_eu_parliament-en.gif','cccamp11-4462-counter-lobbying_in_the_eu_parliament-en_preview.jpg',4,'2014-05-10 13:26:14.050766','2014-05-10 13:26:14.050766','Counter-lobbying in the EU Parliament','cccamp11-4462-counter-lobbying_in_the_eu_parliament-en.jpg','2011-08-11','The german access-blocking debate in 2009 only was a prelude to the EU-wide introduction of a blocking infrastructure in the Internet. Only delayed by the Lisbon Treaty compulsory, blocking by all EU-Memberstate has been discussed in the European Parliament since March 2010.
','http://events.ccc.de/camp/2011/Fahrplan/events/4462.en.html','---
- Christian Bahls MOGiS e.V.
- Jérémie Zimmermann
','cccamp11-4462-counter-lobbying_in_the_eu_parliament-en','How citizens can hack the legislative process to protect their freedoms online','---
- camp2011
- '' Society''
','2011-08-14','f',0);
INSERT INTO "events" VALUES(176,'import-17f6892402aad51b39','cccamp11-4486-building_and_giving_away-en.gif','cccamp11-4486-building_and_giving_away-en_preview.jpg',4,'2014-05-10 13:26:14.078966','2014-05-10 13:26:14.078966','Building and Giving Away: Motivations','cccamp11-4486-building_and_giving_away-en.jpg','2011-08-10','What motivates people to create and freely distribute their works?  This presentation will draw on personal experience, research literature, and existing communities of those who build and give away.  Open source software, hardware, community building.
','http://events.ccc.de/camp/2011/Fahrplan/events/4486.en.html','---
- Greg Newby
','cccamp11-4486-building_and_giving_away-en',NULL,'---
- camp2011
- '' Culture''
','2011-08-30','f',0);
INSERT INTO "events" VALUES(177,'import-edbff5e15d6cf3f558','cccamp11-4505-strahlung_im_weltall-de.gif','cccamp11-4505-strahlung_im_weltall-de_preview.jpg',4,'2014-05-10 13:26:14.107146','2014-07-01 21:17:28.416641','Strahlung im Weltall','cccamp11-4505-strahlung_im_weltall-de.jpg','2011-08-10','Wer eine Mission zum Mond plant, muss sich über das, was die Umgebung dort bereithält, Gedanken machen. Neben Temperaturen von -180 bis +120° C ist Strahlung eine der größten Herausforderungen bei einer derartigen Mission. So genannte Single Event Upsets (SEU) können in einer Speicherzelle Datenbits flippen. Mit diesen umgekippten Bits muss man dann zurechtkommen. 
','http://events.ccc.de/camp/2011/Fahrplan/events/4505.en.html','---
- Karsten Becker
','cccamp11-4505-strahlung_im_weltall-de','Hell yeah, it''s radiation science!','---
- camp2011
- " Hacker Space Program"
','2011-08-30','f',1);
INSERT INTO "events" VALUES(178,'import-3fd66cad1f5c12c6c5','cccamp11-4589-a_brief_history_of_european_internet_surveillance_policy_and_what_maybe_next-en.gif','cccamp11-4589-a_brief_history_of_european_internet_surveillance_policy_and_what_maybe_next-en_preview.jpg',4,'2014-05-10 13:26:14.13514','2014-05-10 13:26:14.13514','tbd','cccamp11-4589-a_brief_history_of_european_internet_surveillance_policy_and_what_maybe_next-en.jpg','2011-08-13','
','http://events.ccc.de/camp/2011/Fahrplan/events/4589.en.html','---
- Caspar Bowden
','cccamp11-4589-a_brief_history_of_european_internet_surveillance_policy_and_what_maybe_next-en',NULL,'---
- camp2011
','2011-10-25','f',0);
INSERT INTO "events" VALUES(179,'import-8e9a990e63e7630ea6','cccamp11-4466-rocket_telemetry-en.gif','cccamp11-4466-rocket_telemetry-en_preview.jpg',4,'2014-05-10 13:26:14.163175','2014-05-10 13:26:14.163175','Telemetry ','cccamp11-4466-rocket_telemetry-en.jpg','2011-08-13','Retrieval of information is essential for every experiment, especially involving rockets. The use of electromagnetic waves is the natural choice for communication with a rocket and sometimes the only means to retrieve flight hardware afterwards.
','http://events.ccc.de/camp/2011/Fahrplan/events/4466.en.html','--- []
','cccamp11-4466-rocket_telemetry-en','Real-time communication during rocket flight','---
- camp2011
- '' Hacker Space Program''
','2011-08-30','f',0);
INSERT INTO "events" VALUES(180,'import-20ec8bc95ec75582c5','cccamp11-4490-ios_application_security-en.gif','cccamp11-4490-ios_application_security-en_preview.jpg',4,'2014-05-10 13:26:14.277474','2014-05-10 13:26:14.277474','iOS application security','cccamp11-4490-ios_application_security-en.jpg','2011-08-11','Over the last few years there has been a signifant amount of iPhone and iPad application development going on. Although based on Mac OSX, its development APIs are new and very specific to the iPhone and iPad. In this presentation, Ilja van Sprundel, Principal Security Consultant at IOActive, will discuss lessons learned from auditing iPhone and iPad applications over the last year.
','http://events.ccc.de/camp/2011/Fahrplan/events/4490.en.html','---
- Ilja van Sprundel
','cccamp11-4490-ios_application_security-en','A look at the security of 3rd party iOS applications','---
- camp2011
- '' Hacking''
','2011-08-12','f',0);
INSERT INTO "events" VALUES(181,'import-fed39f34a5140121e2','cccamp11-4496-applied_research_on_security_of_tetra_radio.gif','cccamp11-4496-applied_research_on_security_of_tetra_radio_preview.jpg',4,'2014-05-10 13:26:14.307246','2014-07-11 20:14:56.771952','Applied Research on security of TETRA radio','cccamp11-4496-applied_research_on_security_of_tetra_radio.jpg','2011-08-12','The digital professional mobile radio system TETRA is used by a wide range of users in almost all continents of the world.  

The OsmocomTETRA project has created a software radio receiver for the TETRA air interface, similar to what airprobe has done for GSM.  Using this receiver plus associated protocol analysis tools, we are able to investigate and research the security level of real-world TETRA networks.
','http://events.ccc.de/camp/2011/Fahrplan/events/4496.en.html','---
- Harald Welte
','cccamp11-4496-applied_research_on_security_of_tetra_radio','digital radio technology beyond GSM','---
- camp2011
- " Hacking"
','2011-10-25','f',17);
INSERT INTO "events" VALUES(182,'import-497340474d79188668','cccamp11-4575-mursat-en.gif','cccamp11-4575-mursat-en_preview.jpg',4,'2014-05-10 13:26:14.330588','2014-06-23 20:10:16.811633','mur.sat','cccamp11-4575-mursat-en.jpg','2011-08-13','In 2011, mur.at will have a nano satellite launched into a low earth orbit (310 km above the surface of our planet). The satellite itself is the evolved descendant of a TubeSat personal satellite kit from Interorbital Systems. mur.sat is a joint venture of mur.at, ESC im Labor and realraum.
','http://events.ccc.de/camp/2011/Fahrplan/events/4575.en.html','---
- Bernhard Tittelbach
- equinox
','cccamp11-4575-mursat-en','A (Hacker) Space Art Project','---
- camp2011
- '' Hacker Space Program''
','2011-08-21','f',2);
INSERT INTO "events" VALUES(183,'import-a42b249d723fec36d7','cccamp11-4429-life_foods-en.gif','cccamp11-4429-life_foods-en_preview.jpg',4,'2014-05-10 13:26:14.359457','2014-05-10 13:26:14.359457','Life foods','cccamp11-4429-life_foods-en.jpg','2011-08-11','The regular consumption of life foods was very important for healthy life style thousands years ago and the same applies for today. The use of today''s scientific knowledge in combination with current technology will allow us to optimise these techniques.
','http://events.ccc.de/camp/2011/Fahrplan/events/4429.en.html','--- []
','cccamp11-4429-life_foods-en','Benefits of use of microbial fermentations in food and beverage preparations.','---
- camp2011
- '' Hacker Space Program''
','2011-08-12','f',0);
INSERT INTO "events" VALUES(184,'import-a45285245f6fde2743','cccamp11-4443-theres_gold_in_them_circuit_boards-en.gif','cccamp11-4443-theres_gold_in_them_circuit_boards-en_preview.jpg',4,'2014-05-10 13:26:14.388177','2014-07-11 00:09:03.754521','There''s Gold in Them Circuit Boards','cccamp11-4443-theres_gold_in_them_circuit_boards-en.jpg','2011-08-13','Everything we do as technologists depends on the critical minerals from which our devices are made.  Recycling junk electronics is no longer just the right thing to do, it''s the smart thing to do.
','http://events.ccc.de/camp/2011/Fahrplan/events/4443.en.html','---
- Steph Alarcon
','cccamp11-4443-theres_gold_in_them_circuit_boards-en','Why E-Waste Recycling Is Smart and How To Make It Smarter','---
- camp2011
- " Society"
','2011-08-21','f',2);
INSERT INTO "events" VALUES(185,'import-c09aabf3b80f40f452','cccamp11-4504-gprs_intercept-en.gif','cccamp11-4504-gprs_intercept-en_preview.jpg',4,'2014-05-10 13:26:14.416942','2014-06-27 13:06:41.508711','GPRS Intercept','cccamp11-4504-gprs_intercept-en.jpg','2011-08-10','GPRS data networks provide the backbone for our mobile society. Just like their siblings, GSM networks, the GPRS infrastructure is often lacking an appropriate level of protection.
','http://events.ccc.de/camp/2011/Fahrplan/events/4504.en.html','---
- Karsten Nohl
- Luca Melette
','cccamp11-4504-gprs_intercept-en','Wardriving phone networks','---
- camp2011
- '' Hacking''
','2011-08-30','f',3);
INSERT INTO "events" VALUES(186,'import-2be6c01f6313e173fe','cccamp11-4440-solid_rocket_engines-en.gif','cccamp11-4440-solid_rocket_engines-en_preview.jpg',4,'2014-05-10 13:26:14.445787','2014-07-08 19:21:56.865056','Solid rocket engines','cccamp11-4440-solid_rocket_engines-en.jpg','2011-08-11','We will present the design and construction of a solid rocket motor and discuss results from recent test campaigns.
','http://events.ccc.de/camp/2011/Fahrplan/events/4440.en.html','--- []
','cccamp11-4440-solid_rocket_engines-en','Design and implementation of engines with solid propellant','---
- camp2011
- " Hacker Space Program"
','2011-08-12','f',5);
INSERT INTO "events" VALUES(187,'import-294b8bec99b645a668','cccamp11-4564-r0ket-en.gif','cccamp11-4564-r0ket-en_preview.jpg',4,'2014-05-10 13:26:14.474931','2014-07-02 12:46:36.966575','r0ket','cccamp11-4564-r0ket-en.jpg','2011-08-10','The r0ket is the badge for the Chaos Communication Camp 2011.
','http://events.ccc.de/camp/2011/Fahrplan/events/4564.en.html','---
- kiu
- s
- Stefan ''Sec'' Zehl
','cccamp11-4564-r0ket-en','The CCC-Badge','---
- camp2011
- " Hacking"
','2011-08-12','f',5);
INSERT INTO "events" VALUES(188,'import-2a8e4a552f6bcde4d8','cccamp11-4476-open_source_photovoltaics-en.gif','cccamp11-4476-open_source_photovoltaics-en_preview.jpg',4,'2014-05-10 13:26:14.503784','2014-05-10 13:26:14.503784','Open source photovoltaics','cccamp11-4476-open_source_photovoltaics-en.jpg','2011-08-13','Opensource-solar.org is working on open hardware power supplies for off-grid applications. The systems consist of self-build solar panels, charge controllers with microcontroller, and LiFePo4 rechargeable batteries. Green energy for your gadgets !
','http://events.ccc.de/camp/2011/Fahrplan/events/4476.en.html','---
- Moritz von Buttlar
','cccamp11-4476-open_source_photovoltaics-en','power for off-grid devices','---
- camp2011
- '' Hacker Space Program''
','2011-08-21','f',0);
INSERT INTO "events" VALUES(189,'import-ecb1be5734be0ea265','cccamp11-4494-laptop_and_electronics_searches_at_the_us_border-en.gif','cccamp11-4494-laptop_and_electronics_searches_at_the_us_border-en_preview.jpg',4,'2014-05-10 13:26:14.532287','2014-07-01 20:43:18.114417','Laptop and Electronics Searches at the U.S. Border','cccamp11-4494-laptop_and_electronics_searches_at_the_us_border-en.jpg','2011-08-14','The Electronic Frontier Foundation will discuss the legal situation that international travelers face when entering or leaving the United States, as well as various ways that travelers can safeguard electronic devices and digital information at the border.
','http://events.ccc.de/camp/2011/Fahrplan/events/4494.en.html','---
- Seth Schoen
','cccamp11-4494-laptop_and_electronics_searches_at_the_us_border-en','A Privacy Guide for Travelers','---
- camp2011
- " Society"
','2011-08-21','f',1);
INSERT INTO "events" VALUES(190,'import-5c46e7826f881f2e04','cccamp11-4395-counselling_mischief_as_thought_crime-en.gif','cccamp11-4395-counselling_mischief_as_thought_crime-en_preview.jpg',4,'2014-05-10 13:26:14.560632','2014-05-10 13:26:14.560632','Counselling Mischief as Thought Crime','cccamp11-4395-counselling_mischief_as_thought_crime-en.jpg','2011-08-12','This presentation will show how the RCMP, CSIS, CSEC and other groups worked to "secure" the 2010 Olympics, G8 and G20 by criminalising dissent, and the use of "Open Source Surveillance" to attempt to crack down on all opposition to these mega-events.
','http://events.ccc.de/camp/2011/Fahrplan/events/4395.en.html','---
- Joe
','cccamp11-4395-counselling_mischief_as_thought_crime-en','Social Networks, Free Speech and the Criminalization of Dissent in Canada ','---
- camp2011
- '' Society''
','2011-08-14','f',0);
INSERT INTO "events" VALUES(653,'import-d15d911a6596734a37','saal_mp7_og_-_2013-07-06_19:00_-_game_of_drones_i_ii_-_mark_-_5064.gif','saal_mp7_og_-_2013-07-06_19:00_-_game_of_drones_i_ii_-_mark_-_5064_preview.jpg',19,'2014-05-10 13:26:28.079438','2014-06-25 21:07:47.142425','Game of Drones I + II','saal_mp7_og_-_2013-07-06_19:00_-_game_of_drones_i_ii_-_mark_-_5064.jpg','2013-07-06','Roboter, die Menschen töten? Vor einigen Jahrzehnten noch als Sci-Fi belächelt, ist es längst Alltag im mittleren Osten. Drohnen bevölkern den Himmel und verdrängen mehr und mehr die herkömmliche Kriegsführung. Doch wie sauber und ethisch ist diese Kriegsführung? 
','https://sigint.ccc.de/schedule/events/5064.html','---
- Mark
','saal_mp7_og_-_2013-07-06_19:00_-_game_of_drones_i_ii_-_mark_-_5064',NULL,'---
- sigint13
- '' Politics''
','2013-07-22','f',2);
INSERT INTO "events" VALUES(654,'import-ab016bd5cd9892b4f5','saal_mp7_og_-_2013-07-07_14:00_-_analog_computing_-_bernd_ulmann_-_5056.gif','saal_mp7_og_-_2013-07-07_14:00_-_analog_computing_-_bernd_ulmann_-_5056_preview.jpg',19,'2014-05-10 13:26:28.207835','2014-06-26 18:00:14.032216','Analog Computing','saal_mp7_og_-_2013-07-07_14:00_-_analog_computing_-_bernd_ulmann_-_5056.jpg','2013-07-07','Analog computing has been largely forgotten and only few analog computers survived in various collections. This is a pity since the basic ideas of analog computers in conjunction with modern technologies like FPGAs and the like may offer a path to low power high performance computing.
','https://sigint.ccc.de/schedule/events/5056.html','---
- Bernd Ulmann
','saal_mp7_og_-_2013-07-07_14:00_-_analog_computing_-_bernd_ulmann_-_5056','High performance/low power computing based on the analog computing paradigm.','---
- sigint13
- '' Hacking''
','2013-07-22','f',3);
INSERT INTO "events" VALUES(655,'import-016622512f1824d52c','konferenz_mp6_og_-_2013-07-06_20:00_-_hpfriends_real-time_social_data-sharing_-_mark_schloesser_-_johannes_gilger_-_5070.gif','konferenz_mp6_og_-_2013-07-06_20:00_-_hpfriends_real-time_social_data-sharing_-_mark_schloesser_-_johannes_gilger_-_5070_preview.jpg',19,'2014-05-10 13:26:28.237966','2014-07-04 15:30:18.097769','hpfriends: real-time social data-sharing','konferenz_mp6_og_-_2013-07-06_20:00_-_hpfriends_real-time_social_data-sharing_-_mark_schloesser_-_johannes_gilger_-_5070.jpg','2013-07-06','Within the Honeynet Project we have used a custom publish/subscribe protocol called "hpfeeds" for sharing live data feeds from honeypots within the group. In 2012 we worked on a new backend with a new sharing and authorization model called "hpfriends". This combines the hpfeeds protocol with social trust relations to grant people access to feeds. This talk presents the protocol and system, which in our vision could enable simple and natural data sharing for the whole security community.
','https://sigint.ccc.de/schedule/events/5070.html','---
- Mark Schloesser
- Johannes Gilger
','konferenz_mp6_og_-_2013-07-06_20:00_-_hpfriends_real-time_social_data-sharing_-_mark_schloesser_-_johannes_gilger_-_5070','publish-subscribe feeds + trust relationship network','---
- sigint13
- " Hacking"
','2013-07-22','f',4);
INSERT INTO "events" VALUES(656,'import-be8c7f62fda931eaa6','konferenz_mp6_og_-_2013-07-05_17:00_-_car_immobilizer_hacking_-_karsten_nohl_-_5034.gif','konferenz_mp6_og_-_2013-07-05_17:00_-_car_immobilizer_hacking_-_karsten_nohl_-_5034_preview.jpg',19,'2014-05-10 13:26:28.267757','2014-07-11 14:03:29.349727','Car immobilizer hacking','konferenz_mp6_og_-_2013-07-05_17:00_-_car_immobilizer_hacking_-_karsten_nohl_-_5034.jpg','2013-07-05','Car manufacturers nicely illustrate what _not_ to do in cryptography.
','https://sigint.ccc.de/schedule/events/5034.html','---
- Karsten Nohl
','konferenz_mp6_og_-_2013-07-05_17:00_-_car_immobilizer_hacking_-_karsten_nohl_-_5034',NULL,'---
- sigint13
- " Hacking"
','2013-07-22','f',20);
INSERT INTO "events" VALUES(657,'import-a4e46602a0e417b76b','saal_mp7_og_-_2013-07-05_12:00_-_adblocker_an_schranke_runter_paywall_hoch_-_katharina_borchert_-_stefan_plochinger_-_jochen_wegner_-_jens_ihlenfeld_-_geraldine_de_bastion_-_5093.gif','saal_mp7_og_-_2013-07-05_12:00_-_adblocker_an_schranke_runter_paywall_hoch_-_katharina_borchert_-_stefan_plochinger_-_jochen_wegner_-_jens_ihlenfeld_-_geraldine_de_bastion_-_5093_preview.jpg',19,'2014-05-10 13:26:28.297058','2014-07-12 04:55:56.88694','Adblocker an, Schranke runter, Paywall hoch?','saal_mp7_og_-_2013-07-05_12:00_-_adblocker_an_schranke_runter_paywall_hoch_-_katharina_borchert_-_stefan_plochinger_-_jochen_wegner_-_jens_ihlenfeld_-_geraldine_de_bastion_-_5093.jpg','2013-07-05','
','https://sigint.ccc.de/schedule/events/5093.html','---
- Katharina Borchert
- Stefan Plöchinger
- Jochen Wegner
- Jens Ihlenfeld
- Geraldine de Bastion
','saal_mp7_og_-_2013-07-05_12:00_-_adblocker_an_schranke_runter_paywall_hoch_-_katharina_borchert_-_stefan_plochinger_-_jochen_wegner_-_jens_ihlenfeld_-_geraldine_de_bastion_-_5093','Der Hindernislauf um die Bezahlung von Onlinejournalisten','---
- sigint13
- " Society"
','2013-07-22','f',4);
INSERT INTO "events" VALUES(658,'import-e8c6d414f23a3f454d','konferenz_mp6_og_-_2013-07-06_11:00_-_the_step_into_cyborgism_-_ennomane_-_5082.gif','konferenz_mp6_og_-_2013-07-06_11:00_-_the_step_into_cyborgism_-_ennomane_-_5082_preview.jpg',19,'2014-05-10 13:26:28.32663','2014-07-07 19:48:32.898273','The step into Cyborgism','konferenz_mp6_og_-_2013-07-06_11:00_-_the_step_into_cyborgism_-_ennomane_-_5082.jpg','2013-07-06','Die ersten echten Cyborgs sind unter uns - Menschen, die ihre Fähigkeiten und Sinne mit Implantaten oder technischen Geräten erweitern, die sie als Teil ihres Körpers empfinden. Das zieht einen Rattenschwanz an technischen, gesellschaftlichen und ethischen Fragestellungen nach sich.
','https://sigint.ccc.de/schedule/events/5082.html','---
- ennomane
','konferenz_mp6_og_-_2013-07-06_11:00_-_the_step_into_cyborgism_-_ennomane_-_5082','Die ersten echten Cyborgs sind da','---
- sigint13
- " Society"
','2013-07-22','f',11);
INSERT INTO "events" VALUES(659,'import-e7676147212bb1dcca','vortrag_mp6_og_-_2013-07-07_16:00_-_through_the_google_glass_and_what_malice_found_there_-_tante_-_5048.gif','vortrag_mp6_og_-_2013-07-07_16:00_-_through_the_google_glass_and_what_malice_found_there_-_tante_-_5048_preview.jpg',19,'2014-05-10 13:26:28.355661','2014-07-09 22:45:16.656734','Through the Google Glass and what Malice Found There','vortrag_mp6_og_-_2013-07-07_16:00_-_through_the_google_glass_and_what_malice_found_there_-_tante_-_5048.jpg','2013-07-07','The cry for regulation come with every new technology or use of data. I believe that instead of focusing on specific products we need to develop a consistent pattern that we can apply to new ideas and technologies. I''ll describe such an approach based on historic examples and the basic properties of data and technology.
','https://sigint.ccc.de/schedule/events/5048.html','---
- tante
','vortrag_mp6_og_-_2013-07-07_16:00_-_through_the_google_glass_and_what_malice_found_there_-_tante_-_5048','regulating technology and data use','---
- sigint13
- " Society"
','2013-07-22','f',8);
INSERT INTO "events" VALUES(660,'import-7811eb0beca6794929','konferenz_mp6_og_-_2013-07-06_15:00_-_e-mobility_as_a_privacy_game_changer_-_tilman_frosch_-_5068.gif','konferenz_mp6_og_-_2013-07-06_15:00_-_e-mobility_as_a_privacy_game_changer_-_tilman_frosch_-_5068_preview.jpg',19,'2014-05-10 13:26:28.384647','2014-06-26 19:08:54.796569','E-Mobility as a Privacy Game Changer','konferenz_mp6_og_-_2013-07-06_15:00_-_e-mobility_as_a_privacy_game_changer_-_tilman_frosch_-_5068.jpg','2013-07-06','Electric vehicles (EVs) are becoming increasingly popular, especially since we need alternatives to cars powered by fuel. Electric mobility will be a privacy game changer. Even a quick charging cycle of an EV takes about 30 minutes for a full charge today, the current infrastructure of gas stations is no longer feasible. Instead a widely distributed network of charging stations is being built. Overly simplified, lithium-ion-based batteries have two states to be avoided: completely charged and completely discharged. Thus, customers are encouraged to plug-in where ever they park their car. This behavior is also supported by a feeling aptly named ''range anxiety''. The worrying side-effect of this change in how we refuel cars is that suddenly this process becomes observable: while today everyone can pay cash at a gas station and expect a reasonable amount of anonymity, charging of EVs changes the rules significantly and enables an observer to track where a user charges her car and thus allows for the creation of quite detailed movement profiles. The talk proposes a solution that protects the user''s location privacy and is practical enough to be actually implemented.
','https://sigint.ccc.de/schedule/events/5068.html','---
- Tilman Frosch
','konferenz_mp6_og_-_2013-07-06_15:00_-_e-mobility_as_a_privacy_game_changer_-_tilman_frosch_-_5068',NULL,'---
- sigint13
- '' Society''
','2013-07-22','f',1);
INSERT INTO "events" VALUES(661,'import-8db59317eeb77a0f6c','saal_mp7_og_-_2013-07-06_12:00_-_eu_data_protection_reform_-_achim_klabunde_-_5081.gif','saal_mp7_og_-_2013-07-06_12:00_-_eu_data_protection_reform_-_achim_klabunde_-_5081_preview.jpg',19,'2014-05-10 13:26:28.413544','2014-07-05 20:58:18.831499','EU Data Protection Reform','saal_mp7_og_-_2013-07-06_12:00_-_eu_data_protection_reform_-_achim_klabunde_-_5081.jpg','2013-07-06','Since January 2012, Members of European Parliament and governments of EU countries have been discussing a proposal by the European Commission to modernise EU data protection rules. Both the Parliament and the governments (acting as the Council of Ministers) want to define their respective positions in June and then start to negotiate with each other. The outcome will directly affect privacy of citizens in more than 30 countries. The talk will highlight the state of procedure, the objectives of both sides and the expected next steps.
','https://sigint.ccc.de/schedule/events/5081.html','---
- Achim Klabunde
','saal_mp7_og_-_2013-07-06_12:00_-_eu_data_protection_reform_-_achim_klabunde_-_5081','State of play before negotiations','---
- sigint13
- " Politics"
','2013-07-22','f',1);
INSERT INTO "events" VALUES(662,'import-080f507b93b240a5d0','saal_mp7_og_-_2013-07-07_16:00_-_revolution_in_military_affairs_--_why_computer_professionals_should_be_concerned_-_dietrich_rik_meyer-ebrecht_-_hans-jorg_kreowski_-_5076.gif','saal_mp7_og_-_2013-07-07_16:00_-_revolution_in_military_affairs_--_why_computer_professionals_should_be_concerned_-_dietrich_rik_meyer-ebrecht_-_hans-jorg_kreowski_-_5076_preview.jpg',19,'2014-05-10 13:26:28.442754','2014-07-04 21:44:25.394441','„Revolution in Military Affairs“ -- Why computer professionals should be concerned','saal_mp7_og_-_2013-07-07_16:00_-_revolution_in_military_affairs_--_why_computer_professionals_should_be_concerned_-_dietrich_rik_meyer-ebrecht_-_hans-jorg_kreowski_-_5076.jpg','2013-07-07','We will discuss the essential and disconcerting role of information and communication technology (ICT) in the current military doctrines and strategies spoken of as the ''Revolution in Military Affairs'' or RMA. We will draw the line from the origin of computers as a genuine dual-use technology towards today''s amalgamation of civil and military technologies and its implications for computer professionals.
','https://sigint.ccc.de/schedule/events/5076.html','---
- Dietrich ''Rik'' Meyer-Ebrecht
- Hans-Jörg Kreowski
','saal_mp7_og_-_2013-07-07_16:00_-_revolution_in_military_affairs_--_why_computer_professionals_should_be_concerned_-_dietrich_rik_meyer-ebrecht_-_hans-jorg_kreowski_-_5076',NULL,'---
- sigint13
- " Politics"
','2013-07-22','f',3);
INSERT INTO "events" VALUES(663,'import-b698bd8cf5e4d19ef1','vortrag_mp6_og_-_2013-07-05_16:00_-_remote_exploits_fur_die_briefwahl_in_deutschland_-_arnim_-_5104.gif','vortrag_mp6_og_-_2013-07-05_16:00_-_remote_exploits_fur_die_briefwahl_in_deutschland_-_arnim_-_5104_preview.jpg',19,'2014-05-10 13:26:28.471823','2014-06-26 15:12:24.833776','Remote Exploits für die Briefwahl in Deutschland','vortrag_mp6_og_-_2013-07-05_16:00_-_remote_exploits_fur_die_briefwahl_in_deutschland_-_arnim_-_5104.jpg','2013-07-05','Der Vortrag zeigt praxisnah die komplette "Eigenherstellung" der deutschen Briefwahlunterlagen, inklusive der Stimmzettel, Wahlscheine, Stimmzettel- und Wahlbriefumschläge. Durch die Abschaffung fast aller Sicherungsmerkmale der Briefwahl wäre so ein Wahlbetrug nicht mehr zu erkennen.
','https://sigint.ccc.de/schedule/events/5104.html','---
- arnim
','vortrag_mp6_og_-_2013-07-05_16:00_-_remote_exploits_fur_die_briefwahl_in_deutschland_-_arnim_-_5104','Seit der Abschaffung der Sicherungsmechanismen ist die Briefwahl sogar leichter manipulierbar als Nedap Wahlcomputer','---
- sigint13
- '' Politics''
','2013-07-22','f',2);
INSERT INTO "events" VALUES(664,'import-70c200884c5a8b15b6','saal_mp7_og_-_2013-07-07_15:00_-_how_to_wiretap_the_cloud_without_anybody_noticing_-_caspar_bowden_-_5088.gif','saal_mp7_og_-_2013-07-07_15:00_-_how_to_wiretap_the_cloud_without_anybody_noticing_-_caspar_bowden_-_5088_preview.jpg',19,'2014-05-10 13:26:28.500488','2014-07-09 04:31:26.076857','How  to wiretap the Cloud without anybody noticing','saal_mp7_og_-_2013-07-07_15:00_-_how_to_wiretap_the_cloud_without_anybody_noticing_-_caspar_bowden_-_5088.jpg','2013-07-07','Whatever happens next in the reform of EU Data Protection law, many Europeans will have little practical alternative to using US Cloud services, and businesses and governments will also be sending personal data into US Clouds without individuals'' consent. The talk will explain why all data sent into Clouds outside Europe is at risk of purely political mass-surveillance, and that the EU Commission and many Data Protection Authorities know this but turn a blind-eye, and a law that is much worse than the notorious PATRIOT Act (if you are not American) but few people have ever heard of.
','https://sigint.ccc.de/schedule/events/5088.html','---
- Caspar Bowden
','saal_mp7_og_-_2013-07-07_15:00_-_how_to_wiretap_the_cloud_without_anybody_noticing_-_caspar_bowden_-_5088','The US Foreign Intelligence Surveillance Amendment Act and implications for the new DP Regulation','---
- sigint13
- " Politics"
','2013-07-22','f',7);
INSERT INTO "events" VALUES(665,'import-8599186bac1618fad5','konferenz_mp6_og_-_2013-07-06_14:00_-_der_kampf_um_die_netzneutralitat_-_markus_beckedahl_-_5054.gif','konferenz_mp6_og_-_2013-07-06_14:00_-_der_kampf_um_die_netzneutralitat_-_markus_beckedahl_-_5054_preview.jpg',19,'2014-05-10 13:26:28.529483','2014-07-06 22:56:15.623026','Der Kampf um die Netzneutralität ','konferenz_mp6_og_-_2013-07-06_14:00_-_der_kampf_um_die_netzneutralitat_-_markus_beckedahl_-_5054.jpg','2013-07-06','
Die Debatte um Netzneutralität dümpelte die vergangenen Jahr in Deutschland etwas vor sich hin. Zwar diskriminieren große Telkos wie Vodafone und T-Mobile in zahlreichen Tarifen bereits Services, aber das wurde von Politik und Öffentlichkeit nicht als Problem angesehen. Im April 2013 änderte sich die Debatte schlagartig als die Deutsche Telekom verbunden mit einem Tarifwechsel einerseits die Abschaffung von Flatrates und andererseits den Einstieg in den Ausstieg aus der Netzneutralität im Kabelnetz verkündete. Fortan werden Inhalte der Deutschen Telekom und ihrer Partner gegenüber der Konkurrenz benachteiligt. Ist das ein Problem?

Der Vortrag will einen Überblick über die Debatte, ihre Player, Interessen und Positionen geben. Und dazu einen Ein- und Ausblick in die Proteste für den Erhalt eines offenen und echten Netzes.
','https://sigint.ccc.de/schedule/events/5054.html','---
- Markus Beckedahl
','konferenz_mp6_og_-_2013-07-06_14:00_-_der_kampf_um_die_netzneutralitat_-_markus_beckedahl_-_5054','Is this the end of the internet as we know it?','---
- sigint13
- " Politics"
','2013-07-22','f',6);
INSERT INTO "events" VALUES(666,'import-96a9a004b788c32b05','konferenz_mp6_og_-_2013-07-06_21:00_-_docpatch_entdecke_unsere_verfassung_-_ben_-_5092.gif','konferenz_mp6_og_-_2013-07-06_21:00_-_docpatch_entdecke_unsere_verfassung_-_ben_-_5092_preview.jpg',19,'2014-05-10 13:26:28.557984','2014-07-11 13:53:54.285291','DocPatch: Entdecke unsere Verfassung!','konferenz_mp6_og_-_2013-07-06_21:00_-_docpatch_entdecke_unsere_verfassung_-_ben_-_5092.jpg','2013-07-06','Die Open-Data-Plattform DocPatch ermöglicht das Nachvollziehen aller Änderungen am Grundgesetz für die Bundesrepublik Deutschland seit seinem Inkrafttreten im Jahr 1949. In diesem Vortrag stellt der Chaospott Essen vor, wie spaßig und mühsam der Weg bis zur Veröffentlichung gewesen ist und in welche Richtung es weitergehen kann.
','https://sigint.ccc.de/schedule/events/5092.html','---
- Ben
','konferenz_mp6_og_-_2013-07-06_21:00_-_docpatch_entdecke_unsere_verfassung_-_ben_-_5092','Mit der Open-Data-Plattform DocPatch das Grundgesetz versionieren','---
- sigint13
- " Politics"
','2013-07-22','f',5);
INSERT INTO "events" VALUES(667,'import-25509fe84cbf4fbd03','konferenz_mp6_og_-_2013-07-06_17:00_-_independents_unite_inside_the_freelancers_movement_-_joel_dullroy_-_5038.gif','konferenz_mp6_og_-_2013-07-06_17:00_-_independents_unite_inside_the_freelancers_movement_-_joel_dullroy_-_5038_preview.jpg',19,'2014-05-10 13:26:28.654317','2014-07-07 02:27:42.436063','Independents unite! Inside the freelancers’ movement','konferenz_mp6_og_-_2013-07-06_17:00_-_independents_unite_inside_the_freelancers_movement_-_joel_dullroy_-_5038.jpg','2013-07-06','As the number of freelancers grows, so too does the urgency of creating a movement to improve their social, political and economic situation. Joel Dullroy is editor of the forthcoming e-book “Independents unite! Inside the freelancers’ movement”, which follows the different groups which are building this new social infrastructure by learning from recent political uprisings, using social media tactics and start-up growth concepts.
','https://sigint.ccc.de/schedule/events/5038.html','---
- Joel Dullroy
','konferenz_mp6_og_-_2013-07-06_17:00_-_independents_unite_inside_the_freelancers_movement_-_joel_dullroy_-_5038','How to learn from online communities and coworking spaces to build a freelancers'' movement','---
- sigint13
- " Society"
','2013-07-22','f',4);
INSERT INTO "events" VALUES(668,'import-855601e93d880a1c1b','saal_mp7_og_-_2013-07-06_15:00_-_making_music_with_a_c_compiler_-_erlehmann_-_5067.gif','saal_mp7_og_-_2013-07-06_15:00_-_making_music_with_a_c_compiler_-_erlehmann_-_5067_preview.jpg',19,'2014-05-10 13:26:28.686559','2014-07-08 05:20:03.206126','Making music with a C compiler','saal_mp7_og_-_2013-07-06_15:00_-_making_music_with_a_c_compiler_-_erlehmann_-_5067.jpg','2013-07-06','Audio synthesis and composition without instruments, notes or tracks is possible: One can create music interpreting the output of short programs written in the C programming language as a description of a waveform using pulse-code modulation (by piping to /dev/dsp). 
','https://sigint.ccc.de/schedule/events/5067.html','---
- erlehmann
','saal_mp7_og_-_2013-07-06_15:00_-_making_music_with_a_c_compiler_-_erlehmann_-_5067','(also introducing libglitch)','---
- sigint13
- " Hacking"
','2013-07-22','f',12);
INSERT INTO "events" VALUES(669,'import-f88f7b7638946005ac','konferenz_mp6_og_-_2013-07-07_11:00_-_gute_arbeit_-_stephan_otten_-_5052.gif','konferenz_mp6_og_-_2013-07-07_11:00_-_gute_arbeit_-_stephan_otten_-_5052_preview.jpg',19,'2014-05-10 13:26:28.7193','2014-07-04 15:35:58.171846','Gute Arbeit','konferenz_mp6_og_-_2013-07-07_11:00_-_gute_arbeit_-_stephan_otten_-_5052.jpg','2013-07-07','- Gute Arbeit aus Sicht von Arbeitnehmern/innen,
- Rechte und Pflichten im Job
- stärker mit Betriebsrat und Gewerkschaft
','https://sigint.ccc.de/schedule/events/5052.html','---
- Stephan Otten
','konferenz_mp6_og_-_2013-07-07_11:00_-_gute_arbeit_-_stephan_otten_-_5052','Gemeinsam für gute Arbeit','---
- sigint13
- " Society"
','2013-07-22','f',1);
INSERT INTO "events" VALUES(670,'import-618b74c8f21e779a8d','saal_mp7_og_-_2013-07-07_11:00_-_it_s_my_party_and_i_crypt_if_i_want_to_-_jochim_selzer_-_5058.gif','saal_mp7_og_-_2013-07-07_11:00_-_it_s_my_party_and_i_crypt_if_i_want_to_-_jochim_selzer_-_5058_preview.jpg',19,'2014-05-10 13:26:28.75279','2014-06-26 19:11:55.735168','It''s my party and I crypt if I want to','saal_mp7_og_-_2013-07-07_11:00_-_it_s_my_party_and_i_crypt_if_i_want_to_-_jochim_selzer_-_5058.jpg','2013-07-07','Cryptoparties sind ein neuer Ansatz, um Verschlüsselungstechniken laienkompatibel zu vermitteln. Was sind Cryptoparties? Wie funktionieren sie? Halten sie, was sie versprechen?
','https://sigint.ccc.de/schedule/events/5058.html','---
- Jochim Selzer
','saal_mp7_og_-_2013-07-07_11:00_-_it_s_my_party_and_i_crypt_if_i_want_to_-_jochim_selzer_-_5058','Cryptoparties als Volkshochschule?','---
- sigint13
- '' Community''
','2013-07-22','f',2);
INSERT INTO "events" VALUES(671,'import-17e5e066d2abbd5258','saal_mp7_og_-_2013-07-05_13:00_-_information_wants_to_be_free_versus_privacy_as_the_right_to_be_left_alone_-_hanspeter_schmidt_-_5121.gif','saal_mp7_og_-_2013-07-05_13:00_-_information_wants_to_be_free_versus_privacy_as_the_right_to_be_left_alone_-_hanspeter_schmidt_-_5121_preview.jpg',19,'2014-05-10 13:26:28.882801','2014-06-26 19:11:45.436139','„Information wants to be free" versus „Privacy as the right to be left alone"','saal_mp7_og_-_2013-07-05_13:00_-_information_wants_to_be_free_versus_privacy_as_the_right_to_be_left_alone_-_hanspeter_schmidt_-_5121.jpg','2013-07-05','Datenschutz und Persönlichkeitsrechte stehen der Informations- und
Pressefreiheit und der Aufgabe der Medien als „Wachhunde der
Öffentlichkeit" gegenüber. Die Rechtsprechung stellt die „praktische
Konkordanz" der widerstreitenden Grundrechte her. Das Pendel schlägt in der jüngsten Rechtsprechung zugunsten der Information aus.
','https://sigint.ccc.de/schedule/events/5121.html','---
- Hanspeter Schmidt
','saal_mp7_og_-_2013-07-05_13:00_-_information_wants_to_be_free_versus_privacy_as_the_right_to_be_left_alone_-_hanspeter_schmidt_-_5121','Die neue Rechtsprechung zum Vorrang der Informationsfreiheit','---
- sigint13
- '' Politics''
','2013-07-22','f',1);
INSERT INTO "events" VALUES(672,'import-f598f668f20869cb04','konferenz_mp6_og_-_2013-07-05_16:00_-_ruby_is_magic_-_sebastian_cohnen_-_dirk_breuer_-_5065.gif','konferenz_mp6_og_-_2013-07-05_16:00_-_ruby_is_magic_-_sebastian_cohnen_-_dirk_breuer_-_5065_preview.jpg',19,'2014-05-10 13:26:28.912855','2014-07-09 16:43:27.446708','Ruby is Magic!','konferenz_mp6_og_-_2013-07-05_16:00_-_ruby_is_magic_-_sebastian_cohnen_-_dirk_breuer_-_5065.jpg','2013-07-05','Ruby is an interpreted, dynamic and fully object-oriented programming language. In the past few years the language became more and more popular. Due to the dynamic nature of the language there are a lot of possibilities to leverage the language itself. Some of those possibilities are very useful and some are to be avoided. Nevertheless both are a lot of fun. We want to present some of those useful and not so useful aspects of the language which are sort of curious and definitely fun. This is not a talk to learn the basic concepts of Ruby, and therefore you should bring some very basic knowledge about Ruby.
','https://sigint.ccc.de/schedule/events/5065.html','---
- Sebastian Cohnen
- Dirk Breuer
','konferenz_mp6_og_-_2013-07-05_16:00_-_ruby_is_magic_-_sebastian_cohnen_-_dirk_breuer_-_5065',NULL,'---
- sigint13
- " Hacking"
','2013-07-22','f',5);
INSERT INTO "events" VALUES(673,'import-d4de5211f99a82e86b','konferenz_mp6_og_-_2013-07-05_14:00_-_parabolic_plane_flights_research_in_weightlessness_-_dr_jens_hauslage_-_5047.gif','konferenz_mp6_og_-_2013-07-05_14:00_-_parabolic_plane_flights_research_in_weightlessness_-_dr_jens_hauslage_-_5047_preview.jpg',19,'2014-05-10 13:26:28.942849','2014-07-07 06:31:48.114251','Parabolic Plane Flights – Research in Weightlessness','konferenz_mp6_og_-_2013-07-05_14:00_-_parabolic_plane_flights_research_in_weightlessness_-_dr_jens_hauslage_-_5047.jpg','2013-07-05','In order to investigate the effects of weightlessness on cells, organisms, material, computer systems etc., it is desirable to achieve this condition by Earth-bound devices, since space missions are extremely costly and rarely to obtain. A simple but very effective method is to perform a parabolic flight. Here, the acceleration of the aircraft – flying a parabola - in outward direction compensates the Earthly gravity vector, which points downward. In effect, parabolic flight weightlessness is earned in the upper part of flown parabolas. Some key benefits are, that the proposed experiments can be controlled by the researcher himself right in the course of a flight and that the used experiment facilities are manufactured by the scientist. Thus, one can run an equipment directly from the homelab. Only minimal changes usually have to be done due to flight safety. The topics investigated range from augmented reality based on virtual reality systems to the investigation of gravisensing algae, fungi, plants and animals via material sciences, such as examining the behavior of different melted alloys under microgravity analyzing the emitted light flash during the phase of solidification etc..
The proposed talk will give an overview about different parabolic plane flight missions and the nominal process. Building of flight hardware, testing, scientific questions, certification of hardware etc. and also living in the region of Bordeaux for two weeks are facets in a parabolic plane flight campaign.
','https://sigint.ccc.de/schedule/events/5047.html','---
- Dr. Jens Hauslage
','konferenz_mp6_og_-_2013-07-05_14:00_-_parabolic_plane_flights_research_in_weightlessness_-_dr_jens_hauslage_-_5047',NULL,'---
- sigint13
- " Science"
','2013-07-22','f',3);
INSERT INTO "events" VALUES(674,'import-4668efe98f02e12b8d','saal_mp7_og_-_2013-07-06_16:00_-_vm32_a_cpu_simulator_for_demonstrational_purposes_of_virtualization_technologies_-_andreas_galauner_-_5101.gif','saal_mp7_og_-_2013-07-06_16:00_-_vm32_a_cpu_simulator_for_demonstrational_purposes_of_virtualization_technologies_-_andreas_galauner_-_5101_preview.jpg',19,'2014-05-10 13:26:28.972687','2014-06-28 03:34:10.340429','VM32: A CPU simulator for demonstrational purposes of virtualization technologies','saal_mp7_og_-_2013-07-06_16:00_-_vm32_a_cpu_simulator_for_demonstrational_purposes_of_virtualization_technologies_-_andreas_galauner_-_5101.jpg','2013-07-06','Virtualization techniques are prevalent nowadays. They power our cloud services, they allow us to implement and debug whole operating systems or fight the bad guys by analyzing malware automatically. But how do these techniques actually work at the system- and hardware-level? How are we able to execute two or more complete operating systems at the same time?

To demonstrate how these techniques work and how they are implemented, the author developed a stripped-down CPU for exactly this purpose: The VM32. It is a completely artificial platform for the sole purpose of demonstrating how modern virtualization techniques work and how they are implemented. The platform consists of a simulator, an assembler, a linker and a command line debugger.

The talk will introduce the audience to different virtualization techniques and explain briefly the developed architecture. A small hypervisor for the platform has been developed and will be demonstrated.
','https://sigint.ccc.de/schedule/events/5101.html','---
- Andreas Galauner
','saal_mp7_og_-_2013-07-06_16:00_-_vm32_a_cpu_simulator_for_demonstrational_purposes_of_virtualization_technologies_-_andreas_galauner_-_5101',NULL,'---
- sigint13
- '' Hacking''
','2013-07-22','f',2);
INSERT INTO "events" VALUES(675,'import-67732f87c85cd9bc30','saal_mp7_og_-_2013-07-06_22:00_-_benutze_krake_mit_gerat_-_ths_-_nedos_-_5042.gif','saal_mp7_og_-_2013-07-06_22:00_-_benutze_krake_mit_gerat_-_ths_-_nedos_-_5042_preview.jpg',19,'2014-05-10 13:26:29.00231','2014-06-27 17:42:02.161501','Benutze Krake mit Gerät','saal_mp7_og_-_2013-07-06_22:00_-_benutze_krake_mit_gerat_-_ths_-_nedos_-_5042.jpg','2013-07-06','Viele Werkzeuge die heute zur Standardausrüstung eines Hardware-Hackers gehören, sind in vielen Fällen nicht ausreichend um moderne Embedded-Systeme analysieren und angreifen zu können. Die größten Schwierigkeiten treten vor allem dann auf, wenn große Datenmengen verarbeitet und transportiert werden müssen, oder ein präzises Timing notwendig ist. Gängige Mikrocontroller-basierte Werkzeuge sind günstig aber verfügen meist nicht über die notwendige Performance wie z. B. High-End Protocol-Analyzer, letztere sind geeignet für ein vorbestimmtes Set an Protokollen und meist sehr teuer. Da einem jeden High-End Hardware-Debugging Werkzeug am Ende ein FPGA zugrunde liegt, warum also nicht selbst einen FPGA als Basis für ein günstiges Opensource Werkzeug verwenden, um den Mittelweg zwischen den beiden existierenden Werkzeug-Arten zu beschreiten?
','https://sigint.ccc.de/schedule/events/5042.html','---
- ths
- nedos
','saal_mp7_og_-_2013-07-06_22:00_-_benutze_krake_mit_gerat_-_ths_-_nedos_-_5042','Programmierbare Logik für Deinen Hardware Reverse-Engineering Werkzeugkoffer','---
- sigint13
- '' Hacking''
','2013-07-22','f',2);
INSERT INTO "events" VALUES(676,'import-601bb8d68e81c0375e','konferenz_mp6_og_-_2013-07-06_16:00_-_pressfreedom_surveillance_and_international_campaigning_-_hauke_gierow_-_5072.gif','konferenz_mp6_og_-_2013-07-06_16:00_-_pressfreedom_surveillance_and_international_campaigning_-_hauke_gierow_-_5072_preview.jpg',19,'2014-05-10 13:26:29.032069','2014-07-12 07:01:03.685936',' Pressfreedom, Surveillance and International Campaigning','konferenz_mp6_og_-_2013-07-06_16:00_-_pressfreedom_surveillance_and_international_campaigning_-_hauke_gierow_-_5072.jpg','2013-07-06','Surveillance especially targets journalists as intermediaries of information. Reporters Without Borders Works to defend Freedom of Information and against intrusive government surveillance of Journalists and Bloggers.
','https://sigint.ccc.de/schedule/events/5072.html','---
- Hauke Gierow
','konferenz_mp6_og_-_2013-07-06_16:00_-_pressfreedom_surveillance_and_international_campaigning_-_hauke_gierow_-_5072',' ','---
- sigint13
','2013-07-22','f',5);
INSERT INTO "events" VALUES(677,'import-ea971d9a74241bb280','vortrag_mp6_og_-_2013-07-05_15:00_-_web_security_101_or_how_to_hack_security_conferences_-_sander_bos_-_5107.gif','vortrag_mp6_og_-_2013-07-05_15:00_-_web_security_101_or_how_to_hack_security_conferences_-_sander_bos_-_5107_preview.jpg',19,'2014-05-10 13:26:29.060954','2014-06-26 14:26:31.457271','Web security 101 (or: how to hack security conferences)','vortrag_mp6_og_-_2013-07-05_15:00_-_web_security_101_or_how_to_hack_security_conferences_-_sander_bos_-_5107.jpg','2013-07-05','The vulnerable nature of Web applications was found out to apply even to security conferences.
','https://sigint.ccc.de/schedule/events/5107.html','---
- Sander Bos
','vortrag_mp6_og_-_2013-07-05_15:00_-_web_security_101_or_how_to_hack_security_conferences_-_sander_bos_-_5107',NULL,'---
- sigint13
- '' Hacking''
','2013-07-22','f',7);
INSERT INTO "events" VALUES(678,'import-0275a644da683f930b','vortrag_mp6_og_-_2013-07-06_19:00_-_lightning_talks_-_day_2_-_5090.gif','vortrag_mp6_og_-_2013-07-06_19:00_-_lightning_talks_-_day_2_-_5090_preview.jpg',19,'2014-05-10 13:26:29.089721','2014-07-01 18:30:26.507189','Lightning Talks - Day 2','vortrag_mp6_og_-_2013-07-06_19:00_-_lightning_talks_-_day_2_-_5090.jpg','2013-07-06','Submit your lightning talks at https://frab.cccv.de/en/sigint13lt/cfp
','https://sigint.ccc.de/schedule/events/5090.html','--- []
','vortrag_mp6_og_-_2013-07-06_19:00_-_lightning_talks_-_day_2_-_5090',NULL,'---
- sigint13
- " Community"
','2013-07-22','f',7);
INSERT INTO "events" VALUES(679,'import-896e00155e91edd7b8','saal_mp7_og_-_2013-07-05_11:00_-_nearly_everything_that_matters_is_a_side_effect_-_mlp_-_5060.gif','saal_mp7_og_-_2013-07-05_11:00_-_nearly_everything_that_matters_is_a_side_effect_-_mlp_-_5060_preview.jpg',19,'2014-05-10 13:26:29.118328','2014-07-07 22:17:14.300228','Nearly Everything That Matters is a Side Effect','saal_mp7_og_-_2013-07-05_11:00_-_nearly_everything_that_matters_is_a_side_effect_-_mlp_-_5060.jpg','2013-07-05','TBD
','https://sigint.ccc.de/schedule/events/5060.html','---
- mlp
','saal_mp7_og_-_2013-07-05_11:00_-_nearly_everything_that_matters_is_a_side_effect_-_mlp_-_5060',NULL,'---
- sigint13
- " Hacking"
','2013-07-22','f',9);
INSERT INTO "events" VALUES(680,'import-096c23ddade2a0996f','saal_mp7_og_-_2013-07-05_16:00_-_offshoreleaks_-_the_how_and_why_of_a_global_investigation_-_kappuchino_-_5044.gif','saal_mp7_og_-_2013-07-05_16:00_-_offshoreleaks_-_the_how_and_why_of_a_global_investigation_-_kappuchino_-_5044_preview.jpg',19,'2014-05-10 13:26:29.146862','2014-07-03 14:03:59.109306','Offshoreleaks - the how and why of a global investigation','saal_mp7_og_-_2013-07-05_16:00_-_offshoreleaks_-_the_how_and_why_of_a_global_investigation_-_kappuchino_-_5044.jpg','2013-07-05','A harddisk with millions of documents with the potential to change and influence a whole industry. This about the how and the why. How we analyzed and used the OSL-Data and why so little from so many information was released. And it is not a conspiracy. Or is it?
','https://sigint.ccc.de/schedule/events/5044.html','---
- kappuchino
','saal_mp7_og_-_2013-07-05_16:00_-_offshoreleaks_-_the_how_and_why_of_a_global_investigation_-_kappuchino_-_5044','How we tried to prove tax evasion and money laundering while not to repeat mistakes made earlier by other leaks','---
- sigint13
- " Politics"
','2013-07-22','f',10);
INSERT INTO "events" VALUES(681,'import-a4488ad1248b1c6017','saal_mp7_og_-_2013-07-05_20:00_-_let_s_tear_down_these_walls_-_angelo_veltens_-_5051.gif','saal_mp7_og_-_2013-07-05_20:00_-_let_s_tear_down_these_walls_-_angelo_veltens_-_5051_preview.jpg',19,'2014-05-10 13:26:29.176083','2014-06-26 19:16:16.083398','Let''s tear down these walls','saal_mp7_og_-_2013-07-05_20:00_-_let_s_tear_down_these_walls_-_angelo_veltens_-_5051.jpg','2013-07-05','Seit jeher verlinkt das Web seine Inhalte, ganz gleich auf welchen Servern sie liegen. Interessanterweise scheint dieses Prinzip noch nicht im Social Web angekommen zu sein. Statt uns mit unseren Freunden, und Inhalten die wir mögen, zu verlinken, pflegen wir unzählige Accounts. Nicht selten stehen wir vor technischen Mauern, die unsere die Vernetzung verhindern. Diese Mauern können wir wahrsten Sinne "mit Links" überwinden.
','https://sigint.ccc.de/schedule/events/5051.html','---
- Angelo Veltens
','saal_mp7_og_-_2013-07-05_20:00_-_let_s_tear_down_these_walls_-_angelo_veltens_-_5051','"Mit Links" die Mauern Sozialer Netzwerke überwinden.','---
- sigint13
- '' Hacking''
','2013-07-22','f',1);
INSERT INTO "events" VALUES(682,'import-a459e40d704e748d02','vortrag_mp6_og_-_2013-07-05_12:00_-_cisco_in_the_sky_with_diamonds_-_fx_-_greg_-_5115.gif','vortrag_mp6_og_-_2013-07-05_12:00_-_cisco_in_the_sky_with_diamonds_-_fx_-_greg_-_5115_preview.jpg',19,'2014-05-10 13:26:29.204778','2014-07-01 22:13:06.908719','Cisco in the Sky with Diamonds','vortrag_mp6_og_-_2013-07-05_12:00_-_cisco_in_the_sky_with_diamonds_-_fx_-_greg_-_5115.jpg','2013-07-05','The majority of VMware Cloud deployments rely on Cisco virtual and physical switching and routing gear for the network layer. We will provide an introduction into the differences virtual networking makes, how to go about researching its components, as well as cover a number of issues, their exploitation path and some creative workarounds.
','https://sigint.ccc.de/schedule/events/5115.html','---
- FX
- greg
','vortrag_mp6_og_-_2013-07-05_12:00_-_cisco_in_the_sky_with_diamonds_-_fx_-_greg_-_5115',NULL,'---
- sigint13
- " Hacking"
','2013-07-22','f',3);
INSERT INTO "events" VALUES(683,'import-fb5fe4937619117a96','saal_mp7_og_-_2013-07-05_17:00_-_funkzellenabfrage_-_ilf_-_5062.gif','saal_mp7_og_-_2013-07-05_17:00_-_funkzellenabfrage_-_ilf_-_5062_preview.jpg',19,'2014-05-10 13:26:29.233468','2014-07-06 21:56:18.595907','Funkzellenabfrage','saal_mp7_og_-_2013-07-05_17:00_-_funkzellenabfrage_-_ilf_-_5062.jpg','2013-07-05','Funkzellenabfragen sind "offensichtlich zum alltäglichen Ermittlungsinstrument geworden, das routinemäßig und ohne hinreichende Beachtung der gesetzlichen Vorgaben eingesetzt wird." (Berliner Datenschutzbeauftragter Dix)
','https://sigint.ccc.de/schedule/events/5062.html','---
- ilf
','saal_mp7_og_-_2013-07-05_17:00_-_funkzellenabfrage_-_ilf_-_5062','Die Mobilfunk-Rasterfahndung als Routinemaßnahme','---
- sigint13
- " Politics"
','2013-07-22','f',7);
INSERT INTO "events" VALUES(684,'import-3c6185884db88b4055','saal_mp7_og_-_2013-07-07_12:00_-_embedded_device_security_nightmares_-_sven_f0f_-_5080.gif','saal_mp7_og_-_2013-07-07_12:00_-_embedded_device_security_nightmares_-_sven_f0f_-_5080_preview.jpg',19,'2014-05-10 13:26:29.261764','2014-07-03 20:11:58.273745',' Embedded device security nightmares','saal_mp7_og_-_2013-07-07_12:00_-_embedded_device_security_nightmares_-_sven_f0f_-_5080.jpg','2013-07-07','These days there''s quite a few embedded devices in our everyday lives: Starting from your mobile phone, your game console or your set-top box and ending at things like your router or your laptop''s keyboard. While all of them usually serve different purposes, there''s one thing they have in common: Just using them for their intended application is insanely boring and getting your own to run on them is a lot more fun!
This talk will essentially be a list of mistakes everyone and their mother makes when they try to design a secure device and how they can be exploited. No new research but instead the core concepts of breaking into the mentioned devices and neat little tricks you may not know about will be presented to hopefully give you the ability to break into your own favorite gadget you have at home!
','https://sigint.ccc.de/schedule/events/5080.html','---
- sven_f0f
','saal_mp7_og_-_2013-07-07_12:00_-_embedded_device_security_nightmares_-_sven_f0f_-_5080','An Introduction to the usual mistakes','---
- sigint13
- " Hacking"
','2013-07-22','f',8);
INSERT INTO "events" VALUES(685,'import-f68fa0a81c42dc019f','vortrag_mp6_og_-_2013-07-05_19:00_-_q_a_with_nadim_on_cryptocat_-_5089.gif','vortrag_mp6_og_-_2013-07-05_19:00_-_q_a_with_nadim_on_cryptocat_-_5089_preview.jpg',19,'2014-05-10 13:26:29.362872','2014-06-26 21:49:31.268555','Q&A with Nadim on CryptoCat','vortrag_mp6_og_-_2013-07-05_19:00_-_q_a_with_nadim_on_cryptocat_-_5089.jpg','2013-07-05','
','https://sigint.ccc.de/schedule/events/5089.html','--- []
','vortrag_mp6_og_-_2013-07-05_19:00_-_q_a_with_nadim_on_cryptocat_-_5089',NULL,'---
- sigint13
- '' Community''
','2013-07-22','f',2);
INSERT INTO "events" VALUES(686,'import-b93ce60268c2d2302a','saal_mp7_og_-_2013-07-06_11:00_-_home_network_horror_stories_-_m-1-k-3_-_5030.gif','saal_mp7_og_-_2013-07-06_11:00_-_home_network_horror_stories_-_m-1-k-3_-_5030_preview.jpg',19,'2014-05-10 13:26:29.395971','2014-07-11 22:23:42.591585','Home Network Horror Stories','saal_mp7_og_-_2013-07-06_11:00_-_home_network_horror_stories_-_m-1-k-3_-_5030.jpg','2013-07-06','In unseren typischen Heimnetzwerken tummelt sich mittlerweile eine Vielzahl unterschiedlicher netzwerkfähiger Geräte. Angefangen vom einfachen Internetrouter über den WLAN Access Point bis hin zum netzwerkfähigen Speicher und dem Multimedia Center. Alles Geräte die meist zum Ziel haben sich überaus einfach über ein Webinterface konfigurieren und anschl. sofort und möglichst einfach nutzen zu lassen. Diese Geräte werden im Hintergrund immer mächtiger und dementsprechend immer komplexer. Gleichzeitig muss sie ein Otto normal Benutzer bedienen und konfigurieren können. Niedrige Preise und dementsprechend niedrige Gewinnspannen machen eine sicherheitstechnisch ausgelegte Entwicklung eher unwahrscheinlich. Dieser Talk umfasst die Ergebnisse der Research Arbeiten an über 20 Geräten unterschiedlicher Hersteller. Es konnten bei nahezu allen Geräten gravierende Schwachstellen erkannt werden. Angefangen von einfachen Design Fehlern über typische und häufig anzutreffende Schwachstellen in Webapplikationen bis zu kritischen Lücken die eine vollständige Kompromittierung des Gerätes und unter Umständen des dahinter liegenden Netzwerkes mit sich führt. 
','https://sigint.ccc.de/schedule/events/5030.html','---
- m-1-k-3
','saal_mp7_og_-_2013-07-06_11:00_-_home_network_horror_stories_-_m-1-k-3_-_5030',NULL,'---
- sigint13
- " Hacking"
','2013-07-22','f',17);
INSERT INTO "events" VALUES(687,'import-4f5581ae41220cba91','konferenz_mp6_og_-_2013-07-05_20:00_-_programming_fpgas_with_pshdl_-_karsten_becker_-_5033.gif','konferenz_mp6_og_-_2013-07-05_20:00_-_programming_fpgas_with_pshdl_-_karsten_becker_-_5033_preview.jpg',19,'2014-05-10 13:26:29.430025','2014-07-10 12:28:26.645511','Programming FPGAs with PSHDL','konferenz_mp6_og_-_2013-07-05_20:00_-_programming_fpgas_with_pshdl_-_karsten_becker_-_5033.jpg','2013-07-05','Learning to program an FPGA is time consuming. Not just do you need to download and install 20gb of vendor tools, but you also need to wrap your brain around the strange ideas of hardware description languages like VHDL. PSHDL aims to ease the learning curve significantly and provide more people with the ability to program FPGAs.
','https://sigint.ccc.de/schedule/events/5033.html','---
- Karsten Becker
','konferenz_mp6_og_-_2013-07-05_20:00_-_programming_fpgas_with_pshdl_-_karsten_becker_-_5033','Lets create the Arduino for FPGAs','---
- sigint13
- " Hacking"
','2013-07-22','f',11);
INSERT INTO "events" VALUES(688,'import-74d091362cd1fd91d2','konferenz_mp6_og_-_2013-07-07_16:00_-_besser_leben_fur_geeks_-_moeffju_-_5085.gif','konferenz_mp6_og_-_2013-07-07_16:00_-_besser_leben_fur_geeks_-_moeffju_-_5085_preview.jpg',19,'2014-05-10 13:26:29.561175','2014-06-22 21:54:02.815521','Besser leben für Geeks','konferenz_mp6_og_-_2013-07-07_16:00_-_besser_leben_fur_geeks_-_moeffju_-_5085.jpg','2013-07-07','Gerade die Hacker, Computer-Arbeiter, Entwickler, Konzepter, Aktivisten, kurz Geeks und Nerds, lieben es, komplexe Systeme zu erfassen, zu verstehen, und zu ihrem Vorteil zu nutzen. Die Komplexitäten unseren täglichen Lebens ignorieren wir jedoch. Wir halten uns mit koffeinhaltigen Zuckergetränken bis spät in die Nacht wach, starren in helle Bildschirme, und essen Fertignudeln dazu.

In dieser Session werden die häufigsten Fehler und Probleme bei Ernährung, Schlafhygiene, und Drogenkonsum aufgezeigt und erklärt, wie man seine Lebensqualität durch einfache Änderungen verbessern kann.
','https://sigint.ccc.de/schedule/events/5085.html','---
- moeffju
','konferenz_mp6_og_-_2013-07-07_16:00_-_besser_leben_fur_geeks_-_moeffju_-_5085','Richtig essen, richtig schlafen, und: lasst die Mate weg.','---
- sigint13
- '' Science''
','2013-07-22','f',1);
INSERT INTO "events" VALUES(689,'import-8959d7a62bf5227af0','konferenz_mp6_og_-_2013-07-06_22:00_-_transparenzgesetz_-_quo_vadis_-_dodger_-_thorsten_sterk_-_5105.gif','konferenz_mp6_og_-_2013-07-06_22:00_-_transparenzgesetz_-_quo_vadis_-_dodger_-_thorsten_sterk_-_5105_preview.jpg',19,'2014-05-10 13:26:29.591909','2014-05-10 13:26:29.591909','Transparenzgesetz - Quo Vadis?','konferenz_mp6_og_-_2013-07-06_22:00_-_transparenzgesetz_-_quo_vadis_-_dodger_-_thorsten_sterk_-_5105.jpg','2013-07-06','Ein Jahr nach Verabschiedung des Hamburgischen Transparenzgesetzes versuchen wir einen Roundup und einen Ausblick.
','https://sigint.ccc.de/schedule/events/5105.html','---
- dodger
- Thorsten Sterk
','konferenz_mp6_og_-_2013-07-06_22:00_-_transparenzgesetz_-_quo_vadis_-_dodger_-_thorsten_sterk_-_5105','Die Transparenzgesetz Initiativen in Deutschland','---
- sigint13
- '' Politics''
','2013-07-22','f',0);
INSERT INTO "events" VALUES(690,'import-0817bb074c26e08380','konferenz_mp6_og_-_2013-07-05_22:00_-_why_we_fight_each_other_-_mspro_-_5049.gif','konferenz_mp6_og_-_2013-07-05_22:00_-_why_we_fight_each_other_-_mspro_-_5049_preview.jpg',19,'2014-05-10 13:26:29.621631','2014-07-02 05:26:33.618159','Why we fight (each other)','konferenz_mp6_og_-_2013-07-05_22:00_-_why_we_fight_each_other_-_mspro_-_5049.jpg','2013-07-05','Die deutsche Netz- und Hackerszene zerstreitet sich bei jeder Gelegenheit und zu allen möglichen Themen. Ich glaube, den strukturellen Ursachen dieser Streits auf den Grund gehen zu können.
','https://sigint.ccc.de/schedule/events/5049.html','---
- mspro
','konferenz_mp6_og_-_2013-07-05_22:00_-_why_we_fight_each_other_-_mspro_-_5049',NULL,'---
- sigint13
- " Community"
','2013-07-22','f',3);
INSERT INTO "events" VALUES(691,'import-e07970a31bd07defcf','konferenz_mp6_og_-_2013-07-07_15:00_-_c_r_o_p_combined_regenerative_organic-food_production_-_dr_jens_hauslage_-_5046.gif','konferenz_mp6_og_-_2013-07-07_15:00_-_c_r_o_p_combined_regenerative_organic-food_production_-_dr_jens_hauslage_-_5046_preview.jpg',19,'2014-05-10 13:26:29.6512','2014-06-30 22:07:13.093041','C.R.O.P. – Combined Regenerative Organic-food Production','konferenz_mp6_og_-_2013-07-07_15:00_-_c_r_o_p_combined_regenerative_organic-food_production_-_dr_jens_hauslage_-_5046.jpg','2013-07-07','Jeden Tag entstehen in Megastädten wie Tokyo, Peking oder Bangkok riesige Müllberge. Die Müllentsorgung ist längst zum Problem geworden. Im Rahmen eines Projektes des Deutschen Zentrums für Luft- und Raumfahrt e.V. (DLR) in Köln wird zurzeit eine Anlage entwickelt, die die Müllmengen verkleinern soll, indem sie biologische Abfälle in einem Kreislauf wiederverwertet. 
Die Forschungsanlage C.R.O.P, ist ein bioregeneratives System: Das heißt die Anlage zersetzt biologische Abfälle und verwendet sie, um neue (pflanzliche) Lebensmittel zu produzieren. 
Dr. Jens Hauslage, Wissenschaftler und Projektleiter (:envihab – Lebenserhaltungssysteme) am DLR-Institut für Luft und Raumfahrtmedizin, glaubt durch die Entwicklung dieses Systems einen ersten Anstoß zu geben, dass sich Forscher intensiver mit Lebenserhaltungssystemen beschäftigen. Diese Systeme sollen das Überleben von Menschen auch unter schwierigen Bedingungen und in harschen Umgebungen ermöglichen und  die Lebensbedingungen verbessern.
Kernstück der Anlage ist ein Biofilter
Das C.R.O.P. – System basiert auf der Verstoffwechslung von organischen Materialien in einem Biofiltersystem. Dabei zersetzen verschiedene Mikroorganismen Substanzen wie Stickstoff- und Kohlenstoffverbindungen. Ziel ist es dabei, z.B. die Stoffkreisläufe so zu verkürzen, dass nur noch die Menge an Nährstoffen zugegeben wird, die in Form von Lebensmitteln aus dem System entnommen werden. Eine Verwendung der Biofilter in Hochtechnologie-Gewächshäusern am Versuchsstandort AgroHort der Universität Bonn konnte bereits zeigen, das über 120kg biologischer Abfall (Pflanzen- , Obst- und Gemüsereste) innerhalb von 100 Tagen zu einer klaren Düngeausgangslösung verstoffwechselt werden kann.
','https://sigint.ccc.de/schedule/events/5046.html','---
- Dr. Jens Hauslage
','konferenz_mp6_og_-_2013-07-07_15:00_-_c_r_o_p_combined_regenerative_organic-food_production_-_dr_jens_hauslage_-_5046','C.R.O.P., ein Forschungsprojekt des Deutschen Zentrums für Luft- und Raumfahrt e.V., nutzt biologische Abbauprodukte, um Lebensmittel zu produzieren ','---
- sigint13
- " Science"
','2013-07-22','f',6);
INSERT INTO "events" VALUES(692,'import-3782fc040147a211ac','saal_mp7_og_-_2013-07-06_21:00_-_cuckoo_sandbox_-_malware_beware_-_mark_schloesser_-_nex_-_skier_-_5074.gif','saal_mp7_og_-_2013-07-06_21:00_-_cuckoo_sandbox_-_malware_beware_-_mark_schloesser_-_nex_-_skier_-_5074_preview.jpg',19,'2014-05-10 13:26:29.680996','2014-07-05 18:52:58.915637','Cuckoo Sandbox - malware beware','saal_mp7_og_-_2013-07-06_21:00_-_cuckoo_sandbox_-_malware_beware_-_mark_schloesser_-_nex_-_skier_-_5074.jpg','2013-07-06','Cuckoo Sandbox is a widely used open-source project for automated dynamic malware analysis. It takes malicious documents or URLs as input and provides both high-level overview reports as well as detailed API call traces of the activities observed inside a virtual machine. The project was founded by Claudio Guarnieri and is mainly developed by four developers in their free time and during weekends.
','https://sigint.ccc.de/schedule/events/5074.html','---
- Mark Schloesser
- Nex
- skier_
','saal_mp7_og_-_2013-07-06_21:00_-_cuckoo_sandbox_-_malware_beware_-_mark_schloesser_-_nex_-_skier_-_5074','Open Source Dynamic Malware Analysis','---
- sigint13
- " Hacking"
','2013-07-22','f',9);
INSERT INTO "events" VALUES(693,'import-b55a825bce0ede19d7','konferenz_mp6_og_-_2013-07-06_12:00_-_sdr_gsm_openbts_-_ralph_a_schmid_-_5099.gif','konferenz_mp6_og_-_2013-07-06_12:00_-_sdr_gsm_openbts_-_ralph_a_schmid_-_5099_preview.jpg',19,'2014-05-10 13:26:29.710232','2014-07-09 17:09:39.061544','SDR, GSM/OpenBTS','konferenz_mp6_og_-_2013-07-06_12:00_-_sdr_gsm_openbts_-_ralph_a_schmid_-_5099.jpg','2013-07-06','Some words from a RF engineer who knows a bit of the white and the black side of the game and recently started playing with SDR technology, with a steep learning curve and amazing results.
','https://sigint.ccc.de/schedule/events/5099.html','---
- Ralph A. Schmid
','konferenz_mp6_og_-_2013-07-06_12:00_-_sdr_gsm_openbts_-_ralph_a_schmid_-_5099','New RF technology - exciting for good guys, bad guys, society...','---
- sigint13
- " Hacking"
','2013-07-22','f',6);
INSERT INTO "events" VALUES(694,'import-c9d167889047eb37bb','konferenz_mp6_og_-_2013-07-05_15:00_-_cryptocat_the_social_and_technical_challenges_of_making_crypto_accessible_to_everyone_-_nadim_kobeissi_-_5050.gif','konferenz_mp6_og_-_2013-07-05_15:00_-_cryptocat_the_social_and_technical_challenges_of_making_crypto_accessible_to_everyone_-_nadim_kobeissi_-_5050_preview.jpg',19,'2014-05-10 13:26:29.739296','2014-07-07 20:15:59.839065','Cryptocat: The Social and Technical Challenges of Making Crypto Accessible to Everyone','konferenz_mp6_og_-_2013-07-05_15:00_-_cryptocat_the_social_and_technical_challenges_of_making_crypto_accessible_to_everyone_-_nadim_kobeissi_-_5050.jpg','2013-07-05','Cryptocat''s (https://crypto.cat) mission to make open source encrypted chat accessible to the masses has been successful — but what are the technical dangers and limitations? What are the social repercussions? I''d like to discuss how leading an open encrypted chat platform to 50,000+ users in a single year has resulted in crazy and new problems that we need to consider if we want to make crypto more accessible.
','https://sigint.ccc.de/schedule/events/5050.html','---
- Nadim Kobeissi
','konferenz_mp6_og_-_2013-07-05_15:00_-_cryptocat_the_social_and_technical_challenges_of_making_crypto_accessible_to_everyone_-_nadim_kobeissi_-_5050',NULL,'---
- sigint13
- " Society"
','2013-07-22','f',5);
INSERT INTO "events" VALUES(695,'import-5cf523cd2fd74f6829','vortrag_mp6_og_-_2013-07-07_11:00_-_transcending_places_-_moritz_heidkamp_-_5102.gif','vortrag_mp6_og_-_2013-07-07_11:00_-_transcending_places_-_moritz_heidkamp_-_5102_preview.jpg',19,'2014-05-10 13:26:29.768387','2014-07-05 21:00:13.246945','Transcending Places','vortrag_mp6_og_-_2013-07-07_11:00_-_transcending_places_-_moritz_heidkamp_-_5102.jpg','2013-07-07','In this talk I want to explore the possibilities which are unlocked when we transcend the traditional programming model (which Rich Hickey calls "place-oriented programming", or "PLOP" for short) to a value based approach. To that end I will explain what exactly "values" are and how they can help us to side step a whole class of problems inherent in PLOP.
','https://sigint.ccc.de/schedule/events/5102.html','---
- Moritz Heidkamp
','vortrag_mp6_og_-_2013-07-07_11:00_-_transcending_places_-_moritz_heidkamp_-_5102','Programming With Values','---
- sigint13
- " Hacking"
','2013-07-22','f',4);
INSERT INTO "events" VALUES(696,'import-a4baaf004d8c564571','vortrag_mp6_og_-_2013-07-05_17:00_-_aufbau_freier_netze_-_yanosz_-_nomaster_-_5100.gif','vortrag_mp6_og_-_2013-07-05_17:00_-_aufbau_freier_netze_-_yanosz_-_nomaster_-_5100_preview.jpg',19,'2014-05-10 13:26:29.797445','2014-07-12 03:29:35.889325','Aufbau freier Netze','vortrag_mp6_og_-_2013-07-05_17:00_-_aufbau_freier_netze_-_yanosz_-_nomaster_-_5100.jpg','2013-07-05','Wie bauen Freifunker offene Netze? Seit 10 Jahren treibt freifunk.net den Aufbau offener und freier Wireless-LAN Netze voran. Viele Communities überzeugen Freunde, Vereine und Unternehmen am Netz teilzunehmen. Mit verschiedenen Strategien begegnen sie Vorbehalten, rechtlichen Unsicherheiten und Fragen.
','https://sigint.ccc.de/schedule/events/5100.html','---
- yanosz
- nomaster
','vortrag_mp6_og_-_2013-07-05_17:00_-_aufbau_freier_netze_-_yanosz_-_nomaster_-_5100','Erfahrungen von den Dächern der Städte','---
- sigint13
- " Society"
','2013-07-22','f',6);
INSERT INTO "events" VALUES(697,'import-6e41e3f78f87e167ab','saal_mp7_og_-_2013-07-05_21:00_-_the_politics_of_surveillance_understanding_the_national_security_agency_-_rainey_reitman_-_5125.gif','saal_mp7_og_-_2013-07-05_21:00_-_the_politics_of_surveillance_understanding_the_national_security_agency_-_rainey_reitman_-_5125_preview.jpg',19,'2014-05-10 13:26:29.82611','2014-07-12 07:26:58.013836','The Politics of Surveillance: Understanding the National Security Agency','saal_mp7_og_-_2013-07-05_21:00_-_the_politics_of_surveillance_understanding_the_national_security_agency_-_rainey_reitman_-_5125.jpg','2013-07-05','For years, the Electronic Frontier Foundation has been fighting against secret dragnet surveillance by the United States’ National Security Agency.  This talk reviews what we know about the NSA’s spying programs and discusses the path forward to stopping reining in the spying – from the courtroom to Washington DC. We’ll talk specifically about the grassroots tactics that activists are using and the challenges we face.
','https://sigint.ccc.de/schedule/events/5125.html','---
- Rainey Reitman
','saal_mp7_og_-_2013-07-05_21:00_-_the_politics_of_surveillance_understanding_the_national_security_agency_-_rainey_reitman_-_5125',NULL,'---
- sigint13
- " Politics"
','2013-07-22','f',6);
INSERT INTO "events" VALUES(698,'import-89663a7917f7269eb1','konferenz_mp6_og_-_2013-07-05_21:00_-_internet-meme_geschichte_und_forschungsstand_-_erlehmann_-_plomlompom_-_5084.gif','konferenz_mp6_og_-_2013-07-05_21:00_-_internet-meme_geschichte_und_forschungsstand_-_erlehmann_-_plomlompom_-_5084_preview.jpg',19,'2014-05-10 13:26:29.854832','2014-06-22 21:50:56.424451','Internet-Meme: Geschichte und Forschungsstand','konferenz_mp6_og_-_2013-07-05_21:00_-_internet-meme_geschichte_und_forschungsstand_-_erlehmann_-_plomlompom_-_5084.jpg','2013-07-05','Internet-Meme sind Populär-Kultur unter Bedingungen des Netzes. Wir
stellen ihre Entwicklung vor und erläutern den aktuellen Forschungsstand
anhand konkreter Arbeiten.
','https://sigint.ccc.de/schedule/events/5084.html','---
- erlehmann
- plomlompom
','konferenz_mp6_og_-_2013-07-05_21:00_-_internet-meme_geschichte_und_forschungsstand_-_erlehmann_-_plomlompom_-_5084',NULL,'---
- sigint13
- '' Culture''
','2013-07-22','f',2);
INSERT INTO "events" VALUES(699,'import-264973248d5b2f9520','saal_mp7_og_-_2013-07-06_14:00_-_the_drm_of_pacman_-_peter_franky_smets_-_5055.gif','saal_mp7_og_-_2013-07-06_14:00_-_the_drm_of_pacman_-_peter_franky_smets_-_5055_preview.jpg',19,'2014-05-10 13:26:29.883919','2014-06-24 04:01:14.621682','The DRM Of Pacman','saal_mp7_og_-_2013-07-06_14:00_-_the_drm_of_pacman_-_peter_franky_smets_-_5055.jpg','2013-07-06','Copy protections are everywhere. On music, movies, games, pretty much everything that is digital. But where did it start ? Not on your C64 in 1982 or any other home computer from that era but many of the R&D that we still see today found its origin in the Arcades of the early 80s. This seminar covers the copy protection schemes of way back then and how they influence the world today... From angry letters over encryption to planned system suicide.
','https://sigint.ccc.de/schedule/events/5055.html','---
- Peter ''FRaNKy'' Smets
','saal_mp7_og_-_2013-07-06_14:00_-_the_drm_of_pacman_-_peter_franky_smets_-_5055','Copy protection schemes of way back then and how they influence the world today','---
- sigint13
- '' Hacking''
','2013-07-22','f',1);
INSERT INTO "events" VALUES(700,'import-cc371f077c977d36d4','konferenz_mp6_og_-_2013-07-05_19:00_-_ui_redressing_attacks_on_android_devices_-_mniemietz_-_5059.gif','konferenz_mp6_og_-_2013-07-05_19:00_-_ui_redressing_attacks_on_android_devices_-_mniemietz_-_5059_preview.jpg',19,'2014-05-10 13:26:29.91256','2014-05-10 13:26:29.91256','UI Redressing Attacks on Android Devices','konferenz_mp6_og_-_2013-07-05_19:00_-_ui_redressing_attacks_on_android_devices_-_mniemietz_-_5059.jpg','2013-07-05','In this presentation, we describe novel high-impact user interface attacks on Android-based mobile devices, additionally focusing on showcasing the possible mitigation techniques for such attacks.
','https://sigint.ccc.de/schedule/events/5059.html','---
- mniemietz
','konferenz_mp6_og_-_2013-07-05_19:00_-_ui_redressing_attacks_on_android_devices_-_mniemietz_-_5059',NULL,'---
- sigint13
- '' Hacking''
','2013-07-22','f',0);
INSERT INTO "events" VALUES(701,'import-57e66dffd1c89bdcdb','vortrag_mp6_og_-_2013-07-07_12:00_-_introduction_to_bitcoin_-_mark_van_cuijk_-_5035.gif','vortrag_mp6_og_-_2013-07-07_12:00_-_introduction_to_bitcoin_-_mark_van_cuijk_-_5035_preview.jpg',19,'2014-05-10 13:26:29.940976','2014-07-12 03:17:52.171611','Introduction to Bitcoin','vortrag_mp6_og_-_2013-07-07_12:00_-_introduction_to_bitcoin_-_mark_van_cuijk_-_5035.jpg','2013-07-07','This presentation will give understandable introduction into the principles that make Bitcoin work, how Bitcoins can be kept and how they can be obtained.
','https://sigint.ccc.de/schedule/events/5035.html','---
- Mark van Cuijk
','vortrag_mp6_og_-_2013-07-07_12:00_-_introduction_to_bitcoin_-_mark_van_cuijk_-_5035',NULL,'---
- sigint13
- " Hacking"
','2013-07-22','f',10);
INSERT INTO "events" VALUES(702,'import-090dbaaaafe194a316','saal_mp7_og_-_2013-07-06_17:00_-_i_o_capture_treiber_framework_-_viviane_-_5073.gif','saal_mp7_og_-_2013-07-06_17:00_-_i_o_capture_treiber_framework_-_viviane_-_5073_preview.jpg',19,'2014-05-10 13:26:30.042214','2014-07-09 22:45:51.505791','I/O Capture Treiber Framework','saal_mp7_og_-_2013-07-06_17:00_-_i_o_capture_treiber_framework_-_viviane_-_5073.jpg','2013-07-06','Jeder kennt Wireshark. Was wäre, wenn man nicht nur für TCPIP mitschneiden könnte, sondern auch jedes andere mögliche "Gerät" oder Hardware-Schnittstelle?
Und wenn man nicht nur mitschneiden, sondern auch live modifizieren könnte? Filter wie bei Wireshark ansetzen könnte, um nur bestimmte interessante I/O Pakete abzufangen? Und das möglichst ohne sich viel mit Kerneltreiber-Details und Programmierung beschäftigen zu müssen?

In diesem Vortrag wird ein Framework (in development) vorgestellt, welches genau das möglich macht -- automatisch maßgeschneiderte Filtertreiber erzeugen.
','https://sigint.ccc.de/schedule/events/5073.html','---
- Viviane
','saal_mp7_og_-_2013-07-06_17:00_-_i_o_capture_treiber_framework_-_viviane_-_5073','Maßgeschneiderte Geräte-Filtertreiber auf Knopfdruck','---
- sigint13
- " Hacking"
','2013-07-22','f',2);
INSERT INTO "events" VALUES(703,'import-f7045c0ce8f8d76b99','konferenz_mp6_og_-_2013-07-05_12:00_-_automatisierte_videouberwachung_-_benjamin_kees_-_5053.gif','konferenz_mp6_og_-_2013-07-05_12:00_-_automatisierte_videouberwachung_-_benjamin_kees_-_5053_preview.jpg',19,'2014-05-10 13:26:30.075923','2014-07-12 07:04:03.847178','Automatisierte Videoüberwachung','konferenz_mp6_og_-_2013-07-05_12:00_-_automatisierte_videouberwachung_-_benjamin_kees_-_5053.jpg','2013-07-05','Warum Algorithmen rassistisch sein können, OperateurInnen Teil des Automatismus werden und Face-Blurring nicht hilft.
','https://sigint.ccc.de/schedule/events/5053.html','---
- Benjamin Kees
','konferenz_mp6_og_-_2013-07-05_12:00_-_automatisierte_videouberwachung_-_benjamin_kees_-_5053','Gesellschaftliche Auswirkung aus technischer Perspektive','---
- sigint13
- " Politics"
','2013-07-22','f',1);
INSERT INTO "events" VALUES(765,'import-ec99415102c530a179','20C3-593-Weird_programming.gif','',23,'2014-05-10 13:26:31.055448','2014-06-23 13:02:49.311498','weird programming (593)','20C3-593-Weird_programming.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/593.en.html','--- []
','20C3-593-Weird_programming',NULL,'---
- 20c3
','2008-01-05','f',1);
INSERT INTO "events" VALUES(766,'import-e6bf982e4949766ac4','20C3-538-Practical_WIN32_and_Unicode_exploitation.gif','',23,'2014-05-10 13:26:31.06665','2014-05-10 13:26:31.06665','Practical Win32 and UNICODE exploitation','20C3-538-Practical_WIN32_and_Unicode_exploitation.jpg','2003-12-28','The talk could also be called "Lessons learned when the Cisco guys went to Windows land", because there are a number of things quite different in Windows land compared to other environments. One of these things is the frequent use of wide characters and the annoying difficulties that arise from that, including return addresses of 0x00410041.
','http://www.ccc.de/congress/2003/fahrplan/event/538.en.html','---
- FX of Phenoelit
','20C3-538-Practical_WIN32_and_Unicode_exploitation',NULL,'---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(767,'import-5ef6c0095ecebf6a2f','20C3-588-Schummeln_in_oeffentlichen-Projekten.gif','',23,'2014-05-10 13:26:31.078088','2014-05-10 13:26:31.078088','Schummeln in Oeffentlichen Projekten (588)','20C3-588-Schummeln_in_oeffentlichen-Projekten.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/588.en.html','--- []
','20C3-588-Schummeln_in_oeffentlichen-Projekten',NULL,'---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(768,'import-340bde5c179b953db1','20C3-653-Device_hacking_with_JTAG.gif','',23,'2014-05-10 13:26:31.089311','2014-05-10 13:26:31.089311','device hacking with jtag (653)','20C3-653-Device_hacking_with_JTAG.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/653.en.html','--- []
','20C3-653-Device_hacking_with_JTAG',NULL,'---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(769,'import-b2af0e61f8de12a218','20C3-609-Security_Nightmares_III.gif','',23,'2014-05-10 13:26:31.100739','2014-05-10 13:26:31.100739','Security Nightmares III','20C3-609-Security_Nightmares_III.jpg','2003-12-29','Moderated Audience Discussion on "Security Nightmares 2004": which Security-Problems will we stumble upon tomorrow? Which Attack-Methods should we be prepared to defend against? Which major Technology will get hacked next year? We?ll be looking back at last years predictions and then walk upon the thin ice of predicting the future.
','http://www.ccc.de/congress/2003/fahrplan/event/609.en.html','---
- Ron
- Frank Rieger
','20C3-609-Security_Nightmares_III','Worüber wir nächstes Jahr lachen werden','---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(770,'import-45631ec4e36434bfcc','20C3-624-Neue_Notrufnummern_fuer_die_Informationsgesellschaft.gif','',23,'2014-05-10 13:26:31.111992','2014-05-10 13:26:31.111992','neue notrufnummern fuer die informationsgesellschaft (624)','20C3-624-Neue_Notrufnummern_fuer_die_Informationsgesellschaft.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/624.en.html','--- []
','20C3-624-Neue_Notrufnummern_fuer_die_Informationsgesellschaft',NULL,'---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(771,'import-4d16517d50ae0e0c3b','20C3-574-Fragen_an_eine_maschinenlesbare_Regierung.gif','',23,'2014-05-10 13:26:31.123285','2014-06-26 13:03:48.465376','Fragen an eine maschinenlesbare Regierung','20C3-574-Fragen_an_eine_maschinenlesbare_Regierung.jpg','2003-12-28','Der Weltgipfel zur Informationsgesellschaft in Genf zeigte etwa zwei Richtungen von Informationen: Das Wahre und als Chance zur bildungsgestützten Demokratie, Mitsprache "aller". Die Regierungswirklichkeit hinkt dem noch etwas nach, vor allem die deutsche. Sogar die Türkei hat inzwischen ein Informationsfreiheitsgesetz, in Deutschland haben bislang nur einige Bundesländer ein Informationsfreiheitsgesetz.
','http://www.ccc.de/congress/2003/fahrplan/event/574.en.html','---
- Gerriet Hellwig
- Jörg Tauss
','20C3-574-Fragen_an_eine_maschinenlesbare_Regierung','Informationsfreiheitsgesetz jetzt!','---
- 20c3
- '' Society''
','2008-01-05','f',1);
INSERT INTO "events" VALUES(772,'import-d6c23abc0101cdf909','20C3-599-Softwarepatente.gif','',23,'2014-05-10 13:26:31.134631','2014-06-27 02:17:21.40267','Software-Patente','20C3-599-Softwarepatente.jpg','2003-12-27','
','http://www.ccc.de/congress/2003/fahrplan/event/599.en.html','---
- Edward Gerhold
','20C3-599-Softwarepatente','Es ist noch nicht vorbei','---
- 20c3
','2008-01-05','f',2);
INSERT INTO "events" VALUES(773,'import-e7e90640ac98acba3e','20C3-644-Gute-Antennen-selber-bauen.gif','',23,'2014-05-10 13:26:31.145885','2014-07-11 12:07:46.0518','Gute Antennen selber bauen (644)','20C3-644-Gute-Antennen-selber-bauen.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/644.en.html','--- []
','20C3-644-Gute-Antennen-selber-bauen',NULL,'---
- 20c3
','2008-01-05','f',6);
INSERT INTO "events" VALUES(774,'import-ef6d6d75b7095316d9','20C3-581-Chaos-Rueckblick-2003.gif','',23,'2014-05-10 13:26:31.157223','2014-06-24 08:38:42.652855','Chaos Jahresrückblick 2003','20C3-581-Chaos-Rueckblick-2003.jpg','2003-12-27','
','http://www.ccc.de/congress/2003/fahrplan/event/581.en.html','---
- Andy Müller-Maguhn
- Lars Weiler
','20C3-581-Chaos-Rueckblick-2003',NULL,'---
- 20c3
','2008-01-05','f',1);
INSERT INTO "events" VALUES(775,'import-b6cd88dc4ad69cbd83','20C3-568-Data_mining_and_intelligence_software.gif','',23,'2014-05-10 13:26:31.168682','2014-06-26 03:36:48.601508','data mining and intelligence software (568)','20C3-568-Data_mining_and_intelligence_software.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/568.en.html','--- []
','20C3-568-Data_mining_and_intelligence_software',NULL,'---
- 20c3
','2008-01-05','f',1);
INSERT INTO "events" VALUES(776,'import-eae4fa54c6a772aa28','20C3-546-1024_bit_RSA_ist_unsicher.gif','',23,'2014-05-10 13:26:31.180401','2014-06-27 17:37:43.95543','1024 bit rsa ist unsicher (546)','20C3-546-1024_bit_RSA_ist_unsicher.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/546.en.html','--- []
','20C3-546-1024_bit_RSA_ist_unsicher',NULL,'---
- 20c3
','2008-01-05','f',2);
INSERT INTO "events" VALUES(777,'import-b6ee8eeadb87d2384c','20C3-623-Softwarekunstprojekt_runme.org.gif','',23,'2014-05-10 13:26:31.192028','2014-06-24 02:58:39.315581','softwarekunstprojekt runme.org (623)','20C3-623-Softwarekunstprojekt_runme.org.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/623.en.html','--- []
','20C3-623-Softwarekunstprojekt_runme_org',NULL,'---
- 20c3
','2008-01-05','f',1);
INSERT INTO "events" VALUES(778,'import-c736b4398a8616a7e5','20C3-560-Soziale_Software.gif','',23,'2014-05-10 13:26:31.203235','2014-05-10 13:26:31.203235','soziale software (560)','20C3-560-Soziale_Software.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/560.en.html','--- []
','20C3-560-Soziale_Software',NULL,'---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(779,'import-3fc3fd435d6c28ebca','20C3-562-Der_Zettel_am_Bildschirm.gif','',23,'2014-05-10 13:26:31.214598','2014-05-10 13:26:31.214598','der zettel am bildschirm (562)','20C3-562-Der_Zettel_am_Bildschirm.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/562.en.html','--- []
','20C3-562-Der_Zettel_am_Bildschirm',NULL,'---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(780,'import-5c1c621fcd842e565d','20C3-610-Abschlussveranstaltung.gif','',23,'2014-05-10 13:26:31.225911','2014-05-10 13:26:31.225911','abschlussveranstaltung (610)','20C3-610-Abschlussveranstaltung.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/610.en.html','--- []
','20C3-610-Abschlussveranstaltung',NULL,'---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(781,'import-777375527796871e60','20C3-611-Hacker_Jeopardy.gif','',23,'2014-05-10 13:26:31.237434','2014-06-23 16:56:54.13687','Hacker Jeopardy','20C3-611-Hacker_Jeopardy.jpg','2003-12-29','
','http://www.ccc.de/congress/2003/fahrplan/event/611.en.html','---
- Stefan ''Sec'' Zehl
','20C3-611-Hacker_Jeopardy',NULL,'---
- 20c3
','2008-01-05','f',1);
INSERT INTO "events" VALUES(782,'import-020b19f7f32b25941d','20C3-577-Secure_Internet_live_conferencing_with_SILC.gif','',23,'2014-05-10 13:26:31.248686','2014-05-10 13:26:31.248686','secure internet live conferencing with silc (577)','20C3-577-Secure_Internet_live_conferencing_with_SILC.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/577.en.html','--- []
','20C3-577-Secure_Internet_live_conferencing_with_SILC',NULL,'---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(783,'import-888da0e302611c285a','20C3-545-Abschlussveranstaltung_Lockpicking.gif','',23,'2014-05-10 13:26:31.260022','2014-07-08 14:23:16.663343','Abschlussveranstaltung Lockpicking','20C3-545-Abschlussveranstaltung_Lockpicking.jpg','2003-12-28','
','http://www.ccc.de/congress/2003/fahrplan/event/545.en.html','---
- Steffen Wernéry
','20C3-545-Abschlussveranstaltung_Lockpicking',NULL,'---
- 20c3
','2008-01-05','f',7);
INSERT INTO "events" VALUES(784,'import-ce2f906c7ada48cec9','20C3-630-The_Quintessenz_biometrics_doqubase1.gif','',23,'2014-05-10 13:26:31.271218','2014-05-10 13:26:31.271218','the quintessenz biometrics doqubase1 (630)','20C3-630-The_Quintessenz_biometrics_doqubase1.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/630.en.html','--- []
','20C3-630-The_Quintessenz_biometrics_doqubase1',NULL,'---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(785,'import-5a1d49359193696c0a','20C3-589-AN.ON_and_the_future_of_anonymizers.gif','',23,'2014-05-10 13:26:31.282456','2014-06-24 08:07:11.476384','an.on and the future of anonymizers (589)','20C3-589-AN.ON_and_the_future_of_anonymizers.jpg','2003-12-28','
','http://www.ccc.de/congress/2003/fahrplan/event/589.en.html','---
- Oliver Berthold
- nulli
','20C3-589-AN_ON_and_the_future_of_anonymizers',NULL,'---
- 20c3
','2008-01-05','f',2);
INSERT INTO "events" VALUES(786,'import-3a321d392c06b04b13','20C3-600-RFID.gif','',23,'2014-05-10 13:26:31.293794','2014-06-27 13:57:52.555945','rfid (600)','20C3-600-RFID.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/600.en.html','--- []
','20C3-600-RFID',NULL,'---
- 20c3
','2008-01-05','f',4);
INSERT INTO "events" VALUES(787,'import-af83df1b1cdc8049c6','20C3-633-Fnord_Jahresrueckschau.gif','',23,'2014-05-10 13:26:31.305099','2014-06-27 13:11:49.451925','Fnord-Jahresrückschau','20C3-633-Fnord_Jahresrueckschau.jpg','2003-01-01','Was wäre die Zeit vor Sylvester ohne einen Jahresrückblick? Dieser Jahresrückblick wird chronologisch einige Meldungen aus teilweise eher obskuren und alternativen Quellen aufgreifen, um so für den sich nur über Heise und Tagesschau informierenden Geek mal live zu zeigen, was er so an Tagesgeschehen verpaßt hat. Die Veranstaltung ist nicht bloß als Vorlesung oder Alternativ-Tagesschau gedacht, sondern soll durchaus auch in eine Diskussion münden, wie man sich am besten von den gleichgeschalteten Medien emanzipieren kann.
','http://www.ccc.de/congress/2003/fahrplan/event/633.en.html','--- []
','20C3-633-Fnord_Jahresrueckschau',NULL,'---
- 20c3
','2008-01-05','f',1);
INSERT INTO "events" VALUES(788,'import-e0385b5ff2224635db','20C3-537-WSIS_Overview.gif','',23,'2014-05-10 13:26:31.316553','2014-06-27 13:16:36.590034','WSIS - An Overview','20C3-537-WSIS_Overview.jpg','2003-12-28','Lessons learned and steps ahead for activists, lobbyists and protesters
','http://www.ccc.de/congress/2003/fahrplan/event/537.en.html','---
- Markus Beckedahl
- Rikke Frank Jørgensen
- Ralf Bendrath
','20C3-537-WSIS_Overview','The World Summit on the Information Society Revisited','---
- 20c3
','2008-01-05','f',2);
INSERT INTO "events" VALUES(789,'import-22d7fca70258bbf57a','20C3-531-NOC_Preview.gif','',23,'2014-05-10 13:26:31.327896','2014-05-10 13:26:31.327896','NOC Preview','20C3-531-NOC_Preview.jpg','2003-12-27','An introduction to the features and capabilities of the computer network at 20C3. We explain how to use IPsec, IPv6 and 802.11a and 802.11b wireless networks.
','http://www.ccc.de/congress/2003/fahrplan/event/531.en.html','---
- cpunkt
','20C3-531-NOC_Preview',NULL,'---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(790,'import-c429172db8cd508503','20C3-542-Trusted_or_Treacherous.gif','',23,'2014-05-10 13:26:31.339324','2014-05-10 13:26:31.339324','Trusted or Treacherous?','20C3-542-Trusted_or_Treacherous.jpg','2003-12-27','Mit der im November 2003 in Amsterdam veröffentlichten TCG 1.2 Spezifikation hat die Trusted Comupting Group erste Schritte in Richtung der Nutzerinteressen gemacht. Eine erste Analyse zeigte jedoch, dass für "Normal-Anwender" zentrale Probleme bestehen bleiben.
','http://www.ccc.de/congress/2003/fahrplan/event/542.en.html','---
- Rüdiger Weis
- Andreas Bogk
','20C3-542-Trusted_or_Treacherous','Eine erste Einschätzung des neuen TCG1.2 Entwurfes.','---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(791,'import-233dfe79ff211f03a1','20C3-555-Eroeffnung.gif','',23,'2014-05-10 13:26:31.350818','2014-06-27 14:21:38.886943','Eröffnung','20C3-555-Eroeffnung.jpg','2003-12-27','Eröffnung des 20. Chaos Communication Congress und organisatorische Hinweise von Nerd zu Nerd. Im Anschluß: erste öffentliche Präsentation des Dokumentationsvideos des Chaos Communication Camps.
','http://www.ccc.de/congress/2003/fahrplan/event/555.en.html','---
- Tim Pritlove
- Andy Müller-Maguhn
- Frank Rosengart
- Andreas Bogk
','20C3-555-Eroeffnung',NULL,'---
- 20c3
','2008-01-05','f',2);
INSERT INTO "events" VALUES(792,'import-c9abd3b976735dc512','20C3-576-Free_WLANs_for_the_masses.gif','',23,'2014-05-10 13:26:31.362185','2014-06-24 22:16:06.112676','Free WLANs for the masses','20C3-576-Free_WLANs_for_the_masses.jpg','2003-12-29','The presentation "Free WLAN for the Masses" talks about the vision of creating an open network of WiFi hotspots that provide alternative mobile Internet access.
','http://www.ccc.de/congress/2003/fahrplan/event/576.en.html','---
- Jan Michael Hess
','20C3-576-Free_WLANs_for_the_masses',NULL,'---
- 20c3
- '' Hacking''
','2008-01-05','f',1);
INSERT INTO "events" VALUES(793,'import-5e16b5a09e0ffdc1da','20C3-SkoleLinux.gif','',23,'2014-05-10 13:26:31.373225','2014-06-27 12:02:11.6986','Skolelinux','20C3-SkoleLinux.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/631.en.html','--- []
','20C3-631-SkoleLinux',NULL,'---
- 20c3
','2009-06-22','f',1);
INSERT INTO "events" VALUES(794,'import-df3783d5d17fb941e9','20C3-550-ROCK-Linux_Das_Tool_zum_Erstellen_von_Distros.gif','',23,'2014-05-10 13:26:31.384266','2014-06-27 11:01:25.761052','linux das tool zum erstellen von distros (550-rock)','20C3-550-ROCK-Linux_Das_Tool_zum_Erstellen_von_Distros.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/550.en.html','--- []
','20C3-550-ROCK-Linux_Das_Tool_zum_Erstellen_von_Distros',NULL,'---
- 20c3
','2008-01-05','f',1);
INSERT INTO "events" VALUES(795,'import-4fe70f274d636f9fcb','20C3-637-Distributed_Computing.gif','',23,'2014-05-10 13:26:31.395434','2014-05-10 13:26:31.395434','distributed computing (637)','20C3-637-Distributed_Computing.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/637.en.html','--- []
','20C3-637-Distributed_Computing',NULL,'---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(796,'import-802e39aaed267dfb47','20C3-591-Berichte_von_den_Big_Brother_Awards.gif','',23,'2014-05-10 13:26:31.406592','2014-05-10 13:26:31.406592','Berichte von den Big Brother Awards','20C3-591-Berichte_von_den_Big_Brother_Awards.jpg','2003-12-27','Die BigBrotherAwards Deutschland wurden ins Leben gerufen, um die öffentliche Diskussion um Privatsphäre und Datenschutz zu fördern - sie sollen missbräuchlichen Umgang mit Technik und Informationen zeigen. Seit 1998 wird ein solcher Preis in England, 1999 in Östererich und seit dem Jahr 2000 auch in Deutschland an Firmen, Organisationen und Personen verliehen, die in besonderer Weise und nachhaltig die Privatsphäre von Menschen beeinträchtigen oder persönliche Daten Dritten zugänglich machen. Zurzeit wird der Preis in 14 Ländern weltweit verliehen.
','http://www.ccc.de/congress/2003/fahrplan/event/591.en.html','---
- Christian Mock
- Rena Tangens
- Matthias Geiser
','20C3-591-Berichte_von_den_Big_Brother_Awards',NULL,'---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(797,'import-99180de8618aece534','20C3-557-Ein_Rant_ueber_den_Missbrauch_von_Java_HTTP_und_XML.gif','',23,'2014-05-10 13:26:31.418135','2014-07-07 14:50:32.919032','Ein Rant über den Missbrauch von Java, HTTP und XML','20C3-557-Ein_Rant_ueber_den_Missbrauch_von_Java_HTTP_und_XML.jpg','2003-12-27','Die heutige Softwareindustrie verlässt sich auf so entscheidende Technologien wie Java, HTTP und XML. Unglücklicherweise werden diese drei Technologien in jeder erdenklichen Art und Weise eingesetzt, nur nicht in der ursprünglich dafür vorgesehenen. Dieser Vortrag zeigt anhand von Originalzitaten und Beispielen aus der Praxis, wofuer Java, HTTP und XML gedacht waren, und wie sie in Wirklichkeit eingesetzt werden.
','http://www.ccc.de/congress/2003/fahrplan/event/557.en.html','---
- Andreas Krennmair
','20C3-557-Ein_Rant_ueber_den_Missbrauch_von_Java_HTTP_und_XML',NULL,'---
- 20c3
','2008-01-05','f',4);
INSERT INTO "events" VALUES(798,'import-1c79c2ce56e02c06d9','20C3-598-Trust_based_P2P_WYMIWYG_KnoBot_project.gif','',23,'2014-05-10 13:26:31.5009','2014-05-10 13:26:31.5009','Trustbased P2P exchange on the semantic web and the WYMIWYG KnoBot project','20C3-598-Trust_based_P2P_WYMIWYG_KnoBot_project.jpg','2003-12-29','
','http://www.ccc.de/congress/2003/fahrplan/event/598.en.html','---
- Reto Bachmann-Gmuer
','20C3-598-Trust_based_P2P_WYMIWYG_KnoBot_project','An agent for decentralised knowledge exchange','---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(799,'import-eb8873e1925f207dc7','20C3-603-Spam_Analyse.gif','',23,'2014-05-10 13:26:31.512777','2014-05-10 13:26:31.512777','spam analyse (603)','20C3-603-Spam_Analyse.jpg','2003-01-01','
','http://www.ccc.de/congress/2003/fahrplan/event/603.en.html','--- []
','20C3-603-Spam_Analyse',NULL,'---
- 20c3
','2008-01-05','f',0);
INSERT INTO "events" VALUES(1721,'import-484b5c4ab1387290dd','5552-h264-hq.gif','5552-h264-hq_preview.jpg',33,'2014-05-10 13:27:00.772934','2014-07-10 20:19:38.264541','India''s Surveillance State','5552-h264-hq.jpg','2013-12-29','India is currently implementing some of the scariest surveillance schemes in the world. This lecture will shed light on India''s surveillance industry, its UID scheme which aims at the collection of all biometric data and on various controversial surveillance schemes, such as the Central Monitoring System (CMS).  
','http://events.ccc.de/congress/2013/Fahrplan/events/5552.html','---
- Maria Xynou
','30C3_-_5552_-_en_-_saal_g_-_201312291130_-_india_s_surveillance_state_-_maria_xynou',NULL,'---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-29','f',21);
INSERT INTO "events" VALUES(1722,'import-9f58f45551eb19acbe','5533-h264-hq.gif','5533-h264-hq_preview.jpg',33,'2014-05-10 13:27:00.80663','2014-07-11 20:38:32.677829','Fast Internet-wide Scanning and its Security Applications','5533-h264-hq.jpg','2013-12-28','Internet-wide network scanning has powerful security applications, including exposing new vulnerabilities, tracking their mitigation, and exposing hidden services.  Unfortunately, probing the entire public address space with standard tools like Nmap requires either months of time or large clusters of machines.  In this talk, I''ll demonstrate <a href="https://zmap.io">ZMap</a>, an open-source network scanner developed by my research group that is designed from the ground up to perform Internet-wide scans efficiently.  We''ve used ZMap with a gigabit Ethernet uplink to survey the entire IPv4 address space in under 45 minutes from a single machine, more than 1300 times faster than Nmap.  I''ll explain how ZMap''s architecture enables such high performance.  We''ll then work through a series of practical examples that explore the security applications of very fast Internet-scale scanning, both offensive and defensive.  I''ll talk about results and experiences from conducting more than 300 Internet-wide scans over the past 18 months, including new revelations about the state of the HTTPS CA ecosystem.  I''ll discuss the reactions our scans have generated--on one occasion we were mistaken for an Iranian attack against U.S. banks and we received a visit from the FBI--and I''ll suggest guidelines and best practices for good Internet citizenship while scanning.
','http://events.ccc.de/congress/2013/Fahrplan/events/5533.html','---
- J. Alex Halderman
','30C3_-_5533_-_en_-_saal_2_-_201312281245_-_fast_internet-wide_scanning_and_its_security_applications_-_j_alex_halderman',NULL,'---
- 30c3
- Security & Safety
','2013-12-28','f',21);
INSERT INTO "events" VALUES(1723,'import-66243d73dcdf7e9846','5577-h264-hq.gif','5577-h264-hq_preview.jpg',33,'2014-05-10 13:27:00.835678','2014-07-11 12:56:13.392173','Hacker Jeopardy','5577-h264-hq.jpg','2013-12-27','The Hacker Jeopardy is a quiz show.
','http://events.ccc.de/congress/2013/Fahrplan/events/5577.html','---
- Sec
- Ray
','30C3_-_5577_-_de_-_saal_1_-_201312280000_-_hacker_jeopardy_-_sec_-_ray','Zahlenraten für Geeks [Number guessing for geeks]','---
- 30c3
- Entertainment
','2014-01-01','f',25);
INSERT INTO "events" VALUES(1724,'import-0d8ba73453069b57a6','5394-h264-iprod.gif','5394-h264-iprod_preview.jpg',33,'2014-05-10 13:27:00.864408','2014-06-27 21:30:35.062255','BREACH in Agda','5394-h264-iprod.jpg','2013-12-28','Software engineering is in a unsustainable state: software is mainly developed in a trial and error fashion, which always leads to vulnerable systems. Several decades ago the correspondence between logics and programming (Curry-Howard) was found. This correspondence is now being used in modern programming languages using dependent types, such as Agda, Coq, and Idris.

In this talk I show our development of attacks and security notions within Agda, using the recent <a href="https://en.wikipedia.org/wiki/BREACH_%28security_exploit%29">BREACH</a> exploit as an example. Our development is a constructive step towards verified software and bridges a gap between theory and practice.
I will explain the details about the Curry-Howard correspondence.
The target audience are interested people with some programming experience.
','http://events.ccc.de/congress/2013/Fahrplan/events/5394.html','---
- Nicolas Pouillard
','30C3_-_5394_-_en_-_saal_g_-_201312281130_-_breach_in_agda_-_nicolas_pouillard','Security notions, proofs and attacks using dependently typed functional programming','---
- 30c3
- Science & Engineering
','2013-12-31','f',3);
INSERT INTO "events" VALUES(1725,'import-b594cfccf637ca2def','5550-h264-hq.gif','5550-h264-hq_preview.jpg',33,'2014-05-10 13:27:00.893152','2014-07-08 20:13:23.999907','Beyond the Tech: Building Internet Freedom Tools for Real People','5550-h264-hq.jpg','2013-12-30','Few hackers will disagree that users are not given enough consideration when building Internet Freedom Tools designed to circumvent censorship and surveillance. But how do we do it? This talk will outline a framework for a user-focused approach to the Development and Impact of Internet Freedom Tools through using ethnography, human-centered design, and the practice of research-based product definition. This talk is intended for developers, researchers, and journalists who seek to understand how better tools can be developed to protect anonymity and provide unfettered access to the Internet.
','http://events.ccc.de/congress/2013/Fahrplan/events/5550.html','---
- Michael Brennan
','30C3_-_5550_-_en_-_saal_g_-_201312301130_-_beyond_the_tech_building_internet_freedom_tools_for_real_people_-_michael_brennan',NULL,'---
- 30c3
- Science & Engineering
','2013-12-31','f',4);
INSERT INTO "events" VALUES(1726,'import-476678ae3ead58116c','5476-h264-hq.gif','5476-h264-hq_preview.jpg',33,'2014-05-10 13:27:00.921952','2014-07-11 10:52:39.461379','Electronic Bank Robberies','5476-h264-hq.jpg','2013-12-27','This talk will discuss a case in which criminals compromised and robbed an ATM by infecting it with specially crafted malware. The successful compromise of an ATM can easily result in the loss of several hundred thousand dollars.
','http://events.ccc.de/congress/2013/Fahrplan/events/5476.html','---
- tw
- sb
','30C3_-_5476_-_en_-_saal_2_-_201312271600_-_electronic_bank_robberies_-_tw_-_sb','Stealing Money from ATMs with Malware','---
- 30c3
- Security & Safety
','2013-12-28','f',61);
INSERT INTO "events" VALUES(1727,'import-bb1bb3db3dba51d66a','5475-h264-iprod.gif','5475-h264-iprod_preview.jpg',33,'2014-05-10 13:27:00.950795','2014-07-05 15:03:19.52474','#SOPA, #NSA, and the New Internet "Lobby"','5475-h264-iprod.jpg','2013-12-29','The movement against SOPA in the US was the largest protest in online history, and as one of the core organizers, we learned a lot of lessons on how to build a grassroots movement for internet freedom.
','http://events.ccc.de/congress/2013/Fahrplan/events/5475.html','---
- Elizabeth Stark
','30C3_-_5475_-_en_-_saal_g_-_201312291600_-_sopa_nsa_and_the_new_internet_lobby_-_elizabeth_stark',NULL,'---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-29','f',10);
INSERT INTO "events" VALUES(1728,'import-5e6dd0911ffe9368dd','5210-h264-hq.gif','5210-h264-hq_preview.jpg',33,'2014-05-10 13:27:00.979221','2014-07-12 09:17:20.141774','Bullshit made in Germany','5210-h264-hq.jpg','2013-12-28','Die technischen Probleme der De-Mail ließen sich juristisch lösen, und auch bei der E-Mail setzen deutsche Provider bald Sicherheitsstandards der Neunziger Jahre um. Auch für "die Cloud" hat das BSI einen feinen Standard parat – natürlich ohne Verschlüsselung. Wofür bräuchten wir die auch im Schlandnet?
','http://events.ccc.de/congress/2013/Fahrplan/events/5210.html','---
- Linus Neumann
','30C3_-_5210_-_de_-_saal_g_-_201312282030_-_bullshit_made_in_germany_-_linus_neumann','So hosten Sie Ihre De-Mail, E-Mail und Cloud direkt beim BND!','---
- 30c3
- Ethics
- Society & Politics
','2013-12-29','t',666);
INSERT INTO "events" VALUES(1729,'import-2d7efdd31acbffc3f0','5307-h264-hq.gif','5307-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.134887','2014-07-12 00:31:49.581235','Reverse engineering of CHIASMUS from GSTOOL','5307-h264-hq.jpg','2013-12-27','We reverse-engineered one implementation of the non-public CHIASMUS cipher designed by the German Federal Office for Information Security (Bundesamt für Sicherheit in der Informationstechnik, short BSI). This did not only give us some insight on the cipher, but also uncovered serious implementation issues in GSTOOL which allow attackers to crack files encrypted with the GSTOOL encryption function with very little effort.
','http://events.ccc.de/congress/2013/Fahrplan/events/5307.html','---
- Jan Schejbal
','30C3_-_5307_-_en_-_saal_2_-_201312271400_-_reverse_engineering_of_chiasmus_from_gstool_-_jan_schejbal','It hurts.','---
- 30c3
- Security & Safety
','2013-12-28','f',13);
INSERT INTO "events" VALUES(1730,'import-28dd01152a12855035','5212-h264-hq.gif','5212-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.165119','2014-07-09 17:57:15.121109','The GNU Name System','5212-h264-hq.jpg','2013-12-27','DNS, DNSSEC and the X.509 CA system leak private information about users to server operators and fail to provide adequate security against modern adversaries.  The fully decentralized GNU Name System provides a privacy-enhancing and censorship-resistant alternative.
','http://events.ccc.de/congress/2013/Fahrplan/events/5212.html','---
- grothoff
','30C3_-_5212_-_en_-_saal_6_-_201312272145_-_the_gnu_name_system_-_grothoff','A Decentralized PKI For Social Movements','---
- 30c3
- Security & Safety
','2013-12-28','f',14);
INSERT INTO "events" VALUES(1731,'import-21462b2220df0fa8a0','5479-h264-hq.gif','5479-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.195193','2014-07-01 02:01:01.736768','Building a safe NFC ticketing system','5479-h264-hq.jpg','2013-12-29','NFC technology is becoming more and more relevant in our lives. One of its major uses is in ticketing solutions. However, most of companies use bad implementations of NFC technology. By this talk we will explain a complete solution, analyzing security challenges and outlining the best practices and implementation choices.
','http://events.ccc.de/congress/2013/Fahrplan/events/5479.html','---
- bughardy
- Eagle1753
','30C3_-_5479_-_en_-_saal_6_-_201312291215_-_building_a_safe_nfc_ticketing_system_-_bughardy_-_eagle1753',NULL,'---
- 30c3
- Hardware & Making
','2013-12-29','f',10);
INSERT INTO "events" VALUES(1732,'import-f1a109dc2274fbca54','5425-h264-hq.gif','5425-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.22529','2014-07-05 21:27:10.320202','Hacking as Artistic Practice','5425-h264-hq.jpg','2013-12-28','!Mediengruppe Bitnik are contemporary artists. In their talk they will show two examples of their work, illustrating the translation of hacking from the computer field into an artistic practice. Bitnik will show how to hack the opera in ten easy steps and what happens when you send a parcel with a hidden live webcam to Julian Assange at the Ecuadorian Embassy in London. 

Using the strategies of hacking, !Mediengrupppe Bitnik intervenes into settings with the aim of opening them up to re-evaluation and new perspectives.
','http://events.ccc.de/congress/2013/Fahrplan/events/5425.html','---
- "!Mediengruppe Bitnik"
- "!Mediengruppe Bitnik"
','30C3_-_5425_-_en_-_saal_6_-_201312281900_-_hacking_as_artistic_practice_-_mediengruppe_bitnik_-_mediengruppe_bitnik','!Mediengruppe Bitnik about their recent works','---
- 30c3
- Art & Beauty
','2014-01-06','f',5);
INSERT INTO "events" VALUES(1733,'import-749be4b0d92bfb4d76','5529-h264-hq.gif','5529-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.314332','2014-07-10 18:19:52.22418','Hardening hardware and choosing a #goodBIOS','5529-h264-hq.jpg','2013-12-27','A commodity laptop is analyzed to identify exposed attack surfaces and is then secured on both the hardware and the firmware level against permanent modifications by malicious software as well as quick drive-by hardware attacks by evil maids, ensuring that the machine always powers up to a known good state and significantly raising the bar for an attacker who wants to use the machine against its owner.
','http://events.ccc.de/congress/2013/Fahrplan/events/5529.html','---
- Peter Stuge
','30C3_-_5529_-_en_-_saal_2_-_201312271830_-_hardening_hardware_and_choosing_a_goodbios_-_peter_stuge','Clean boot every boot -  rejecting persistence of malicious software and tripping up the evil maid','---
- 30c3
- Security & Safety
','2013-12-28','f',44);
INSERT INTO "events" VALUES(1734,'import-6785fd302cd8eccd95','5563-h264-hq.gif','5563-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.343846','2014-07-07 23:12:04.478388','Lightning Talks, Day 3','5563-h264-hq.jpg','2013-12-29','
','http://events.ccc.de/congress/2013/Fahrplan/events/5563.html','---
- nickfarr
','30C3_-_5563_-_en_-_saal_g_-_201312291245_-_lightning_talks_day_3_-_nickfarr',NULL,'---
- 30c3
- Other
','2013-12-29','f',9);
INSERT INTO "events" VALUES(1735,'import-7bad24bafb176ab7ea','5311-h264-hq.gif','5311-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.37297','2014-07-08 23:27:28.762362','lasers in space','5311-h264-hq.jpg','2013-12-27','This talk will give an introduction on lasers and space and it will show the huge diversity of applications for lasers in space.
','http://events.ccc.de/congress/2013/Fahrplan/events/5311.html','---
- anja
','30C3_-_5311_-_en_-_saal_6_-_201312271645_-_lasers_in_space_-_anja','more than just pew pew!','---
- 30c3
- Science & Engineering
','2013-12-28','f',17);
INSERT INTO "events" VALUES(1736,'import-105146b98b866f1a9b','5444-h264-iprod.gif','5444-h264-iprod_preview.jpg',33,'2014-05-10 13:27:01.401962','2014-07-10 17:07:49.282724','Attacking HomeMatic','5444-h264-iprod.jpg','2013-12-30','HomeMatic is a good working, inexpensive and quickly spreading home automation system supporting wired as well as (partly AES handshake protected) wireless communication. The first part of our talk deals with security issues of HomeMatic devices and their wireless communication protocol called BidCoS (Bidirectional Communication Standard). In the second part we introduce Homegear, our own interface software to control HomeMatic devices.
','http://events.ccc.de/congress/2013/Fahrplan/events/5444.html','---
- sathya
- Malli
','30C3_-_5444_-_en_-_saal_g_-_201312301600_-_attacking_homematic_-_sathya_-_malli',NULL,'---
- 30c3
- Security & Safety
','2013-12-31','f',53);
INSERT INTO "events" VALUES(1737,'import-1efd948ceb93256379','5582-h264-hq.gif','5582-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.431049','2014-07-04 21:41:31.706605','SCADA StrangeLove 2','5582-h264-hq.jpg','2013-12-28','SCADA StrangeLove team will present their research on ICS systems for the second time on CCC. Last year we showed current situation with security of industrial world and disclosed a big number of vulnerabilities found in Siemens ICS solutions. Part of vulnerabilities, we can say most notable one, wasn’t disclosed due to Responsible Disclosure. This time we already know. We will speak about several industrial protocols and their weaknesses. During this year we played with new industrial hardware and software – this patitially brings new “We don’t know yet” vulnerability details. Moreover, we’ll mention creepiest bugs undisclosed from last year, tell you about new ones and build attack vectors from them. At last, we will share our experience in pentesting ICS enviroments.

Speakers: Gleb Gritsai and Sergey Gordeychik
','http://events.ccc.de/congress/2013/Fahrplan/events/5582.html','---
- repdet
- sgordey
','30C3_-_5582_-_en_-_saal_2_-_201312282300_-_scada_strangelove_2_-_repdet_-_sgordey','We already know','---
- 30c3
- Security & Safety
','2013-12-28','f',32);
INSERT INTO "events" VALUES(1738,'import-b2767875cff62d0545','5483-h264-hq.gif','5483-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.460171','2014-07-02 15:44:33.552417','Europe, the USA and Identity Ecosystems','5483-h264-hq.jpg','2013-12-29','Talk introducing NSTIC and COM 238, i.e. the current digital identity policy proposals in the USA and European discussing their similarities, differences and possible conflicts.
',NULL,'---
- NoisyNarrowBandDevice
','30C3_-_5483_-_en_-_saal_2_-_201312291130_-_europe_the_usa_and_identity_ecosystems_-_noisynarrowbanddevice',NULL,'---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-29','f',10);
INSERT INTO "events" VALUES(1739,'import-d49b78f05730705f8a','5566-h264-hq.gif','5566-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.489236','2014-07-06 09:38:23.16504','Open source experimental incubator build up','5566-h264-hq.jpg','2013-12-28','This is a call for participation in a project aimed to build up an open source based experimental incubator which can be used for variety of food, beverage and bio hacking projects allowing for easy control and monitoring of internal condition like temperature and humidity. Working groups will be established to develop prototypes which can be easily and relatively cheaply assembled. Securing funding and establishing a portal to effectively share the news and knowledge within the groups and wider community will be major part of the first phase.
','http://events.ccc.de/congress/2013/Fahrplan/events/5566.html','---
- Frantisek Algoldor Apfelbeck
','30C3_-_5566_-_en_-_saal_6_-_201312281815_-_open_source_experimental_incubator_build_up_-_frantisek_algoldor_apfelbeck','call for participation in project and product development','---
- 30c3
- Hardware & Making
','2013-12-28','f',8);
INSERT INTO "events" VALUES(1740,'import-ecf694c28573f7454b','5186-h264-hq.gif','5186-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.51812','2014-07-12 00:10:24.672019','Programming FPGAs with PSHDL','5186-h264-hq.jpg','2013-12-28','Learning to program an FPGA is time consuming. Not just do you need to download and install 20 GB of vendor tools, but you also need to wrap your brain around the strange ideas of hardware description languages like VHDL. PSHDL aims to ease the learning curve significantly and provide more people with the ability to program FPGAs.
','http://events.ccc.de/congress/2013/Fahrplan/events/5186.html','---
- Karsten Becker
','30C3_-_5186_-_en_-_saal_6_-_201312282145_-_programming_fpgas_with_pshdl_-_karsten_becker','Let''s create the Arduino for FPGAs','---
- 30c3
- Hardware & Making
','2013-12-28','f',13);
INSERT INTO "events" VALUES(1741,'import-c00bf12f4c397cc8d6','5319-h264-hq.gif','5319-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.546949','2014-07-11 16:34:54.826932','Technomonopolies','5319-h264-hq.jpg','2013-12-28','We all know monopolies are bad. We even have laws against them that sometimes get enforced. However, today we have new kinds of monopolies that affect us without us even noticing them for what they truly are. And technology plays a central role.
','http://events.ccc.de/congress/2013/Fahrplan/events/5319.html','---
- rysiek
','30C3_-_5319_-_en_-_saal_g_-_201312282330_-_technomonopolies_-_rysiek','How technology is used to subvert and circumvent anti-monopoly laws','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-29','f',10);
INSERT INTO "events" VALUES(1742,'import-cac821c5179ab8dbbe','5420-h264-hq.gif','5420-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.575565','2014-07-06 21:25:57.779859','calc.pw','5420-h264-hq.jpg','2013-12-29','Bei calc.pw handelt es sich um DIY Hardware, mit deren Hilfe man Passwörter aus einem Masterpasswort und einfach merkbaren Informationen (z. B. "ebay", "amazon", etc.) generieren kann. Im Vortrag soll es um die Probleme vorhandener Passwortverfahren (Passwortschemen, Passwortdatenbanken) gehen. Es soll die Theorie hinter der Passwortberechnung erläutert und eine praktische Implementierung dieser Berechnung vorgestellt werden.
','http://events.ccc.de/congress/2013/Fahrplan/events/5420.html','---
- Kenneth Newwood
','30C3_-_5420_-_de_-_saal_6_-_201312291345_-_calc_pw_-_kenneth_newwood','Passwortgenerierung mit Arduino  [Generating passwords with Arduino]','---
- 30c3
- Hardware & Making
','2013-12-29','f',10);
INSERT INTO "events" VALUES(1743,'import-3bbc9a2d9ce9e4f9fc','5713-h264-hq.gif','5713-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.604202','2014-07-12 10:27:47.746108','To Protect And Infect, Part 2','5713-h264-hq.jpg','2013-12-30','
','http://events.ccc.de/congress/2013/Fahrplan/events/5713.html','---
- Jacob
','30C3_-_5713_-_en_-_saal_2_-_201312301130_-_to_protect_and_infect_part_2_-_jacob','The militarization of the Internet','---
- 30c3
- Security & Safety
','2014-01-01','t',319);
INSERT INTO "events" VALUES(1744,'import-7912b9b46c3f0af5c0','5440-h264-hq.gif','5440-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.632625','2014-07-09 13:05:33.879528','Art of the Exploit: An Introduction to Critical Engineering','5440-h264-hq.jpg','2013-12-28','In this lecture Julian will introduce projects and interventions made by himself and others that foreground Engineering, rather than Art, in the creative and critical frame, offering highly public insights into the hidden mechanisms and power struggles within our technical environment. Projects such as the <i>Transparency Grenade</i>, <i>Packetbruecke</i> and <i>Newstweek</i> will be covered in detail.
','http://events.ccc.de/congress/2013/Fahrplan/events/5440.html','---
- Julian Oliver
','30C3_-_5440_-_en_-_saal_2_-_201312282145_-_art_of_the_exploit_an_introduction_to_critical_engineering_-_julian_oliver',NULL,'---
- 30c3
- Art & Beauty
','2013-12-29','f',22);
INSERT INTO "events" VALUES(1745,'import-093424389eb158ff35','5453-h264-hq.gif','5453-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.661204','2014-07-04 07:53:40.206433','Against Metadata','5453-h264-hq.jpg','2013-12-28','Using case studies of documentary film, Freedom of Information Law document dumps, soundbanks, and a hacker conference, I will demonstrate experiments and results of several years developing open source tools to reorient the idea of documentary around its documents. This is in opposition to a tendancy towards textual and machine-readable metadata, which unduly constrain our wonder, perception, and ability to navigate ambiguous and unknown material.
','http://events.ccc.de/congress/2013/Fahrplan/events/5453.html','---
- Robert M Ochshorn
','30C3_-_5453_-_en_-_saal_6_-_201312281600_-_against_metadata_-_robert_m_ochshorn','Twisting time and space to explore the unknown','---
- 30c3
- Art & Beauty
','2013-12-29','f',9);
INSERT INTO "events" VALUES(1746,'import-670179f7df26506692','5304-h264-hq.gif','5304-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.814934','2014-07-12 08:52:42.60943','CounterStrike','5304-h264-hq.jpg','2013-12-29','Lawful Interception is a monitoring access for law enforcement agencies, but also one of the primary data sources of many surveillance programs. (Almost?) every Internet service provider needs to provide LI functionality in its routers. However, LI exposes a larger attack surface to the one being surveilled than any router should. Could this be a mistake?
','http://events.ccc.de/congress/2013/Fahrplan/events/5304.html','---
- FX
','30C3_-_5304_-_en_-_saal_1_-_201312292315_-_counterstrike_-_fx','Lawful Interception','---
- 30c3
- Security & Safety
','2014-01-03','f',76);
INSERT INTO "events" VALUES(1747,'import-1f04461b32413400de','5607-h264-hq.gif','5607-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.8452','2014-07-08 22:24:49.573962','The Pirate Cinema','5607-h264-hq.jpg','2013-12-28','"The Pirate Cinema" reveals Peer-to-Peer information flows. It is a composition generated by the activity on file sharing networks. "The Pirate Cinema" immerses the viewer in network flows.
','http://events.ccc.de/congress/2013/Fahrplan/events/5607.html','---
- Nicolas Maigret
- Brendan Howell
','30C3_-_5607_-_en_-_saal_6_-_201312281645_-_the_pirate_cinema_-_nicolas_maigret_-_brendan_howell','Creating mash-up movies by hidden activity and geography of Peer-to-Peer file sharing','---
- 30c3
- Art & Beauty
','2013-12-29','f',23);
INSERT INTO "events" VALUES(1748,'import-8650b5037f9c5e39b4','5502-h264-hq.gif','5502-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.875929','2014-07-11 23:50:35.205135','Zwischen supersicherer Verschlüsselung und Klartext liegt nur ein falsches Bit ','5502-h264-hq.jpg','2013-12-29','»Lange Schlüssel sind sicherer als kurze.«
»RSA und/oder AES sind einfach zu implementieren.«
»Für Zufallszahlen reicht es, java.util.Random zu nehmen.«
Solche oder ähnliche Aussagen hört man immer mal wieder. Doch was ist da dran? Welche Fehler werden bei der Benutzung und Implementierung von Kryptografie gern gemacht?
','http://events.ccc.de/congress/2013/Fahrplan/events/5502.html','---
- qbi
','30C3_-_5502_-_de_-_saal_2_-_201312292300_-_zwischen_supersicherer_verschlusselung_und_klartext_liegt_nur_ein_falsches_bit_-_qbi','Ein Streifzug durch die Fehler in der Kryptografie ','---
- 30c3
- Security & Safety
','2013-12-29','f',14);
INSERT INTO "events" VALUES(1749,'import-78b01f9b65a84c132c','5281-h264-hd.gif','5281-h264-hd_preview.jpg',33,'2014-05-10 13:27:01.90721','2014-07-11 13:43:43.311468','Keine Anhaltspunkte für flächendeckende Überwachung','5281-h264-hd.jpg','2013-12-27','Die Enthüllungen Edward Snowdens haben die deutsche Politik für kurze Zeit in Aufregung gebracht. Für eine Beruhigung reichte es bereits aus, die Enthüllungen in sprachlich-logisch cleverer Weise zu verarbeiten, sie teilweise in ein anderen Kontext zu stellen und so schließlich Entwarnung geben zu können: Die Bundesregierung hat „keine Anhaltspunkte für flächendeckende Überwachung“.

Bei diesem Vorgehen handelt sich um ein Paradebeispiel dafür, wie mit einfachen sprachlich-rhetorischen Tricks die politisch Verantwortlichen die Öffentlichkeit und sich selbst so weit täuschten, dass es ihnen nicht mehr nötig erschien, sich mit den eigentlichen Problemen auseinanderzusetzen, und so das leidige Thema aus dem Wahlkampf herausgehalten werden konnte. Neben den mittlerweile zum Standard gehörenden „Basta“-Floskeln spielte das Phänomen der Modalisierung eine besondere Rolle, wie die genauere Analyse zeigt. Auch logische Fehler wie Zirkelschlüssel und (zu) strikte Einschränkung des thematischen Bezugs erlaubten diese „Flucht-nach-vorne“-Strategie. Die Häufung sprachlicher Tricks und des logisch-inhaltlichen Ausweichens legen eine Inszenierung nahe.
','http://events.ccc.de/congress/2013/Fahrplan/events/5281.html','---
- Martin Haase/maha
- khamacher
','30C3_-_5281_-_de_-_saal_1_-_201312271400_-_keine_anhaltspunkte_fur_flachendeckende_uberwachung_-_martin_haase_maha_-_khamacher','Die Diskussion um NSA, PRISM, Tempora sprachlich und logisch aufgearbeitet','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-31','f',25);
INSERT INTO "events" VALUES(1750,'import-cc595cff48d14dbb3d','5289-h264-hq.gif','5289-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.947253','2014-07-09 02:24:40.567241','Coding your body','5289-h264-hq.jpg','2013-12-30','The average movement habits of a clichè hacker are legendary. Cowering for days in front of unergonomic hardware setups, stoic ignorance of hardly decodeable signs of the body like hunger, eye- and backpains. Probably due to a general disinterest in non-digitally engineered systems.

Shouldn’t a true hacker know at least bits and pieces about the codes and signs of the body? We all know bits and pieces.. but are they the correct and helpful ones? We will discuss some technical and biological details of slipped discs, posture disservice and pain. I will show fundamental “red flags” which have to be serviced by a medical geek. But not all medical geeks have a good idea about the body''s code, therefore I will also suggest some helpful therapies for the most common cases.
Bottom line: how to code your body to prevent pain without relying on smattering.
','http://events.ccc.de/congress/2013/Fahrplan/events/5289.html','---
- Sophie Hiltner
','30C3_-_5289_-_en_-_saal_6_-_201312301215_-_coding_your_body_-_sophie_hiltner','How to decipher the messages of your body','---
- 30c3
- Science & Engineering
','2013-12-31','f',4);
INSERT INTO "events" VALUES(1751,'import-4f5e1dfbb327419493','5526-h264-hq.gif','5526-h264-hq_preview.jpg',33,'2014-05-10 13:27:01.982322','2014-07-08 23:46:50.652055','How to Build a Mind','5526-h264-hq.jpg','2013-12-29','A foray into the present, future and ideas of Artificial Intelligence. Are we going to build (beyond) human-level artificial intelligence one day? Very likely. When? Nobody knows, because the specs are not fully done yet. But let me give you some of those we already know, just to get you started.
','http://events.ccc.de/congress/2013/Fahrplan/events/5526.html','---
- Joscha
','30C3_-_5526_-_en_-_saal_2_-_201312291600_-_how_to_build_a_mind_-_joscha','Artificial Intelligence Reloaded','---
- 30c3
- Science & Engineering
','2013-12-29','f',30);
INSERT INTO "events" VALUES(1752,'import-7ea97299ce826ad8d3','5376-h264-iprod.gif','5376-h264-iprod_preview.jpg',33,'2014-05-10 13:27:02.01597','2014-07-11 21:26:53.519763','Do You Think That''s Funny?','5376-h264-iprod.jpg','2013-12-27','This lecture shall give a first person account of how circumstances have dramatically changed for actionist art practice over the last 15 years. I will use examples from my own art practice to show the  impossibility to engange in digital and real-life actionism as they are considered criminal under anti-terrorist laws.
','http://events.ccc.de/congress/2013/Fahrplan/events/5376.html','---
- lizvlx
','30C3_-_5376_-_en_-_saal_1_-_201312271130_-_do_you_think_that_s_funny_-_lizvlx','Art Practice under the Regime of Anti-Terror Legislation','---
- 30c3
- Art & Beauty
','2014-01-03','f',20);
INSERT INTO "events" VALUES(1753,'import-74d1b75990e182d68e','5605-h264-hq.gif','5605-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.049975','2014-07-11 12:38:40.172302','Opening Event','5605-h264-hq.jpg','2013-12-27','Introductory event to say hello to everybody, give a brief overview of the event''s features and look into history and future alike
','http://events.ccc.de/congress/2013/Fahrplan/events/5605.html','---
- Tim Pritlove
','30C3_-_5605_-_en_-_saal_1_-_201312271100_-_opening_event_-_tim_pritlove','Welcome to the 30th Chaos Communication Congress','---
- 30c3
- CCC
','2013-12-31','f',35);
INSERT INTO "events" VALUES(1754,'import-a0f73aced08763622c','5361-h264-hq.gif','5361-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.08129','2014-07-07 23:11:40.55811','Disclosure DOs, Disclosure DON''Ts','5361-h264-hq.jpg','2013-12-28','This talk will focus on responsible disclosure best and worst practices from both legal and practical perspectives. I''ll also focus on usable advice, both positive and negative, and answer any questions the audience has on best practices.
','http://events.ccc.de/congress/2013/Fahrplan/events/5361.html','---
- Nate Cardozo
','30C3_-_5361_-_en_-_saal_6_-_201312282300_-_disclosure_dos_disclosure_don_ts_-_nate_cardozo','Pragmatic Advice for Security Researchers','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-29','f',9);
INSERT INTO "events" VALUES(1755,'import-d4a0e2a58706970133','5387-h264-hq.gif','5387-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.112994','2014-07-07 23:14:03.634726','Toward a Cognitive "Quantified Self" ','5387-h264-hq.jpg','2013-12-27','The talk gives an overview about our work of quantifying knowledge acquisition tasks in real-life environments, focusing on reading. We combine several pervasive sensing approaches (computer vision, motion-based activity recognition etc.) to tackle the problem of recognizing and classifying knowledge acquisition tasks with a special focus on reading. We discuss which sensing modalities can be used for digital and offline reading recognition, as well as how to combine them dynamically.
','http://events.ccc.de/congress/2013/Fahrplan/events/5387.html','---
- Kai
','30C3_-_5387_-_en_-_saal_6_-_201312272030_-_toward_a_cognitive_quantified_self_-_kai','Activity Recognition for the Mind','---
- 30c3
- Science & Engineering
','2013-12-28','f',11);
INSERT INTO "events" VALUES(1756,'import-f6790d3b115ae448f8','5491-h264-hd.gif','5491-h264-hd_preview.jpg',33,'2014-05-10 13:27:02.142305','2014-07-11 21:44:34.797398','No Neutral Ground in a Burning World','5491-h264-hd.jpg','2013-12-27','The news of the past few years is one small ripple in what is a great wave of culture and history, a generational clash of civilizations.  If you want to understand why governments are acting and reacting the way they are, and as importantly, how to shift their course, you need to understand what they''re reacting to, how they see and fail to see the world, and how power, money, and idea of rule of law actually interact.
','http://events.ccc.de/congress/2013/Fahrplan/events/5491.html','---
- Quinn Norton
- Eleanor Saitta
','30C3_-_5491_-_en_-_saal_1_-_201312272300_-_no_neutral_ground_in_a_burning_world_-_quinn_norton_-_eleanor_saitta',NULL,'---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-31','f',29);
INSERT INTO "events" VALUES(1757,'import-66a770e0c76f461997','5601-h264-hq.gif','5601-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.176559','2014-07-02 19:33:33.294566','EUDataP: State of the Union','5601-h264-hq.jpg','2013-12-28','Jan Phillip Albrecht is rapporteur of the European Parliament for the EU''s General Data Protection Regulation as well as for the EU-US data protection framework agreement.
','http://events.ccc.de/congress/2013/Fahrplan/events/5601.html','---
- Jan Philipp Albrecht
','30C3_-_5601_-_en_-_saal_2_-_201312281400_-_eudatap_state_of_the_union_-_jan_philipp_albrecht',NULL,'---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-28','f',4);
INSERT INTO "events" VALUES(1758,'import-17669d34274587d239','5398-h264-hq.gif','5398-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.206672','2014-07-11 18:27:46.686483','HbbTV Security','5398-h264-hq.jpg','2013-12-27','HbbTV (Hybrid broadband broadcast TV) is an emerging standard that is implemented in a growing number of smart TV devices. The idea is to bundle broadcast media content with online content which can be retrieved by the TV set through an Internet connection.

Mechanisms that allow the online content to be accessed by the TV set can be attacked and might put the TV user’s privacy at stake. The presentation highlights possible attack vectors of HbbTV-capable TV sets and introduces possible mitigations.
','http://events.ccc.de/congress/2013/Fahrplan/events/5398.html','---
- Martin Herfurt
','30C3_-_5398_-_en_-_saal_2_-_201312272300_-_hbbtv_security_-_martin_herfurt','OMG - my Smart TV got pr0wn3d','---
- 30c3
- Security & Safety
','2013-12-28','f',41);
INSERT INTO "events" VALUES(1759,'import-1c3e8a850095845817','5348-h264-hq.gif','5348-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.235925','2014-07-09 12:06:47.209263','Der Kampf um Netzneutralität','5348-h264-hq.jpg','2013-12-27','Seit Jahren nur in Fachzirkeln diskutiert gab es 2013 den Durchbruch für die Debatte um Netzneutralität. Mit der Ankündigung der Deutschen Telekom im Frühjahr, zukünftig auf Volumentarife umzusteigen und Partnerdienste priorisiert durchzulassen, wurde Netzneutralität eines der meistdiskutierten netzpolitischen Debatten des Jahres.

Auf nationaler Ebene startete das Bundeswirtschaftsminsiterium eine Diskussion über eine Verordnung und auf EU-Ebene legte die Kommission einen Verordnungsvorschlag vor.
','http://events.ccc.de/congress/2013/Fahrplan/events/5348.html','---
- Markus Beckedahl
- Thomas Lohninger
','30C3_-_5348_-_de_-_saal_2_-_201312272145_-_der_kampf_um_netzneutralitat_-_markus_beckedahl_-_thomas_lohninger','Wer kontrolliert das Netz?','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-28','f',31);
INSERT INTO "events" VALUES(1760,'import-4bb5dd7f4672eb85bb','5295-h264-iprod.gif','5295-h264-iprod_preview.jpg',33,'2014-05-10 13:27:02.264977','2014-07-11 23:54:46.858409','The Four Wars','5295-h264-iprod.jpg','2013-12-29','Based on her own experiences as an Intelligence Officer for MI5 (the UK domestic security service) and a whistleblower, Annie Machon will talk about the relationships between the wars on ''terror'', drugs, whistleblowers, and the internet, and suggest some ideas about what we can do.
','http://events.ccc.de/congress/2013/Fahrplan/events/5295.html','---
- Annie Machon
','30C3_-_5295_-_en_-_saal_1_-_201312292030_-_the_four_wars_-_annie_machon','Terror, whistleblowers, drugs, internet','---
- 30c3
- Ethics
- " Society & Politics"
','2014-01-01','f',19);
INSERT INTO "events" VALUES(1761,'import-02c636fca08040f3ef','5293-h264-hq.gif','5293-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.293517','2014-07-11 23:13:02.518618','Dead Man Edition','5293-h264-hq.jpg','2013-12-30','Die alarmierenden Zustände beim Abbau der Rohstoffe, die in den Bauteilen (z. B. dem Tantal-Elektrolytkondensator) eines Computers stecken, rufen Menschenrechtler auf den Plan. In den U.S.A. ist es 2010 gelungen, ein umstrittenes Gesetz umzusetzen, das die Finanzierung von Kriegsparteien durch Erzhandel regulieren soll. In der EU soll nun ähnliches geschehen. Der Vortrag klärt über die Geschichte auf, nennt Konsequenzen und formuliert Forderungen. 
','http://events.ccc.de/congress/2013/Fahrplan/events/5293.html','---
- Sebastian Jekutsch
','30C3_-_5293_-_de_-_saal_6_-_201312301600_-_dead_man_edition_-_sebastian_jekutsch','Auf dem Weg zu fairer Elektronik am Beispiel der Elkos  [The way to fair electronics, by example of capacitors]','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-31','f',9);
INSERT INTO "events" VALUES(1762,'import-51ea02616da4a40487','5467-h264-iprod.gif','5467-h264-iprod_preview.jpg',33,'2014-05-10 13:27:02.322254','2014-07-11 23:39:23.777229','Warum die Digitale Revolution des Lernens gescheitert ist.','5467-h264-iprod.jpg','2013-12-30','Der digitale Wandel hat uns grandiose Chancen für selbstbestimmtes, kreatives, kollaboratives, kritisches und demokratisches Lernen gebracht. Wir haben sie nicht genutzt.
','http://events.ccc.de/congress/2013/Fahrplan/events/5467.html','---
- Jöran Muuß-Merholz
','30C3_-_5467_-_de_-_saal_2_-_201312301245_-_warum_die_digitale_revolution_des_lernens_gescheitert_ist_-_joran_muuss-merholz','Fünf Desillusionen','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-31','f',14);
INSERT INTO "events" VALUES(1763,'import-8f1d95dc226798cffc','5609-h264-hq.gif','5609-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.350969','2014-06-30 11:30:38.092586','Infrastructure Review','5609-h264-hq.jpg','2013-12-30','
','http://events.ccc.de/congress/2013/Fahrplan/events/5609.html','---
- kay
- Peter Stuge
- florolf
- Sebastian
- "*m"
','30C3_-_5609_-_en_-_saal_6_-_201312301430_-_infrastructure_review_-_kay_-_peter_stuge_-_florolf_-_sebastian_-_m','Presentation of MOC/NOC/VOC/SOC/*OC','---
- 30c3
- CCC
','2014-01-06','f',7);
INSERT INTO "events" VALUES(1764,'import-e79766e3cf68e910e1','5294-h264-hq.gif','5294-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.503559','2014-07-12 08:14:19.205404','The Exploration and Exploitation of an SD Memory Card','5294-h264-hq.jpg','2013-12-29','All “managed FLASH” devices, such as SD, microSD, and SSD, contain an embedded controller to assist with the complex tasks necessary to create an abstraction of reliable, contiguous storage out of FLASH silicon that is fundamentally unreliable and unpredictably fragmented. This controller is an attack surface of interest. First, the ability to modify the block allocation and erasure algorithms introduces the opportunity to perform various MITM attacks in a virtually undetectable fashion. Second, the controller itself is typically powerful, with performance around 50MIPS, yet with a cost of mere pennies, making it an interesting and possibly useful development target for other non-storage related purposes. Finally, understanding the inner workings of the controller enables opportunities for data recovery in cards that are thought to have been erased, or have been partially damaged.

This talk demonstrates a method for reverse engineering and loading code into the microcontroller within a SD memory card.
','http://events.ccc.de/congress/2013/Fahrplan/events/5294.html','---
- bunnie
- Xobs
','30C3_-_5294_-_en_-_saal_1_-_201312291400_-_the_exploration_and_exploitation_of_an_sd_memory_card_-_bunnie_-_xobs','by xobs & bunnie','---
- 30c3
- Hardware & Making
','2014-01-03','f',163);
INSERT INTO "events" VALUES(1765,'import-f85b8f0891259bda11','5406-h264-hd.gif','5406-h264-hd_preview.jpg',33,'2014-05-10 13:27:02.536731','2014-07-06 23:15:58.192267','Drones','5406-h264-hd.jpg','2013-12-29','During the last 10 years the technology that was formerly only available to the military, reached the hands of thousands. Researchers, hackers, enthusiasts and hobbyists helped drive the technology further and higher than anyone had imagined just a few years ago. We will recap what the civilian airborne robot community has achieved in the last decade and what the next frontiers are that need to be addressed.
','http://events.ccc.de/congress/2013/Fahrplan/events/5406.html','---
- Piotr Esden-Tempski
','30C3_-_5406_-_en_-_saal_1_-_201312291245_-_drones_-_piotr_esden-tempski','Autonomous flying vehicles, where are we and where are we going?','---
- 30c3
- Science & Engineering
','2013-12-29','f',13);
INSERT INTO "events" VALUES(1766,'import-ccf4ca7ec31d400156','5545-h264-hd.gif','5545-h264-hd_preview.jpg',33,'2014-05-10 13:27:02.566783','2014-07-10 11:47:11.976436','Trezor: Bitcoin hardware wallet','5545-h264-hd.jpg','2013-12-29','TREZOR is a hardware wallet for Bitcoin. We identified security of the end users'' computer as one of the main problems that block Bitcoin mass adoption.
','http://events.ccc.de/congress/2013/Fahrplan/events/5545.html','---
- Pavol "stick" Rusnak
','30C3_-_5545_-_en_-_saal_1_-_201312292200_-_trezor_bitcoin_hardware_wallet_-_pavol_stick_rusnak',NULL,'---
- 30c3
- Hardware & Making
','2013-12-29','f',16);
INSERT INTO "events" VALUES(1767,'import-4b4a7f32770c554894','5537-h264-hd.gif','5537-h264-hd_preview.jpg',33,'2014-05-10 13:27:02.596755','2014-07-05 22:13:21.550248','Glass Hacks','5537-h264-hd.jpg','2013-12-28','A one hour technical lecture that covers everything from machine learning and AI to hardware design and manufacture. Includes demonstrations of applications enabled by an always-on image capturing wearable computer. You''ll leave with a clear understanding of the field''s status quo, how we got here, and insight into what''s around the corner.
','http://events.ccc.de/congress/2013/Fahrplan/events/5537.html','---
- Stephen Balaban
','30C3_-_5537_-_en_-_saal_1_-_201312281245_-_glass_hacks_-_stephen_balaban','Fun and frightening uses of always-on camera enabled wearable computers','---
- 30c3
- Science & Engineering
','2014-01-01','f',13);
INSERT INTO "events" VALUES(1768,'import-9a9094b4b41225fdde','5469-h264-hq.gif','5469-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.626835','2014-07-10 13:39:12.513644','2 Takte später','5469-h264-hq.jpg','2013-12-29','Auf dem 29C3 stellten wir euch die Cultural Commons Collecting Society (C3S) als Initiative zur Gründung einer GEMA-Alternative vor. Seit dem ist sehr viel passiert: Unter anderem ist mittlerweile eine Europäische Genossenschaft gegründet, die mit sechsstelligem Kapital aus einer Crowdfunding-Kampagne in das Jahr 2014 geht. Auf Seiten der GEMA sind angesichts der entstehenden Konkurrentin bereits erste Anzeichen für eine Kursänderung wahrnehmbar.
','http://events.ccc.de/congress/2013/Fahrplan/events/5469.html','---
- m.eik
- bruder
','30C3_-_5469_-_de_-_saal_g_-_201312291815_-_2_takte_spater_-_m_eik_-_bruder','30C3S SCE mbH: GEMA-Konkurrenz für Fortgeschrittene ','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-29','f',10);
INSERT INTO "events" VALUES(1769,'import-126618a2097fb55a5c','5421-h264-hq.gif','5421-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.656654','2014-07-11 23:04:34.794983','THE DATABASE NATION, a.k.a THE STATE OF SURVEILLANCE','5421-h264-hq.jpg','2013-12-30','23rd of December 2008 was a sad day in India for civil liberties. On this day, The Indian Parliament passed the "The Information Technology (Amendment) Act" with no debate in the House, which effectively means is that the government of India now has the power to monitor all digital communications in the country without a court order or a warrant. The "world''s largest democracy" strongly leaning towards becoming a surveillance state raises many questions and poses severe challenges for free speech and economic justice in India and globally. This talk will map and review the current political, socio-cultural and legal landscape of mass-surveillance, data protection and censorship in India and analyse how it ties in to the global landscape of surveillance and censorship. It will also aim to create a discussion space to investigate the deeper effects of these so called "welfare" projects and how citizen-led movements can drive the state towards stronger data protection and privacy laws.
','http://events.ccc.de/congress/2013/Fahrplan/events/5421.html','---
- houndbee
','30C3_-_5421_-_en_-_saal_2_-_201312301400_-_the_database_nation_a_k_a_the_state_of_surveillance_-_houndbee',NULL,'---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-31','f',14);
INSERT INTO "events" VALUES(1770,'import-96a33690549695046e','5298-h264-hq.gif','5298-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.68652','2014-07-09 17:30:05.749893','Rock'' em Graphic Cards','5298-h264-hq.jpg','2013-12-27','This talks introduces programming concepts and languages for parallel programming on accelerator cards. 
','http://events.ccc.de/congress/2013/Fahrplan/events/5298.html','---
- mel/ Agnes Meyder
','30C3_-_5298_-_en_-_saal_g_-_201312271600_-_rock_em_graphic_cards_-_mel_agnes_meyder',' Introduction to Heterogeneous Parallel Programming','---
- 30c3
- Hardware & Making
','2013-12-28','f',7);
INSERT INTO "events" VALUES(1771,'import-6c4b576dc937567470','5192-h264-hd.gif','5192-h264-hd_preview.jpg',33,'2014-05-10 13:27:02.750688','2014-07-05 14:56:32.264127','Android DDI','5192-h264-hd.jpg','2013-12-29','As application security becomes more important on Android we need better tools to analyze and understand them. Android applications are written in Java and a run in the Dalvik VM. Until now most analysis is done via disassembling and monitored execution in an emulator. This talk presents a new technique to instrument Android applications executed in the DVM. The talk will introduce the new technique in great detail including many small examples and a whole attack based on it. We will go step by step to show you what can be achieved using this technique. 
','http://events.ccc.de/congress/2013/Fahrplan/events/5192.html','---
- Collin Mulliner
','30C3_-_5192_-_en_-_saal_1_-_201312291600_-_android_ddi_-_collin_mulliner','Dynamic Dalvik Instrumentation of Android Applications and the Android Framework','---
- 30c3
- Security & Safety
','2013-12-29','f',14);
INSERT INTO "events" VALUES(1772,'import-64c6146d0b939a7093','5405-h264-hq.gif','5405-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.780719','2014-06-30 19:17:14.252511','Data Mining for Good','5405-h264-hq.jpg','2013-12-29','For over thirty years, human rights groups in Guatemala have carefully documented the killing and disappearance of many people in the early 1980s. There are tens of thousands of records in many databases, and over 80 million paper pages of police records available in the Archives of the National Police. Most of the prosecutions of the former military and police officials who committed the atrocities depends on eyewitnesses, specific documents, and forensic anthropologists'' examination of exhumed bones. However, data analysis helps to see the big patterns in the violence.
','http://events.ccc.de/congress/2013/Fahrplan/events/5405.html','---
- Patrick
','30C3_-_5405_-_en_-_saal_g_-_201312291730_-_data_mining_for_good_-_patrick','Using random sampling, entity resolution, communications metadata, and statistical modeling to assist prosecutions for disappearance and genocide in Guatemala','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-31','f',4);
INSERT INTO "events" VALUES(1773,'import-6e7625533607102919','5214-h264-hd.gif','5214-h264-hd_preview.jpg',33,'2014-05-10 13:27:02.81029','2014-07-06 20:14:55.391118','The Gospel of IRMA ','5214-h264-hd.jpg','2013-12-28','Attribute Based Credentials (ABC) allow users to prove certain properties about themselves (e.g. age, race, license, etc.) without revealing their full identity. ABC are therefore important to protect the privacy of the user. The IRMA (I Reveal My Attributes) project of the Radboud University Nijmegen has created the first full and efficient implementation of this technology on smart cards. This allows ABC technology to be used in practice both on the Internet as well as in the physical world. We will discuss ABCs in general, the IRMA system, it''s advantages and pitfalls, and future work.
','http://events.ccc.de/congress/2013/Fahrplan/events/5214.html','---
- Jaap-Henk Hoepman
','30C3_-_5214_-_en_-_saal_1_-_201312281130_-_the_gospel_of_irma_-_jaap-henk_hoepman','Attribute Based Credentials in Practice','---
- 30c3
- Security & Safety
','2013-12-31','f',3);
INSERT INTO "events" VALUES(1774,'import-b36403daf21224ab1f','5564-h264-hq.gif','5564-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.856374','2014-07-06 21:30:45.214715','Lightning Talks, Day 4','5564-h264-hq.jpg','2013-12-30','
','http://events.ccc.de/congress/2013/Fahrplan/events/5564.html','---
- nickfarr
','30C3_-_5564_-_en_-_saal_g_-_201312301245_-_lightning_talks_day_4_-_nickfarr',NULL,'---
- 30c3
- Other
','2013-12-31','f',17);
INSERT INTO "events" VALUES(1775,'import-8ceb7e3b7b5881f636','5594-h264-hq.gif','5594-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.885413','2014-07-11 14:41:15.642672','Structuring open hardware projects','5594-h264-hq.jpg','2013-12-29','Every successful open hardware project needs a solid organization structure at some point in time, especially when plan to produce and sell your project. In our “i3 Berlin” 3d printer project, we took some elements of the PLM (Product Lifecycle Management) concept and implemented it with open source tools like Github and Blender. 
','http://events.ccc.de/congress/2013/Fahrplan/events/5594.html','---
- Bram de Vries
- Morris Winkler
','30C3_-_5594_-_en_-_saal_6_-_201312291300_-_structuring_open_hardware_projects_-_bram_de_vries_-_morris_winkler','experiences from the “i3 Berlin” 3D printer project with Blender and Github','---
- 30c3
- Hardware & Making
','2013-12-29','f',4);
INSERT INTO "events" VALUES(1776,'import-b85e7bbbf3d8db7b77','5380-h264-iprod.gif','5380-h264-iprod_preview.jpg',33,'2014-05-10 13:27:02.91424','2014-07-11 07:27:57.238344','Persistent, Stealthy, Remote-controlled Dedicated Hardware Malware','5380-h264-iprod.jpg','2013-12-29','In this work we present a stealthy malware that exploits dedicated hardware on the target system and remains persistant across boot cycles. The malware is capable of gathering valuable information such as passwords. Because the infected hardware can perform arbitrary main memory accesses, the malware can modify kernel data structures and escalate privileges of processes executed on the system.

The malware itself is a DMA malware implementation referred to as DAGGER. DAGGER exploits Intel’s Manageability Engine (ME), that executes firmware code such as Intel’s Active Management Technology (iAMT), as well as its OOB network channel. We have recently improved DAGGER’s capabilites to include support for 64-bit operating systems and a stealthy update mechanism to download new attack code.
','http://events.ccc.de/congress/2013/Fahrplan/events/5380.html','---
- Patrick Stewin
','30C3_-_5380_-_en_-_saal_2_-_201312291830_-_persistent_stealthy_remote-controlled_dedicated_hardware_malware_-_patrick_stewin',NULL,'---
- 30c3
- Security & Safety
','2013-12-31','f',38);
INSERT INTO "events" VALUES(1777,'import-c5a2f186adbc622144','5494-h264-iprod.gif','5494-h264-iprod_preview.jpg',33,'2014-05-10 13:27:02.943116','2014-07-05 15:05:07.630648','Nerds in the news','5494-h264-iprod.jpg','2013-12-29','Knight-Mozilla OpenNews sends coders into news organisations on a ten-month fellowship to make new tools for reporting and measuring the news. We believe that to remain relevant, journalism has to smarten up about tech and data. As a global community, we develop tools to datamine public data, news apps to make information accessible, and visualisations to break down complex stories. In my talk, I want to present the lessons about tech that I''ve learned in a newsroom and the things that still need to be built. 
','http://events.ccc.de/congress/2013/Fahrplan/events/5494.html','---
- Friedrich Lindenberg
','30C3_-_5494_-_en_-_saal_g_-_201312291645_-_nerds_in_the_news_-_friedrich_lindenberg','Spending a year coding in a newsroom','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-29','f',9);
INSERT INTO "events" VALUES(1778,'import-2c3d06ce989e83a0e7','5360-h264-hq.gif','5360-h264-hq_preview.jpg',33,'2014-05-10 13:27:02.972104','2014-07-12 11:33:34.975868','Script Your Car!','5360-h264-hq.jpg','2013-12-28','Almost all higher-end cars come with very beefy in-car entertainment hardware. In this talk, I''ll describe how to take advantage of an existing hands-free kit to connect your car to the internet and script your dashboard in python.
','http://events.ccc.de/congress/2013/Fahrplan/events/5360.html','---
- Felix "tmbinc" Domke
','30C3_-_5360_-_en_-_saal_2_-_201312281600_-_script_your_car_-_felix_tmbinc_domke','Using existing hardware platforms to integrate python into your dashboard','---
- 30c3
- Hardware & Making
','2013-12-28','f',175);
INSERT INTO "events" VALUES(1779,'import-eb1726dcda15da6d3e','5610-h264-hq.gif','5610-h264-hq_preview.jpg',33,'2014-05-10 13:27:03.000758','2014-07-10 08:52:15.654581','Seidenstraße','5610-h264-hq.jpg','2013-12-27','Auf dem 30C3 wird es, neben der bisher gewohnten digitalen Infrastruktur mit Netz, Telefon etc. dieses Jahr auch erstmalig ein Rohrpost-System mit dem schönen Namen Seidenstraße geben. Als Inspiration dient die auf geschlossenen Drainagerohren und Staubsaugern basierende Installation OCTO der Künstlergruppe Telekommunisten, die einigen von der letzten transmediale bekannt sein dürfte.
','http://events.ccc.de/congress/2013/Fahrplan/events/5610.html','---
- "*m"
- Jeff Mann
- frank
- Diani Barreto
','30C3_-_5610_-__-_saal_2_-_201312271245_-_seidenstrasse_-_m_-_jeff_mann_-_frank_-_diani_barreto','The Making of…','---
- 30c3
- Art & Beauty
','2013-12-28','f',42);
INSERT INTO "events" VALUES(1780,'import-55d0d9177b76c5da17','5417-h264-hq.gif','5417-h264-hq_preview.jpg',33,'2014-05-10 13:27:03.029448','2014-07-08 04:57:18.819773','Extracting keys from FPGAs, OTP Tokens and Door Locks','5417-h264-hq.jpg','2013-12-28','Side-channel analysis (SCA) and related methods exploit physical characteristics of a (cryptographic) implementations to bypass security mechanisms and extract secret keys. Yet, SCA is often considered a purely academic exercise with no impact on real systems. In this talk, we show that this is not the case: Using the example of several wide-spread real-world devices, we demonstrate that even seemingly secure systems can be attacked by means of SCA with limited effort.  
','http://events.ccc.de/congress/2013/Fahrplan/events/5417.html','---
- David
','30C3_-_5417_-_en_-_saal_6_-_201312281245_-_extracting_keys_from_fpgas_otp_tokens_and_door_locks_-_david','Side-Channel (and other) Attacks in Practice','---
- 30c3
- Security & Safety
','2013-12-31','f',22);
INSERT INTO "events" VALUES(1781,'import-e120208c68acac0ff8','5509-h264-hq.gif','5509-h264-hq_preview.jpg',33,'2014-05-10 13:27:03.058366','2014-07-05 15:10:49.131573','IFGINT','5509-h264-hq.jpg','2013-12-27','Mit Informationsfreiheitsgesetz (IFG) und FragDenStaat.de kann man als Bürger den Staat einfach zurücküberwachen. Was erfährt man, wenn man fragt? Wo sind die Probleme, was sind die Workarounds? Ein Blick zurück auf 2013, nach vorn auf 2014 und ein Aufruf das IFG zu nutzen.
','http://events.ccc.de/congress/2013/Fahrplan/events/5509.html','---
- Stefan Wehrmeyer
','30C3_-_5509_-_de_-_saal_6_-_201312271600_-_ifgint_-_stefan_wehrmeyer','Erkenntnisse aus Informationsfreiheitsanfragen - Hacks, Bugs, Workarounds ','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-28','f',3);
INSERT INTO "events" VALUES(1782,'import-9bd7608b8bfb29133b','5433-h264-iprod.gif','5433-h264-iprod_preview.jpg',33,'2014-05-10 13:27:03.220158','2014-07-07 04:50:59.956223','Recht auf Remix','5433-h264-iprod.jpg','2013-12-29','Wir leben in einem Zeitalter des Remix. Kreativität und Kultur bauten schon immer auf bereits Bestehendem auf. Internet und digitale Technologien ermöglichen aber die kreative Nutzung existierender Werke in völlig neuen Dimensionen: Nie zuvor war es so vielen möglich, Werke auf so unterschiedliche Arten zu verändern und so einfach anderen zugänglich zu machen. In dem Maße, in dem die kreative Kopie Teil des kommunikativen Alltags breiter Bevölkerungsschichten wird, ist ein Recht auf Remix eine grundlegende Voraussetzung für die Kunst- und Meinungsfreiheit einer Gesellschaft. Die Gegenwart ist jedoch geprägt von restriktivem Rechtemanagement und entgrenzter Rechtsdurchsetzung. Die Initiative "Recht auf Remix" möchte das ändern.
','http://events.ccc.de/congress/2013/Fahrplan/events/5433.html','---
- Leonhard Dobusch
','30C3_-_5433_-_de_-_saal_6_-_201312291715_-_recht_auf_remix_-_leonhard_dobusch','','---
- 30c3
- Ethics
- Society & Politics
','2013-12-29','f',18);
INSERT INTO "events" VALUES(1783,'import-54c628c30a102f5429','5497-h264-hq.gif','5497-h264-hq_preview.jpg',33,'2014-05-10 13:27:03.250637','2014-07-11 21:26:08.526336','10 Years of Fun with Embedded Devices','5497-h264-hq.jpg','2013-12-27','A review of the 10 year history of the OpenWrt project, current events, and upcoming developments.
','http://events.ccc.de/congress/2013/Fahrplan/events/5497.html','---
- nbd
','30C3_-_5497_-_en_-_saal_g_-_201312271400_-_10_years_of_fun_with_embedded_devices_-_nbd','How OpenWrt evolved from a WRT54G firmware to an universal Embedded Linux OS','---
- 30c3
- Hardware & Making
','2013-12-28','f',9);
INSERT INTO "events" VALUES(1784,'import-1b349ae481143e8d11','5538-h264-iprod.gif','5538-h264-iprod_preview.jpg',33,'2014-05-10 13:27:03.280878','2014-07-12 07:55:43.593576','The Internet (Doesn''t) Need Another Security Guide','5538-h264-iprod.jpg','2013-12-29','As Internet privacy/security professionals and amateur enthusiasts, we are often asked to give advice about best practices in this field. Sometimes this takes the form of one-on-one advice to our friends, sometimes it''s training a room full of people, and sometimes you may be asked to write a blog post or a brief guide or an entire curriculum. This talk will survey the current Internet privacy guide landscape and discuss the perils and pitfalls of creating this type of resource, using the Electronic Frontier Foundation''s Surveillance Self Defense project as a case study.
','http://events.ccc.de/congress/2013/Fahrplan/events/5538.html','---
- evacide
','30C3_-_5538_-_en_-_saal_2_-_201312292030_-_the_internet_doesn_t_need_another_security_guide_-_evacide','Creating Internet Privacy and Security Resources That Don''t Suck','---
- 30c3
- Science & Engineering
','2013-12-31','f',25);
INSERT INTO "events" VALUES(1785,'import-cd67b1c25a8cfb9602','5337-h264-hq.gif','5337-h264-hq_preview.jpg',33,'2014-05-10 13:27:03.311099','2014-07-11 21:19:49.959717','Kryptographie nach Snowden','5337-h264-hq.jpg','2013-12-27','Die Verwendung von mittelmäßiger Kryptographie scheint gegen Angreifer mit Milliarden-Etat komplett versagt zu haben. Namentlich RC4, MD5 und SHA1 scheinen praxisrelevant brechbar.
','http://events.ccc.de/congress/2013/Fahrplan/events/5337.html','---
- ruedi
','30C3_-_5337_-_de_-_saal_2_-_201312271715_-_kryptographie_nach_snowden_-_ruedi',' Was tun nach der mittelmäßigen Kryptographie-Apokalypse?','---
- 30c3
- Security & Safety
','2013-12-28','f',32);
INSERT INTO "events" VALUES(1786,'import-2db40aa65f1a96339c','5590-h264-iprod.gif','5590-h264-iprod_preview.jpg',33,'2014-05-10 13:27:03.341043','2014-07-08 17:35:07.420929','White-Box Cryptography','5590-h264-iprod.jpg','2013-12-29','The goal of white-box cryptography is to protect cryptographic keys in a public implementation of encryption algorithms, primarily in the context of Pay-TV and tamper-resistant software. I present an overview of the white-box cryptography concept along with the most common applications and proposed designs. I discuss the subtle difference between white-box cryptography, public-key cryptography, and obfuscation. 
','http://events.ccc.de/congress/2013/Fahrplan/events/5590.html','---
- Dmitry Khovratovich
','30C3_-_5590_-_en_-_saal_2_-_201312291715_-_white-box_cryptography_-_dmitry_khovratovich','Survey','---
- 30c3
- Security & Safety
','2013-12-29','f',8);
INSERT INTO "events" VALUES(1787,'import-b924daa6653028f0ec','5356-h264-hq.gif','5356-h264-hq_preview.jpg',33,'2014-05-10 13:27:03.370854','2014-07-12 08:57:42.312246','Firmware Fat Camp','5356-h264-hq.jpg','2013-12-27','We present a collection of techniques which aim to automagically remove significant (and unnecessary) portions of firmware binaries from common embedded devices to drastically reduce the attack surface of these devices. We present a brief theoretical explanation of Firmware Fat Camp, a collection of "before" and "after" photos of graduates of FFC, along with a set of live demonstrations of FFC in action on common embedded devices.

Modern embedded systems such as VoIP phones, network printers and routers typically ship with all available features compiled into its firmware image. A small subset of these features is activated at any given time on individual devices based on its specific configuration. An even smaller subset of features is actually used, as some unused and insecure features cannot are typically enabled by default and cannot be disabled. However, all embedded devices still contain a large amount of code and data that should never be executed or read according to its current configuration. This unnecessary binary is not simply a waste of memory; it contains vulnerable code and data that can be used by an attacker to exploit the system. This “dead code” provides an ideal attack surface. Automated minimization of this attack surface will significantly improve the security of the device without any impact to the device’s functionality. 
','http://events.ccc.de/congress/2013/Fahrplan/events/5356.html','---
- angcui
','30C3_-_5356_-_en_-_saal_6_-_201312272300_-_firmware_fat_camp_-_angcui','Embedded Security Using Binary Autotomy','---
- 30c3
- Security & Safety
','2013-12-28','f',14);
INSERT INTO "events" VALUES(1788,'import-f0978eb04ae6489a9d','5463-h264-hd.gif','5463-h264-hd_preview.jpg',33,'2014-05-10 13:27:03.400492','2014-07-11 17:27:13.770836','Hillbilly Tracking of Low Earth Orbit','5463-h264-hd.jpg','2013-12-28','Satellites in Low Earth Orbit have tons of nifty signals, but they move quickly though the sky and are difficult to track with fine accuracy.  This lecture describes a remotely operable satellite tracking system that the author built from a Navy-surplus Inmarsat dish in Southern Appalachia.
','http://events.ccc.de/congress/2013/Fahrplan/events/5463.html','---
- Travis Goodspeed
','30C3_-_5463_-_en_-_saal_1_-_201312281400_-_hillbilly_tracking_of_low_earth_orbit_-_travis_goodspeed','Repurposing an Inmarsat Dish','---
- 30c3
- Science & Engineering
','2013-12-28','f',19);
INSERT INTO "events" VALUES(1789,'import-adc6e9c3884734a386','5619-h264-hq.gif','5619-h264-hq_preview.jpg',33,'2014-05-10 13:27:03.429616','2014-07-08 21:45:26.65066','Mind-Hacking mit Psychedelika','5619-h264-hq.jpg','2013-12-29','Substanzen wie MDMA, Psilocybin, LSD und Ketamin besitzen erhebliches therapeutisches Potential, und die Erforschung ihrer Wirkmechanismen erlaubt Einblicke in die Funktionsweise der menschlichen Psyche. Der trotz Illegalität relativ einfachen Verfügbarkeit steht ein Mangel an Aufklärung über Risiken, Effekte und Pharmakologie gegenüber, dem mit dieser Einführung begegnet werden soll.
','http://events.ccc.de/congress/2013/Fahrplan/events/5619.html','---
- Julia Aksënova
','30C3_-_5619_-_de_-_saal_2_-_201312292145_-_mind-hacking_mit_psychedelika_-_julia_aksenova','Eine Einführung in die Wirkungsweise psychedelischer Substanzen','---
- 30c3
- Science & Engineering
','2013-12-29','f',14);
INSERT INTO "events" VALUES(1790,'import-b66fca64d5a28707d6','5468-h264-hq.gif','5468-h264-hq_preview.jpg',33,'2014-05-10 13:27:03.458827','2014-07-09 03:09:16.195124','We only have one earth','5468-h264-hq.jpg','2013-12-28','An abundant number of existential risks threatens humanity. Many of those planetary by nature. Current science already enables us to colonize nearby space, yet nobody bothers to supply the modest financial resources. Hence this call to action.
','http://events.ccc.de/congress/2013/Fahrplan/events/5468.html','---
- Drahflow
','30C3_-_5468_-_en_-_saal_6_-_201312281130_-_we_only_have_one_earth_-_drahflow','A case for expansionistic space policy','---
- 30c3
- Science & Engineering
','2013-12-28','f',18);
INSERT INTO "events" VALUES(1791,'import-fe3cec799d4a20a4a6','5445-h264-iprod.gif','5445-h264-iprod_preview.jpg',33,'2014-05-10 13:27:03.489359','2014-07-09 17:55:24.087556','Virtually Impossible: The Reality Of Virtualization Security','5445-h264-iprod.jpg','2013-12-29','This talk will demonstrate why it is virtually impossible to secure virtual machines implementations properly. In the talk I will try to give an overview of the basics of hardware virtualization technology, the existing attack techniques against virtualization and also explain why it is such a complex problem to create a secure hypervisor. The talk will focus on the low level interfaces and how it affects all aspects of computer platform security. I will also try to review a few interesting Erratas at the end of the talk.
','http://events.ccc.de/congress/2013/Fahrplan/events/5445.html','---
- Gal Diskin
','30C3_-_5445_-_en_-_saal_6_-_201312292145_-_virtually_impossible_the_reality_of_virtualization_security_-_gal_diskin','Errata FTW','---
- 30c3
- Security & Safety
','2013-12-29','f',27);
INSERT INTO "events" VALUES(1792,'import-3897f8033121be44a5','5606-h264-iprod.gif','5606-h264-iprod_preview.jpg',33,'2014-05-10 13:27:03.519483','2014-07-10 09:38:17.570131','Closing Event','5606-h264-iprod.jpg','2013-12-30','
','http://events.ccc.de/congress/2013/Fahrplan/events/5606.html','---
- ths
','30C3_-_5606_-_en_-_saal_1_-_201312301830_-_closing_event_-_ths',NULL,'---
- 30c3
- CCC
','2014-01-03','f',7);
INSERT INTO "events" VALUES(1793,'import-5546fa5f06eae833bf','5608-h264-hq.gif','5608-h264-hq_preview.jpg',33,'2014-05-10 13:27:03.548852','2014-07-11 18:02:58.386506','Jahresrückblick des CCC','5608-h264-hq.jpg','2013-12-28','Auch das Jahr 2013 geht irgendwann vorbei. Deshalb werfen wir einen Blick zurück auf die für uns besonders relevanten Themen und versuchen abzuschätzen, was im Jahr 2014 auf uns zukommen könnte.
','http://events.ccc.de/congress/2013/Fahrplan/events/5608.html','---
- Constanze Kurz
- frank
- Linus Neumann
','30C3_-_5608_-_de_-_saal_1_-_201312290000_-_jahresruckblick_des_ccc_-_constanze_kurz_-_frank_-_linus_neumann',NULL,'---
- 30c3
- CCC
','2013-12-29','f',115);
INSERT INTO "events" VALUES(1794,'import-203f7f7d23b74fcf30','5614-h264-hq.gif','5614-h264-hq_preview.jpg',33,'2014-05-10 13:27:03.577884','2014-07-06 02:13:07.621625','Perfect Paul','5614-h264-hq.jpg','2013-12-27','The facial hacking research presented in this lecture/ performance exploits a well known vulnerability of the human nervous system that it can be easily accessed and controlled by electrodes mounted on the bodies exterior. External digital facial control allows for an unprecedented exploration of human facial expressiveness and has unveiled an unknown expressive potential of the human facial hardware. 
',NULL,'---
- artelse
','30C3_-_5614_-_en_-_saal_2_-_201312280000_-_perfect_paul_-_artelse','On Freedom of Facial Expression','---
- 30c3
- Art & Beauty
','2013-12-29','f',8);
INSERT INTO "events" VALUES(1795,'import-4186b12176ae3f8e3c','5279-h264-iprod.gif','5279-h264-iprod_preview.jpg',33,'2014-05-10 13:27:03.606672','2014-07-12 00:04:03.093202','Even More Tamagotchis Were Harmed in the Making of this Presentation','5279-h264-iprod.jpg','2013-12-29','You might remember Tamagotchi virtual pets from the 1990''s. These toys are still around and just as demanding as ever! At 29C3, I talked about my attempts to reverse engineer the latest Tamagotchis, and this presentation covers my progress since then. It includes methods for executing code on and dumping code from a Tamagotchi, an analysis of the Tamagotchi code dump and a demonstration of Tamagotchi development tools that make use of these capabilities. 
','http://events.ccc.de/congress/2013/Fahrplan/events/5279.html','---
- Natalie Silvanovich
','30C3_-_5279_-_en_-_saal_1_-_201312291715_-_even_more_tamagotchis_were_harmed_in_the_making_of_this_presentation_-_natalie_silvanovich',NULL,'---
- 30c3
- Hardware & Making
','2014-01-03','f',18);
INSERT INTO "events" VALUES(1796,'import-c633dcd97810ca27a2','5412-h264-hd.gif','5412-h264-hd_preview.jpg',33,'2014-05-10 13:27:03.635422','2014-07-04 19:42:41.849784','Bug class genocide','5412-h264-hd.jpg','2013-12-27','Violation of memory safety is still a major source of vulnerabilities in everyday systems. This talk presents the state of the art in compiler instrumentation to completely eliminate such vulnerabilities in C/C++ software.
','http://events.ccc.de/congress/2013/Fahrplan/events/5412.html','---
- Andreas Bogk
','30C3_-_5412_-_en_-_saal_1_-_201312271830_-_bug_class_genocide_-_andreas_bogk','Applying science to eliminate 100% of buffer overflows','---
- 30c3
- Security & Safety
','2013-12-28','f',13);
INSERT INTO "events" VALUES(1797,'import-2e8d32df3f589bb3e4','5426-h264-hq.gif','5426-h264-hq_preview.jpg',33,'2014-05-10 13:27:03.663893','2014-07-10 19:06:33.392227','Das FlipDot-Projekt','5426-h264-hq.jpg','2013-12-29','Inbetriebnahme alter Flip-Dot-Anzeigemodule eines
Autobahn-Parkleitsystems zu einer interaktiven Anzeige. Reverse
Engineering des Protokolls und Entwicklung einer Steuerplatine auf
Basis des Raspberry Pi.
','http://events.ccc.de/congress/2013/Fahrplan/events/5426.html','---
- RFguy
','30C3_-_5426_-_de_-_saal_6_-_201312292300_-_das_flipdot-projekt_-_rfguy','Spaß mit mechanischer Anzeige','---
- 30c3
- Hardware & Making
','2013-12-31','f',24);
INSERT INTO "events" VALUES(1798,'import-fe85b1927fe9b7acc7','5413-h264-iprod.gif','5413-h264-iprod_preview.jpg',33,'2014-05-10 13:27:03.692304','2014-07-12 07:48:44.741266','Security Nightmares','5413-h264-iprod.jpg','2013-12-30','Was hat sich im letzten Jahr im Bereich IT-Sicherheit getan? Welche neuen Entwicklungen haben sich ergeben? Welche neuen Buzzwords und Trends waren zu sehen?
','http://events.ccc.de/congress/2013/Fahrplan/events/5413.html','---
- frank
- Ron
','30C3_-_5413_-_de_-_saal_1_-_201312301715_-_security_nightmares_-_frank_-_ron','Damit Sie auch morgen schlecht von Ihrem Computer träumen. [Tomorrow’s computer nightmares, today.]','---
- 30c3
- Entertainment
','2014-01-01','f',93);
INSERT INTO "events" VALUES(1799,'import-031a2cf3d3dde673ef','5397-h264-hq.gif','5397-h264-hq_preview.jpg',33,'2014-05-10 13:27:03.720795','2014-07-11 21:57:56.019735','Sysadmins of the world, unite!','5397-h264-hq.jpg','2013-12-29','<p>Finally, the world is aware of the threat of mass surveillance and control, but we still have a fight on our hands, and that fight is both technical and political. Global democracy is not going to protect itself. There has never been a higher demand for a politically-engaged hackerdom. Jacob Appelbaum and Julian Assange discuss what needs to be done if we are going to win.</p>
','http://events.ccc.de/congress/2013/Fahrplan/events/5397.html','---
- Julian Assange
- Jacob
','30C3_-_5397_-_en_-_saal_1_-_201312292245_-_sysadmins_of_the_world_unite_-_julian_assange_-_jacob','a call to resistance','---
- 30c3
- Ethics
- " Society & Politics"
','2014-01-03','f',45);
INSERT INTO "events" VALUES(1800,'import-0ba6795f637f330dda','5290-h264-hq.gif','5290-h264-hq_preview.jpg',33,'2014-05-10 13:27:03.880005','2014-07-11 11:08:47.396764','Console Hacking 2013','5290-h264-hq.jpg','2013-12-27','About a year ago Nintendo released their latest video gaming console, the Wii U. Since 2006, the Wii has led to one of the most active homebrew scenes after its security system was completely bypassed. This talk will discuss the improvements made in Wii U''s architecture and explain how it was broken in less than 31 days. The talk is targeted at those who hack (or design) embedded system security, but gamers might also find it interesting.
','http://events.ccc.de/congress/2013/Fahrplan/events/5290.html','---
- sven
- marcan
- Nicholas Allegra (comex)
','30C3_-_5290_-_en_-_saal_2_-_201312272030_-_console_hacking_2013_-_sven_-_marcan_-_nicholas_allegra_comex','WiiU','---
- 30c3
- Security & Safety
','2013-12-28','f',68);
INSERT INTO "events" VALUES(1801,'import-261375d58c3e4f533a','5193-h264-hd.gif','5193-h264-hd_preview.jpg',33,'2014-05-10 13:27:03.910459','2014-07-06 18:13:36.543271','Hardware Attacks, Advanced ARM Exploitation, and Android Hacking','5193-h264-hd.jpg','2013-12-28','In this talk (which in part was delivered at Infiltrate 2013 and NoSuchCon 2013) we will discuss our recent research that is being rolled into our Practical ARM Exploitation course (sold out at Blackhat this year and last) on Linux and Android (for embedded applications and mobile devices). We will also demonstrate these techniques and discuss how we were able to discover them using several ARM hardware development platforms that we custom built.  Where relevant we will also discuss ARM exploitation as it related to Android as we wrote about in the "Android Hackers Handbook" which we co-authored and will be released in October 2013.
','http://events.ccc.de/congress/2013/Fahrplan/events/5193.html','---
- Stephen A. Ridley
','30C3_-_5193_-_en_-_saal_1_-_201312281715_-_hardware_attacks_advanced_arm_exploitation_and_android_hacking_-_stephen_a_ridley',NULL,'---
- 30c3
- Security & Safety
','2014-01-01','f',25);
INSERT INTO "events" VALUES(1802,'import-69a20c2ba334426b6c','5339-h264-hd.gif','5339-h264-hd_preview.jpg',33,'2014-05-10 13:27:03.940941','2014-07-12 08:12:56.299394','The Year in Crypto','5339-h264-hd.jpg','2013-12-28','This was a busy year for crypto.

TLS was broken.  And then broken again.

Discrete logs were computed.  And then computed again.

Is the cryptopocalypse nigh?

Has the NSA backdoored everything in sight?

Also, answers to last year''s exercises will be given.
','http://events.ccc.de/congress/2013/Fahrplan/events/5339.html','---
- Nadia Heninger
- djb
- Tanja Lange
','30C3_-_5339_-_en_-_saal_1_-_201312281830_-_the_year_in_crypto_-_nadia_heninger_-_djb_-_tanja_lange',NULL,'---
- 30c3
- Security & Safety
','2014-01-01','f',32);
INSERT INTO "events" VALUES(1803,'import-a8167512c1f4c48f95','5618-h264-hd.gif','5618-h264-hd_preview.jpg',33,'2014-05-10 13:27:03.971091','2014-07-10 13:57:30.406506','Baseband Exploitation in 2013','5618-h264-hd.jpg','2013-12-27','Exploitation of baseband vulnerabilities has become significantly harder on average. With Qualcomm having grabbed 97% of the market share of shipped LTE chipsets in 1Q2013, you see their chipset in every single top-of-the-line smartphone, whether it is an Android, an iPhone, a Windows Phone or a Blackberry.
','http://events.ccc.de/congress/2013/Fahrplan/events/5618.html','---
- RPW, esizkur
','30C3_-_5618_-_en_-_saal_1_-_201312272145_-_baseband_exploitation_in_2013_-_rpw_esizkur','Hexagon challenges','---
- 30c3
- Security & Safety
','2014-01-01','f',28);
INSERT INTO "events" VALUES(1804,'import-4cb337013e8e27bd70','5544-h264-hq.gif','5544-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.001145','2014-06-29 00:03:07.78542','Sim Gishel','5544-h264-hq.jpg','2013-12-27','Sim Gishel is a multimedia robot. He sings and dances on request. He will try hard to take part in casting shows to become a popstar.
','http://events.ccc.de/congress/2013/Fahrplan/events/5544.html','---
- Karl Heinz Jeron
','30C3_-_5544_-_de_-_saal_2_-_201312280030_-_sim_gishel_-_karl_heinz_jeron','A singing and dancing robot build to take part in casting shows ','---
- 30c3
- Art & Beauty
','2013-12-28','f',5);
INSERT INTO "events" VALUES(1805,'import-d32e7c7d44962ffc4c','5543-h264-iprod.gif','5543-h264-iprod_preview.jpg',33,'2014-05-10 13:27:04.031766','2014-07-09 22:25:08.777791','ID Cards in China: Your Worst Nightmare','5543-h264-iprod.jpg','2013-12-29','Imagine getting pulled over for running a stop sign and learning for the first time – from the cop – that you are HIV-positive. People in China are required to carry electronic, swipeable ID cards that hold their political views, their HIV status, their mental health situation, and much more.
','http://events.ccc.de/congress/2013/Fahrplan/events/5543.html','---
- Kate Krauss
','30C3_-_5543_-_en_-_saal_2_-_201312291245_-_id_cards_in_china_your_worst_nightmare_-_kate_krauss','In China Your ID Card Knows Everything','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-29','f',31);
INSERT INTO "events" VALUES(1806,'import-6988bfde5e618ee8eb','5477-h264-hd.gif','5477-h264-hd_preview.jpg',33,'2014-05-10 13:27:04.061294','2014-07-03 22:19:20.829157','An introduction to Firmware Analysis','5477-h264-hd.jpg','2013-12-27','This talk gives an introduction to firmware analysis: It starts with how to retrieve the binary, e.g. get a plain file from manufacturer, extract it from an executable or memory device, or even sniff it out of an update process or internal CPU memory, which can be really tricky. After that it introduces the necessary tools, gives tips on how to detect the processor architecture, and explains some more advanced analysis techniques, including how to figure out the offsets where the firmware is loaded to, and how to start the investigation.
','http://events.ccc.de/congress/2013/Fahrplan/events/5477.html','---
- Stefan Widmann
','30C3_-_5477_-_en_-_saal_1_-_201312271245_-_an_introduction_to_firmware_analysis_-_stefan_widmann','Techniques - Tools - Tricks','---
- 30c3
- Security & Safety
','2013-12-28','f',9);
INSERT INTO "events" VALUES(1807,'import-050f549768138d2a3a','5474-h264-hq.gif','5474-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.090702','2014-07-12 08:44:40.863705','World War II Hackers','5474-h264-hq.jpg','2013-12-27','The use of encryption to secure sensitive data from unauthorized eyes is as old as human communication itself. Before the relatively new method of computerized encryption software converting data into a format unintelligible to anyone lacking the necessary key for its decryption, for a long time there was pen and paper and the human brain doing quite a bit of work. Up until the 20th century encryption had to be done literally by hand, to then be transmitted in paper form, via telegraphy or radio. In this context, encryption of data has always been of special importance during times of political conflict and war; subsequently, it saw its major developments during those times in history. This talk will examine and explain common hand encryption methods still employed today using the example of one very successful Soviet espionage group operating in Japan in the 1930s and 1940s: the spy ring centered around Richard Sorge, codenamed “Ramsay”.
','http://events.ccc.de/congress/2013/Fahrplan/events/5474.html','---
- Anja Drephal
','30C3_-_5474_-_en_-_saal_g_-_201312272145_-_world_war_ii_hackers_-_anja_drephal','Stalin''s best men, armed with paper and pen','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-31','f',22);
INSERT INTO "events" VALUES(1808,'import-556ef0bc0154a32f3a','5459-h264-iprod.gif','5459-h264-iprod_preview.jpg',33,'2014-05-10 13:27:04.120145','2014-07-08 13:44:14.33069','Security of the IC Backside','5459-h264-iprod.jpg','2013-12-28','In the chain of trust of most secure schemes is an electronic chip that holds secret information. These schemes often employ cryptographically secure protocols. The weakest link of such a scheme is the chip itself. By attacking the chip directly an attacker can gain access to the secret data in its unencrypted form. In this presentation we demonstrate the attack class of the future, backside attacks. This class of attacks mitigate all device countermeasures and can access all signals of the device. As opposed to the attacks of today, these attacks can also be applied to complex systems such as the ARM SoCs of modern smartphones.
','http://events.ccc.de/congress/2013/Fahrplan/events/5459.html','---
- nedos
','30C3_-_5459_-__-_saal_1_-_201312282145_-_security_of_the_ic_backside_-_nedos','The future of IC analysis','---
- 30c3
- Security & Safety
','2014-01-01','f',24);
INSERT INTO "events" VALUES(1809,'import-a09994ea7897af2610','5539-webm.gif','5539-webm_preview.jpg',33,'2014-05-10 13:27:04.150902','2014-06-28 22:19:04.003847','Human Rights and Technology','5539-webm.jpg','2013-12-30','This talk aims to shed some light on recent human rights violations in the context of the use of digital information and communications technology, particularly considering the latest disclosures about the surveillance programmes of Western intelligence services. At the same time, it shall provide information about Amnesty International''s positions and activities in this field and invite anybody interested in our work to get involved.
','http://events.ccc.de/congress/2013/Fahrplan/events/5539.html','---
- Seb
','30C3_-_5539_-_en_-_saal_6_-_201312301345_-_human_rights_and_technology_-_seb','"A New Hope" or "The Empire Strikes Back"?','---
- 30c3
- Ethics
- '' Society & Politics''
','2013-12-31','f',5);
INSERT INTO "events" VALUES(1810,'import-8aad170666dcb0615d','5437-h264-hq.gif','5437-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.180439','2014-07-05 12:49:47.224105','Plants & Machines','5437-h264-hq.jpg','2013-12-28','Did you ever feel the need to be in charge of your environment? We did . A detailed story of our experience playing with 220VAC and water to build an automated, digitally controlled ecosystem. A place, where you can be the climate-change. Double the temperature, triple the floods, let it storm or rain. A Tamagotchi that generates food from electricity. All done with Arduino, raspberry Pi and Node.js. 
','http://events.ccc.de/congress/2013/Fahrplan/events/5437.html','---
- mrv
- bbuegler
','30C3_-_5437_-_en_-_saal_g_-_201312282245_-_plants_machines_-_mrv_-_bbuegler','Food replicating Robots from Open Source Technologies','---
- 30c3
- Hardware & Making
','2013-12-28','f',7);
INSERT INTO "events" VALUES(1811,'import-63c1d002e35baefaab','5562-h264-hq.gif','5562-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.209938','2014-06-30 20:14:49.664221','Lightning Talks, Day 2','5562-h264-hq.jpg','2013-12-28','
','http://events.ccc.de/congress/2013/Fahrplan/events/5562.html','---
- nickfarr
','30C3_-_5562_-_en_-_saal_g_-_201312281245_-_lightning_talks_day_2_-_nickfarr',NULL,'---
- 30c3
- Other
','2013-12-29','f',10);
INSERT INTO "events" VALUES(1812,'import-1e08588a343b42c924','5478-h264-hq.gif','5478-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.241375','2014-07-12 08:15:10.681026','Backdoors, Government Hacking and The Next Crypto Wars','5478-h264-hq.jpg','2013-12-29','Law enforcement agencies claim they are "going dark". Encryption technologies have finally been deployed by software companies, and critically, enabled by default, such that emails are flowing over HTTPS, and disk encryption is now frequently used. Friendly telcos, who were once a one-stop-shop for surveillance can no longer meet the needs of our government. What are the FBI and other law enforcement agencies doing to preserve their spying capabilities? 

','http://events.ccc.de/congress/2013/Fahrplan/events/5478.html','---
- Christopher Soghoian
','30C3_-_5478_-_en_-_saal_g_-_201312292145_-_backdoors_government_hacking_and_the_next_crypto_wars_-_christopher_soghoian',NULL,'---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-29','f',36);
INSERT INTO "events" VALUES(1813,'import-f603edc0b3630e1f13','5634-h264-iprod.gif','5634-h264-iprod_preview.jpg',33,'2014-05-10 13:27:04.270278','2014-06-30 16:06:30.628066','07KINGSTON25 JAMAICA: MALARIA UPDATE Dispatches from Fort Meade','5634-h264-iprod.jpg','2013-12-27','At Fort George "Orwell" Meade, home of the NSA and the US Defense Information School, managing the message of Chelsea Manning''s trial was facilitated by a lack of public access to most of the court filings and rulings until 18 months into her legal proceeding.
','http://events.ccc.de/congress/2013/Fahrplan/events/5634.html','---
- Alexa O''Brien
','30C3_-_5634_-__-_saal_1_-_201312271600_-_07kingston25_jamaica_malaria_update_dispatches_from_fort_meade_-_alexa_o_brien','Reporting on the secret trial of Chelsea Manning','---
- 30c3
- Ethics
- " Society & Politics"
','2014-01-01','f',5);
INSERT INTO "events" VALUES(1814,'import-f7b8821179191566b5','5604-h264-iprod.gif','5604-h264-iprod_preview.jpg',33,'2014-05-10 13:27:04.2995','2014-07-11 21:22:58.839355','Seeing The Secret State: Six Landscapes','5604-h264-iprod.jpg','2013-12-28','Although people around the world are becoming increasingly aware of the United States'' global geography of surveillance, covert action, and other secret programs, much of this landscape is invisible in our everyday lives.
','http://events.ccc.de/congress/2013/Fahrplan/events/5604.html','---
- Trevor Paglen
','30C3_-_5604_-_en_-_saal_1_-_201312282300_-_seeing_the_secret_state_six_landscapes_-_trevor_paglen',NULL,'---
- 30c3
- Art & Beauty
','2014-01-01','f',91);
INSERT INTO "events" VALUES(1815,'import-a061a2ed4806e6aeb5','5334-h264-iprod.gif','5334-h264-iprod_preview.jpg',33,'2014-05-10 13:27:04.328176','2014-07-10 21:51:22.372166','RFID Treehouse of Horror','5334-h264-iprod.jpg','2013-12-29','In this lecture, we present a black-box analysis of an electronic contact-less system that has been steadily
replacing a conventional mechanical key on multi-party
houses in a big European city. So far, there are est. 10.000 installations of the electronic system. The mechanical key has been introduced about 40 years ago to allow mail delivery services to access multi-party houses but has since then aggregated many additional users, such as garbage collection, police, fire brigade and other emergency services. Over 92% of residential buildings in this city are equipped with such a solution.  
','http://events.ccc.de/congress/2013/Fahrplan/events/5334.html','---
- Adrian Dabrowski
','30C3_-_5334_-_en_-_saal_2_-_201312291400_-_rfid_treehouse_of_horror_-_adrian_dabrowski','Hacking City-Wide Access Control Systems','---
- 30c3
- Security & Safety
','2013-12-29','f',35);
INSERT INTO "events" VALUES(1816,'import-710e358bbb57f04478','5490-h264-iprod.gif','5490-h264-iprod_preview.jpg',33,'2014-05-10 13:27:04.356851','2014-07-11 19:12:58.400103','Fnord News Show','5490-h264-iprod.jpg','2013-12-29','Im Format einer lockeren Abendshow werden wir die Highlights des Jahres präsentieren, die Meldungen zwischen den Meldungen, die subtilen Sensationen hinter den Schlagzeilen. Kommen Sie, hören Sie, sehen Sie! Lassen Sie sich mitreißen!
','http://events.ccc.de/congress/2013/Fahrplan/events/5490.html','---
- frank
- Fefe
','30C3_-_5490_-_de_-_saal_1_-_201312300000_-_fnord_news_show_-_frank_-_fefe','Der schonungslose Realitätsabgleich mit Birzarrometer-Rekalibrierung [The harsh reality check and recalibration of the bizarre-o-meter]','---
- 30c3
- Entertainment
','2014-01-01','f',118);
INSERT INTO "events" VALUES(1817,'import-9a2312a020ab9dbce1','5542-h264-hq.gif','5542-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.385513','2014-06-23 02:23:16.775865','Revisiting "Trusting Trust" for binary toolchains','5542-h264-hq.jpg','2013-12-28','Ken Thompson''s classic "Reflections on Trusting Trust" examined the impacts of planted build chain bugs, from an example of a compiler Trojan to a hypothetical "well-placed microcode bug". Once theoretical & remote, such scenarios have lately been revealed as a stark reality.

But what if we could have every individual piece of software or firmware in the binary toolchain bug-free, performing just as their programmers intended? Would we be safe from run-away computation if only well-formed inputs to each of the individual tools were allowed? Not so. Potential for malicious computation lurks in a variety of input formats along all steps of the binary runtime process construction and execution. Until the "glue" data of an ABI and the binary toolchains in general is reduced to predictable, statically analyzable power, plenty of room for bug-less Trojans remains.

We will discuss our latest work in constructing Turing-complete computation out of different levels of metadata, present tools to normalize and disambiguate these metadata, and conclude with proposals for criteria to trust binary toolchains beyond "Trusting trust" compilers and planted bugs.
','http://events.ccc.de/congress/2013/Fahrplan/events/5542.html','---
- sergeybratus
- Julian Bangert
- bx
','30C3_-_5542_-_en_-_saal_2_-_201312282030_-_revisiting_trusting_trust_for_binary_toolchains_-_sergeybratus_-_julian_bangert_-_bx',NULL,'---
- 30c3
- Science & Engineering
','2013-12-28','f',1);
INSERT INTO "events" VALUES(1818,'import-e40047823b52f995a3','5391-h264-iprod.gif','5391-h264-iprod_preview.jpg',33,'2014-05-10 13:27:04.54283','2014-07-11 01:14:43.559877','Y U NO ISP, taking back the Net','5391-h264-iprod.jpg','2013-12-29','Building and running an ISP is not that difficult. It''s hard to say how many people are connected to the Internet by such weird structures, but we know that they are more and more each day.
What is at stake is taking back the control of the Internet infrastructure and showing that a neutral Internet access is natural.
','http://events.ccc.de/congress/2013/Fahrplan/events/5391.html','---
- taziden
','30C3_-_5391_-_en_-_saal_6_-_201312291130_-_y_u_no_isp_taking_back_the_net_-_taziden',NULL,'---
- 30c3
- Hardware & Making
','2013-12-28','f',32);
INSERT INTO "events" VALUES(1819,'import-06fb86d8a63bd64ae4','5571-h264-hq.gif','5571-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.573374','2014-07-10 15:22:27.852585','Calafou, postcapitalist ecoindustrial community','5571-h264-hq.jpg','2013-12-29','Calafou – the Ecoindustrial Postcapitalist Colony – is a settlement of around three dozen people in the Catalonian countryside. Concrete pylons standing 20 meters high hold a highway passing above the wild forest valley, where hall after dilapidated hall of industrial ruins stretch along the banks of a contaminated stream nurturing a twisted yet lively ecosystem.  Echoes of unseen, passing cars blend into the organic static of wildlife, punctuated by beats booming from the hacklab speakers.
','http://events.ccc.de/congress/2013/Fahrplan/events/5571.html','---
- acracia
','30C3_-_5571_-_en_-_saal_6_-_201312291830_-_calafou_postcapitalist_ecoindustrial_community_-_acracia','Building a space for grassroots sustainable technology development near Barcelona','---
- 30c3
- Science & Engineering
','2013-12-29','f',22);
INSERT INTO "events" VALUES(1820,'import-9e41b0c8cc37a6b14c','5532-h264-iprod.gif','5532-h264-iprod_preview.jpg',33,'2014-05-10 13:27:04.603735','2014-07-11 14:16:52.672398','Die Drohnenkriege','5532-h264-iprod.jpg','2013-12-29','Die Drohnenkriege sind Ausdruck einer rasanten Entwicklung: vom „Krieg gegen den Terror“ nach 9/11 zur Kriegsführung der Zukunft. Einer Zukunft, die gelegentlich der Science Fiction der späten Achtziger zu entstammen scheint, in der Roboter die schmutzigen Kriege der Menschen kämpfen und sich schließlich gegen ihre Schöpfer erheben. Letzteres liegt noch längst nicht im Bereich des Möglichen, aber Wege zur Erschaffung autonomer Kampfroboter werden bereits beschritten. Der Vortrag will das Phänomen des Drohnenkrieges politisch einordnen und einen Ausblick versuchen.
','http://events.ccc.de/congress/2013/Fahrplan/events/5532.html','---
- Norbert Schepers
','30C3_-_5532_-_de_-_saal_g_-_201312292300_-_die_drohnenkriege_-_norbert_schepers','Kriegsführung der Zukunft?','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-31','f',24);
INSERT INTO "events" VALUES(1821,'import-3f105f1f5ea9884ea7','5527-h264-hq.gif','5527-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.634187','2014-07-08 16:53:53.956478','Basics of Digital Wireless Communication','5527-h264-hq.jpg','2013-12-27','The aim of this talk is to give an understandable insight into wireless communication, using existing systems as examples on why there are different communication systems for different uses.
','http://events.ccc.de/congress/2013/Fahrplan/events/5527.html','---
- Clemens Hopfer
','30C3_-_5527_-_en_-_saal_g_-_201312271715_-_basics_of_digital_wireless_communication_-_clemens_hopfer','introduction to software radio principles','---
- 30c3
- Hardware & Making
','2013-12-28','f',22);
INSERT INTO "events" VALUES(1822,'import-04161ad232ec75b82d','5500-h264-hq.gif','5500-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.664317','2014-07-11 16:11:50.181833','Anonymity and Privacy in Public Space and on the Internet','5500-h264-hq.jpg','2013-12-29','How is it possible to participate in a social event anonymously? How can we hide from surveillance in public space? How can we communicate anonymously in real life? 
How can we be private in public?
This talk will give an overview about existing hacks and techniques that allow to be private in public, and compare privacy technologies from the web to anonymity techniques that can be used in real life.
','http://events.ccc.de/congress/2013/Fahrplan/events/5500.html','---
- aluburka
','30C3_-_5500_-_en_-_saal_g_-_201312291900_-_anonymity_and_privacy_in_public_space_and_on_the_internet_-_aluburka',NULL,'---
- 30c3
- Art & Beauty
','2013-12-29','f',17);
INSERT INTO "events" VALUES(1823,'import-15b40a57a3fc6c0b89','5495-h264-hq.gif','5495-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.695047','2014-07-08 06:52:42.377357','Concepts for global TSCM','5495-h264-hq.jpg','2013-12-30','After studying the various levels of activities that come together in BuggedPlanet and realizing the scope and level of implementation of NSA´s SIGINT theatre, it´s propably time to step back, summarize the big picture and ask how we handle it properly.
','http://events.ccc.de/congress/2013/Fahrplan/events/5495.html','---
- andy
','30C3_-_5495_-_en_-_saal_2_-_201312301600_-_concepts_for_global_tscm_-_andy','getting out of surveillance state mode','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-31','f',14);
INSERT INTO "events" VALUES(1824,'import-4f9f9721a72838f8c1','5595-h264-iprod.gif','5595-h264-iprod_preview.jpg',33,'2014-05-10 13:27:04.724521','2014-07-10 15:04:58.476089','The ArduGuitar','5595-h264-iprod.jpg','2013-12-29','The <a href="http://www.arduguitar.org">ArduGuitar</a> is an electric guitar with <i>no physical controls,</i> i.e. no buttons or knobs to adjust volume, tone or to select the pickups. All of these functions are performed remotely via a bluetooth device such as an Android phone, or via a dedicated Arduino powered blutetooth footpedal. The musician still plucks the strings, of course! This talk will give an overview of the technology and particularly the voyage that took me from nearly no knowledge about anything electronic to enough know-how to make it all work.I will explain what I learned by collaborating on forums, with Hackerspaces and with component providers: "How to ask the right questions." The guitar with its Arduino powered circuit and an Android tablet will be available for demo; the code is all available on the github <a href="https://github.com/gratefulfrog/ArduGuitar">arduguitar repo</a> with the associated <a href="https://github.com/gratefulfrog/lib">Arduino footpedal libraries</a>.
','http://events.ccc.de/congress/2013/Fahrplan/events/5595.html','---
- gratefulfrog
','30C3_-_5595_-_en_-_saal_6_-_201312291430_-_the_arduguitar_-_gratefulfrog','An Arduino Powered Electric Guitar','---
- 30c3
- Hardware & Making
','2013-12-28','f',21);
INSERT INTO "events" VALUES(1825,'import-5227d53d47998ddcdf','5554-h264-hq.gif','5554-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.754988','2014-07-11 05:13:23.592235','Magic Lantern','5554-h264-hq.jpg','2013-12-28','We present Magic Lantern, a free open software add-on for Canon DSLR cameras, that offers increased functionality aimed mainly at DSLR pro and power users. It runs alongside Canon''s own firmware and introduces to consumer-grade DSLRs features usually only found in professional high-end digital (cinema) cameras.
','http://events.ccc.de/congress/2013/Fahrplan/events/5554.html','---
- Michael Zöller
','30C3_-_5554_-_en_-_saal_6_-_201312281400_-_magic_lantern_-_michael_zoller','Free Software on Your Camera','---
- 30c3
- Hardware & Making
','2013-12-28','f',54);
INSERT INTO "events" VALUES(1826,'import-d1c48aa81fb3c80109','5185-h264-hq.gif','5185-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.784414','2014-07-12 08:38:26.568965','FPGA 101','5185-h264-hq.jpg','2013-12-28','In this talk I want to show you around in the mysterious world of
Field Programmable Gate Arrays, or short FPGAs. The aim is to enable you to get a rough understanding on what FPGAs are good at and how they can be used in areas where conventional CPUs and Microcontrollers are failing upon us. FPGAs open up the world of high-speed serial interconnects, nano-second event reactions and hardware fuzzing.
','http://events.ccc.de/congress/2013/Fahrplan/events/5185.html','---
- Karsten Becker
','30C3_-_5185_-_en_-_saal_g_-_201312281715_-_fpga_101_-_karsten_becker','Making awesome stuff with FPGAs','---
- 30c3
- Hardware & Making
','2013-12-29','f',11);
INSERT INTO "events" VALUES(1827,'import-859ad0f5b13604058c','5142-h264-hq.gif','5142-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.813733','2014-07-09 18:03:41.178914','Monitoring the Spectrum: Building Your Own Distributed RF Scanner Array','5142-h264-hq.jpg','2013-12-27','Software-Defined Radio (SDR) has increased in popularity in recent years due to the decrease in hardware costs and increase in processing power. One example of such a class of devices is the RTL-SDR USB dongles based on the Realtek RTL2832U demodulator. This talk will discuss my experience in building a distributed RF scanner array for monitoring and spectrum mapping using such cheap SDR devices. The goal is to help the audience understand the what, why, and how of building their own RF monitoring array so that they will be able to do it themselves. In this era of increasingly being ``watched'''', we must be prepared to do our own ``watching''''.
','http://events.ccc.de/congress/2013/Fahrplan/events/5142.html','---
- Andrew Reiter (arr,awr)
','30C3_-_5142_-_en_-_saal_6_-_201312271900_-_monitoring_the_spectrum_building_your_own_distributed_rf_scanner_array_-_andrew_reiter_arr_awr',NULL,'---
- 30c3
- Hardware & Making
','2013-12-28','f',18);
INSERT INTO "events" VALUES(1828,'import-b0705064a38233a3aa','5423-h264-hd.gif','5423-h264-hd_preview.jpg',33,'2014-05-10 13:27:04.878303','2014-07-12 04:20:21.404346','The Tor Network','5423-h264-hd.jpg','2013-12-27','Roger Dingledine and Jacob Appelbaum will discuss contemporary Tor Network issues related to censorship, security, privacy and anonymity online.
','http://events.ccc.de/congress/2013/Fahrplan/events/5423.html','---
- Jacob
- arma
','30C3_-_5423_-_en_-_saal_1_-_201312272030_-_the_tor_network_-_jacob_-_arma','We''re living in interesting times','---
- 30c3
- Ethics
- Society & Politics
','2013-12-31','f',107);
INSERT INTO "events" VALUES(1829,'import-8e04d8715901fe4dbf','5305-h264-hq.gif','5305-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.90713','2014-07-08 23:11:27.532638','Breaking Baryons','5305-h264-hq.jpg','2013-12-27','A light-hearted presentation about many aspects of particle accelerators like the LHC and their particle collision experiments. Aimed at technically interested non-scientists and physics buffs alike.
','http://events.ccc.de/congress/2013/Fahrplan/events/5305.html','---
- Michael Büker
','30C3_-_5305_-_en_-_saal_g_-_201312272300_-_breaking_baryons_-_michael_buker','On the Awesomeness of Particle Accelerators and Colliders','---
- 30c3
- Science & Engineering
','2013-12-28','f',12);
INSERT INTO "events" VALUES(1830,'import-618ef60115d38aa696','5499-h264-hq.gif','5499-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.936396','2014-07-10 14:17:40.718207','X Security','5499-h264-hq.jpg','2013-12-29','For the past year, I''ve been looking at the implementation of X.org code. both client and server. During this presentation, I''ll give an overview of the good, the bad and the ugly. 
','http://events.ccc.de/congress/2013/Fahrplan/events/5499.html','---
- Ilja van Sprundel
','30C3_-_5499_-_en_-_saal_1_-_201312291830_-_x_security_-_ilja_van_sprundel','It''s worse than it looks','---
- 30c3
- Security & Safety
','2013-12-29','f',52);
INSERT INTO "events" VALUES(1831,'import-d05d547349dcf1bfe9','5593-h264-hq.gif','5593-h264-hq_preview.jpg',33,'2014-05-10 13:27:04.966106','2014-07-08 20:11:03.189365','Hacking the Czech Parliament via SMS','5593-h264-hq.jpg','2013-12-30','The Czech art collective Ztohoven'' project “Moral Reform” was accomplished in collaboration with web security experts. Together they created the unique art concept of a mobile phone mass-hack.
','http://events.ccc.de/congress/2013/Fahrplan/events/5593.html','---
- Ztohoven
','30C3_-_5593_-_en_-_saal_1_-_201312301130_-_hacking_the_czech_parliament_via_sms_-_ztohoven','A parliamentary drama of 223 actors','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-31','f',6);
INSERT INTO "events" VALUES(1832,'import-fd1c740306fdc1a4b4','5322-h264-iprod.gif','5322-h264-iprod_preview.jpg',33,'2014-05-10 13:27:04.995266','2014-07-09 18:58:36.732733','Reverse engineering the Wii U Gamepad','5322-h264-iprod.jpg','2013-12-29','A year ago in November 2012, Nintendo released their latest home video game console: the Wii U. While most video game consoles use controllers that are very basic, the Wii U took the opposite route with a very featureful gamepad: wireless with a fairly high range, touch screen, speakers, accelerometer, video camera, and even NFC are supported by the Wii U gamepad. However, as of today, this interesting piece of hardware can only be used in conjunction with a Wii U: wireless communications are encrypted and obfuscated, and there is no documentation about the protocols used for data exchange between the console and its controller. Around december 2012, I started working with two other hackers in order to reverse engineer, document and implement the Wii U gamepad communication protocols on a PC. This talk will present our findings and show the current state of our reverse engineering efforts.
',NULL,'---
- delroth
','30C3_-_5322_-_en_-_saal_g_-_201312292030_-_reverse_engineering_the_wii_u_gamepad_-_delroth',NULL,'---
- 30c3
- Hardware & Making
','2013-12-29','f',17);
INSERT INTO "events" VALUES(1833,'import-6b6f007bca3aa41098','5588-h264-hq.gif','5588-h264-hq_preview.jpg',33,'2014-05-10 13:27:05.024208','2014-07-09 13:00:55.113274','My journey into FM-RDS','5588-h264-hq.jpg','2013-12-28','How I discovered mysterious hidden signals on a public radio channel and eventually found out their meaning through hardware hacking, reverse engineering and little cryptanalysis.
','http://events.ccc.de/congress/2013/Fahrplan/events/5588.html','---
- Oona Räisänen
','30C3_-_5588_-_en_-_saal_g_-_201312281600_-_my_journey_into_fm-rds_-_oona_raisanen',NULL,'---
- 30c3
- Hardware & Making
','2013-12-29','f',100);
INSERT INTO "events" VALUES(1834,'import-0367562fc8336025f3','5377-h264-iprod.gif','5377-h264-iprod_preview.jpg',33,'2014-05-10 13:27:05.05301','2014-07-12 07:16:56.526488','Überwachen und Sprache','5377-h264-iprod.jpg','2013-12-27','Der Vortrag stellt fortgeschrittene linguistische Methoden des politisch motivierten Internetmonitorings vor. Er gibt keine Anleitung, wie man sich der Überwachung wirkungsvoll entziehen kann, denn das ist ohnehin zwecklos.
','http://events.ccc.de/congress/2013/Fahrplan/events/5377.html','---
- josch
','30C3_-_5377_-_de_-_saal_6_-_201312271245_-_uberwachen_und_sprache_-_josch','How to do things with words','---
- 30c3
- Science & Engineering
','2013-12-28','f',28);
INSERT INTO "events" VALUES(1835,'import-da5f2baaf42494ab82','5449-h264-hd.gif','5449-h264-hd_preview.jpg',33,'2014-05-10 13:27:05.081695','2014-07-10 19:22:27.787601','Mobile network attack evolution','5449-h264-hd.jpg','2013-12-27','Mobile networks should protect users on several fronts: Calls need to be encrypted, customer data protected, and SIM cards shielded from malware.

Many networks are still reluctant to implement appropriate protection measures in legacy systems. But even those who add mitigations often fail to fully capture attacks: They target symptoms instead of solving the core issue.

This talks discusses mobile network and SIM card attacks that circumvent common protection techniques to illustrate the ongoing mobile attack evolution.
','http://events.ccc.de/congress/2013/Fahrplan/events/5449.html','---
- Karsten Nohl
- Luca Melette
','30C3_-_5449_-_en_-_saal_1_-_201312271715_-_mobile_network_attack_evolution_-_karsten_nohl_-_luca_melette',NULL,'---
- 30c3
- Security & Safety
','2013-12-31','f',34);
INSERT INTO "events" VALUES(1836,'import-0f9813fc7b10d89f56','5224-h264-hq.gif','5224-h264-hq_preview.jpg',33,'2014-05-10 13:27:05.2446','2014-07-05 22:44:09.603735','Triggering Deep Vulnerabilities Using Symbolic Execution','5224-h264-hq.jpg','2013-12-27','Symbolic Execution (SE) is a powerful way to analyze programs. Instead of using concrete data values SE uses symbolic values to evaluate a large set of parallel program paths at once. A drawback of many systems is that they need source code access and only scale to few lines of code. This talk explains how SE and binary analysis can be used to (i) reverse-engineer components of binary only applications and (ii) construct specific concrete input that triggers a given condition deep inside the application (think of defining an error condition and the SE engine constructs the input to the application that triggers the error).
','http://events.ccc.de/congress/2013/Fahrplan/events/5224.html','---
- gannimo
','30C3_-_5224_-_en_-_saal_6_-_201312271400_-_triggering_deep_vulnerabilities_using_symbolic_execution_-_gannimo','Deep program analysis without the headache','---
- 30c3
- Security & Safety
','2013-12-28','f',5);
INSERT INTO "events" VALUES(1837,'import-6fc14b193301c98136','5600-h264-hq.gif','5600-h264-hq_preview.jpg',33,'2014-05-10 13:27:05.275408','2014-07-12 10:52:33.591366','Thwarting Evil Maid Attacks','5600-h264-hq.jpg','2013-12-30',' 	Increasingly, users and their computing hardware are exposed a range of software and hardware attacks, ranging from disk imaging to hardware keylogger installation and beyond. Existing methods are inadequate to fully protect users, particularly from covert physical hardware modifications in the "evil maid" scenario, and yet are very inconvenient. Victims include governments and corporations traveling internationally (e.g. China), anti-government activists in places like Syria, and anyone who is a target of a motivated attacker who can gain physical access.

Physically Unclonable Functions, combined with a trusted mobile device and a network service, can be used to mitigate these risks. We present a novel open-source mobile client and network service which can protect arbitrary hardware from many forms of covert modification and attack, and which when integrated with software, firmware, and policy defenses, can provide greater protection to users and limit potential attack surface. We''ll also be showing video of an unreleased tool to the public utilized by surveillance teams.
','http://events.ccc.de/congress/2013/Fahrplan/events/5600.html','---
- Eric Michaud
- Ryan Lackey
','30C3_-_5600_-_en_-_saal_1_-_201312301245_-_thwarting_evil_maid_attacks_-_eric_michaud_-_ryan_lackey','Physically Unclonable Functions for Hardware Tamper Detection','---
- 30c3
- Security & Safety
','2014-01-03','f',42);
INSERT INTO "events" VALUES(1838,'import-20661c760d10008d91','5611-h264-hq.gif','5611-h264-hq_preview.jpg',33,'2014-05-10 13:27:05.306043','2014-07-09 17:37:35.79345','Hello World!','5611-h264-hq.jpg','2013-12-28','USB DeadDrops, IRL map marker in public, FUCK 3D glasses or How to vacuum form a guy fawkes mask. I will present an extensive overview of my art projects from over the last 10 years including the Fake Google car by F.A.T. and moar!! It all started here at the CCC congress! :)) For more info see link --->
','http://events.ccc.de/congress/2013/Fahrplan/events/5611.html','---
- Aram Bartholl
','30C3_-_5611_-_en_-_saal_2_-_201312281130_-_hello_world_-_aram_bartholl','How to make art after Snowden?','---
- 30c3
- Art & Beauty
','2013-12-28','f',17);
INSERT INTO "events" VALUES(1839,'import-91fab41ee6fe7ebaaf','5443-h264-hq.gif','5443-h264-hq_preview.jpg',33,'2014-05-10 13:27:05.336446','2014-07-08 22:37:05.41306','Introduction to Processor Design','5443-h264-hq.jpg','2013-12-28','This lecture gives an introduction to processor design.
It is mostly interesting for people new to processor design and does not cover high performance pipelined structures.
Small knowledge on VHDL programming would be great but is not essential. A very small processor core will described here.
Demo:

Create a backdoor in the VHDL Code of a processor core.
Exploit this backdoor to get a root shell in the linux operating system.
','http://events.ccc.de/congress/2013/Fahrplan/events/5443.html','---
- byterazor
','30C3_-_5443_-_en_-_saal_g_-_201312281830_-_introduction_to_processor_design_-_byterazor',NULL,'---
- 30c3
- Hardware & Making
','2013-12-29','f',18);
INSERT INTO "events" VALUES(1840,'import-98eea2990c7ad6a636','5223-h264-iprod.gif','5223-h264-iprod_preview.jpg',33,'2014-05-10 13:27:05.366386','2014-07-11 08:11:57.941122','WarGames in memory','5223-h264-iprod.jpg','2013-12-29','Memory corruption has been around forever but is still one of the most exploited problems on current systems. This talk looks at the past 30 years of memory corruption and systematizes the different existing exploit and defense techniques in a streamlined way. We evaluate (i) how the different attacks evolved, (ii) how researchers came up with defense mechanisms as an answer to new threats, and (iii) what we will have to expect in the future.
','http://events.ccc.de/congress/2013/Fahrplan/events/5223.html','---
- gannimo
','30C3_-_5223_-_en_-_saal_6_-_201312292030_-_wargames_in_memory_-_gannimo','what is the winning move?','---
- 30c3
- Security & Safety
','2013-12-29','f',16);
INSERT INTO "events" VALUES(1841,'import-5be448b116c2dd7252','5613-h264-hq.gif','5613-h264-hq_preview.jpg',33,'2014-05-10 13:27:05.396149','2014-07-10 19:18:48.065162','Forbidden Fruit','5613-h264-hq.jpg','2013-12-27','Various dietary restrictions are historically associated with human culture and civilization. In addition, millions suffer from eating disorders that have both pathological and cultural origins.
','http://events.ccc.de/congress/2013/Fahrplan/events/5613.html','---
- Joe Davis
','30C3_-_5613_-_en_-_saal_g_-_201312272030_-_forbidden_fruit_-_joe_davis',NULL,'---
- 30c3
- Art & Beauty
','2013-12-28','f',10);
INSERT INTO "events" VALUES(1842,'import-aadc22a0774bade952','5547-h264-hq.gif','5547-h264-hq_preview.jpg',33,'2014-05-10 13:27:05.460382','2014-07-12 00:22:50.764698','Turing Complete User','5547-h264-hq.jpg','2013-12-28','With the disappearance of the computer, something else is silently becoming invisible as well — the User. Users are disappearing as both phenomena and term, and this development is either unnoticed or accepted as progress — an evolutionary step. Though the Invisible User is more of an issue than an Invisible Computer.
','http://events.ccc.de/congress/2013/Fahrplan/events/5547.html','---
- olia lialina
','30C3_-_5547_-_en_-_saal_6_-_201312281730_-_turing_complete_user_-_olia_lialina','What can be done to protect the term, the notion and the existence of the Users?','---
- 30c3
- Art & Beauty
','2013-12-28','f',15);
INSERT INTO "events" VALUES(1843,'import-087c162e505f648d1f','5278-webm.gif','5278-webm_preview.jpg',33,'2014-05-10 13:27:05.489682','2014-07-10 15:46:04.389249','The philosophy of hacking','5278-webm.jpg','2013-12-30','Modern society''s use of technology as an instrument for domination is deeply problematic. Are instrumentality and domination inherent to the essence of technology? Can hacking provide an alternative approach to technology which can overcome this? How do art and beauty fit into this approach?
','http://events.ccc.de/congress/2013/Fahrplan/events/5278.html','---
- groente
','30C3_-_5278_-_en_-_saal_6_-_201312301300_-_the_philosophy_of_hacking_-_groente','Contemplations on the essence of hacking and its implications on hacker ethics','---
- 30c3
- Art & Beauty
','2013-12-31','f',21);
INSERT INTO "events" VALUES(1844,'import-b1ddb4aaa9a934a139','5415-h264-hq.gif','5415-h264-hq_preview.jpg',33,'2014-05-10 13:27:05.518792','2014-07-12 08:49:44.647345','Der tiefe Staat','5415-h264-hq.jpg','2013-12-27','Dieser Vortrag beschreibt Konzept und Idee des tiefen Staates anhand der Geschichte der BRD.
','http://events.ccc.de/congress/2013/Fahrplan/events/5415.html','---
- Andreas Lehner
','30C3_-_5415_-_de_-_saal_g_-_201312271245_-_der_tiefe_staat_-_andreas_lehner',NULL,'---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-28','f',52);
INSERT INTO "events" VALUES(1845,'import-8e0988f2594dcf81d9','5255-h264-iprod.gif','5255-h264-iprod_preview.jpg',33,'2014-05-10 13:27:05.548669','2014-07-10 21:47:30.411819','Through a PRISM, Darkly','5255-h264-iprod.jpg','2013-12-30','From Stellar Wind to PRISM, Boundless Informant to EvilOlive, the NSA spying programs are shrouded in secrecy and rubber-stamped by secret opinions from a court that meets in a faraday cage. The Electronic Frontier Foundation''s Kurt Opsahl explains the known facts about how the programs operate and the laws and regulations the U.S. government asserts allows the NSA to spy on you.
','http://events.ccc.de/congress/2013/Fahrplan/events/5255.html','---
- Kurt Opsahl
','30C3_-_5255_-_en_-_saal_1_-_201312301400_-_through_a_prism_darkly_-_kurt_opsahl','Everything we know about NSA spying','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-31','f',24);
INSERT INTO "events" VALUES(1846,'import-e4d8002bb02aee8dbc','5439-opus.gif','5439-opus_preview.jpg',33,'2014-05-10 13:27:05.578871','2014-07-12 07:46:39.811101','To Protect And Infect','5439-opus.jpg','2013-12-29','2013 will be remembered as the year that the Internet lost its innocence for nearly everyone as light was shed on the widespread use of dragnet surveillance by the NSA and intelligence agencies globally. With the uprisings of the Arab Spring where people raided the offices of their regimes to bring evidence to light, we''ve seen a tremendous phenomenon: a large numbers of whistleblowers have taken action to inform the public about important details. The WikiLeaks SpyFiles series also shows us important details to corroborate these claims. There is ample evidence about the use and abuses of a multi-billion dollar industry that have now come to light. This evidence includes increasing use of targeted attacks to establish even more invasive control over corporate, government or other so-called legitimate targets.
','http://events.ccc.de/congress/2013/Fahrplan/events/5439.html','---
- Claudio Guarnieri
- Morgan Marquis-Boire
','30C3_-_5439_-_en_-_saal_1_-_201312292105_-_to_protect_and_infect_-_claudio_guarnieri_-_morgan_marquis-boire','The militarization of the Internet','---
- 30c3
- Security & Safety
','2014-01-13','f',57);
INSERT INTO "events" VALUES(1847,'import-69fcc275efca6308b6','5622-h264-hd.gif','5622-h264-hd_preview.jpg',33,'2014-05-10 13:27:05.6082','2014-07-12 06:03:30.771731','30c3 Keynote','5622-h264-hd.jpg','2013-12-27','via videolink.
','http://events.ccc.de/congress/2013/Fahrplan/events/5622.html','---
- Glenn Greenwald
- frank
','30C3_-_5622_-_en_-_saal_1_-_201312271930_-_30c3_keynote_-_glenn_greenwald_-_frank',NULL,'---
- 30c3
- CCC
','2013-12-28','f',57);
INSERT INTO "events" VALUES(1848,'import-dd6b128aa6669b186d','5416-h264-hq.gif','5416-h264-hq_preview.jpg',33,'2014-05-10 13:27:05.636942','2014-07-08 13:46:43.089924','Desperately Seeking Susy','5416-h264-hq.jpg','2013-12-28','Supersymmetry has been particle theorists'' favorite toy for several decades. It predicts a yet unobserved symmetry of nature and implies that to each known type of elementary particle there exists a partner particle none of which has been detected up to today. 

I will explain why it is  an attractive idea nevertheless and what is the current situation after the large hadron collider (LHC) at CERN has looked at many places where supersymmetric partners were expected and did not find them. Is it time to give up hope that susy is a property of nature? 
','http://events.ccc.de/congress/2013/Fahrplan/events/5416.html','---
- atdotde
','30C3_-_5416_-_en_-_saal_6_-_201312282030_-_desperately_seeking_susy_-_atdotde','A farewell to a bold proposal?','---
- 30c3
- Science & Engineering
','2013-12-29','f',10);
INSERT INTO "events" VALUES(1849,'import-7bb022b25f78e9abd6','5548-h264-hq.gif','5548-h264-hq_preview.jpg',33,'2014-05-10 13:27:05.665971','2014-07-09 20:55:23.690269','25 Jahre Chipkarten-Angriffe','5548-h264-hq.jpg','2013-12-28','Eine unterhaltsame, spannende und lehrreiche Reise durch 25 Jahre Chipkarten-Angriffe mit tiefen Einblicken in Amateur- und Profi-Hackerlabore, inklusive eines Ausblicks in neueste Methoden und zukünftige Ansätze.
','http://events.ccc.de/congress/2013/Fahrplan/events/5548.html','---
- Peter Laackmann
- Marcus Janke
','30C3_-_5548_-_de_-_saal_1_-_201312282030_-_25_jahre_chipkarten-angriffe_-_peter_laackmann_-_marcus_janke','Von der Historie zur Zukunft','---
- 30c3
- Security & Safety
','2014-01-01','f',40);
INSERT INTO "events" VALUES(1850,'import-31676bd5fdb8327ff5','5446-h264-iprod.gif','5446-h264-iprod_preview.jpg',33,'2014-05-10 13:27:05.695168','2014-07-11 18:20:32.652217','The good, the bad, and the ugly - Linux Kernel patches','5446-h264-iprod.jpg','2013-12-28','Companies are often blamed for not working upstream. Surprisingly, the situation is not per se better with community projects. To change the latter for the better, Wolfram will show some examples regarding the Linux Kernel and present ideas to create win-win-win situations.
','http://events.ccc.de/congress/2013/Fahrplan/events/5446.html','---
- wsa
','30C3_-_5446_-_en_-_saal_g_-_201312282200_-_the_good_the_bad_and_the_ugly_-_linux_kernel_patches_-_wsa',NULL,'---
- 30c3
- Hardware & Making
','2013-12-31','f',27);
INSERT INTO "events" VALUES(1851,'import-195862fab55529d3cd','5623-h264-hq.gif','5623-h264-hq_preview.jpg',33,'2014-05-10 13:27:05.723679','2014-07-09 00:29:54.915236','Amtliche Datenschützer: Kontrolleure oder Papiertiger?','5623-h264-hq.jpg','2013-12-30','In dem Vortrag beschäftigt sich der Ex-Bundesdatenschützer mit der Rolle der Datenschutzbeauftragten: Welche Durchsetzungsmöglichkeiten haben sie? Wie ist ihr Verhältnis zur Zivilgesellschaft? Welchen Einfluss können sie auf europäischer und internationaler Ebene ausüben?
','http://events.ccc.de/congress/2013/Fahrplan/events/5623.html','---
- Peter Schaar
','30C3_-_5623_-_de_-_saal_1_-_201312301600_-_amtliche_datenschutzer_kontrolleure_oder_papiertiger_-_peter_schaar',NULL,'---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-31','f',22);
INSERT INTO "events" VALUES(1852,'import-66d737fe1f5c32c79a','5536-h264-hq.gif','5536-h264-hq_preview.jpg',33,'2014-05-10 13:27:05.91728','2014-07-08 15:13:52.871046','Long Distance Quantum Communication','5536-h264-hq.jpg','2013-12-27','This talk should introduce the general 30c3 participant with several components of long distance quantum communication.
','http://events.ccc.de/congress/2013/Fahrplan/events/5536.html','---
- C B
','30C3_-_5536_-_en_-_saal_g_-_201312271830_-_long_distance_quantum_communication_-_c_b','Concepts and components for intercontinal communication with single photons.','---
- 30c3
- Science & Engineering
','2013-12-28','f',16);
INSERT INTO "events" VALUES(1853,'import-90ecbc3bad4174dc04','5447-h264-hq.gif','5447-h264-hq_preview.jpg',33,'2014-05-10 13:27:05.947521','2014-07-01 10:22:52.615056','Policing the Romantic Crowd','5447-h264-hq.jpg','2013-12-27','This talk considers the use of new technology to police large crowds in the Romantic period. We examine ethical aspects of modern surveillance technologies by looking at debates around crowd control and face recognition in the age that first imagined, and reflected on, the surveillance state.
','http://events.ccc.de/congress/2013/Fahrplan/events/5447.html','---
- MaTu
','30C3_-_5447_-_en_-_saal_6_-_201312271730_-_policing_the_romantic_crowd_-_matu','Velocipedes and Face Recognition','---
- 30c3
- Ethics
- " Society & Politics"
','2013-12-28','f',11);
INSERT INTO "events" VALUES(1854,'import-f83c482143f1261646','5395-h264-hq.gif','5395-h264-hq_preview.jpg',33,'2014-05-10 13:27:05.977976','2014-07-10 14:18:58.756014','Towards an affordable brain-computer-interface','5395-h264-hq.jpg','2013-12-29','The brain can be understood as a highly specialized information processing device. Because computers basically do the same thing, it''s not too absurd to try to link these two together. The result is a brain-computer-interface.
This talk explains the core functionality of our brain and how to access the stored data from the outside. Software and hardware have already reached a somewhat hacker-friendly state, and we want to show you how we got there. We''re also here to answer all your questions about the brain.
','http://events.ccc.de/congress/2013/Fahrplan/events/5395.html','---
- Dominic
- Anne
','30C3_-_5395_-_en_-_saal_6_-_201312291600_-_towards_an_affordable_brain-computer-interface_-_dominic_-_anne',NULL,'---
- 30c3
- Science & Engineering
','2013-12-29','f',13);
INSERT INTO "events" VALUES(1855,'import-53792d8b505cd65da2','5587-h264-hd.gif','5587-h264-hd_preview.jpg',33,'2014-05-10 13:27:06.008333','2014-07-09 09:38:27.245976','Making machines that make','5587-h264-hd.jpg','2013-12-29','Making a new control system for a machine is often a slow and tedious task. Maybe you already have a 3 axis stage, and you already know how to move it around. But what if you want to add a camera and use it for position feedback? You''d have to redesign the whole hardware layer. I''ll talk about some ways I''ve built modularity into control systems for machines so that you can quickly iterate on different kinds of machine systems without getting stuck in hardware land forever. This includes connecting synchronized nodes across a network and importing legacy nodes for things like, say, an old pressure box you found in the trash and has rs232 in. Down with gcode! Long live machine control.
','http://events.ccc.de/congress/2013/Fahrplan/events/5587.html','---
- Nadya Peek
','30C3_-_5587_-_en_-_saal_1_-_201312291130_-_making_machines_that_make_-_nadya_peek','rapid prototyping of digital fabrication and instrumentation machines','---
- 30c3
- Hardware & Making
','2013-12-29','f',16);
CREATE TABLE "import_templates" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "acronym" varchar(255), "title" varchar(255), "logo" varchar(255), "webgen_location" varchar(255), "aspect_ratio" varchar(255), "recordings_path" varchar(255), "images_path" varchar(255), "date" date, "release_date" date, "mime_type" varchar(255), "folder" varchar(255), "width" integer, "height" integer, "created_at" datetime, "updated_at" datetime);
INSERT INTO "import_templates" VALUES(1,'chaostv','Chaos TV','','broadcasts/chaostv','4:3','broadcast/chaosradio/chaostv','chaostv','2009-06-11','2009-06-11','video/mp4','',NULL,NULL,'2014-06-11 22:26:17.610399','2014-06-22 11:56:50.050013');
CREATE TABLE "news" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "title" varchar(255), "body" text, "date" date, "created_at" datetime, "updated_at" datetime);
INSERT INTO "news" VALUES(1,'Torrents','The new CDN allows us to serve torrents for all the videos. Torrent links have been added to all video pages.','2013-11-28','2014-05-10 13:31:13.889961','2014-05-10 13:31:13.889961');
INSERT INTO "news" VALUES(2,' 30C3 Recordings Release','The <a href="http://media.ccc.de/browse/congress/2013">30C3 video recording</a> release process has started.','2013-12-30','2014-05-10 13:31:13.901941','2014-05-10 13:31:13.901941');
INSERT INTO "news" VALUES(3,'New Media','Over the next weeks media.ccc.de will be updated. The upgrade involves new hardware and a new frontend.

<p>
With regards to the frontend, I''m afraid some features will be lost by the upgrade and may never return, like FLV with flash player.
Some of the more obscure video folders won''t be part of the initial import.
However they will get imported and probably re-encoded for HTML5 eventually.
</p>

The <a href="http://cdn.media.ccc.de">CDN</a> should have a minimal downtime only while we change the machine.','2014-05-01','2014-05-10 13:31:13.909942','2014-05-10 13:31:13.909942');
INSERT INTO "news" VALUES(4,'New Hardware','<p>Big thanks to everyone involved! We successfully switched to the new hardware.</p>

<p>There are still some of the smaller folders missing, but we''re working on it.</p>

<p>
In the meantime you can take a look at our <a href="/about.html">mirror status table</a>, that is if you ignore SSL errors.
If you want to stay up to date with media news, you can subscribe to our  new atom <a href="/news.atom">news feed</a>.
</p>

Besides our existing feeds, we now offer an experimental public <a href="https://api.media.ccc.de/public/conferences?format=json">JSON API</a> for all the recordings.','2014-05-31','2014-05-31 22:15:37.998236','2014-05-31 22:29:27.284677');
INSERT INTO "news" VALUES(5,'Gulaschprogrammiernacht 14','All recorded <a href="//entropia.de/GPN14">GPN14</a> talks are <a href="//media.ccc.de/browse/conferences/gpn/gpn14/">available</a> from now on.','2014-06-25','2014-06-25 15:32:27.1269','2014-06-25 15:32:27.1269');
CREATE TABLE "recording_views" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "recording_id" integer, "created_at" datetime, "updated_at" datetime);
INSERT INTO "recording_views" VALUES(2,3767,'2014-06-27 18:18:52.770441','2014-06-27 18:18:52.770441');
INSERT INTO "recording_views" VALUES(3,3767,'2014-06-27 18:20:57.889229','2014-06-27 18:20:57.889229');
INSERT INTO "recording_views" VALUES(4,3766,'2014-06-27 18:21:22.576258','2014-06-27 18:21:22.576258');
INSERT INTO "recording_views" VALUES(5,3766,'2014-06-27 18:23:32.657124','2014-06-27 18:23:32.657124');
INSERT INTO "recording_views" VALUES(7,3766,'2014-06-27 18:29:48.102315','2014-06-27 18:29:48.102315');
INSERT INTO "recording_views" VALUES(8,3509,'2014-06-27 18:30:05.019905','2014-06-27 18:30:05.019905');
INSERT INTO "recording_views" VALUES(10,3766,'2014-06-27 18:33:32.264512','2014-06-27 18:33:32.264512');
INSERT INTO "recording_views" VALUES(11,3743,'2014-06-27 18:36:07.310152','2014-06-27 18:36:07.310152');
INSERT INTO "recording_views" VALUES(12,3766,'2014-06-27 18:39:54.520858','2014-06-27 18:39:54.520858');
INSERT INTO "recording_views" VALUES(13,3766,'2014-06-27 18:42:19.920596','2014-06-27 18:42:19.920596');
INSERT INTO "recording_views" VALUES(14,3811,'2014-06-27 18:42:43.234097','2014-06-27 18:42:43.234097');
INSERT INTO "recording_views" VALUES(15,3475,'2014-06-27 18:45:49.275655','2014-06-27 18:45:49.275655');
INSERT INTO "recording_views" VALUES(16,3475,'2014-06-27 18:47:49.678753','2014-06-27 18:47:49.678753');
INSERT INTO "recording_views" VALUES(19,3431,'2014-06-27 18:50:24.365023','2014-06-27 18:50:24.365023');
INSERT INTO "recording_views" VALUES(20,3811,'2014-06-27 18:50:36.556227','2014-06-27 18:50:36.556227');
INSERT INTO "recording_views" VALUES(21,3683,'2014-06-27 18:51:45.630698','2014-06-27 18:51:45.630698');
INSERT INTO "recording_views" VALUES(22,3575,'2014-06-27 18:51:53.60552','2014-06-27 18:51:53.60552');
INSERT INTO "recording_views" VALUES(23,3682,'2014-06-27 18:52:09.69323','2014-06-27 18:52:09.69323');
INSERT INTO "recording_views" VALUES(25,3683,'2014-06-27 18:53:21.120819','2014-06-27 18:53:21.120819');
INSERT INTO "recording_views" VALUES(26,3767,'2014-06-27 18:54:06.943879','2014-06-27 18:54:06.943879');
INSERT INTO "recording_views" VALUES(27,3674,'2014-06-27 18:54:18.315527','2014-06-27 18:54:18.315527');
INSERT INTO "recording_views" VALUES(28,3713,'2014-06-27 18:55:04.435251','2014-06-27 18:55:04.435251');
INSERT INTO "recording_views" VALUES(29,3683,'2014-06-27 18:55:48.880631','2014-06-27 18:55:48.880631');
INSERT INTO "recording_views" VALUES(31,3475,'2014-06-27 18:58:01.134944','2014-06-27 18:58:01.134944');
INSERT INTO "recording_views" VALUES(34,3713,'2014-06-27 19:03:16.296246','2014-06-27 19:03:16.296246');
INSERT INTO "recording_views" VALUES(35,3713,'2014-06-27 19:05:17.33509','2014-06-27 19:05:17.33509');
INSERT INTO "recording_views" VALUES(38,3674,'2014-06-27 19:13:28.829643','2014-06-27 19:13:28.829643');
INSERT INTO "recording_views" VALUES(40,3674,'2014-06-27 19:17:13.72145','2014-06-27 19:17:13.72145');
INSERT INTO "recording_views" VALUES(42,3713,'2014-06-27 19:18:38.978223','2014-06-27 19:18:38.978223');
INSERT INTO "recording_views" VALUES(43,3430,'2014-06-27 19:18:48.243569','2014-06-27 19:18:48.243569');
INSERT INTO "recording_views" VALUES(44,3713,'2014-06-27 19:21:02.579561','2014-06-27 19:21:02.579561');
INSERT INTO "recording_views" VALUES(45,3766,'2014-06-27 19:21:36.779089','2014-06-27 19:21:36.779089');
INSERT INTO "recording_views" VALUES(46,3767,'2014-06-27 19:22:56.462121','2014-06-27 19:22:56.462121');
INSERT INTO "recording_views" VALUES(47,3767,'2014-06-27 19:23:06.674535','2014-06-27 19:23:06.674535');
INSERT INTO "recording_views" VALUES(49,3811,'2014-06-27 19:24:34.72073','2014-06-27 19:24:34.72073');
INSERT INTO "recording_views" VALUES(50,3683,'2014-06-27 19:25:50.328498','2014-06-27 19:25:50.328498');
INSERT INTO "recording_views" VALUES(51,3721,'2014-06-27 19:25:55.711088','2014-06-27 19:25:55.711088');
INSERT INTO "recording_views" VALUES(54,3713,'2014-06-27 19:31:52.46773','2014-06-27 19:31:52.46773');
INSERT INTO "recording_views" VALUES(55,3560,'2014-06-27 19:32:13.029185','2014-06-27 19:32:13.029185');
INSERT INTO "recording_views" VALUES(57,3560,'2014-06-27 19:34:32.188483','2014-06-27 19:34:32.188483');
INSERT INTO "recording_views" VALUES(58,3773,'2014-06-27 19:35:03.026938','2014-06-27 19:35:03.026938');
INSERT INTO "recording_views" VALUES(59,3452,'2014-06-27 19:35:11.886543','2014-06-27 19:35:11.886543');
INSERT INTO "recording_views" VALUES(60,3560,'2014-06-27 19:37:13.496299','2014-06-27 19:37:13.496299');
INSERT INTO "recording_views" VALUES(61,3767,'2014-06-27 19:39:35.134018','2014-06-27 19:39:35.134018');
INSERT INTO "recording_views" VALUES(62,3767,'2014-06-27 19:39:47.923992','2014-06-27 19:39:47.923992');
INSERT INTO "recording_views" VALUES(65,3646,'2014-06-27 19:46:10.828437','2014-06-27 19:46:10.828437');
INSERT INTO "recording_views" VALUES(66,3646,'2014-06-27 19:49:02.747164','2014-06-27 19:49:02.747164');
INSERT INTO "recording_views" VALUES(67,3452,'2014-06-27 19:50:42.978071','2014-06-27 19:50:42.978071');
INSERT INTO "recording_views" VALUES(68,3767,'2014-06-27 19:52:00.195411','2014-06-27 19:52:00.195411');
INSERT INTO "recording_views" VALUES(74,3721,'2014-06-27 20:04:52.065441','2014-06-27 20:04:52.065441');
INSERT INTO "recording_views" VALUES(79,3767,'2014-06-27 20:11:51.846729','2014-06-27 20:11:51.846729');
INSERT INTO "recording_views" VALUES(81,3674,'2014-06-27 20:22:34.656695','2014-06-27 20:22:34.656695');
INSERT INTO "recording_views" VALUES(82,3713,'2014-06-27 20:23:58.118081','2014-06-27 20:23:58.118081');
INSERT INTO "recording_views" VALUES(84,3710,'2014-06-27 20:25:47.86771','2014-06-27 20:25:47.86771');
INSERT INTO "recording_views" VALUES(87,3662,'2014-06-27 20:34:11.248862','2014-06-27 20:34:11.248862');
INSERT INTO "recording_views" VALUES(88,3767,'2014-06-27 20:36:30.266547','2014-06-27 20:36:30.266547');
INSERT INTO "recording_views" VALUES(89,3788,'2014-06-27 20:42:52.890104','2014-06-27 20:42:52.890104');
INSERT INTO "recording_views" VALUES(91,3766,'2014-06-27 20:56:47.633889','2014-06-27 20:56:47.633889');
INSERT INTO "recording_views" VALUES(94,3767,'2014-06-27 21:03:47.280291','2014-06-27 21:03:47.280291');
INSERT INTO "recording_views" VALUES(97,3788,'2014-06-27 21:09:12.058345','2014-06-27 21:09:12.058345');
INSERT INTO "recording_views" VALUES(98,1278,'2014-06-27 21:09:51.237345','2014-06-27 21:09:51.237345');
INSERT INTO "recording_views" VALUES(100,1278,'2014-06-27 21:12:35.171813','2014-06-27 21:12:35.171813');
INSERT INTO "recording_views" VALUES(101,3602,'2014-06-27 21:12:39.313313','2014-06-27 21:12:39.313313');
INSERT INTO "recording_views" VALUES(102,3767,'2014-06-27 21:13:38.2233','2014-06-27 21:13:38.2233');
INSERT INTO "recording_views" VALUES(103,3575,'2014-06-27 21:16:55.363682','2014-06-27 21:16:55.363682');
INSERT INTO "recording_views" VALUES(104,1278,'2014-06-27 21:16:56.201375','2014-06-27 21:16:56.201375');
INSERT INTO "recording_views" VALUES(105,1278,'2014-06-27 21:21:24.35568','2014-06-27 21:21:24.35568');
INSERT INTO "recording_views" VALUES(106,3752,'2014-06-27 21:24:11.703238','2014-06-27 21:24:11.703238');
INSERT INTO "recording_views" VALUES(107,3767,'2014-06-27 21:24:18.576126','2014-06-27 21:24:18.576126');
INSERT INTO "recording_views" VALUES(108,3788,'2014-06-27 21:27:21.779912','2014-06-27 21:27:21.779912');
INSERT INTO "recording_views" VALUES(109,3752,'2014-06-27 21:27:25.718991','2014-06-27 21:27:25.718991');
INSERT INTO "recording_views" VALUES(110,3602,'2014-06-27 21:27:38.37186','2014-06-27 21:27:38.37186');
INSERT INTO "recording_views" VALUES(111,3715,'2014-06-27 21:28:17.216045','2014-06-27 21:28:17.216045');
INSERT INTO "recording_views" VALUES(112,3440,'2014-06-27 21:30:35.055802','2014-06-27 21:30:35.055802');
INSERT INTO "recording_views" VALUES(116,3788,'2014-06-27 21:35:29.019076','2014-06-27 21:35:29.019076');
INSERT INTO "recording_views" VALUES(121,3536,'2014-06-27 21:47:34.617206','2014-06-27 21:47:34.617206');
INSERT INTO "recording_views" VALUES(125,3767,'2014-06-27 21:52:20.418896','2014-06-27 21:52:20.418896');
INSERT INTO "recording_views" VALUES(129,3569,'2014-06-27 21:56:49.816392','2014-06-27 21:56:49.816392');
INSERT INTO "recording_views" VALUES(130,3478,'2014-06-27 21:58:57.870914','2014-06-27 21:58:57.870914');
INSERT INTO "recording_views" VALUES(147,3452,'2014-06-27 22:20:41.091456','2014-06-27 22:20:41.091456');
INSERT INTO "recording_views" VALUES(148,3452,'2014-06-27 22:23:36.1529','2014-06-27 22:23:36.1529');
INSERT INTO "recording_views" VALUES(153,3478,'2014-06-27 22:29:12.285811','2014-06-27 22:29:12.285811');
INSERT INTO "recording_views" VALUES(158,3452,'2014-06-27 22:33:53.699117','2014-06-27 22:33:53.699117');
INSERT INTO "recording_views" VALUES(159,3448,'2014-06-27 22:41:40.20075','2014-06-27 22:41:40.20075');
INSERT INTO "recording_views" VALUES(160,3665,'2014-06-27 22:43:42.195043','2014-06-27 22:43:42.195043');
INSERT INTO "recording_views" VALUES(161,3713,'2014-06-27 22:44:54.586794','2014-06-27 22:44:54.586794');
INSERT INTO "recording_views" VALUES(166,3674,'2014-06-27 22:52:32.451303','2014-06-27 22:52:32.451303');
INSERT INTO "recording_views" VALUES(173,3448,'2014-06-27 23:08:12.181668','2014-06-27 23:08:12.181668');
INSERT INTO "recording_views" VALUES(175,1341,'2014-06-27 23:09:40.128256','2014-06-27 23:09:40.128256');
INSERT INTO "recording_views" VALUES(176,1254,'2014-06-27 23:10:03.459471','2014-06-27 23:10:03.459471');
INSERT INTO "recording_views" VALUES(177,3710,'2014-06-27 23:10:28.227644','2014-06-27 23:10:28.227644');
INSERT INTO "recording_views" VALUES(179,3446,'2014-06-27 23:12:42.958207','2014-06-27 23:12:42.958207');
INSERT INTO "recording_views" VALUES(188,3503,'2014-06-27 23:26:52.354499','2014-06-27 23:26:52.354499');
INSERT INTO "recording_views" VALUES(190,3503,'2014-06-27 23:30:08.395817','2014-06-27 23:30:08.395817');
INSERT INTO "recording_views" VALUES(191,3667,'2014-06-27 23:31:46.18725','2014-06-27 23:31:46.18725');
INSERT INTO "recording_views" VALUES(192,3728,'2014-06-27 23:35:49.363704','2014-06-27 23:35:49.363704');
INSERT INTO "recording_views" VALUES(198,3667,'2014-06-27 23:43:33.662028','2014-06-27 23:43:33.662028');
INSERT INTO "recording_views" VALUES(201,3452,'2014-06-27 23:52:21.013464','2014-06-27 23:52:21.013464');
INSERT INTO "recording_views" VALUES(203,3716,'2014-06-28 00:12:53.148502','2014-06-28 00:12:53.148502');
INSERT INTO "recording_views" VALUES(204,3716,'2014-06-28 00:19:15.12679','2014-06-28 00:19:15.12679');
INSERT INTO "recording_views" VALUES(207,3497,'2014-06-28 01:21:41.240872','2014-06-28 01:21:41.240872');
INSERT INTO "recording_views" VALUES(211,1260,'2014-06-28 03:34:10.334332','2014-06-28 03:34:10.334332');
INSERT INTO "recording_views" VALUES(213,3559,'2014-06-28 03:48:45.220339','2014-06-28 03:48:45.220339');
INSERT INTO "recording_views" VALUES(214,3779,'2014-06-28 03:52:07.043744','2014-06-28 03:52:07.043744');
INSERT INTO "recording_views" VALUES(215,3779,'2014-06-28 03:54:10.854461','2014-06-28 03:54:10.854461');
INSERT INTO "recording_views" VALUES(216,3559,'2014-06-28 03:54:29.852558','2014-06-28 03:54:29.852558');
INSERT INTO "recording_views" VALUES(217,3779,'2014-06-28 03:57:24.423921','2014-06-28 03:57:24.423921');
INSERT INTO "recording_views" VALUES(218,3779,'2014-06-28 04:42:48.643756','2014-06-28 04:42:48.643756');
INSERT INTO "recording_views" VALUES(220,3560,'2014-06-28 05:15:19.202709','2014-06-28 05:15:19.202709');
INSERT INTO "recording_views" VALUES(221,3767,'2014-06-28 05:43:17.023669','2014-06-28 05:43:17.023669');
INSERT INTO "recording_views" VALUES(222,3452,'2014-06-28 05:53:39.863597','2014-06-28 05:53:39.863597');
INSERT INTO "recording_views" VALUES(223,3797,'2014-06-28 05:55:39.736891','2014-06-28 05:55:39.736891');
INSERT INTO "recording_views" VALUES(224,3695,'2014-06-28 05:56:55.119043','2014-06-28 05:56:55.119043');
INSERT INTO "recording_views" VALUES(225,3695,'2014-06-28 06:11:40.508357','2014-06-28 06:11:40.508357');
INSERT INTO "recording_views" VALUES(227,3767,'2014-06-28 06:20:07.61183','2014-06-28 06:20:07.61183');
INSERT INTO "recording_views" VALUES(228,3767,'2014-06-28 06:22:36.235137','2014-06-28 06:22:36.235137');
INSERT INTO "recording_views" VALUES(229,3811,'2014-06-28 06:38:20.467184','2014-06-28 06:38:20.467184');
INSERT INTO "recording_views" VALUES(231,3767,'2014-06-28 06:55:25.092976','2014-06-28 06:55:25.092976');
INSERT INTO "recording_views" VALUES(232,3497,'2014-06-28 06:56:42.527668','2014-06-28 06:56:42.527668');
INSERT INTO "recording_views" VALUES(233,3767,'2014-06-28 06:57:26.238589','2014-06-28 06:57:26.238589');
INSERT INTO "recording_views" VALUES(235,3743,'2014-06-28 07:05:01.849174','2014-06-28 07:05:01.849174');
INSERT INTO "recording_views" VALUES(236,3479,'2014-06-28 07:05:30.786258','2014-06-28 07:05:30.786258');
INSERT INTO "recording_views" VALUES(237,3560,'2014-06-28 07:05:33.214758','2014-06-28 07:05:33.214758');
INSERT INTO "recording_views" VALUES(238,3560,'2014-06-28 07:07:48.394942','2014-06-28 07:07:48.394942');
INSERT INTO "recording_views" VALUES(239,3479,'2014-06-28 07:11:15.358075','2014-06-28 07:11:15.358075');
INSERT INTO "recording_views" VALUES(240,3575,'2014-06-28 07:13:46.821262','2014-06-28 07:13:46.821262');
INSERT INTO "recording_views" VALUES(241,3446,'2014-06-28 07:14:57.348417','2014-06-28 07:14:57.348417');
INSERT INTO "recording_views" VALUES(242,3758,'2014-06-28 07:14:59.349366','2014-06-28 07:14:59.349366');
INSERT INTO "recording_views" VALUES(243,3539,'2014-06-28 07:15:26.268769','2014-06-28 07:15:26.268769');
INSERT INTO "recording_views" VALUES(244,3560,'2014-06-28 07:15:39.182088','2014-06-28 07:15:39.182088');
INSERT INTO "recording_views" VALUES(245,3800,'2014-06-28 07:16:19.030237','2014-06-28 07:16:19.030237');
INSERT INTO "recording_views" VALUES(246,3560,'2014-06-28 07:22:20.861489','2014-06-28 07:22:20.861489');
INSERT INTO "recording_views" VALUES(247,3560,'2014-06-28 07:26:58.864738','2014-06-28 07:26:58.864738');
INSERT INTO "recording_views" VALUES(248,3560,'2014-06-28 07:33:29.636605','2014-06-28 07:33:29.636605');
INSERT INTO "recording_views" VALUES(249,3560,'2014-06-28 07:38:57.013626','2014-06-28 07:38:57.013626');
INSERT INTO "recording_views" VALUES(250,3506,'2014-06-28 07:40:12.619253','2014-06-28 07:40:12.619253');
INSERT INTO "recording_views" VALUES(251,3796,'2014-06-28 07:42:18.86322','2014-06-28 07:42:18.86322');
INSERT INTO "recording_views" VALUES(253,3514,'2014-06-28 07:45:57.252714','2014-06-28 07:45:57.252714');
INSERT INTO "recording_views" VALUES(254,3509,'2014-06-28 07:46:00.039666','2014-06-28 07:46:00.039666');
INSERT INTO "recording_views" VALUES(256,3647,'2014-06-28 07:51:35.058034','2014-06-28 07:51:35.058034');
INSERT INTO "recording_views" VALUES(257,3602,'2014-06-28 07:52:38.501894','2014-06-28 07:52:38.501894');
INSERT INTO "recording_views" VALUES(258,3514,'2014-06-28 08:21:24.540644','2014-06-28 08:21:24.540644');
INSERT INTO "recording_views" VALUES(260,3514,'2014-06-28 08:32:00.424604','2014-06-28 08:32:00.424604');
INSERT INTO "recording_views" VALUES(261,3767,'2014-06-28 08:36:56.965503','2014-06-28 08:36:56.965503');
INSERT INTO "recording_views" VALUES(262,3716,'2014-06-28 08:42:59.840308','2014-06-28 08:42:59.840308');
INSERT INTO "recording_views" VALUES(263,3668,'2014-06-28 08:43:36.618453','2014-06-28 08:43:36.618453');
INSERT INTO "recording_views" VALUES(264,3716,'2014-06-28 08:45:20.488097','2014-06-28 08:45:20.488097');
INSERT INTO "recording_views" VALUES(265,3514,'2014-06-28 08:49:02.700035','2014-06-28 08:49:02.700035');
INSERT INTO "recording_views" VALUES(266,3767,'2014-06-28 08:51:55.872735','2014-06-28 08:51:55.872735');
INSERT INTO "recording_views" VALUES(267,3715,'2014-06-28 08:53:28.609872','2014-06-28 08:53:28.609872');
INSERT INTO "recording_views" VALUES(268,3542,'2014-06-28 08:54:45.976757','2014-06-28 08:54:45.976757');
INSERT INTO "recording_views" VALUES(270,1287,'2014-06-28 09:17:35.290166','2014-06-28 09:17:35.290166');
INSERT INTO "recording_views" VALUES(271,3767,'2014-06-28 09:19:37.344615','2014-06-28 09:19:37.344615');
INSERT INTO "recording_views" VALUES(272,3742,'2014-06-28 09:21:55.246725','2014-06-28 09:21:55.246725');
INSERT INTO "recording_views" VALUES(276,3466,'2014-06-28 09:40:46.524404','2014-06-28 09:40:46.524404');
INSERT INTO "recording_views" VALUES(278,3742,'2014-06-28 09:43:40.43661','2014-06-28 09:43:40.43661');
INSERT INTO "recording_views" VALUES(280,1326,'2014-06-28 09:53:06.931298','2014-06-28 09:53:06.931298');
INSERT INTO "recording_views" VALUES(281,1296,'2014-06-28 10:00:35.471363','2014-06-28 10:00:35.471363');
INSERT INTO "recording_views" VALUES(283,3742,'2014-06-28 10:06:45.871603','2014-06-28 10:06:45.871603');
INSERT INTO "recording_views" VALUES(286,3475,'2014-06-28 10:12:08.442333','2014-06-28 10:12:08.442333');
INSERT INTO "recording_views" VALUES(288,3452,'2014-06-28 10:13:18.249976','2014-06-28 10:13:18.249976');
INSERT INTO "recording_views" VALUES(293,3452,'2014-06-28 10:17:28.877794','2014-06-28 10:17:28.877794');
INSERT INTO "recording_views" VALUES(299,3749,'2014-06-28 10:21:31.62724','2014-06-28 10:21:31.62724');
INSERT INTO "recording_views" VALUES(303,3833,'2014-06-28 10:31:06.164001','2014-06-28 10:31:06.164001');
INSERT INTO "recording_views" VALUES(309,3475,'2014-06-28 10:42:23.871397','2014-06-28 10:42:23.871397');
INSERT INTO "recording_views" VALUES(314,3601,'2014-06-28 10:50:52.000575','2014-06-28 10:50:52.000575');
INSERT INTO "recording_views" VALUES(316,3500,'2014-06-28 10:53:56.999426','2014-06-28 10:53:56.999426');
INSERT INTO "recording_views" VALUES(319,3833,'2014-06-28 11:07:24.173551','2014-06-28 11:07:24.173551');
INSERT INTO "recording_views" VALUES(321,3475,'2014-06-28 11:09:57.005631','2014-06-28 11:09:57.005631');
INSERT INTO "recording_views" VALUES(323,3475,'2014-06-28 11:13:18.055743','2014-06-28 11:13:18.055743');
INSERT INTO "recording_views" VALUES(326,3833,'2014-06-28 11:23:49.046771','2014-06-28 11:23:49.046771');
INSERT INTO "recording_views" VALUES(330,3659,'2014-06-28 11:29:14.92419','2014-06-28 11:29:14.92419');
INSERT INTO "recording_views" VALUES(334,3467,'2014-06-28 11:48:55.610187','2014-06-28 11:48:55.610187');
INSERT INTO "recording_views" VALUES(335,3596,'2014-06-28 11:49:08.955279','2014-06-28 11:49:08.955279');
INSERT INTO "recording_views" VALUES(336,3596,'2014-06-28 11:51:09.376397','2014-06-28 11:51:09.376397');
INSERT INTO "recording_views" VALUES(337,3467,'2014-06-28 11:53:51.342737','2014-06-28 11:53:51.342737');
INSERT INTO "recording_views" VALUES(338,3467,'2014-06-28 11:56:08.348244','2014-06-28 11:56:08.348244');
INSERT INTO "recording_views" VALUES(340,3467,'2014-06-28 12:03:54.723012','2014-06-28 12:03:54.723012');
INSERT INTO "recording_views" VALUES(342,3767,'2014-06-28 12:17:22.868332','2014-06-28 12:17:22.868332');
INSERT INTO "recording_views" VALUES(345,3475,'2014-06-28 13:00:39.744078','2014-06-28 13:00:39.744078');
INSERT INTO "recording_views" VALUES(346,3475,'2014-06-28 13:03:16.563809','2014-06-28 13:03:16.563809');
INSERT INTO "recording_views" VALUES(347,3715,'2014-06-28 13:06:01.687368','2014-06-28 13:06:01.687368');
INSERT INTO "recording_views" VALUES(348,3475,'2014-06-28 13:10:05.814399','2014-06-28 13:10:05.814399');
INSERT INTO "recording_views" VALUES(349,3475,'2014-06-28 13:14:39.742013','2014-06-28 13:14:39.742013');
INSERT INTO "recording_views" VALUES(350,3466,'2014-06-28 13:18:49.572966','2014-06-28 13:18:49.572966');
INSERT INTO "recording_views" VALUES(351,3475,'2014-06-28 13:18:57.708275','2014-06-28 13:18:57.708275');
INSERT INTO "recording_views" VALUES(353,3475,'2014-06-28 13:21:27.042276','2014-06-28 13:21:27.042276');
INSERT INTO "recording_views" VALUES(354,3767,'2014-06-28 13:25:02.250086','2014-06-28 13:25:02.250086');
INSERT INTO "recording_views" VALUES(355,3497,'2014-06-28 13:27:50.18265','2014-06-28 13:27:50.18265');
INSERT INTO "recording_views" VALUES(357,3475,'2014-06-28 13:30:10.811499','2014-06-28 13:30:10.811499');
INSERT INTO "recording_views" VALUES(359,3475,'2014-06-28 13:35:13.667796','2014-06-28 13:35:13.667796');
INSERT INTO "recording_views" VALUES(360,3713,'2014-06-28 13:35:32.559131','2014-06-28 13:35:32.559131');
INSERT INTO "recording_views" VALUES(361,3713,'2014-06-28 13:36:10.805487','2014-06-28 13:36:10.805487');
INSERT INTO "recording_views" VALUES(362,3475,'2014-06-28 13:38:05.430563','2014-06-28 13:38:05.430563');
INSERT INTO "recording_views" VALUES(364,3475,'2014-06-28 13:42:39.68578','2014-06-28 13:42:39.68578');
INSERT INTO "recording_views" VALUES(365,3559,'2014-06-28 13:43:09.44609','2014-06-28 13:43:09.44609');
INSERT INTO "recording_views" VALUES(368,3715,'2014-06-28 13:54:34.18141','2014-06-28 13:54:34.18141');
INSERT INTO "recording_views" VALUES(370,3497,'2014-06-28 14:16:09.287663','2014-06-28 14:16:09.287663');
INSERT INTO "recording_views" VALUES(372,166,'2014-06-28 14:31:34.875192','2014-06-28 14:31:34.875192');
INSERT INTO "recording_views" VALUES(377,3767,'2014-06-28 14:48:38.200651','2014-06-28 14:48:38.200651');
INSERT INTO "recording_views" VALUES(381,3710,'2014-06-28 15:15:24.904365','2014-06-28 15:15:24.904365');
INSERT INTO "recording_views" VALUES(383,3710,'2014-06-28 15:17:40.67686','2014-06-28 15:17:40.67686');
INSERT INTO "recording_views" VALUES(388,1311,'2014-06-28 15:36:03.642764','2014-06-28 15:36:03.642764');
INSERT INTO "recording_views" VALUES(389,3652,'2014-06-28 15:37:52.570628','2014-06-28 15:37:52.570628');
INSERT INTO "recording_views" VALUES(390,3653,'2014-06-28 15:38:05.190474','2014-06-28 15:38:05.190474');
INSERT INTO "recording_views" VALUES(391,3743,'2014-06-28 15:42:13.506133','2014-06-28 15:42:13.506133');
INSERT INTO "recording_views" VALUES(401,3452,'2014-06-28 16:04:14.382601','2014-06-28 16:04:14.382601');
INSERT INTO "recording_views" VALUES(405,3767,'2014-06-28 16:17:58.100078','2014-06-28 16:17:58.100078');
INSERT INTO "recording_views" VALUES(408,3767,'2014-06-28 16:22:45.160772','2014-06-28 16:22:45.160772');
INSERT INTO "recording_views" VALUES(419,3767,'2014-06-28 16:40:29.561034','2014-06-28 16:40:29.561034');
INSERT INTO "recording_views" VALUES(431,3497,'2014-06-28 17:07:24.191976','2014-06-28 17:07:24.191976');
INSERT INTO "recording_views" VALUES(438,3446,'2014-06-28 17:34:28.751297','2014-06-28 17:34:28.751297');
INSERT INTO "recording_views" VALUES(448,3715,'2014-06-28 17:58:06.52214','2014-06-28 17:58:06.52214');
INSERT INTO "recording_views" VALUES(449,3709,'2014-06-28 17:58:41.716734','2014-06-28 17:58:41.716734');
INSERT INTO "recording_views" VALUES(451,3479,'2014-06-28 18:08:03.839066','2014-06-28 18:08:03.839066');
INSERT INTO "recording_views" VALUES(453,3728,'2014-06-28 18:09:29.320407','2014-06-28 18:09:29.320407');
INSERT INTO "recording_views" VALUES(465,3709,'2014-06-28 18:26:06.400095','2014-06-28 18:26:06.400095');
INSERT INTO "recording_views" VALUES(467,3466,'2014-06-28 18:28:25.062718','2014-06-28 18:28:25.062718');
INSERT INTO "recording_views" VALUES(473,3467,'2014-06-28 18:35:25.724268','2014-06-28 18:35:25.724268');
INSERT INTO "recording_views" VALUES(486,3767,'2014-06-28 18:55:05.375705','2014-06-28 18:55:05.375705');
INSERT INTO "recording_views" VALUES(488,3716,'2014-06-28 18:58:03.32966','2014-06-28 18:58:03.32966');
INSERT INTO "recording_views" VALUES(496,3821,'2014-06-28 19:38:00.580886','2014-06-28 19:38:00.580886');
INSERT INTO "recording_views" VALUES(498,3541,'2014-06-28 19:50:59.345589','2014-06-28 19:50:59.345589');
INSERT INTO "recording_views" VALUES(499,3445,'2014-06-28 19:51:02.562261','2014-06-28 19:51:02.562261');
INSERT INTO "recording_views" VALUES(508,3656,'2014-06-28 20:11:48.211954','2014-06-28 20:11:48.211954');
INSERT INTO "recording_views" VALUES(515,3596,'2014-06-28 20:22:08.264507','2014-06-28 20:22:08.264507');
INSERT INTO "recording_views" VALUES(522,3662,'2014-06-28 20:31:19.960187','2014-06-28 20:31:19.960187');
INSERT INTO "recording_views" VALUES(527,3715,'2014-06-28 20:35:20.064123','2014-06-28 20:35:20.064123');
INSERT INTO "recording_views" VALUES(528,3596,'2014-06-28 20:36:21.49565','2014-06-28 20:36:21.49565');
INSERT INTO "recording_views" VALUES(532,3662,'2014-06-28 20:39:16.770852','2014-06-28 20:39:16.770852');
INSERT INTO "recording_views" VALUES(538,3662,'2014-06-28 20:48:30.901221','2014-06-28 20:48:30.901221');
INSERT INTO "recording_views" VALUES(541,3596,'2014-06-28 20:54:46.947489','2014-06-28 20:54:46.947489');
INSERT INTO "recording_views" VALUES(548,3662,'2014-06-28 20:59:35.125919','2014-06-28 20:59:35.125919');
INSERT INTO "recording_views" VALUES(549,1272,'2014-06-28 21:00:10.570995','2014-06-28 21:00:10.570995');
INSERT INTO "recording_views" VALUES(550,3715,'2014-06-28 21:00:24.93085','2014-06-28 21:00:24.93085');
INSERT INTO "recording_views" VALUES(551,1341,'2014-06-28 21:00:53.242564','2014-06-28 21:00:53.242564');
INSERT INTO "recording_views" VALUES(552,3662,'2014-06-28 21:02:02.484963','2014-06-28 21:02:02.484963');
INSERT INTO "recording_views" VALUES(553,3715,'2014-06-28 21:04:41.511907','2014-06-28 21:04:41.511907');
INSERT INTO "recording_views" VALUES(554,3596,'2014-06-28 21:05:11.164131','2014-06-28 21:05:11.164131');
INSERT INTO "recording_views" VALUES(555,3662,'2014-06-28 21:06:17.047534','2014-06-28 21:06:17.047534');
INSERT INTO "recording_views" VALUES(556,3800,'2014-06-28 21:07:16.801702','2014-06-28 21:07:16.801702');
INSERT INTO "recording_views" VALUES(559,3800,'2014-06-28 21:14:06.779184','2014-06-28 21:14:06.779184');
INSERT INTO "recording_views" VALUES(565,3662,'2014-06-28 21:29:50.301955','2014-06-28 21:29:50.301955');
INSERT INTO "recording_views" VALUES(566,3800,'2014-06-28 21:30:50.624409','2014-06-28 21:30:50.624409');
INSERT INTO "recording_views" VALUES(573,3605,'2014-06-28 21:51:37.906958','2014-06-28 21:51:37.906958');
INSERT INTO "recording_views" VALUES(575,3767,'2014-06-28 21:52:38.163907','2014-06-28 21:52:38.163907');
INSERT INTO "recording_views" VALUES(576,3475,'2014-06-28 21:52:47.90221','2014-06-28 21:52:47.90221');
INSERT INTO "recording_views" VALUES(577,3662,'2014-06-28 21:54:10.956617','2014-06-28 21:54:10.956617');
INSERT INTO "recording_views" VALUES(579,3662,'2014-06-28 21:56:18.903684','2014-06-28 21:56:18.903684');
INSERT INTO "recording_views" VALUES(580,3524,'2014-06-28 21:56:22.353427','2014-06-28 21:56:22.353427');
INSERT INTO "recording_views" VALUES(581,3662,'2014-06-28 21:58:19.240023','2014-06-28 21:58:19.240023');
INSERT INTO "recording_views" VALUES(582,3524,'2014-06-28 21:58:58.197083','2014-06-28 21:58:58.197083');
INSERT INTO "recording_views" VALUES(583,3767,'2014-06-28 21:59:05.301382','2014-06-28 21:59:05.301382');
INSERT INTO "recording_views" VALUES(585,3749,'2014-06-28 22:03:39.809495','2014-06-28 22:03:39.809495');
INSERT INTO "recording_views" VALUES(587,3662,'2014-06-28 22:06:19.028839','2014-06-28 22:06:19.028839');
INSERT INTO "recording_views" VALUES(588,3749,'2014-06-28 22:08:21.969544','2014-06-28 22:08:21.969544');
INSERT INTO "recording_views" VALUES(589,3695,'2014-06-28 22:08:56.245031','2014-06-28 22:08:56.245031');
INSERT INTO "recording_views" VALUES(590,3800,'2014-06-28 22:09:34.758739','2014-06-28 22:09:34.758739');
INSERT INTO "recording_views" VALUES(592,3695,'2014-06-28 22:19:03.997509','2014-06-28 22:19:03.997509');
INSERT INTO "recording_views" VALUES(593,3710,'2014-06-28 22:19:05.495801','2014-06-28 22:19:05.495801');
INSERT INTO "recording_views" VALUES(595,3710,'2014-06-28 22:22:22.235912','2014-06-28 22:22:22.235912');
INSERT INTO "recording_views" VALUES(596,3758,'2014-06-28 22:24:51.29119','2014-06-28 22:24:51.29119');
INSERT INTO "recording_views" VALUES(597,3710,'2014-06-28 22:26:53.077285','2014-06-28 22:26:53.077285');
INSERT INTO "recording_views" VALUES(599,3530,'2014-06-28 22:30:16.362004','2014-06-28 22:30:16.362004');
INSERT INTO "recording_views" VALUES(601,3710,'2014-06-28 22:31:00.769348','2014-06-28 22:31:00.769348');
INSERT INTO "recording_views" VALUES(603,3539,'2014-06-28 22:38:13.215712','2014-06-28 22:38:13.215712');
INSERT INTO "recording_views" VALUES(604,3575,'2014-06-28 22:39:27.368327','2014-06-28 22:39:27.368327');
INSERT INTO "recording_views" VALUES(606,3800,'2014-06-28 22:43:41.161716','2014-06-28 22:43:41.161716');
INSERT INTO "recording_views" VALUES(607,3800,'2014-06-28 22:45:57.469393','2014-06-28 22:45:57.469393');
INSERT INTO "recording_views" VALUES(609,3575,'2014-06-28 22:53:57.778498','2014-06-28 22:53:57.778498');
INSERT INTO "recording_views" VALUES(610,3665,'2014-06-28 22:57:04.225065','2014-06-28 22:57:04.225065');
INSERT INTO "recording_views" VALUES(613,3596,'2014-06-28 23:08:10.166384','2014-06-28 23:08:10.166384');
INSERT INTO "recording_views" VALUES(614,3449,'2014-06-28 23:09:16.960663','2014-06-28 23:09:16.960663');
INSERT INTO "recording_views" VALUES(615,3710,'2014-06-28 23:11:45.667408','2014-06-28 23:11:45.667408');
INSERT INTO "recording_views" VALUES(616,3665,'2014-06-28 23:11:58.444766','2014-06-28 23:11:58.444766');
INSERT INTO "recording_views" VALUES(617,3452,'2014-06-28 23:12:53.975335','2014-06-28 23:12:53.975335');
INSERT INTO "recording_views" VALUES(618,3452,'2014-06-28 23:15:44.269251','2014-06-28 23:15:44.269251');
INSERT INTO "recording_views" VALUES(619,3665,'2014-06-28 23:16:17.554706','2014-06-28 23:16:17.554706');
INSERT INTO "recording_views" VALUES(620,3500,'2014-06-28 23:18:32.809753','2014-06-28 23:18:32.809753');
INSERT INTO "recording_views" VALUES(621,3506,'2014-06-28 23:19:50.35691','2014-06-28 23:19:50.35691');
INSERT INTO "recording_views" VALUES(622,3563,'2014-06-28 23:20:23.691985','2014-06-28 23:20:23.691985');
INSERT INTO "recording_views" VALUES(623,3584,'2014-06-28 23:22:20.663402','2014-06-28 23:22:20.663402');
INSERT INTO "recording_views" VALUES(624,3703,'2014-06-28 23:22:56.054569','2014-06-28 23:22:56.054569');
INSERT INTO "recording_views" VALUES(625,3536,'2014-06-28 23:23:30.757502','2014-06-28 23:23:30.757502');
INSERT INTO "recording_views" VALUES(626,3665,'2014-06-28 23:29:42.418953','2014-06-28 23:29:42.418953');
INSERT INTO "recording_views" VALUES(628,3452,'2014-06-28 23:31:00.421756','2014-06-28 23:31:00.421756');
INSERT INTO "recording_views" VALUES(629,3452,'2014-06-28 23:37:47.982361','2014-06-28 23:37:47.982361');
INSERT INTO "recording_views" VALUES(630,3665,'2014-06-28 23:39:41.665719','2014-06-28 23:39:41.665719');
INSERT INTO "recording_views" VALUES(631,3665,'2014-06-28 23:42:30.871739','2014-06-28 23:42:30.871739');
INSERT INTO "recording_views" VALUES(632,3452,'2014-06-28 23:42:59.73743','2014-06-28 23:42:59.73743');
INSERT INTO "recording_views" VALUES(634,3665,'2014-06-28 23:44:52.319514','2014-06-28 23:44:52.319514');
INSERT INTO "recording_views" VALUES(635,3452,'2014-06-28 23:45:20.43448','2014-06-28 23:45:20.43448');
INSERT INTO "recording_views" VALUES(637,3665,'2014-06-28 23:47:36.926789','2014-06-28 23:47:36.926789');
INSERT INTO "recording_views" VALUES(638,3665,'2014-06-28 23:49:26.459137','2014-06-28 23:49:26.459137');
INSERT INTO "recording_views" VALUES(639,3665,'2014-06-28 23:52:14.882773','2014-06-28 23:52:14.882773');
INSERT INTO "recording_views" VALUES(641,3650,'2014-06-28 23:59:52.332583','2014-06-28 23:59:52.332583');
INSERT INTO "recording_views" VALUES(642,3638,'2014-06-29 00:01:19.159244','2014-06-29 00:01:19.159244');
INSERT INTO "recording_views" VALUES(643,3680,'2014-06-29 00:03:07.778335','2014-06-29 00:03:07.778335');
INSERT INTO "recording_views" VALUES(644,3701,'2014-06-29 00:04:28.816194','2014-06-29 00:04:28.816194');
INSERT INTO "recording_views" VALUES(646,3665,'2014-06-29 00:12:38.574571','2014-06-29 00:12:38.574571');
INSERT INTO "recording_views" VALUES(647,3701,'2014-06-29 00:13:05.571938','2014-06-29 00:13:05.571938');
INSERT INTO "recording_views" VALUES(649,3497,'2014-06-29 00:17:32.615514','2014-06-29 00:17:32.615514');
INSERT INTO "recording_views" VALUES(650,3809,'2014-06-29 00:18:34.241324','2014-06-29 00:18:34.241324');
INSERT INTO "recording_views" VALUES(652,3809,'2014-06-29 00:24:15.538145','2014-06-29 00:24:15.538145');
INSERT INTO "recording_views" VALUES(653,3632,'2014-06-29 00:24:32.906155','2014-06-29 00:24:32.906155');
INSERT INTO "recording_views" VALUES(655,3632,'2014-06-29 00:28:11.069452','2014-06-29 00:28:11.069452');
INSERT INTO "recording_views" VALUES(656,3815,'2014-06-29 00:36:05.522914','2014-06-29 00:36:05.522914');
INSERT INTO "recording_views" VALUES(658,3815,'2014-06-29 00:38:07.506661','2014-06-29 00:38:07.506661');
INSERT INTO "recording_views" VALUES(659,3815,'2014-06-29 00:42:19.258977','2014-06-29 00:42:19.258977');
INSERT INTO "recording_views" VALUES(660,3815,'2014-06-29 00:45:37.208855','2014-06-29 00:45:37.208855');
INSERT INTO "recording_views" VALUES(661,3815,'2014-06-29 00:48:54.200791','2014-06-29 00:48:54.200791');
INSERT INTO "recording_views" VALUES(662,3608,'2014-06-29 00:50:46.732997','2014-06-29 00:50:46.732997');
INSERT INTO "recording_views" VALUES(663,3608,'2014-06-29 00:53:10.845435','2014-06-29 00:53:10.845435');
INSERT INTO "recording_views" VALUES(665,3758,'2014-06-29 01:13:43.110107','2014-06-29 01:13:43.110107');
INSERT INTO "recording_views" VALUES(673,3599,'2014-06-29 21:09:38.792727','2014-06-29 21:09:38.792727');
INSERT INTO "recording_views" VALUES(674,3785,'2014-06-29 21:15:07.412142','2014-06-29 21:15:07.412142');
INSERT INTO "recording_views" VALUES(676,3661,'2014-06-29 21:15:33.003814','2014-06-29 21:15:33.003814');
INSERT INTO "recording_views" VALUES(677,217,'2014-06-29 21:17:11.636637','2014-06-29 21:17:11.636637');
INSERT INTO "recording_views" VALUES(679,3608,'2014-06-29 21:18:38.491327','2014-06-29 21:18:38.491327');
INSERT INTO "recording_views" VALUES(680,217,'2014-06-29 21:20:23.380461','2014-06-29 21:20:23.380461');
INSERT INTO "recording_views" VALUES(681,3560,'2014-06-29 21:21:05.938085','2014-06-29 21:21:05.938085');
INSERT INTO "recording_views" VALUES(686,3608,'2014-06-29 21:23:49.908356','2014-06-29 21:23:49.908356');
INSERT INTO "recording_views" VALUES(687,3446,'2014-06-29 21:23:51.013455','2014-06-29 21:23:51.013455');
INSERT INTO "recording_views" VALUES(688,217,'2014-06-29 21:24:15.62273','2014-06-29 21:24:15.62273');
INSERT INTO "recording_views" VALUES(690,3560,'2014-06-29 21:25:03.39969','2014-06-29 21:25:03.39969');
INSERT INTO "recording_views" VALUES(695,3661,'2014-06-29 21:27:43.333268','2014-06-29 21:27:43.333268');
INSERT INTO "recording_views" VALUES(697,217,'2014-06-29 21:28:14.838672','2014-06-29 21:28:14.838672');
INSERT INTO "recording_views" VALUES(698,3608,'2014-06-29 21:28:17.489318','2014-06-29 21:28:17.489318');
INSERT INTO "recording_views" VALUES(702,217,'2014-06-29 21:34:16.844027','2014-06-29 21:34:16.844027');
INSERT INTO "recording_views" VALUES(703,3559,'2014-06-29 21:39:53.218787','2014-06-29 21:39:53.218787');
INSERT INTO "recording_views" VALUES(704,3608,'2014-06-29 21:41:48.50253','2014-06-29 21:41:48.50253');
INSERT INTO "recording_views" VALUES(705,3559,'2014-06-29 21:45:21.411105','2014-06-29 21:45:21.411105');
INSERT INTO "recording_views" VALUES(706,3470,'2014-06-29 21:46:52.449711','2014-06-29 21:46:52.449711');
INSERT INTO "recording_views" VALUES(707,3560,'2014-06-29 21:47:46.95162','2014-06-29 21:47:46.95162');
INSERT INTO "recording_views" VALUES(708,217,'2014-06-29 21:52:08.808255','2014-06-29 21:52:08.808255');
INSERT INTO "recording_views" VALUES(711,217,'2014-06-29 21:55:42.604221','2014-06-29 21:55:42.604221');
INSERT INTO "recording_views" VALUES(716,3646,'2014-06-30 11:07:10.462604','2014-06-30 11:07:10.462604');
INSERT INTO "recording_views" VALUES(720,3646,'2014-06-30 11:15:37.946305','2014-06-30 11:15:37.946305');
INSERT INTO "recording_views" VALUES(722,3646,'2014-06-30 11:18:07.510632','2014-06-30 11:18:07.510632');
INSERT INTO "recording_views" VALUES(723,3452,'2014-06-30 11:19:53.0586','2014-06-30 11:19:53.0586');
INSERT INTO "recording_views" VALUES(725,1314,'2014-06-30 11:21:42.035847','2014-06-30 11:21:42.035847');
INSERT INTO "recording_views" VALUES(726,3637,'2014-06-30 11:29:42.939874','2014-06-30 11:29:42.939874');
INSERT INTO "recording_views" VALUES(728,3557,'2014-06-30 11:30:38.086284','2014-06-30 11:30:38.086284');
INSERT INTO "recording_views" VALUES(730,3452,'2014-06-30 11:33:11.44562','2014-06-30 11:33:11.44562');
INSERT INTO "recording_views" VALUES(733,3452,'2014-06-30 11:36:46.366408','2014-06-30 11:36:46.366408');
INSERT INTO "recording_views" VALUES(734,3637,'2014-06-30 11:39:53.967976','2014-06-30 11:39:53.967976');
INSERT INTO "recording_views" VALUES(737,3452,'2014-06-30 11:42:25.461048','2014-06-30 11:42:25.461048');
INSERT INTO "recording_views" VALUES(738,3452,'2014-06-30 11:45:46.645158','2014-06-30 11:45:46.645158');
INSERT INTO "recording_views" VALUES(739,3497,'2014-06-30 11:47:43.138611','2014-06-30 11:47:43.138611');
INSERT INTO "recording_views" VALUES(740,3596,'2014-06-30 11:51:41.859904','2014-06-30 11:51:41.859904');
INSERT INTO "recording_views" VALUES(742,3497,'2014-06-30 11:52:35.382604','2014-06-30 11:52:35.382604');
INSERT INTO "recording_views" VALUES(743,3452,'2014-06-30 11:54:27.173926','2014-06-30 11:54:27.173926');
INSERT INTO "recording_views" VALUES(744,3497,'2014-06-30 11:55:35.577802','2014-06-30 11:55:35.577802');
INSERT INTO "recording_views" VALUES(745,3637,'2014-06-30 11:56:05.653004','2014-06-30 11:56:05.653004');
INSERT INTO "recording_views" VALUES(746,3596,'2014-06-30 11:57:12.562086','2014-06-30 11:57:12.562086');
INSERT INTO "recording_views" VALUES(747,3637,'2014-06-30 11:59:16.630662','2014-06-30 11:59:16.630662');
INSERT INTO "recording_views" VALUES(749,3452,'2014-06-30 12:01:54.787213','2014-06-30 12:01:54.787213');
INSERT INTO "recording_views" VALUES(750,3637,'2014-06-30 12:03:06.138941','2014-06-30 12:03:06.138941');
INSERT INTO "recording_views" VALUES(751,3497,'2014-06-30 12:03:15.779165','2014-06-30 12:03:15.779165');
INSERT INTO "recording_views" VALUES(752,3646,'2014-06-30 12:04:32.830902','2014-06-30 12:04:32.830902');
INSERT INTO "recording_views" VALUES(753,3497,'2014-06-30 12:05:33.468488','2014-06-30 12:05:33.468488');
INSERT INTO "recording_views" VALUES(755,3497,'2014-06-30 12:08:06.174951','2014-06-30 12:08:06.174951');
INSERT INTO "recording_views" VALUES(759,3637,'2014-06-30 12:14:42.635792','2014-06-30 12:14:42.635792');
INSERT INTO "recording_views" VALUES(764,3452,'2014-06-30 12:30:14.564972','2014-06-30 12:30:14.564972');
INSERT INTO "recording_views" VALUES(765,3637,'2014-06-30 12:33:21.088645','2014-06-30 12:33:21.088645');
INSERT INTO "recording_views" VALUES(766,3646,'2014-06-30 12:33:39.834638','2014-06-30 12:33:39.834638');
INSERT INTO "recording_views" VALUES(768,3646,'2014-06-30 12:37:25.360381','2014-06-30 12:37:25.360381');
INSERT INTO "recording_views" VALUES(769,3637,'2014-06-30 12:37:55.772719','2014-06-30 12:37:55.772719');
INSERT INTO "recording_views" VALUES(771,3646,'2014-06-30 12:50:51.958469','2014-06-30 12:50:51.958469');
INSERT INTO "recording_views" VALUES(777,3452,'2014-06-30 12:58:43.988184','2014-06-30 12:58:43.988184');
INSERT INTO "recording_views" VALUES(778,3646,'2014-06-30 13:00:12.972129','2014-06-30 13:00:12.972129');
INSERT INTO "recording_views" VALUES(780,3452,'2014-06-30 13:04:10.729745','2014-06-30 13:04:10.729745');
INSERT INTO "recording_views" VALUES(781,3452,'2014-06-30 13:18:28.357442','2014-06-30 13:18:28.357442');
INSERT INTO "recording_views" VALUES(784,3452,'2014-06-30 13:25:51.498603','2014-06-30 13:25:51.498603');
INSERT INTO "recording_views" VALUES(790,3452,'2014-06-30 13:29:35.009673','2014-06-30 13:29:35.009673');
INSERT INTO "recording_views" VALUES(794,3452,'2014-06-30 13:38:59.947002','2014-06-30 13:38:59.947002');
INSERT INTO "recording_views" VALUES(795,3451,'2014-06-30 13:41:24.348296','2014-06-30 13:41:24.348296');
INSERT INTO "recording_views" VALUES(796,3452,'2014-06-30 13:48:27.503165','2014-06-30 13:48:27.503165');
INSERT INTO "recording_views" VALUES(800,3451,'2014-06-30 13:59:11.917633','2014-06-30 13:59:11.917633');
INSERT INTO "recording_views" VALUES(803,3497,'2014-06-30 14:01:32.910709','2014-06-30 14:01:32.910709');
INSERT INTO "recording_views" VALUES(805,3497,'2014-06-30 14:05:05.417226','2014-06-30 14:05:05.417226');
INSERT INTO "recording_views" VALUES(806,3451,'2014-06-30 14:05:33.757389','2014-06-30 14:05:33.757389');
INSERT INTO "recording_views" VALUES(807,3497,'2014-06-30 14:07:34.190914','2014-06-30 14:07:34.190914');
INSERT INTO "recording_views" VALUES(808,3452,'2014-06-30 14:08:08.43369','2014-06-30 14:08:08.43369');
INSERT INTO "recording_views" VALUES(809,3452,'2014-06-30 14:10:36.372327','2014-06-30 14:10:36.372327');
INSERT INTO "recording_views" VALUES(810,3497,'2014-06-30 14:14:01.401194','2014-06-30 14:14:01.401194');
INSERT INTO "recording_views" VALUES(813,3497,'2014-06-30 14:16:08.411223','2014-06-30 14:16:08.411223');
INSERT INTO "recording_views" VALUES(814,3452,'2014-06-30 14:19:21.189875','2014-06-30 14:19:21.189875');
INSERT INTO "recording_views" VALUES(817,3452,'2014-06-30 14:21:59.110855','2014-06-30 14:21:59.110855');
INSERT INTO "recording_views" VALUES(818,3646,'2014-06-30 14:22:52.432395','2014-06-30 14:22:52.432395');
INSERT INTO "recording_views" VALUES(819,3773,'2014-06-30 14:26:52.736515','2014-06-30 14:26:52.736515');
INSERT INTO "recording_views" VALUES(821,3452,'2014-06-30 14:31:21.695925','2014-06-30 14:31:21.695925');
INSERT INTO "recording_views" VALUES(824,3646,'2014-06-30 14:32:55.749949','2014-06-30 14:32:55.749949');
INSERT INTO "recording_views" VALUES(826,3452,'2014-06-30 14:35:32.616946','2014-06-30 14:35:32.616946');
INSERT INTO "recording_views" VALUES(827,3452,'2014-06-30 14:36:43.025029','2014-06-30 14:36:43.025029');
INSERT INTO "recording_views" VALUES(829,3646,'2014-06-30 14:37:28.563715','2014-06-30 14:37:28.563715');
INSERT INTO "recording_views" VALUES(831,3661,'2014-06-30 14:43:46.632368','2014-06-30 14:43:46.632368');
INSERT INTO "recording_views" VALUES(832,1242,'2014-06-30 14:45:24.805685','2014-06-30 14:45:24.805685');
INSERT INTO "recording_views" VALUES(835,3452,'2014-06-30 14:48:07.111464','2014-06-30 14:48:07.111464');
INSERT INTO "recording_views" VALUES(842,3808,'2014-06-30 14:54:44.526153','2014-06-30 14:54:44.526153');
INSERT INTO "recording_views" VALUES(843,3646,'2014-06-30 14:57:04.904616','2014-06-30 14:57:04.904616');
INSERT INTO "recording_views" VALUES(844,3452,'2014-06-30 15:02:26.522964','2014-06-30 15:02:26.522964');
INSERT INTO "recording_views" VALUES(845,3646,'2014-06-30 15:04:32.061538','2014-06-30 15:04:32.061538');
INSERT INTO "recording_views" VALUES(846,3452,'2014-06-30 15:05:16.985106','2014-06-30 15:05:16.985106');
INSERT INTO "recording_views" VALUES(848,3446,'2014-06-30 15:07:10.811448','2014-06-30 15:07:10.811448');
INSERT INTO "recording_views" VALUES(849,3452,'2014-06-30 15:08:09.815241','2014-06-30 15:08:09.815241');
INSERT INTO "recording_views" VALUES(850,3446,'2014-06-30 15:10:00.869266','2014-06-30 15:10:00.869266');
INSERT INTO "recording_views" VALUES(852,3581,'2014-06-30 15:11:29.261864','2014-06-30 15:11:29.261864');
INSERT INTO "recording_views" VALUES(853,3497,'2014-06-30 15:12:16.892941','2014-06-30 15:12:16.892941');
INSERT INTO "recording_views" VALUES(855,3581,'2014-06-30 15:13:30.370482','2014-06-30 15:13:30.370482');
INSERT INTO "recording_views" VALUES(856,3452,'2014-06-30 15:15:08.255896','2014-06-30 15:15:08.255896');
INSERT INTO "recording_views" VALUES(857,3646,'2014-06-30 15:16:20.291837','2014-06-30 15:16:20.291837');
INSERT INTO "recording_views" VALUES(859,1242,'2014-06-30 15:24:50.481502','2014-06-30 15:24:50.481502');
INSERT INTO "recording_views" VALUES(861,3497,'2014-06-30 15:25:53.55438','2014-06-30 15:25:53.55438');
INSERT INTO "recording_views" VALUES(862,3497,'2014-06-30 15:31:46.7435','2014-06-30 15:31:46.7435');
INSERT INTO "recording_views" VALUES(863,3452,'2014-06-30 15:32:40.478714','2014-06-30 15:32:40.478714');
INSERT INTO "recording_views" VALUES(864,1242,'2014-06-30 15:33:27.663891','2014-06-30 15:33:27.663891');
INSERT INTO "recording_views" VALUES(865,3808,'2014-06-30 15:37:34.595537','2014-06-30 15:37:34.595537');
INSERT INTO "recording_views" VALUES(866,3452,'2014-06-30 15:37:44.580262','2014-06-30 15:37:44.580262');
INSERT INTO "recording_views" VALUES(868,3451,'2014-06-30 15:38:04.175468','2014-06-30 15:38:04.175468');
INSERT INTO "recording_views" VALUES(869,3473,'2014-06-30 15:39:43.779095','2014-06-30 15:39:43.779095');
INSERT INTO "recording_views" VALUES(871,3808,'2014-06-30 15:43:35.967569','2014-06-30 15:43:35.967569');
INSERT INTO "recording_views" VALUES(872,3452,'2014-06-30 15:43:48.540064','2014-06-30 15:43:48.540064');
INSERT INTO "recording_views" VALUES(874,3497,'2014-06-30 15:45:16.422388','2014-06-30 15:45:16.422388');
INSERT INTO "recording_views" VALUES(875,1287,'2014-06-30 15:45:23.160517','2014-06-30 15:45:23.160517');
INSERT INTO "recording_views" VALUES(876,3808,'2014-06-30 15:47:48.503541','2014-06-30 15:47:48.503541');
INSERT INTO "recording_views" VALUES(881,3809,'2014-06-30 16:00:57.320012','2014-06-30 16:00:57.320012');
INSERT INTO "recording_views" VALUES(882,3794,'2014-06-30 16:03:02.184063','2014-06-30 16:03:02.184063');
INSERT INTO "recording_views" VALUES(883,3514,'2014-06-30 16:03:16.848173','2014-06-30 16:03:16.848173');
INSERT INTO "recording_views" VALUES(884,3518,'2014-06-30 16:04:34.307004','2014-06-30 16:04:34.307004');
INSERT INTO "recording_views" VALUES(885,3512,'2014-06-30 16:05:25.706117','2014-06-30 16:05:25.706117');
INSERT INTO "recording_views" VALUES(886,3707,'2014-06-30 16:06:30.62172','2014-06-30 16:06:30.62172');
INSERT INTO "recording_views" VALUES(887,3653,'2014-06-30 16:08:09.901284','2014-06-30 16:08:09.901284');
INSERT INTO "recording_views" VALUES(888,3689,'2014-06-30 16:09:26.198089','2014-06-30 16:09:26.198089');
INSERT INTO "recording_views" VALUES(891,3497,'2014-06-30 16:17:06.971176','2014-06-30 16:17:06.971176');
INSERT INTO "recording_views" VALUES(892,3452,'2014-06-30 16:18:18.426693','2014-06-30 16:18:18.426693');
INSERT INTO "recording_views" VALUES(893,3640,'2014-06-30 16:23:53.721131','2014-06-30 16:23:53.721131');
INSERT INTO "recording_views" VALUES(895,1254,'2014-06-30 16:34:11.204197','2014-06-30 16:34:11.204197');
INSERT INTO "recording_views" VALUES(896,3514,'2014-06-30 16:35:49.879712','2014-06-30 16:35:49.879712');
INSERT INTO "recording_views" VALUES(897,3452,'2014-06-30 16:39:11.216439','2014-06-30 16:39:11.216439');
INSERT INTO "recording_views" VALUES(901,3515,'2014-06-30 16:48:27.80059','2014-06-30 16:48:27.80059');
INSERT INTO "recording_views" VALUES(907,3743,'2014-06-30 17:01:48.796201','2014-06-30 17:01:48.796201');
INSERT INTO "recording_views" VALUES(909,3527,'2014-06-30 17:05:37.666021','2014-06-30 17:05:37.666021');
INSERT INTO "recording_views" VALUES(910,3527,'2014-06-30 17:08:09.575958','2014-06-30 17:08:09.575958');
INSERT INTO "recording_views" VALUES(916,3452,'2014-06-30 17:14:40.63947','2014-06-30 17:14:40.63947');
INSERT INTO "recording_views" VALUES(917,1254,'2014-06-30 17:15:35.822613','2014-06-30 17:15:35.822613');
INSERT INTO "recording_views" VALUES(919,3743,'2014-06-30 17:17:55.353268','2014-06-30 17:17:55.353268');
INSERT INTO "recording_views" VALUES(936,3763,'2014-06-30 17:36:57.309229','2014-06-30 17:36:57.309229');
INSERT INTO "recording_views" VALUES(938,3820,'2014-06-30 17:37:05.16049','2014-06-30 17:37:05.16049');
INSERT INTO "recording_views" VALUES(948,3743,'2014-06-30 17:50:56.617322','2014-06-30 17:50:56.617322');
INSERT INTO "recording_views" VALUES(950,3743,'2014-06-30 17:56:06.15207','2014-06-30 17:56:06.15207');
INSERT INTO "recording_views" VALUES(954,1287,'2014-06-30 18:05:43.902331','2014-06-30 18:05:43.902331');
INSERT INTO "recording_views" VALUES(955,3497,'2014-06-30 18:07:25.165091','2014-06-30 18:07:25.165091');
INSERT INTO "recording_views" VALUES(956,1287,'2014-06-30 18:08:55.293463','2014-06-30 18:08:55.293463');
INSERT INTO "recording_views" VALUES(963,1272,'2014-06-30 18:15:49.728797','2014-06-30 18:15:49.728797');
INSERT INTO "recording_views" VALUES(964,1272,'2014-06-30 18:18:27.866035','2014-06-30 18:18:27.866035');
INSERT INTO "recording_views" VALUES(965,1272,'2014-06-30 18:21:07.49795','2014-06-30 18:21:07.49795');
INSERT INTO "recording_views" VALUES(966,1272,'2014-06-30 18:23:39.067532','2014-06-30 18:23:39.067532');
INSERT INTO "recording_views" VALUES(969,3452,'2014-06-30 18:31:11.326226','2014-06-30 18:31:11.326226');
INSERT INTO "recording_views" VALUES(970,3470,'2014-06-30 18:33:14.287094','2014-06-30 18:33:14.287094');
INSERT INTO "recording_views" VALUES(972,3470,'2014-06-30 18:36:24.070638','2014-06-30 18:36:24.070638');
INSERT INTO "recording_views" VALUES(975,3470,'2014-06-30 18:42:49.59098','2014-06-30 18:42:49.59098');
INSERT INTO "recording_views" VALUES(978,3608,'2014-06-30 18:46:22.502568','2014-06-30 18:46:22.502568');
INSERT INTO "recording_views" VALUES(991,3722,'2014-06-30 19:04:35.607161','2014-06-30 19:04:35.607161');
INSERT INTO "recording_views" VALUES(993,3608,'2014-06-30 19:05:58.971083','2014-06-30 19:05:58.971083');
INSERT INTO "recording_views" VALUES(994,3470,'2014-06-30 19:06:02.25551','2014-06-30 19:06:02.25551');
INSERT INTO "recording_views" VALUES(995,3497,'2014-06-30 19:06:34.007713','2014-06-30 19:06:34.007713');
INSERT INTO "recording_views" VALUES(997,3470,'2014-06-30 19:08:28.310101','2014-06-30 19:08:28.310101');
INSERT INTO "recording_views" VALUES(1001,3497,'2014-06-30 19:12:21.386013','2014-06-30 19:12:21.386013');
INSERT INTO "recording_views" VALUES(1002,3494,'2014-06-30 19:13:16.375548','2014-06-30 19:13:16.375548');
INSERT INTO "recording_views" VALUES(1005,3566,'2014-06-30 19:15:34.908092','2014-06-30 19:15:34.908092');
INSERT INTO "recording_views" VALUES(1006,3584,'2014-06-30 19:17:14.245724','2014-06-30 19:17:14.245724');
INSERT INTO "recording_views" VALUES(1007,3731,'2014-06-30 19:19:07.860396','2014-06-30 19:19:07.860396');
INSERT INTO "recording_views" VALUES(1008,3686,'2014-06-30 19:22:43.907886','2014-06-30 19:22:43.907886');
INSERT INTO "recording_views" VALUES(1009,3536,'2014-06-30 19:25:11.728879','2014-06-30 19:25:11.728879');
INSERT INTO "recording_views" VALUES(1011,3506,'2014-06-30 19:27:52.752794','2014-06-30 19:27:52.752794');
INSERT INTO "recording_views" VALUES(1012,3701,'2014-06-30 19:27:52.922426','2014-06-30 19:27:52.922426');
INSERT INTO "recording_views" VALUES(1013,1233,'2014-06-30 19:28:26.669098','2014-06-30 19:28:26.669098');
INSERT INTO "recording_views" VALUES(1017,3701,'2014-06-30 19:37:34.439762','2014-06-30 19:37:34.439762');
INSERT INTO "recording_views" VALUES(1018,3452,'2014-06-30 19:41:15.545996','2014-06-30 19:41:15.545996');
INSERT INTO "recording_views" VALUES(1020,3497,'2014-06-30 19:42:18.789112','2014-06-30 19:42:18.789112');
INSERT INTO "recording_views" VALUES(1023,3701,'2014-06-30 19:46:38.98172','2014-06-30 19:46:38.98172');
INSERT INTO "recording_views" VALUES(1024,3452,'2014-06-30 19:48:00.370649','2014-06-30 19:48:00.370649');
INSERT INTO "recording_views" VALUES(1025,3701,'2014-06-30 19:49:21.911821','2014-06-30 19:49:21.911821');
INSERT INTO "recording_views" VALUES(1027,3701,'2014-06-30 19:53:59.421593','2014-06-30 19:53:59.421593');
INSERT INTO "recording_views" VALUES(1028,3452,'2014-06-30 19:56:12.834692','2014-06-30 19:56:12.834692');
INSERT INTO "recording_views" VALUES(1029,1233,'2014-06-30 19:58:20.016032','2014-06-30 19:58:20.016032');
INSERT INTO "recording_views" VALUES(1031,3452,'2014-06-30 20:02:07.623537','2014-06-30 20:02:07.623537');
INSERT INTO "recording_views" VALUES(1032,3701,'2014-06-30 20:03:36.057047','2014-06-30 20:03:36.057047');
INSERT INTO "recording_views" VALUES(1033,3701,'2014-06-30 20:09:22.477497','2014-06-30 20:09:22.477497');
INSERT INTO "recording_views" VALUES(1034,3605,'2014-06-30 20:11:02.304824','2014-06-30 20:11:02.304824');
INSERT INTO "recording_views" VALUES(1035,3497,'2014-06-30 20:12:15.92087','2014-06-30 20:12:15.92087');
INSERT INTO "recording_views" VALUES(1036,3452,'2014-06-30 20:12:47.061694','2014-06-30 20:12:47.061694');
INSERT INTO "recording_views" VALUES(1038,3701,'2014-06-30 20:14:49.657608','2014-06-30 20:14:49.657608');
INSERT INTO "recording_views" VALUES(1039,3452,'2014-06-30 20:14:50.249656','2014-06-30 20:14:50.249656');
INSERT INTO "recording_views" VALUES(1042,3452,'2014-06-30 20:18:18.842395','2014-06-30 20:18:18.842395');
INSERT INTO "recording_views" VALUES(1043,1233,'2014-06-30 20:30:50.928998','2014-06-30 20:30:50.928998');
INSERT INTO "recording_views" VALUES(1044,1296,'2014-06-30 20:32:57.413668','2014-06-30 20:32:57.413668');
INSERT INTO "recording_views" VALUES(1048,1296,'2014-06-30 20:38:13.734657','2014-06-30 20:38:13.734657');
INSERT INTO "recording_views" VALUES(1049,3527,'2014-06-30 20:41:01.70846','2014-06-30 20:41:01.70846');
INSERT INTO "recording_views" VALUES(1053,1296,'2014-06-30 20:47:08.330688','2014-06-30 20:47:08.330688');
INSERT INTO "recording_views" VALUES(1055,3488,'2014-06-30 20:53:09.222157','2014-06-30 20:53:09.222157');
INSERT INTO "recording_views" VALUES(1056,3578,'2014-06-30 20:55:11.833874','2014-06-30 20:55:11.833874');
INSERT INTO "recording_views" VALUES(1057,3590,'2014-06-30 20:56:03.221104','2014-06-30 20:56:03.221104');
INSERT INTO "recording_views" VALUES(1058,183,'2014-06-30 20:57:16.488149','2014-06-30 20:57:16.488149');
INSERT INTO "recording_views" VALUES(1059,1311,'2014-06-30 20:57:43.354658','2014-06-30 20:57:43.354658');
INSERT INTO "recording_views" VALUES(1061,3554,'2014-06-30 21:00:22.464774','2014-06-30 21:00:22.464774');
INSERT INTO "recording_views" VALUES(1062,3554,'2014-06-30 21:04:38.479398','2014-06-30 21:04:38.479398');
INSERT INTO "recording_views" VALUES(1065,3452,'2014-06-30 21:14:50.690559','2014-06-30 21:14:50.690559');
INSERT INTO "recording_views" VALUES(1068,3635,'2014-06-30 21:16:56.9776','2014-06-30 21:16:56.9776');
INSERT INTO "recording_views" VALUES(1069,3590,'2014-06-30 21:18:53.416821','2014-06-30 21:18:53.416821');
INSERT INTO "recording_views" VALUES(1070,3716,'2014-06-30 21:21:16.276022','2014-06-30 21:21:16.276022');
INSERT INTO "recording_views" VALUES(1071,3761,'2014-06-30 21:23:32.873989','2014-06-30 21:23:32.873989');
INSERT INTO "recording_views" VALUES(1072,3590,'2014-06-30 21:29:45.723191','2014-06-30 21:29:45.723191');
INSERT INTO "recording_views" VALUES(1073,3512,'2014-06-30 21:31:48.664327','2014-06-30 21:31:48.664327');
INSERT INTO "recording_views" VALUES(1074,3452,'2014-06-30 21:34:48.986305','2014-06-30 21:34:48.986305');
INSERT INTO "recording_views" VALUES(1075,3452,'2014-06-30 21:37:22.419532','2014-06-30 21:37:22.419532');
INSERT INTO "recording_views" VALUES(1076,3590,'2014-06-30 21:40:31.166254','2014-06-30 21:40:31.166254');
INSERT INTO "recording_views" VALUES(1079,3590,'2014-06-30 21:44:03.85715','2014-06-30 21:44:03.85715');
INSERT INTO "recording_views" VALUES(1080,3590,'2014-06-30 21:52:04.475604','2014-06-30 21:52:04.475604');
INSERT INTO "recording_views" VALUES(1081,3437,'2014-06-30 21:53:35.402104','2014-06-30 21:53:35.402104');
INSERT INTO "recording_views" VALUES(1083,3590,'2014-06-30 21:55:39.017067','2014-06-30 21:55:39.017067');
INSERT INTO "recording_views" VALUES(1084,3590,'2014-06-30 22:01:42.885716','2014-06-30 22:01:42.885716');
INSERT INTO "recording_views" VALUES(1085,3590,'2014-06-30 22:03:51.500305','2014-06-30 22:03:51.500305');
INSERT INTO "recording_views" VALUES(1086,1311,'2014-06-30 22:07:13.086403','2014-06-30 22:07:13.086403');
INSERT INTO "recording_views" VALUES(1087,3590,'2014-06-30 22:07:49.146376','2014-06-30 22:07:49.146376');
INSERT INTO "recording_views" VALUES(1088,3452,'2014-06-30 22:11:54.960568','2014-06-30 22:11:54.960568');
INSERT INTO "recording_views" VALUES(1090,3590,'2014-06-30 22:15:28.459589','2014-06-30 22:15:28.459589');
INSERT INTO "recording_views" VALUES(1092,3452,'2014-06-30 22:27:01.142909','2014-06-30 22:27:01.142909');
INSERT INTO "recording_views" VALUES(1093,3452,'2014-06-30 22:29:55.527013','2014-06-30 22:29:55.527013');
INSERT INTO "recording_views" VALUES(1094,3452,'2014-06-30 22:31:03.22986','2014-06-30 22:31:03.22986');
INSERT INTO "recording_views" VALUES(1096,3452,'2014-06-30 22:34:19.530306','2014-06-30 22:34:19.530306');
INSERT INTO "recording_views" VALUES(1097,3452,'2014-06-30 22:39:25.61796','2014-06-30 22:39:25.61796');
INSERT INTO "recording_views" VALUES(1099,3452,'2014-06-30 22:42:15.229804','2014-06-30 22:42:15.229804');
INSERT INTO "recording_views" VALUES(1100,1242,'2014-06-30 22:44:08.815343','2014-06-30 22:44:08.815343');
INSERT INTO "recording_views" VALUES(1101,3560,'2014-06-30 22:52:22.812662','2014-06-30 22:52:22.812662');
INSERT INTO "recording_views" VALUES(1102,1242,'2014-06-30 22:58:28.733371','2014-06-30 22:58:28.733371');
INSERT INTO "recording_views" VALUES(1104,3452,'2014-06-30 23:06:34.730784','2014-06-30 23:06:34.730784');
INSERT INTO "recording_views" VALUES(1107,3797,'2014-06-30 23:17:26.017371','2014-06-30 23:17:26.017371');
INSERT INTO "recording_views" VALUES(1113,3452,'2014-06-30 23:31:42.110582','2014-06-30 23:31:42.110582');
INSERT INTO "recording_views" VALUES(1115,3452,'2014-06-30 23:35:09.348889','2014-06-30 23:35:09.348889');
INSERT INTO "recording_views" VALUES(1119,1290,'2014-06-30 23:48:12.172491','2014-06-30 23:48:12.172491');
INSERT INTO "recording_views" VALUES(1121,3662,'2014-06-30 23:58:49.008576','2014-06-30 23:58:49.008576');
INSERT INTO "recording_views" VALUES(1122,3506,'2014-07-01 00:00:56.101437','2014-07-01 00:00:56.101437');
INSERT INTO "recording_views" VALUES(1123,3710,'2014-07-01 00:03:30.459994','2014-07-01 00:03:30.459994');
INSERT INTO "recording_views" VALUES(1124,3751,'2014-07-01 00:09:36.913258','2014-07-01 00:09:36.913258');
INSERT INTO "recording_views" VALUES(1126,3758,'2014-07-01 00:15:10.792395','2014-07-01 00:15:10.792395');
INSERT INTO "recording_views" VALUES(1127,3751,'2014-07-01 00:16:23.801465','2014-07-01 00:16:23.801465');
INSERT INTO "recording_views" VALUES(1128,1290,'2014-07-01 00:16:25.839157','2014-07-01 00:16:25.839157');
INSERT INTO "recording_views" VALUES(1129,3758,'2014-07-01 00:18:26.078201','2014-07-01 00:18:26.078201');
INSERT INTO "recording_views" VALUES(1130,1287,'2014-07-01 00:23:46.058849','2014-07-01 00:23:46.058849');
INSERT INTO "recording_views" VALUES(1131,3452,'2014-07-01 00:49:25.00113','2014-07-01 00:49:25.00113');
INSERT INTO "recording_views" VALUES(1132,3452,'2014-07-01 00:51:54.900352','2014-07-01 00:51:54.900352');
INSERT INTO "recording_views" VALUES(1136,3452,'2014-07-01 01:17:05.203324','2014-07-01 01:17:05.203324');
INSERT INTO "recording_views" VALUES(1141,3757,'2014-07-01 01:28:10.589306','2014-07-01 01:28:10.589306');
INSERT INTO "recording_views" VALUES(1142,3667,'2014-07-01 01:31:07.724627','2014-07-01 01:31:07.724627');
INSERT INTO "recording_views" VALUES(1144,3460,'2014-07-01 01:32:44.81613','2014-07-01 01:32:44.81613');
INSERT INTO "recording_views" VALUES(1146,3460,'2014-07-01 01:35:54.035781','2014-07-01 01:35:54.035781');
INSERT INTO "recording_views" VALUES(1148,3460,'2014-07-01 02:01:01.730271','2014-07-01 02:01:01.730271');
INSERT INTO "recording_views" VALUES(1156,3455,'2014-07-01 02:29:07.065928','2014-07-01 02:29:07.065928');
INSERT INTO "recording_views" VALUES(1163,3455,'2014-07-01 02:40:26.578257','2014-07-01 02:40:26.578257');
INSERT INTO "recording_views" VALUES(1165,3455,'2014-07-01 02:45:25.890476','2014-07-01 02:45:25.890476');
INSERT INTO "recording_views" VALUES(1167,3752,'2014-07-01 02:56:57.894814','2014-07-01 02:56:57.894814');
INSERT INTO "recording_views" VALUES(1168,3455,'2014-07-01 02:57:47.407516','2014-07-01 02:57:47.407516');
INSERT INTO "recording_views" VALUES(1169,3752,'2014-07-01 03:11:12.715078','2014-07-01 03:11:12.715078');
INSERT INTO "recording_views" VALUES(1170,3758,'2014-07-01 03:13:52.367801','2014-07-01 03:13:52.367801');
INSERT INTO "recording_views" VALUES(1171,3446,'2014-07-01 03:17:58.807719','2014-07-01 03:17:58.807719');
INSERT INTO "recording_views" VALUES(1172,3752,'2014-07-01 03:56:16.777315','2014-07-01 03:56:16.777315');
INSERT INTO "recording_views" VALUES(1176,3743,'2014-07-01 05:47:14.22174','2014-07-01 05:47:14.22174');
INSERT INTO "recording_views" VALUES(1179,3445,'2014-07-01 05:53:27.683024','2014-07-01 05:53:27.683024');
INSERT INTO "recording_views" VALUES(1183,3497,'2014-07-01 06:43:55.463986','2014-07-01 06:43:55.463986');
INSERT INTO "recording_views" VALUES(1186,3526,'2014-07-01 07:15:41.451647','2014-07-01 07:15:41.451647');
INSERT INTO "recording_views" VALUES(1188,3526,'2014-07-01 07:26:50.77449','2014-07-01 07:26:50.77449');
INSERT INTO "recording_views" VALUES(1190,3526,'2014-07-01 07:35:11.613577','2014-07-01 07:35:11.613577');
INSERT INTO "recording_views" VALUES(1191,3803,'2014-07-01 07:43:22.849501','2014-07-01 07:43:22.849501');
INSERT INTO "recording_views" VALUES(1193,3496,'2014-07-01 08:02:00.081612','2014-07-01 08:02:00.081612');
INSERT INTO "recording_views" VALUES(1195,3716,'2014-07-01 08:08:38.964224','2014-07-01 08:08:38.964224');
INSERT INTO "recording_views" VALUES(1196,3452,'2014-07-01 08:13:48.867268','2014-07-01 08:13:48.867268');
INSERT INTO "recording_views" VALUES(1199,3808,'2014-07-01 08:16:18.768604','2014-07-01 08:16:18.768604');
INSERT INTO "recording_views" VALUES(1200,3808,'2014-07-01 08:16:18.777657','2014-07-01 08:16:18.777657');
INSERT INTO "recording_views" VALUES(1201,3452,'2014-07-01 08:36:16.885842','2014-07-01 08:36:16.885842');
INSERT INTO "recording_views" VALUES(1202,3452,'2014-07-01 08:36:51.858366','2014-07-01 08:36:51.858366');
INSERT INTO "recording_views" VALUES(1203,3452,'2014-07-01 08:38:14.349961','2014-07-01 08:38:14.349961');
INSERT INTO "recording_views" VALUES(1205,3452,'2014-07-01 08:44:22.195021','2014-07-01 08:44:22.195021');
INSERT INTO "recording_views" VALUES(1206,3452,'2014-07-01 08:54:16.861156','2014-07-01 08:54:16.861156');
INSERT INTO "recording_views" VALUES(1208,3773,'2014-07-01 09:00:19.367398','2014-07-01 09:00:19.367398');
INSERT INTO "recording_views" VALUES(1209,3452,'2014-07-01 09:06:52.248151','2014-07-01 09:06:52.248151');
INSERT INTO "recording_views" VALUES(1212,3785,'2014-07-01 09:14:21.899522','2014-07-01 09:14:21.899522');
INSERT INTO "recording_views" VALUES(1213,3452,'2014-07-01 09:16:54.48935','2014-07-01 09:16:54.48935');
INSERT INTO "recording_views" VALUES(1215,3497,'2014-07-01 09:20:11.205994','2014-07-01 09:20:11.205994');
INSERT INTO "recording_views" VALUES(1216,3452,'2014-07-01 09:23:03.145043','2014-07-01 09:23:03.145043');
INSERT INTO "recording_views" VALUES(1217,3497,'2014-07-01 09:23:27.145757','2014-07-01 09:23:27.145757');
INSERT INTO "recording_views" VALUES(1218,3497,'2014-07-01 09:26:49.845098','2014-07-01 09:26:49.845098');
INSERT INTO "recording_views" VALUES(1219,3452,'2014-07-01 09:27:07.764597','2014-07-01 09:27:07.764597');
INSERT INTO "recording_views" VALUES(1220,3497,'2014-07-01 09:30:16.922672','2014-07-01 09:30:16.922672');
INSERT INTO "recording_views" VALUES(1221,3452,'2014-07-01 09:30:56.535589','2014-07-01 09:30:56.535589');
INSERT INTO "recording_views" VALUES(1223,3497,'2014-07-01 09:32:41.836251','2014-07-01 09:32:41.836251');
INSERT INTO "recording_views" VALUES(1224,3497,'2014-07-01 09:33:24.419475','2014-07-01 09:33:24.419475');
INSERT INTO "recording_views" VALUES(1226,3497,'2014-07-01 09:35:31.352002','2014-07-01 09:35:31.352002');
INSERT INTO "recording_views" VALUES(1227,3785,'2014-07-01 09:35:34.293665','2014-07-01 09:35:34.293665');
INSERT INTO "recording_views" VALUES(1228,3452,'2014-07-01 09:36:59.18496','2014-07-01 09:36:59.18496');
INSERT INTO "recording_views" VALUES(1229,3497,'2014-07-01 09:38:03.026856','2014-07-01 09:38:03.026856');
INSERT INTO "recording_views" VALUES(1230,3497,'2014-07-01 09:40:23.961009','2014-07-01 09:40:23.961009');
INSERT INTO "recording_views" VALUES(1231,3452,'2014-07-01 09:40:39.612587','2014-07-01 09:40:39.612587');
INSERT INTO "recording_views" VALUES(1232,3497,'2014-07-01 09:42:48.131526','2014-07-01 09:42:48.131526');
INSERT INTO "recording_views" VALUES(1233,3452,'2014-07-01 09:42:57.62553','2014-07-01 09:42:57.62553');
INSERT INTO "recording_views" VALUES(1234,3767,'2014-07-01 09:43:34.944167','2014-07-01 09:43:34.944167');
INSERT INTO "recording_views" VALUES(1235,3452,'2014-07-01 09:44:21.058579','2014-07-01 09:44:21.058579');
INSERT INTO "recording_views" VALUES(1236,3452,'2014-07-01 09:45:15.645541','2014-07-01 09:45:15.645541');
INSERT INTO "recording_views" VALUES(1237,3452,'2014-07-01 09:50:17.483377','2014-07-01 09:50:17.483377');
INSERT INTO "recording_views" VALUES(1239,3452,'2014-07-01 09:50:46.35825','2014-07-01 09:50:46.35825');
INSERT INTO "recording_views" VALUES(1240,3497,'2014-07-01 09:51:26.738936','2014-07-01 09:51:26.738936');
INSERT INTO "recording_views" VALUES(1241,3785,'2014-07-01 09:52:00.1886','2014-07-01 09:52:00.1886');
INSERT INTO "recording_views" VALUES(1242,3452,'2014-07-01 09:53:07.342967','2014-07-01 09:53:07.342967');
INSERT INTO "recording_views" VALUES(1244,3497,'2014-07-01 09:58:03.180547','2014-07-01 09:58:03.180547');
INSERT INTO "recording_views" VALUES(1245,3505,'2014-07-01 09:58:15.79332','2014-07-01 09:58:15.79332');
INSERT INTO "recording_views" VALUES(1246,3452,'2014-07-01 09:59:47.806171','2014-07-01 09:59:47.806171');
INSERT INTO "recording_views" VALUES(1247,3497,'2014-07-01 10:00:25.485581','2014-07-01 10:00:25.485581');
INSERT INTO "recording_views" VALUES(1248,3502,'2014-07-01 10:00:27.245184','2014-07-01 10:00:27.245184');
INSERT INTO "recording_views" VALUES(1249,3526,'2014-07-01 10:00:56.348964','2014-07-01 10:00:56.348964');
INSERT INTO "recording_views" VALUES(1250,3452,'2014-07-01 10:03:50.100427','2014-07-01 10:03:50.100427');
INSERT INTO "recording_views" VALUES(1251,3497,'2014-07-01 10:05:47.857694','2014-07-01 10:05:47.857694');
INSERT INTO "recording_views" VALUES(1252,3452,'2014-07-01 10:06:26.775216','2014-07-01 10:06:26.775216');
INSERT INTO "recording_views" VALUES(1253,3497,'2014-07-01 10:09:05.719134','2014-07-01 10:09:05.719134');
INSERT INTO "recording_views" VALUES(1254,3451,'2014-07-01 10:10:56.190079','2014-07-01 10:10:56.190079');
INSERT INTO "recording_views" VALUES(1255,3452,'2014-07-01 10:11:50.062667','2014-07-01 10:11:50.062667');
INSERT INTO "recording_views" VALUES(1256,3497,'2014-07-01 10:11:52.669747','2014-07-01 10:11:52.669747');
INSERT INTO "recording_views" VALUES(1257,3764,'2014-07-01 10:13:29.313947','2014-07-01 10:13:29.313947');
INSERT INTO "recording_views" VALUES(1258,3497,'2014-07-01 10:14:38.73026','2014-07-01 10:14:38.73026');
INSERT INTO "recording_views" VALUES(1260,3452,'2014-07-01 10:15:26.619387','2014-07-01 10:15:26.619387');
INSERT INTO "recording_views" VALUES(1261,3497,'2014-07-01 10:16:58.437408','2014-07-01 10:16:58.437408');
INSERT INTO "recording_views" VALUES(1262,3764,'2014-07-01 10:18:14.135127','2014-07-01 10:18:14.135127');
INSERT INTO "recording_views" VALUES(1263,3509,'2014-07-01 10:18:49.046491','2014-07-01 10:18:49.046491');
INSERT INTO "recording_views" VALUES(1264,3506,'2014-07-01 10:19:39.906898','2014-07-01 10:19:39.906898');
INSERT INTO "recording_views" VALUES(1265,3827,'2014-07-01 10:22:52.608723','2014-07-01 10:22:52.608723');
INSERT INTO "recording_views" VALUES(1266,3452,'2014-07-01 10:23:35.092534','2014-07-01 10:23:35.092534');
INSERT INTO "recording_views" VALUES(1267,3665,'2014-07-01 10:24:40.398715','2014-07-01 10:24:40.398715');
INSERT INTO "recording_views" VALUES(1269,3544,'2014-07-01 10:26:50.684126','2014-07-01 10:26:50.684126');
INSERT INTO "recording_views" VALUES(1270,3452,'2014-07-01 10:27:18.112711','2014-07-01 10:27:18.112711');
INSERT INTO "recording_views" VALUES(1271,3506,'2014-07-01 10:28:39.426644','2014-07-01 10:28:39.426644');
INSERT INTO "recording_views" VALUES(1272,3581,'2014-07-01 10:29:19.387065','2014-07-01 10:29:19.387065');
INSERT INTO "recording_views" VALUES(1273,3515,'2014-07-01 10:29:30.330723','2014-07-01 10:29:30.330723');
INSERT INTO "recording_views" VALUES(1274,3515,'2014-07-01 10:31:53.441199','2014-07-01 10:31:53.441199');
INSERT INTO "recording_views" VALUES(1275,3667,'2014-07-01 10:32:03.865705','2014-07-01 10:32:03.865705');
INSERT INTO "recording_views" VALUES(1276,3452,'2014-07-01 10:34:48.172723','2014-07-01 10:34:48.172723');
INSERT INTO "recording_views" VALUES(1277,3470,'2014-07-01 10:35:37.814729','2014-07-01 10:35:37.814729');
INSERT INTO "recording_views" VALUES(1278,3800,'2014-07-01 10:35:41.666067','2014-07-01 10:35:41.666067');
INSERT INTO "recording_views" VALUES(1279,3758,'2014-07-01 10:35:55.471453','2014-07-01 10:35:55.471453');
INSERT INTO "recording_views" VALUES(1280,3716,'2014-07-01 10:39:22.107282','2014-07-01 10:39:22.107282');
INSERT INTO "recording_views" VALUES(1282,3452,'2014-07-01 10:41:17.006653','2014-07-01 10:41:17.006653');
INSERT INTO "recording_views" VALUES(1283,3758,'2014-07-01 10:46:48.514099','2014-07-01 10:46:48.514099');
INSERT INTO "recording_views" VALUES(1284,3452,'2014-07-01 10:52:08.483214','2014-07-01 10:52:08.483214');
INSERT INTO "recording_views" VALUES(1291,3452,'2014-07-01 11:01:41.863801','2014-07-01 11:01:41.863801');
INSERT INTO "recording_views" VALUES(1292,3758,'2014-07-01 11:03:25.811415','2014-07-01 11:03:25.811415');
INSERT INTO "recording_views" VALUES(1294,3452,'2014-07-01 11:07:21.772597','2014-07-01 11:07:21.772597');
INSERT INTO "recording_views" VALUES(1295,3758,'2014-07-01 11:11:40.549818','2014-07-01 11:11:40.549818');
INSERT INTO "recording_views" VALUES(1296,3452,'2014-07-01 11:19:48.790169','2014-07-01 11:19:48.790169');
INSERT INTO "recording_views" VALUES(1297,3716,'2014-07-01 11:20:25.56134','2014-07-01 11:20:25.56134');
INSERT INTO "recording_views" VALUES(1300,3452,'2014-07-01 11:38:40.867535','2014-07-01 11:38:40.867535');
INSERT INTO "recording_views" VALUES(1319,3452,'2014-07-01 12:16:11.753264','2014-07-01 12:16:11.753264');
INSERT INTO "recording_views" VALUES(1320,3497,'2014-07-01 12:17:23.004186','2014-07-01 12:17:23.004186');
INSERT INTO "recording_views" VALUES(1325,3800,'2014-07-01 12:38:46.735042','2014-07-01 12:38:46.735042');
INSERT INTO "recording_views" VALUES(1327,3509,'2014-07-01 12:47:11.22083','2014-07-01 12:47:11.22083');
INSERT INTO "recording_views" VALUES(1328,3506,'2014-07-01 12:48:15.597802','2014-07-01 12:48:15.597802');
INSERT INTO "recording_views" VALUES(1329,3815,'2014-07-01 12:49:30.748931','2014-07-01 12:49:30.748931');
INSERT INTO "recording_views" VALUES(1331,3815,'2014-07-01 12:51:38.060955','2014-07-01 12:51:38.060955');
INSERT INTO "recording_views" VALUES(1333,3515,'2014-07-01 13:01:42.2795','2014-07-01 13:01:42.2795');
INSERT INTO "recording_views" VALUES(1337,3704,'2014-07-01 13:07:09.739498','2014-07-01 13:07:09.739498');
INSERT INTO "recording_views" VALUES(1338,3608,'2014-07-01 13:07:38.932576','2014-07-01 13:07:38.932576');
INSERT INTO "recording_views" VALUES(1340,3605,'2014-07-01 13:17:20.95188','2014-07-01 13:17:20.95188');
INSERT INTO "recording_views" VALUES(1341,3452,'2014-07-01 13:27:48.267153','2014-07-01 13:27:48.267153');
INSERT INTO "recording_views" VALUES(1343,3815,'2014-07-01 13:33:19.212184','2014-07-01 13:33:19.212184');
INSERT INTO "recording_views" VALUES(1344,3500,'2014-07-01 13:34:04.121353','2014-07-01 13:34:04.121353');
INSERT INTO "recording_views" VALUES(1345,3560,'2014-07-01 13:34:25.597298','2014-07-01 13:34:25.597298');
INSERT INTO "recording_views" VALUES(1346,3704,'2014-07-01 13:36:54.980053','2014-07-01 13:36:54.980053');
INSERT INTO "recording_views" VALUES(1347,3566,'2014-07-01 13:37:14.70577','2014-07-01 13:37:14.70577');
INSERT INTO "recording_views" VALUES(1349,3452,'2014-07-01 13:49:18.456626','2014-07-01 13:49:18.456626');
INSERT INTO "recording_views" VALUES(1350,3560,'2014-07-01 13:51:03.81996','2014-07-01 13:51:03.81996');
INSERT INTO "recording_views" VALUES(1351,3452,'2014-07-01 13:52:15.338996','2014-07-01 13:52:15.338996');
INSERT INTO "recording_views" VALUES(1352,3452,'2014-07-01 13:53:28.627943','2014-07-01 13:53:28.627943');
INSERT INTO "recording_views" VALUES(1353,3452,'2014-07-01 13:57:21.800171','2014-07-01 13:57:21.800171');
INSERT INTO "recording_views" VALUES(1356,3452,'2014-07-01 14:00:20.639518','2014-07-01 14:00:20.639518');
INSERT INTO "recording_views" VALUES(1361,3623,'2014-07-01 14:10:49.892068','2014-07-01 14:10:49.892068');
INSERT INTO "recording_views" VALUES(1362,3467,'2014-07-01 14:11:12.727696','2014-07-01 14:11:12.727696');
INSERT INTO "recording_views" VALUES(1363,3623,'2014-07-01 14:12:57.755696','2014-07-01 14:12:57.755696');
INSERT INTO "recording_views" VALUES(1364,3814,'2014-07-01 14:17:11.726494','2014-07-01 14:17:11.726494');
INSERT INTO "recording_views" VALUES(1366,3452,'2014-07-01 14:29:44.37144','2014-07-01 14:29:44.37144');
INSERT INTO "recording_views" VALUES(1367,3467,'2014-07-01 14:30:18.244971','2014-07-01 14:30:18.244971');
INSERT INTO "recording_views" VALUES(1374,3814,'2014-07-01 14:55:14.540053','2014-07-01 14:55:14.540053');
INSERT INTO "recording_views" VALUES(1376,3467,'2014-07-01 14:56:42.938109','2014-07-01 14:56:42.938109');
INSERT INTO "recording_views" VALUES(1379,3964,'2014-07-01 15:01:56.062537','2014-07-01 15:01:56.062537');
INSERT INTO "recording_views" VALUES(1388,3544,'2014-07-01 15:33:10.555551','2014-07-01 15:33:10.555551');
INSERT INTO "recording_views" VALUES(1399,3452,'2014-07-01 15:52:42.752445','2014-07-01 15:52:42.752445');
INSERT INTO "recording_views" VALUES(1412,3452,'2014-07-01 16:15:12.993521','2014-07-01 16:15:12.993521');
INSERT INTO "recording_views" VALUES(1418,3521,'2014-07-01 16:25:08.544236','2014-07-01 16:25:08.544236');
INSERT INTO "recording_views" VALUES(1424,3452,'2014-07-01 16:39:32.034594','2014-07-01 16:39:32.034594');
INSERT INTO "recording_views" VALUES(1425,3452,'2014-07-01 16:42:20.859507','2014-07-01 16:42:20.859507');
INSERT INTO "recording_views" VALUES(1429,3452,'2014-07-01 16:47:35.427405','2014-07-01 16:47:35.427405');
INSERT INTO "recording_views" VALUES(1431,3497,'2014-07-01 16:49:34.539791','2014-07-01 16:49:34.539791');
INSERT INTO "recording_views" VALUES(1432,3785,'2014-07-01 16:49:56.319077','2014-07-01 16:49:56.319077');
INSERT INTO "recording_views" VALUES(1439,3452,'2014-07-01 17:09:57.739683','2014-07-01 17:09:57.739683');
INSERT INTO "recording_views" VALUES(1440,3601,'2014-07-01 17:15:56.714779','2014-07-01 17:15:56.714779');
INSERT INTO "recording_views" VALUES(1445,3667,'2014-07-01 17:28:54.416297','2014-07-01 17:28:54.416297');
INSERT INTO "recording_views" VALUES(1446,3497,'2014-07-01 17:37:19.59969','2014-07-01 17:37:19.59969');
INSERT INTO "recording_views" VALUES(1447,3452,'2014-07-01 17:42:18.99583','2014-07-01 17:42:18.99583');
INSERT INTO "recording_views" VALUES(1449,3452,'2014-07-01 17:44:36.284832','2014-07-01 17:44:36.284832');
INSERT INTO "recording_views" VALUES(1450,3452,'2014-07-01 17:52:01.373738','2014-07-01 17:52:01.373738');
INSERT INTO "recording_views" VALUES(1451,3677,'2014-07-01 17:53:10.482705','2014-07-01 17:53:10.482705');
INSERT INTO "recording_views" VALUES(1452,3677,'2014-07-01 17:55:53.407169','2014-07-01 17:55:53.407169');
INSERT INTO "recording_views" VALUES(1453,3677,'2014-07-01 18:06:20.499319','2014-07-01 18:06:20.499319');
INSERT INTO "recording_views" VALUES(1455,3677,'2014-07-01 18:08:25.824111','2014-07-01 18:08:25.824111');
INSERT INTO "recording_views" VALUES(1456,3563,'2014-07-01 18:13:42.99395','2014-07-01 18:13:42.99395');
INSERT INTO "recording_views" VALUES(1457,3737,'2014-07-01 18:14:45.250922','2014-07-01 18:14:45.250922');
INSERT INTO "recording_views" VALUES(1458,3617,'2014-07-01 18:15:15.700329','2014-07-01 18:15:15.700329');
INSERT INTO "recording_views" VALUES(1460,3452,'2014-07-01 18:16:29.171166','2014-07-01 18:16:29.171166');
INSERT INTO "recording_views" VALUES(1463,3617,'2014-07-01 18:24:09.014221','2014-07-01 18:24:09.014221');
INSERT INTO "recording_views" VALUES(1466,3617,'2014-07-01 18:29:56.548888','2014-07-01 18:29:56.548888');
INSERT INTO "recording_views" VALUES(1468,1272,'2014-07-01 18:30:26.500821','2014-07-01 18:30:26.500821');
INSERT INTO "recording_views" VALUES(1469,1284,'2014-07-01 18:31:50.017083','2014-07-01 18:31:50.017083');
INSERT INTO "recording_views" VALUES(1470,1290,'2014-07-01 18:33:24.031045','2014-07-01 18:33:24.031045');
INSERT INTO "recording_views" VALUES(1472,1290,'2014-07-01 18:35:33.67947','2014-07-01 18:35:33.67947');
INSERT INTO "recording_views" VALUES(1475,3506,'2014-07-01 18:41:35.888821','2014-07-01 18:41:35.888821');
INSERT INTO "recording_views" VALUES(1478,3506,'2014-07-01 18:46:28.519795','2014-07-01 18:46:28.519795');
INSERT INTO "recording_views" VALUES(1479,1290,'2014-07-01 18:54:57.546505','2014-07-01 18:54:57.546505');
INSERT INTO "recording_views" VALUES(1480,3497,'2014-07-01 18:55:08.671118','2014-07-01 18:55:08.671118');
INSERT INTO "recording_views" VALUES(1481,3779,'2014-07-01 18:55:25.535997','2014-07-01 18:55:25.535997');
INSERT INTO "recording_views" VALUES(1484,3779,'2014-07-01 18:57:52.074005','2014-07-01 18:57:52.074005');
INSERT INTO "recording_views" VALUES(1491,3506,'2014-07-01 19:05:52.888255','2014-07-01 19:05:52.888255');
INSERT INTO "recording_views" VALUES(1495,3506,'2014-07-01 19:09:40.285225','2014-07-01 19:09:40.285225');
INSERT INTO "recording_views" VALUES(1498,3581,'2014-07-01 19:10:39.409388','2014-07-01 19:10:39.409388');
INSERT INTO "recording_views" VALUES(1500,3479,'2014-07-01 19:12:24.401993','2014-07-01 19:12:24.401993');
INSERT INTO "recording_views" VALUES(1501,3665,'2014-07-01 19:14:24.790239','2014-07-01 19:14:24.790239');
INSERT INTO "recording_views" VALUES(1503,3479,'2014-07-01 19:15:50.304244','2014-07-01 19:15:50.304244');
INSERT INTO "recording_views" VALUES(1504,3479,'2014-07-01 19:18:09.996467','2014-07-01 19:18:09.996467');
INSERT INTO "recording_views" VALUES(1505,3479,'2014-07-01 19:21:15.174531','2014-07-01 19:21:15.174531');
INSERT INTO "recording_views" VALUES(1507,3479,'2014-07-01 19:24:28.102223','2014-07-01 19:24:28.102223');
INSERT INTO "recording_views" VALUES(1510,3479,'2014-07-01 19:28:22.976047','2014-07-01 19:28:22.976047');
INSERT INTO "recording_views" VALUES(1513,3452,'2014-07-01 19:34:57.171998','2014-07-01 19:34:57.171998');
INSERT INTO "recording_views" VALUES(1515,3479,'2014-07-01 19:36:48.443235','2014-07-01 19:36:48.443235');
INSERT INTO "recording_views" VALUES(1516,1320,'2014-07-01 19:38:57.533006','2014-07-01 19:38:57.533006');
INSERT INTO "recording_views" VALUES(1517,3479,'2014-07-01 19:40:39.517195','2014-07-01 19:40:39.517195');
INSERT INTO "recording_views" VALUES(1518,1323,'2014-07-01 19:42:22.087754','2014-07-01 19:42:22.087754');
INSERT INTO "recording_views" VALUES(1527,3677,'2014-07-01 19:57:47.469283','2014-07-01 19:57:47.469283');
INSERT INTO "recording_views" VALUES(1533,3497,'2014-07-01 20:17:34.749344','2014-07-01 20:17:34.749344');
INSERT INTO "recording_views" VALUES(1534,3452,'2014-07-01 20:19:02.520305','2014-07-01 20:19:02.520305');
INSERT INTO "recording_views" VALUES(1535,3737,'2014-07-01 20:19:14.268363','2014-07-01 20:19:14.268363');
INSERT INTO "recording_views" VALUES(1537,3662,'2014-07-01 20:23:12.513437','2014-07-01 20:23:12.513437');
INSERT INTO "recording_views" VALUES(1544,3662,'2014-07-01 20:30:09.465916','2014-07-01 20:30:09.465916');
INSERT INTO "recording_views" VALUES(1545,3716,'2014-07-01 20:30:56.838984','2014-07-01 20:30:56.838984');
INSERT INTO "recording_views" VALUES(1548,3737,'2014-07-01 20:31:44.737807','2014-07-01 20:31:44.737807');
INSERT INTO "recording_views" VALUES(1550,3662,'2014-07-01 20:32:32.784231','2014-07-01 20:32:32.784231');
INSERT INTO "recording_views" VALUES(1552,3740,'2014-07-01 20:32:36.698255','2014-07-01 20:32:36.698255');
INSERT INTO "recording_views" VALUES(1554,3740,'2014-07-01 20:35:08.575294','2014-07-01 20:35:08.575294');
INSERT INTO "recording_views" VALUES(1556,3446,'2014-07-01 20:36:46.845037','2014-07-01 20:36:46.845037');
INSERT INTO "recording_views" VALUES(1557,3605,'2014-07-01 20:39:00.438417','2014-07-01 20:39:00.438417');
INSERT INTO "recording_views" VALUES(1559,3653,'2014-07-01 20:41:31.667595','2014-07-01 20:41:31.667595');
INSERT INTO "recording_views" VALUES(1561,242,'2014-07-01 20:43:18.108084','2014-07-01 20:43:18.108084');
INSERT INTO "recording_views" VALUES(1562,3446,'2014-07-01 20:43:18.710849','2014-07-01 20:43:18.710849');
INSERT INTO "recording_views" VALUES(1563,3524,'2014-07-01 20:44:09.239031','2014-07-01 20:44:09.239031');
INSERT INTO "recording_views" VALUES(1565,3527,'2014-07-01 20:44:50.226912','2014-07-01 20:44:50.226912');
INSERT INTO "recording_views" VALUES(1567,3452,'2014-07-01 20:46:40.106171','2014-07-01 20:46:40.106171');
INSERT INTO "recording_views" VALUES(1571,3716,'2014-07-01 20:54:09.84661','2014-07-01 20:54:09.84661');
INSERT INTO "recording_views" VALUES(1572,3758,'2014-07-01 20:58:37.795636','2014-07-01 20:58:37.795636');
INSERT INTO "recording_views" VALUES(1575,103,'2014-07-01 21:08:39.941369','2014-07-01 21:08:39.941369');
INSERT INTO "recording_views" VALUES(1577,106,'2014-07-01 21:10:54.391286','2014-07-01 21:10:54.391286');
INSERT INTO "recording_views" VALUES(1578,148,'2014-07-01 21:12:16.595621','2014-07-01 21:12:16.595621');
INSERT INTO "recording_views" VALUES(1580,148,'2014-07-01 21:15:14.786511','2014-07-01 21:15:14.786511');
INSERT INTO "recording_views" VALUES(1583,207,'2014-07-01 21:17:28.410315','2014-07-01 21:17:28.410315');
INSERT INTO "recording_views" VALUES(1584,148,'2014-07-01 21:20:22.617561','2014-07-01 21:20:22.617561');
INSERT INTO "recording_views" VALUES(1590,3497,'2014-07-01 21:25:12.100321','2014-07-01 21:25:12.100321');
INSERT INTO "recording_views" VALUES(1591,148,'2014-07-01 21:27:48.014672','2014-07-01 21:27:48.014672');
INSERT INTO "recording_views" VALUES(1592,148,'2014-07-01 21:30:06.255958','2014-07-01 21:30:06.255958');
INSERT INTO "recording_views" VALUES(1603,157,'2014-07-01 21:59:30.436316','2014-07-01 21:59:30.436316');
INSERT INTO "recording_views" VALUES(1612,1284,'2014-07-01 22:13:06.902401','2014-07-01 22:13:06.902401');
INSERT INTO "recording_views" VALUES(1613,1242,'2014-07-01 22:13:26.771049','2014-07-01 22:13:26.771049');
INSERT INTO "recording_views" VALUES(1615,148,'2014-07-01 22:23:39.556991','2014-07-01 22:23:39.556991');
INSERT INTO "recording_views" VALUES(1616,3644,'2014-07-01 22:33:19.061422','2014-07-01 22:33:19.061422');
INSERT INTO "recording_views" VALUES(1617,3647,'2014-07-01 22:34:20.999529','2014-07-01 22:34:20.999529');
INSERT INTO "recording_views" VALUES(1618,3647,'2014-07-01 22:41:03.473971','2014-07-01 22:41:03.473971');
INSERT INTO "recording_views" VALUES(1619,3752,'2014-07-01 22:44:34.129554','2014-07-01 22:44:34.129554');
INSERT INTO "recording_views" VALUES(1620,3452,'2014-07-01 22:44:47.179142','2014-07-01 22:44:47.179142');
INSERT INTO "recording_views" VALUES(1621,3527,'2014-07-01 22:45:30.377564','2014-07-01 22:45:30.377564');
INSERT INTO "recording_views" VALUES(1622,3752,'2014-07-01 22:47:28.891895','2014-07-01 22:47:28.891895');
INSERT INTO "recording_views" VALUES(1623,3527,'2014-07-01 22:47:48.419663','2014-07-01 22:47:48.419663');
INSERT INTO "recording_views" VALUES(1624,3451,'2014-07-01 22:49:11.783215','2014-07-01 22:49:11.783215');
INSERT INTO "recording_views" VALUES(1626,3752,'2014-07-01 22:56:13.777904','2014-07-01 22:56:13.777904');
INSERT INTO "recording_views" VALUES(1627,3752,'2014-07-01 23:01:12.693061','2014-07-01 23:01:12.693061');
INSERT INTO "recording_views" VALUES(1628,3451,'2014-07-01 23:07:48.723327','2014-07-01 23:07:48.723327');
INSERT INTO "recording_views" VALUES(1629,3752,'2014-07-01 23:08:09.406302','2014-07-01 23:08:09.406302');
INSERT INTO "recording_views" VALUES(1630,3451,'2014-07-01 23:29:45.568636','2014-07-01 23:29:45.568636');
INSERT INTO "recording_views" VALUES(1631,3451,'2014-07-01 23:32:18.853896','2014-07-01 23:32:18.853896');
INSERT INTO "recording_views" VALUES(1636,3466,'2014-07-02 00:07:23.682522','2014-07-02 00:07:23.682522');
INSERT INTO "recording_views" VALUES(1638,3752,'2014-07-02 00:14:36.974364','2014-07-02 00:14:36.974364');
INSERT INTO "recording_views" VALUES(1639,3752,'2014-07-02 00:17:16.630947','2014-07-02 00:17:16.630947');
INSERT INTO "recording_views" VALUES(1640,3496,'2014-07-02 00:18:00.513461','2014-07-02 00:18:00.513461');
INSERT INTO "recording_views" VALUES(1642,3752,'2014-07-02 00:44:41.956776','2014-07-02 00:44:41.956776');
INSERT INTO "recording_views" VALUES(1643,3752,'2014-07-02 00:47:02.295276','2014-07-02 00:47:02.295276');
INSERT INTO "recording_views" VALUES(1644,3497,'2014-07-02 01:20:34.224605','2014-07-02 01:20:34.224605');
INSERT INTO "recording_views" VALUES(1645,3560,'2014-07-02 01:20:41.543069','2014-07-02 01:20:41.543069');
INSERT INTO "recording_views" VALUES(1646,3506,'2014-07-02 01:24:55.183775','2014-07-02 01:24:55.183775');
INSERT INTO "recording_views" VALUES(1647,3509,'2014-07-02 01:25:36.503981','2014-07-02 01:25:36.503981');
INSERT INTO "recording_views" VALUES(1648,3497,'2014-07-02 01:52:10.224711','2014-07-02 01:52:10.224711');
INSERT INTO "recording_views" VALUES(1649,3770,'2014-07-02 02:07:50.300792','2014-07-02 02:07:50.300792');
INSERT INTO "recording_views" VALUES(1650,3452,'2014-07-02 02:09:12.132527','2014-07-02 02:09:12.132527');
INSERT INTO "recording_views" VALUES(1651,3808,'2014-07-02 02:40:41.540743','2014-07-02 02:40:41.540743');
INSERT INTO "recording_views" VALUES(1652,3602,'2014-07-02 02:59:03.143903','2014-07-02 02:59:03.143903');
INSERT INTO "recording_views" VALUES(1653,3757,'2014-07-02 03:18:40.331117','2014-07-02 03:18:40.331117');
INSERT INTO "recording_views" VALUES(1654,3757,'2014-07-02 03:22:20.91866','2014-07-02 03:22:20.91866');
INSERT INTO "recording_views" VALUES(1655,3815,'2014-07-02 03:33:05.741217','2014-07-02 03:33:05.741217');
INSERT INTO "recording_views" VALUES(1656,3506,'2014-07-02 03:33:27.516431','2014-07-02 03:33:27.516431');
INSERT INTO "recording_views" VALUES(1657,3815,'2014-07-02 03:35:35.808688','2014-07-02 03:35:35.808688');
INSERT INTO "recording_views" VALUES(1658,3623,'2014-07-02 03:35:37.802646','2014-07-02 03:35:37.802646');
INSERT INTO "recording_views" VALUES(1659,3716,'2014-07-02 03:56:23.922931','2014-07-02 03:56:23.922931');
INSERT INTO "recording_views" VALUES(1661,3515,'2014-07-02 04:52:13.042509','2014-07-02 04:52:13.042509');
INSERT INTO "recording_views" VALUES(1662,3605,'2014-07-02 04:53:46.186753','2014-07-02 04:53:46.186753');
INSERT INTO "recording_views" VALUES(1663,3452,'2014-07-02 05:21:29.005427','2014-07-02 05:21:29.005427');
INSERT INTO "recording_views" VALUES(1664,1215,'2014-07-02 05:25:29.384562','2014-07-02 05:25:29.384562');
INSERT INTO "recording_views" VALUES(1665,1308,'2014-07-02 05:26:33.611774','2014-07-02 05:26:33.611774');
INSERT INTO "recording_views" VALUES(1666,3452,'2014-07-02 05:36:27.579233','2014-07-02 05:36:27.579233');
INSERT INTO "recording_views" VALUES(1668,3500,'2014-07-02 05:41:12.787943','2014-07-02 05:41:12.787943');
INSERT INTO "recording_views" VALUES(1669,3452,'2014-07-02 05:45:46.469353','2014-07-02 05:45:46.469353');
INSERT INTO "recording_views" VALUES(1670,3452,'2014-07-02 05:48:19.179938','2014-07-02 05:48:19.179938');
INSERT INTO "recording_views" VALUES(1671,3500,'2014-07-02 05:51:44.961701','2014-07-02 05:51:44.961701');
INSERT INTO "recording_views" VALUES(1672,3500,'2014-07-02 05:56:59.500026','2014-07-02 05:56:59.500026');
INSERT INTO "recording_views" VALUES(1673,3452,'2014-07-02 06:13:37.078837','2014-07-02 06:13:37.078837');
INSERT INTO "recording_views" VALUES(1674,3452,'2014-07-02 06:16:40.090379','2014-07-02 06:16:40.090379');
INSERT INTO "recording_views" VALUES(1676,3452,'2014-07-02 06:19:25.554865','2014-07-02 06:19:25.554865');
INSERT INTO "recording_views" VALUES(1679,3560,'2014-07-02 06:33:29.127478','2014-07-02 06:33:29.127478');
INSERT INTO "recording_views" VALUES(1680,3452,'2014-07-02 06:38:08.061521','2014-07-02 06:38:08.061521');
INSERT INTO "recording_views" VALUES(1681,3452,'2014-07-02 06:44:29.054939','2014-07-02 06:44:29.054939');
INSERT INTO "recording_views" VALUES(1682,3509,'2014-07-02 06:47:24.279127','2014-07-02 06:47:24.279127');
INSERT INTO "recording_views" VALUES(1683,3509,'2014-07-02 06:54:31.975663','2014-07-02 06:54:31.975663');
INSERT INTO "recording_views" VALUES(1696,3602,'2014-07-02 08:35:11.798332','2014-07-02 08:35:11.798332');
INSERT INTO "recording_views" VALUES(1698,3710,'2014-07-02 08:40:51.051665','2014-07-02 08:40:51.051665');
INSERT INTO "recording_views" VALUES(1699,3560,'2014-07-02 08:57:14.756325','2014-07-02 08:57:14.756325');
INSERT INTO "recording_views" VALUES(1702,3647,'2014-07-02 09:08:55.366496','2014-07-02 09:08:55.366496');
INSERT INTO "recording_views" VALUES(1703,3542,'2014-07-02 09:10:40.031269','2014-07-02 09:10:40.031269');
INSERT INTO "recording_views" VALUES(1704,3647,'2014-07-02 09:11:29.349913','2014-07-02 09:11:29.349913');
INSERT INTO "recording_views" VALUES(1707,3743,'2014-07-02 09:22:45.545733','2014-07-02 09:22:45.545733');
INSERT INTO "recording_views" VALUES(1711,3647,'2014-07-02 09:38:10.563148','2014-07-02 09:38:10.563148');
INSERT INTO "recording_views" VALUES(1714,3647,'2014-07-02 09:45:51.479559','2014-07-02 09:45:51.479559');
INSERT INTO "recording_views" VALUES(1718,3731,'2014-07-02 09:52:05.263421','2014-07-02 09:52:05.263421');
INSERT INTO "recording_views" VALUES(1720,3809,'2014-07-02 09:52:25.598357','2014-07-02 09:52:25.598357');
INSERT INTO "recording_views" VALUES(1722,3722,'2014-07-02 09:56:48.610709','2014-07-02 09:56:48.610709');
INSERT INTO "recording_views" VALUES(1723,3602,'2014-07-02 09:57:02.898962','2014-07-02 09:57:02.898962');
INSERT INTO "recording_views" VALUES(1724,3809,'2014-07-02 09:58:02.021854','2014-07-02 09:58:02.021854');
INSERT INTO "recording_views" VALUES(1725,3452,'2014-07-02 09:58:06.513033','2014-07-02 09:58:06.513033');
INSERT INTO "recording_views" VALUES(1727,3602,'2014-07-02 09:59:07.494567','2014-07-02 09:59:07.494567');
INSERT INTO "recording_views" VALUES(1728,3452,'2014-07-02 10:01:03.249802','2014-07-02 10:01:03.249802');
INSERT INTO "recording_views" VALUES(1729,3602,'2014-07-02 10:02:54.49908','2014-07-02 10:02:54.49908');
INSERT INTO "recording_views" VALUES(1730,3602,'2014-07-02 10:05:03.071502','2014-07-02 10:05:03.071502');
INSERT INTO "recording_views" VALUES(1731,3734,'2014-07-02 10:05:49.267633','2014-07-02 10:05:49.267633');
INSERT INTO "recording_views" VALUES(1732,3500,'2014-07-02 10:05:50.480191','2014-07-02 10:05:50.480191');
INSERT INTO "recording_views" VALUES(1733,3752,'2014-07-02 10:07:30.147493','2014-07-02 10:07:30.147493');
INSERT INTO "recording_views" VALUES(1736,3602,'2014-07-02 10:08:43.537265','2014-07-02 10:08:43.537265');
INSERT INTO "recording_views" VALUES(1737,3602,'2014-07-02 10:11:32.032884','2014-07-02 10:11:32.032884');
INSERT INTO "recording_views" VALUES(1738,3602,'2014-07-02 10:11:53.693477','2014-07-02 10:11:53.693477');
INSERT INTO "recording_views" VALUES(1739,3449,'2014-07-02 10:13:02.501892','2014-07-02 10:13:02.501892');
INSERT INTO "recording_views" VALUES(1741,3473,'2014-07-02 10:19:07.088311','2014-07-02 10:19:07.088311');
INSERT INTO "recording_views" VALUES(1742,3602,'2014-07-02 10:19:19.953977','2014-07-02 10:19:19.953977');
INSERT INTO "recording_views" VALUES(1743,3500,'2014-07-02 10:19:49.113178','2014-07-02 10:19:49.113178');
INSERT INTO "recording_views" VALUES(1744,3809,'2014-07-02 10:21:37.323821','2014-07-02 10:21:37.323821');
INSERT INTO "recording_views" VALUES(1745,3602,'2014-07-02 10:21:50.943711','2014-07-02 10:21:50.943711');
INSERT INTO "recording_views" VALUES(1747,3500,'2014-07-02 10:23:27.808912','2014-07-02 10:23:27.808912');
INSERT INTO "recording_views" VALUES(1748,3602,'2014-07-02 10:23:57.715889','2014-07-02 10:23:57.715889');
INSERT INTO "recording_views" VALUES(1749,3602,'2014-07-02 10:26:13.726356','2014-07-02 10:26:13.726356');
INSERT INTO "recording_views" VALUES(1750,3602,'2014-07-02 10:26:29.281067','2014-07-02 10:26:29.281067');
INSERT INTO "recording_views" VALUES(1751,3602,'2014-07-02 10:28:40.726285','2014-07-02 10:28:40.726285');
INSERT INTO "recording_views" VALUES(1752,3602,'2014-07-02 10:29:18.512438','2014-07-02 10:29:18.512438');
INSERT INTO "recording_views" VALUES(1753,3635,'2014-07-02 10:29:45.166641','2014-07-02 10:29:45.166641');
INSERT INTO "recording_views" VALUES(1754,3602,'2014-07-02 10:31:16.436635','2014-07-02 10:31:16.436635');
INSERT INTO "recording_views" VALUES(1755,3602,'2014-07-02 10:34:21.695937','2014-07-02 10:34:21.695937');
INSERT INTO "recording_views" VALUES(1756,3809,'2014-07-02 10:35:27.720373','2014-07-02 10:35:27.720373');
INSERT INTO "recording_views" VALUES(1757,3602,'2014-07-02 10:38:57.621159','2014-07-02 10:38:57.621159');
INSERT INTO "recording_views" VALUES(1758,3809,'2014-07-02 10:42:16.191809','2014-07-02 10:42:16.191809');
INSERT INTO "recording_views" VALUES(1759,3497,'2014-07-02 10:43:48.508045','2014-07-02 10:43:48.508045');
INSERT INTO "recording_views" VALUES(1762,3452,'2014-07-02 10:47:39.65857','2014-07-02 10:47:39.65857');
INSERT INTO "recording_views" VALUES(1768,3602,'2014-07-02 10:57:37.057322','2014-07-02 10:57:37.057322');
INSERT INTO "recording_views" VALUES(1769,3602,'2014-07-02 10:59:42.629763','2014-07-02 10:59:42.629763');
INSERT INTO "recording_views" VALUES(1771,3602,'2014-07-02 11:10:27.004499','2014-07-02 11:10:27.004499');
INSERT INTO "recording_views" VALUES(1772,3605,'2014-07-02 11:17:48.850768','2014-07-02 11:17:48.850768');
INSERT INTO "recording_views" VALUES(1774,3605,'2014-07-02 11:19:51.515779','2014-07-02 11:19:51.515779');
INSERT INTO "recording_views" VALUES(1775,3703,'2014-07-02 11:20:10.92635','2014-07-02 11:20:10.92635');
INSERT INTO "recording_views" VALUES(1777,3703,'2014-07-02 11:31:27.785391','2014-07-02 11:31:27.785391');
INSERT INTO "recording_views" VALUES(1778,3497,'2014-07-02 11:32:01.695267','2014-07-02 11:32:01.695267');
INSERT INTO "recording_views" VALUES(1780,3703,'2014-07-02 11:37:52.866297','2014-07-02 11:37:52.866297');
INSERT INTO "recording_views" VALUES(1790,3605,'2014-07-02 11:59:27.534481','2014-07-02 11:59:27.534481');
INSERT INTO "recording_views" VALUES(1793,3496,'2014-07-02 12:02:33.894059','2014-07-02 12:02:33.894059');
INSERT INTO "recording_views" VALUES(1794,3452,'2014-07-02 12:05:09.589213','2014-07-02 12:05:09.589213');
INSERT INTO "recording_views" VALUES(1797,3452,'2014-07-02 12:07:11.565099','2014-07-02 12:07:11.565099');
INSERT INTO "recording_views" VALUES(1801,3452,'2014-07-02 12:09:47.098941','2014-07-02 12:09:47.098941');
INSERT INTO "recording_views" VALUES(1804,3496,'2014-07-02 12:10:55.892337','2014-07-02 12:10:55.892337');
INSERT INTO "recording_views" VALUES(1805,3560,'2014-07-02 12:11:24.111174','2014-07-02 12:11:24.111174');
INSERT INTO "recording_views" VALUES(1806,3751,'2014-07-02 12:11:48.165609','2014-07-02 12:11:48.165609');
INSERT INTO "recording_views" VALUES(1807,3452,'2014-07-02 12:14:59.419165','2014-07-02 12:14:59.419165');
INSERT INTO "recording_views" VALUES(1808,3452,'2014-07-02 12:17:06.943887','2014-07-02 12:17:06.943887');
INSERT INTO "recording_views" VALUES(1809,3452,'2014-07-02 12:22:12.746109','2014-07-02 12:22:12.746109');
INSERT INTO "recording_views" VALUES(1810,148,'2014-07-02 12:22:51.423801','2014-07-02 12:22:51.423801');
INSERT INTO "recording_views" VALUES(1812,236,'2014-07-02 12:24:45.120931','2014-07-02 12:24:45.120931');
INSERT INTO "recording_views" VALUES(1814,3452,'2014-07-02 12:26:33.726656','2014-07-02 12:26:33.726656');
INSERT INTO "recording_views" VALUES(1817,3446,'2014-07-02 12:34:35.365451','2014-07-02 12:34:35.365451');
INSERT INTO "recording_views" VALUES(1818,3497,'2014-07-02 12:36:19.305882','2014-07-02 12:36:19.305882');
INSERT INTO "recording_views" VALUES(1819,3667,'2014-07-02 12:37:13.362907','2014-07-02 12:37:13.362907');
INSERT INTO "recording_views" VALUES(1821,236,'2014-07-02 12:46:36.960228','2014-07-02 12:46:36.960228');
INSERT INTO "recording_views" VALUES(1822,3431,'2014-07-02 12:53:16.629922','2014-07-02 12:53:16.629922');
INSERT INTO "recording_views" VALUES(1827,3497,'2014-07-02 13:12:19.427402','2014-07-02 13:12:19.427402');
INSERT INTO "recording_views" VALUES(1829,3484,'2014-07-02 13:13:47.665859','2014-07-02 13:13:47.665859');
INSERT INTO "recording_views" VALUES(1831,3497,'2014-07-02 13:14:57.648426','2014-07-02 13:14:57.648426');
INSERT INTO "recording_views" VALUES(1833,3497,'2014-07-02 13:18:34.08481','2014-07-02 13:18:34.08481');
INSERT INTO "recording_views" VALUES(1836,3497,'2014-07-02 13:35:00.089966','2014-07-02 13:35:00.089966');
INSERT INTO "recording_views" VALUES(1843,3506,'2014-07-02 13:42:29.84962','2014-07-02 13:42:29.84962');
INSERT INTO "recording_views" VALUES(1846,3497,'2014-07-02 13:45:14.449','2014-07-02 13:45:14.449');
INSERT INTO "recording_views" VALUES(1847,3452,'2014-07-02 13:47:09.026488','2014-07-02 13:47:09.026488');
INSERT INTO "recording_views" VALUES(1849,3452,'2014-07-02 13:48:34.923003','2014-07-02 13:48:34.923003');
INSERT INTO "recording_views" VALUES(1851,3602,'2014-07-02 13:52:18.601543','2014-07-02 13:52:18.601543');
INSERT INTO "recording_views" VALUES(1853,3821,'2014-07-02 13:54:11.327475','2014-07-02 13:54:11.327475');
INSERT INTO "recording_views" VALUES(1855,3497,'2014-07-02 13:56:03.744817','2014-07-02 13:56:03.744817');
INSERT INTO "recording_views" VALUES(1856,3821,'2014-07-02 13:56:46.760628','2014-07-02 13:56:46.760628');
INSERT INTO "recording_views" VALUES(1858,3602,'2014-07-02 13:58:16.422989','2014-07-02 13:58:16.422989');
INSERT INTO "recording_views" VALUES(1860,3602,'2014-07-02 14:00:36.589895','2014-07-02 14:00:36.589895');
INSERT INTO "recording_views" VALUES(1861,3821,'2014-07-02 14:03:30.061203','2014-07-02 14:03:30.061203');
INSERT INTO "recording_views" VALUES(1863,3497,'2014-07-02 14:09:29.820965','2014-07-02 14:09:29.820965');
INSERT INTO "recording_views" VALUES(1866,3497,'2014-07-02 14:09:53.74804','2014-07-02 14:09:53.74804');
INSERT INTO "recording_views" VALUES(1868,3602,'2014-07-02 14:10:15.616254','2014-07-02 14:10:15.616254');
INSERT INTO "recording_views" VALUES(1869,3602,'2014-07-02 14:14:35.545307','2014-07-02 14:14:35.545307');
INSERT INTO "recording_views" VALUES(1870,3821,'2014-07-02 14:15:40.226498','2014-07-02 14:15:40.226498');
INSERT INTO "recording_views" VALUES(1874,3437,'2014-07-02 14:21:37.473538','2014-07-02 14:21:37.473538');
INSERT INTO "recording_views" VALUES(1875,3497,'2014-07-02 14:22:10.454929','2014-07-02 14:22:10.454929');
INSERT INTO "recording_views" VALUES(1877,3497,'2014-07-02 14:25:14.702209','2014-07-02 14:25:14.702209');
INSERT INTO "recording_views" VALUES(1882,3553,'2014-07-02 14:48:50.875101','2014-07-02 14:48:50.875101');
INSERT INTO "recording_views" VALUES(1886,3452,'2014-07-02 14:56:47.348311','2014-07-02 14:56:47.348311');
INSERT INTO "recording_views" VALUES(1887,3452,'2014-07-02 14:59:40.97282','2014-07-02 14:59:40.97282');
INSERT INTO "recording_views" VALUES(1888,3497,'2014-07-02 14:59:58.473327','2014-07-02 14:59:58.473327');
INSERT INTO "recording_views" VALUES(1889,3572,'2014-07-02 15:01:03.581066','2014-07-02 15:01:03.581066');
INSERT INTO "recording_views" VALUES(1890,3602,'2014-07-02 15:02:12.728146','2014-07-02 15:02:12.728146');
INSERT INTO "recording_views" VALUES(1891,3806,'2014-07-02 15:04:30.897259','2014-07-02 15:04:30.897259');
INSERT INTO "recording_views" VALUES(1894,3806,'2014-07-02 15:07:33.850985','2014-07-02 15:07:33.850985');
INSERT INTO "recording_views" VALUES(1895,3497,'2014-07-02 15:08:29.479949','2014-07-02 15:08:29.479949');
INSERT INTO "recording_views" VALUES(1897,3751,'2014-07-02 15:12:53.049039','2014-07-02 15:12:53.049039');
INSERT INTO "recording_views" VALUES(1898,3602,'2014-07-02 15:13:19.460133','2014-07-02 15:13:19.460133');
INSERT INTO "recording_views" VALUES(1900,3752,'2014-07-02 15:16:10.494054','2014-07-02 15:16:10.494054');
INSERT INTO "recording_views" VALUES(1901,3733,'2014-07-02 15:18:37.833003','2014-07-02 15:18:37.833003');
INSERT INTO "recording_views" VALUES(1902,3431,'2014-07-02 15:20:23.504701','2014-07-02 15:20:23.504701');
INSERT INTO "recording_views" VALUES(1903,3497,'2014-07-02 15:20:45.327512','2014-07-02 15:20:45.327512');
INSERT INTO "recording_views" VALUES(1906,3467,'2014-07-02 15:22:38.168084','2014-07-02 15:22:38.168084');
INSERT INTO "recording_views" VALUES(1907,3806,'2014-07-02 15:24:19.478656','2014-07-02 15:24:19.478656');
INSERT INTO "recording_views" VALUES(1911,3481,'2014-07-02 15:30:25.668632','2014-07-02 15:30:25.668632');
INSERT INTO "recording_views" VALUES(1912,3602,'2014-07-02 15:31:05.15607','2014-07-02 15:31:05.15607');
INSERT INTO "recording_views" VALUES(1913,3452,'2014-07-02 15:31:31.661616','2014-07-02 15:31:31.661616');
INSERT INTO "recording_views" VALUES(1914,3481,'2014-07-02 15:32:37.122296','2014-07-02 15:32:37.122296');
INSERT INTO "recording_views" VALUES(1915,3431,'2014-07-02 15:33:08.489057','2014-07-02 15:33:08.489057');
INSERT INTO "recording_views" VALUES(1917,1233,'2014-07-02 15:40:26.76303','2014-07-02 15:40:26.76303');
INSERT INTO "recording_views" VALUES(1920,3752,'2014-07-02 15:42:06.057308','2014-07-02 15:42:06.057308');
INSERT INTO "recording_views" VALUES(1921,3481,'2014-07-02 15:44:33.54596','2014-07-02 15:44:33.54596');
INSERT INTO "recording_views" VALUES(1922,1233,'2014-07-02 15:45:10.223521','2014-07-02 15:45:10.223521');
INSERT INTO "recording_views" VALUES(1924,3497,'2014-07-02 15:50:09.695329','2014-07-02 15:50:09.695329');
INSERT INTO "recording_views" VALUES(1925,3526,'2014-07-02 15:51:46.655045','2014-07-02 15:51:46.655045');
INSERT INTO "recording_views" VALUES(1926,3716,'2014-07-02 15:52:12.24703','2014-07-02 15:52:12.24703');
INSERT INTO "recording_views" VALUES(1927,3808,'2014-07-02 15:52:47.512193','2014-07-02 15:52:47.512193');
INSERT INTO "recording_views" VALUES(1928,3602,'2014-07-02 15:52:58.331179','2014-07-02 15:52:58.331179');
INSERT INTO "recording_views" VALUES(1929,3497,'2014-07-02 15:53:31.573962','2014-07-02 15:53:31.573962');
INSERT INTO "recording_views" VALUES(1930,3659,'2014-07-02 15:55:29.991519','2014-07-02 15:55:29.991519');
INSERT INTO "recording_views" VALUES(1933,3497,'2014-07-02 15:57:44.584507','2014-07-02 15:57:44.584507');
INSERT INTO "recording_views" VALUES(1934,198,'2014-07-02 15:57:50.951189','2014-07-02 15:57:50.951189');
INSERT INTO "recording_views" VALUES(1935,3602,'2014-07-02 15:59:33.573481','2014-07-02 15:59:33.573481');
INSERT INTO "recording_views" VALUES(1937,3808,'2014-07-02 16:00:58.117515','2014-07-02 16:00:58.117515');
INSERT INTO "recording_views" VALUES(1939,198,'2014-07-02 16:02:16.318334','2014-07-02 16:02:16.318334');
INSERT INTO "recording_views" VALUES(1941,3497,'2014-07-02 16:06:13.370678','2014-07-02 16:06:13.370678');
INSERT INTO "recording_views" VALUES(1943,3602,'2014-07-02 16:07:04.771665','2014-07-02 16:07:04.771665');
INSERT INTO "recording_views" VALUES(1945,3808,'2014-07-02 16:10:26.285733','2014-07-02 16:10:26.285733');
INSERT INTO "recording_views" VALUES(1946,198,'2014-07-02 16:11:31.956071','2014-07-02 16:11:31.956071');
INSERT INTO "recording_views" VALUES(1947,198,'2014-07-02 16:13:55.987575','2014-07-02 16:13:55.987575');
INSERT INTO "recording_views" VALUES(1948,3808,'2014-07-02 16:16:53.154097','2014-07-02 16:16:53.154097');
INSERT INTO "recording_views" VALUES(1950,3808,'2014-07-02 16:24:05.599621','2014-07-02 16:24:05.599621');
INSERT INTO "recording_views" VALUES(1955,3497,'2014-07-02 16:33:12.302315','2014-07-02 16:33:12.302315');
INSERT INTO "recording_views" VALUES(1959,3497,'2014-07-02 16:43:51.557578','2014-07-02 16:43:51.557578');
INSERT INTO "recording_views" VALUES(1961,3808,'2014-07-02 16:53:14.721976','2014-07-02 16:53:14.721976');
INSERT INTO "recording_views" VALUES(1963,3716,'2014-07-02 16:54:28.570822','2014-07-02 16:54:28.570822');
INSERT INTO "recording_views" VALUES(1965,3808,'2014-07-02 17:01:04.879696','2014-07-02 17:01:04.879696');
INSERT INTO "recording_views" VALUES(1967,3452,'2014-07-02 17:02:42.70696','2014-07-02 17:02:42.70696');
INSERT INTO "recording_views" VALUES(1968,3497,'2014-07-02 17:03:26.208691','2014-07-02 17:03:26.208691');
INSERT INTO "recording_views" VALUES(1970,3799,'2014-07-02 17:11:11.226601','2014-07-02 17:11:11.226601');
INSERT INTO "recording_views" VALUES(1972,3808,'2014-07-02 17:11:55.07034','2014-07-02 17:11:55.07034');
INSERT INTO "recording_views" VALUES(1973,3452,'2014-07-02 17:14:42.544761','2014-07-02 17:14:42.544761');
INSERT INTO "recording_views" VALUES(1975,3452,'2014-07-02 17:16:23.546575','2014-07-02 17:16:23.546575');
INSERT INTO "recording_views" VALUES(1976,3602,'2014-07-02 17:16:29.903304','2014-07-02 17:16:29.903304');
INSERT INTO "recording_views" VALUES(1977,3767,'2014-07-02 17:17:48.475719','2014-07-02 17:17:48.475719');
INSERT INTO "recording_views" VALUES(1978,3808,'2014-07-02 17:20:39.042569','2014-07-02 17:20:39.042569');
INSERT INTO "recording_views" VALUES(1979,3452,'2014-07-02 17:20:58.932436','2014-07-02 17:20:58.932436');
INSERT INTO "recording_views" VALUES(1980,3799,'2014-07-02 17:23:47.754938','2014-07-02 17:23:47.754938');
INSERT INTO "recording_views" VALUES(1981,3602,'2014-07-02 17:29:07.40188','2014-07-02 17:29:07.40188');
INSERT INTO "recording_views" VALUES(1982,3602,'2014-07-02 17:42:58.345723','2014-07-02 17:42:58.345723');
INSERT INTO "recording_views" VALUES(1984,3452,'2014-07-02 17:52:35.309275','2014-07-02 17:52:35.309275');
INSERT INTO "recording_views" VALUES(1985,3497,'2014-07-02 17:57:42.05863','2014-07-02 17:57:42.05863');
INSERT INTO "recording_views" VALUES(1986,3452,'2014-07-02 18:04:13.197284','2014-07-02 18:04:13.197284');
INSERT INTO "recording_views" VALUES(1987,3629,'2014-07-02 18:06:01.453513','2014-07-02 18:06:01.453513');
INSERT INTO "recording_views" VALUES(1988,3452,'2014-07-02 18:07:12.665373','2014-07-02 18:07:12.665373');
INSERT INTO "recording_views" VALUES(1989,3602,'2014-07-02 18:10:28.428014','2014-07-02 18:10:28.428014');
INSERT INTO "recording_views" VALUES(1990,3716,'2014-07-02 18:13:04.109237','2014-07-02 18:13:04.109237');
INSERT INTO "recording_views" VALUES(1991,3716,'2014-07-02 18:15:50.524872','2014-07-02 18:15:50.524872');
INSERT INTO "recording_views" VALUES(1992,3602,'2014-07-02 18:16:12.697864','2014-07-02 18:16:12.697864');
INSERT INTO "recording_views" VALUES(1993,3662,'2014-07-02 18:16:29.973475','2014-07-02 18:16:29.973475');
INSERT INTO "recording_views" VALUES(1994,3782,'2014-07-02 18:19:09.422754','2014-07-02 18:19:09.422754');
INSERT INTO "recording_views" VALUES(1997,3778,'2014-07-02 18:40:39.941996','2014-07-02 18:40:39.941996');
INSERT INTO "recording_views" VALUES(1999,3662,'2014-07-02 18:49:33.166169','2014-07-02 18:49:33.166169');
INSERT INTO "recording_views" VALUES(2000,3497,'2014-07-02 18:50:15.332107','2014-07-02 18:50:15.332107');
INSERT INTO "recording_views" VALUES(2001,3799,'2014-07-02 18:54:07.404114','2014-07-02 18:54:07.404114');
INSERT INTO "recording_views" VALUES(2004,3475,'2014-07-02 19:01:19.823679','2014-07-02 19:01:19.823679');
INSERT INTO "recording_views" VALUES(2005,3799,'2014-07-02 19:04:27.839965','2014-07-02 19:04:27.839965');
INSERT INTO "recording_views" VALUES(2006,3602,'2014-07-02 19:05:29.632779','2014-07-02 19:05:29.632779');
INSERT INTO "recording_views" VALUES(2007,3497,'2014-07-02 19:06:56.676704','2014-07-02 19:06:56.676704');
INSERT INTO "recording_views" VALUES(2008,3778,'2014-07-02 19:11:24.163624','2014-07-02 19:11:24.163624');
INSERT INTO "recording_views" VALUES(2009,3475,'2014-07-02 19:11:39.289392','2014-07-02 19:11:39.289392');
INSERT INTO "recording_views" VALUES(2011,3698,'2014-07-02 19:14:44.713664','2014-07-02 19:14:44.713664');
INSERT INTO "recording_views" VALUES(2013,3698,'2014-07-02 19:17:29.995546','2014-07-02 19:17:29.995546');
INSERT INTO "recording_views" VALUES(2014,3662,'2014-07-02 19:18:58.589015','2014-07-02 19:18:58.589015');
INSERT INTO "recording_views" VALUES(2015,3698,'2014-07-02 19:19:50.286482','2014-07-02 19:19:50.286482');
INSERT INTO "recording_views" VALUES(2016,3698,'2014-07-02 19:19:50.30065','2014-07-02 19:19:50.30065');
INSERT INTO "recording_views" VALUES(2019,3698,'2014-07-02 19:22:55.949201','2014-07-02 19:22:55.949201');
INSERT INTO "recording_views" VALUES(2020,3665,'2014-07-02 19:25:56.585942','2014-07-02 19:25:56.585942');
INSERT INTO "recording_views" VALUES(2021,3665,'2014-07-02 19:29:06.041451','2014-07-02 19:29:06.041451');
INSERT INTO "recording_views" VALUES(2022,3539,'2014-07-02 19:33:33.288297','2014-07-02 19:33:33.288297');
INSERT INTO "recording_views" VALUES(2026,3722,'2014-07-02 19:53:36.798874','2014-07-02 19:53:36.798874');
INSERT INTO "recording_views" VALUES(2027,3722,'2014-07-02 19:56:33.944349','2014-07-02 19:56:33.944349');
INSERT INTO "recording_views" VALUES(2035,3683,'2014-07-02 20:05:38.565633','2014-07-02 20:05:38.565633');
INSERT INTO "recording_views" VALUES(2040,3767,'2014-07-02 20:18:34.052953','2014-07-02 20:18:34.052953');
INSERT INTO "recording_views" VALUES(2041,3451,'2014-07-02 20:18:48.936949','2014-07-02 20:18:48.936949');
INSERT INTO "recording_views" VALUES(2042,3713,'2014-07-02 20:18:56.91509','2014-07-02 20:18:56.91509');
INSERT INTO "recording_views" VALUES(2044,3602,'2014-07-02 20:21:23.869692','2014-07-02 20:21:23.869692');
INSERT INTO "recording_views" VALUES(2045,3683,'2014-07-02 20:21:28.362138','2014-07-02 20:21:28.362138');
INSERT INTO "recording_views" VALUES(2047,3767,'2014-07-02 20:27:58.006246','2014-07-02 20:27:58.006246');
INSERT INTO "recording_views" VALUES(2049,3497,'2014-07-02 20:34:39.021973','2014-07-02 20:34:39.021973');
INSERT INTO "recording_views" VALUES(2051,3716,'2014-07-02 20:37:06.04497','2014-07-02 20:37:06.04497');
INSERT INTO "recording_views" VALUES(2053,3527,'2014-07-02 20:43:30.538683','2014-07-02 20:43:30.538683');
INSERT INTO "recording_views" VALUES(2057,3674,'2014-07-02 20:50:24.653412','2014-07-02 20:50:24.653412');
INSERT INTO "recording_views" VALUES(2070,3808,'2014-07-02 21:03:19.59041','2014-07-02 21:03:19.59041');
INSERT INTO "recording_views" VALUES(2076,3821,'2014-07-02 21:12:49.656144','2014-07-02 21:12:49.656144');
INSERT INTO "recording_views" VALUES(2078,3821,'2014-07-02 21:19:41.647759','2014-07-02 21:19:41.647759');
INSERT INTO "recording_views" VALUES(2079,1341,'2014-07-02 21:22:29.99265','2014-07-02 21:22:29.99265');
INSERT INTO "recording_views" VALUES(2080,3821,'2014-07-02 21:25:23.944383','2014-07-02 21:25:23.944383');
INSERT INTO "recording_views" VALUES(2082,3821,'2014-07-02 21:33:37.630171','2014-07-02 21:33:37.630171');
INSERT INTO "recording_views" VALUES(2083,3715,'2014-07-02 21:42:17.791654','2014-07-02 21:42:17.791654');
INSERT INTO "recording_views" VALUES(2084,3821,'2014-07-02 21:48:10.298182','2014-07-02 21:48:10.298182');
INSERT INTO "recording_views" VALUES(2085,3734,'2014-07-02 21:57:19.253385','2014-07-02 21:57:19.253385');
INSERT INTO "recording_views" VALUES(2086,3743,'2014-07-02 22:15:07.319989','2014-07-02 22:15:07.319989');
INSERT INTO "recording_views" VALUES(2093,3715,'2014-07-02 23:16:12.133547','2014-07-02 23:16:12.133547');
INSERT INTO "recording_views" VALUES(2095,3496,'2014-07-02 23:22:11.499403','2014-07-02 23:22:11.499403');
INSERT INTO "recording_views" VALUES(2108,3505,'2014-07-03 01:53:22.413519','2014-07-03 01:53:22.413519');
INSERT INTO "recording_views" VALUES(2109,3814,'2014-07-03 01:53:44.44867','2014-07-03 01:53:44.44867');
INSERT INTO "recording_views" VALUES(2110,3721,'2014-07-03 01:55:22.069549','2014-07-03 01:55:22.069549');
INSERT INTO "recording_views" VALUES(2111,3721,'2014-07-03 02:06:20.910741','2014-07-03 02:06:20.910741');
INSERT INTO "recording_views" VALUES(2112,3560,'2014-07-03 02:34:18.05143','2014-07-03 02:34:18.05143');
INSERT INTO "recording_views" VALUES(2113,3560,'2014-07-03 02:36:24.425025','2014-07-03 02:36:24.425025');
INSERT INTO "recording_views" VALUES(2114,3595,'2014-07-03 02:36:56.843011','2014-07-03 02:36:56.843011');
INSERT INTO "recording_views" VALUES(2115,3487,'2014-07-03 02:37:16.211808','2014-07-03 02:37:16.211808');
INSERT INTO "recording_views" VALUES(2116,3715,'2014-07-03 02:37:44.357067','2014-07-03 02:37:44.357067');
INSERT INTO "recording_views" VALUES(2117,3634,'2014-07-03 02:38:39.180445','2014-07-03 02:38:39.180445');
INSERT INTO "recording_views" VALUES(2118,3634,'2014-07-03 02:41:33.411359','2014-07-03 02:41:33.411359');
INSERT INTO "recording_views" VALUES(2119,3634,'2014-07-03 02:47:25.254432','2014-07-03 02:47:25.254432');
INSERT INTO "recording_views" VALUES(2121,3799,'2014-07-03 03:47:46.949644','2014-07-03 03:47:46.949644');
INSERT INTO "recording_views" VALUES(2122,3646,'2014-07-03 03:49:10.789619','2014-07-03 03:49:10.789619');
INSERT INTO "recording_views" VALUES(2123,3479,'2014-07-03 03:51:30.240036','2014-07-03 03:51:30.240036');
INSERT INTO "recording_views" VALUES(2124,3479,'2014-07-03 03:53:32.648721','2014-07-03 03:53:32.648721');
INSERT INTO "recording_views" VALUES(2125,3479,'2014-07-03 03:56:10.434361','2014-07-03 03:56:10.434361');
INSERT INTO "recording_views" VALUES(2126,3479,'2014-07-03 03:58:22.568316','2014-07-03 03:58:22.568316');
INSERT INTO "recording_views" VALUES(2127,3479,'2014-07-03 04:00:24.446714','2014-07-03 04:00:24.446714');
INSERT INTO "recording_views" VALUES(2128,3479,'2014-07-03 04:02:29.06622','2014-07-03 04:02:29.06622');
INSERT INTO "recording_views" VALUES(2129,3479,'2014-07-03 04:04:43.796808','2014-07-03 04:04:43.796808');
INSERT INTO "recording_views" VALUES(2130,3497,'2014-07-03 05:26:29.087021','2014-07-03 05:26:29.087021');
INSERT INTO "recording_views" VALUES(2131,3473,'2014-07-03 05:33:01.533213','2014-07-03 05:33:01.533213');
INSERT INTO "recording_views" VALUES(2140,3715,'2014-07-03 06:48:27.54062','2014-07-03 06:48:27.54062');
INSERT INTO "recording_views" VALUES(2141,3626,'2014-07-03 07:02:49.700371','2014-07-03 07:02:49.700371');
INSERT INTO "recording_views" VALUES(2143,3506,'2014-07-03 07:03:25.15694','2014-07-03 07:03:25.15694');
INSERT INTO "recording_views" VALUES(2144,3602,'2014-07-03 07:03:59.689411','2014-07-03 07:03:59.689411');
INSERT INTO "recording_views" VALUES(2147,3431,'2014-07-03 07:14:27.507914','2014-07-03 07:14:27.507914');
INSERT INTO "recording_views" VALUES(2148,3715,'2014-07-03 07:27:05.240371','2014-07-03 07:27:05.240371');
INSERT INTO "recording_views" VALUES(2152,3602,'2014-07-03 07:48:30.946133','2014-07-03 07:48:30.946133');
INSERT INTO "recording_views" VALUES(2154,3602,'2014-07-03 07:57:33.204245','2014-07-03 07:57:33.204245');
INSERT INTO "recording_views" VALUES(2155,3752,'2014-07-03 07:57:52.745163','2014-07-03 07:57:52.745163');
INSERT INTO "recording_views" VALUES(2156,3496,'2014-07-03 08:04:35.033308','2014-07-03 08:04:35.033308');
INSERT INTO "recording_views" VALUES(2157,3496,'2014-07-03 08:07:37.273484','2014-07-03 08:07:37.273484');
INSERT INTO "recording_views" VALUES(2159,3602,'2014-07-03 08:11:39.987479','2014-07-03 08:11:39.987479');
INSERT INTO "recording_views" VALUES(2160,3496,'2014-07-03 08:11:43.691685','2014-07-03 08:11:43.691685');
INSERT INTO "recording_views" VALUES(2162,3602,'2014-07-03 08:15:19.456446','2014-07-03 08:15:19.456446');
INSERT INTO "recording_views" VALUES(2163,3496,'2014-07-03 08:19:23.691391','2014-07-03 08:19:23.691391');
INSERT INTO "recording_views" VALUES(2164,3661,'2014-07-03 08:20:00.234841','2014-07-03 08:20:00.234841');
INSERT INTO "recording_views" VALUES(2165,3602,'2014-07-03 08:20:32.408076','2014-07-03 08:20:32.408076');
INSERT INTO "recording_views" VALUES(2168,3661,'2014-07-03 08:25:45.254843','2014-07-03 08:25:45.254843');
INSERT INTO "recording_views" VALUES(2169,3661,'2014-07-03 08:28:35.851825','2014-07-03 08:28:35.851825');
INSERT INTO "recording_views" VALUES(2170,3542,'2014-07-03 08:31:36.858829','2014-07-03 08:31:36.858829');
INSERT INTO "recording_views" VALUES(2172,3661,'2014-07-03 08:33:54.339859','2014-07-03 08:33:54.339859');
INSERT INTO "recording_views" VALUES(2174,3496,'2014-07-03 08:37:18.048232','2014-07-03 08:37:18.048232');
INSERT INTO "recording_views" VALUES(2178,3451,'2014-07-03 08:44:55.137173','2014-07-03 08:44:55.137173');
INSERT INTO "recording_views" VALUES(2179,3496,'2014-07-03 08:49:23.143231','2014-07-03 08:49:23.143231');
INSERT INTO "recording_views" VALUES(2180,3451,'2014-07-03 08:51:43.085121','2014-07-03 08:51:43.085121');
INSERT INTO "recording_views" VALUES(2181,3560,'2014-07-03 08:54:33.788791','2014-07-03 08:54:33.788791');
INSERT INTO "recording_views" VALUES(2182,3497,'2014-07-03 08:54:56.583547','2014-07-03 08:54:56.583547');
INSERT INTO "recording_views" VALUES(2185,3661,'2014-07-03 09:03:46.173533','2014-07-03 09:03:46.173533');
INSERT INTO "recording_views" VALUES(2187,3661,'2014-07-03 09:06:04.945175','2014-07-03 09:06:04.945175');
INSERT INTO "recording_views" VALUES(2188,3451,'2014-07-03 09:06:35.156108','2014-07-03 09:06:35.156108');
INSERT INTO "recording_views" VALUES(2191,3496,'2014-07-03 09:09:22.189169','2014-07-03 09:09:22.189169');
INSERT INTO "recording_views" VALUES(2200,3496,'2014-07-03 09:22:29.210491','2014-07-03 09:22:29.210491');
INSERT INTO "recording_views" VALUES(2203,3602,'2014-07-03 09:39:24.074448','2014-07-03 09:39:24.074448');
INSERT INTO "recording_views" VALUES(2204,3661,'2014-07-03 09:41:54.202666','2014-07-03 09:41:54.202666');
INSERT INTO "recording_views" VALUES(2207,3661,'2014-07-03 09:45:17.209519','2014-07-03 09:45:17.209519');
INSERT INTO "recording_views" VALUES(2208,3661,'2014-07-03 09:48:09.859303','2014-07-03 09:48:09.859303');
INSERT INTO "recording_views" VALUES(2210,3661,'2014-07-03 09:53:49.081875','2014-07-03 09:53:49.081875');
INSERT INTO "recording_views" VALUES(2213,3496,'2014-07-03 09:55:52.74356','2014-07-03 09:55:52.74356');
INSERT INTO "recording_views" VALUES(2215,3661,'2014-07-03 10:01:25.37481','2014-07-03 10:01:25.37481');
INSERT INTO "recording_views" VALUES(2216,3451,'2014-07-03 10:04:12.909333','2014-07-03 10:04:12.909333');
INSERT INTO "recording_views" VALUES(2217,3727,'2014-07-03 10:04:44.478601','2014-07-03 10:04:44.478601');
INSERT INTO "recording_views" VALUES(2218,3623,'2014-07-03 10:05:34.312742','2014-07-03 10:05:34.312742');
INSERT INTO "recording_views" VALUES(2219,3661,'2014-07-03 10:06:03.452145','2014-07-03 10:06:03.452145');
INSERT INTO "recording_views" VALUES(2220,3808,'2014-07-03 10:31:08.432794','2014-07-03 10:31:08.432794');
INSERT INTO "recording_views" VALUES(2221,3601,'2014-07-03 10:31:36.528482','2014-07-03 10:31:36.528482');
INSERT INTO "recording_views" VALUES(2223,3452,'2014-07-03 10:34:28.572871','2014-07-03 10:34:28.572871');
INSERT INTO "recording_views" VALUES(2224,3506,'2014-07-03 10:40:17.261633','2014-07-03 10:40:17.261633');
INSERT INTO "recording_views" VALUES(2225,3773,'2014-07-03 10:41:17.202432','2014-07-03 10:41:17.202432');
INSERT INTO "recording_views" VALUES(2226,3703,'2014-07-03 10:42:09.11301','2014-07-03 10:42:09.11301');
INSERT INTO "recording_views" VALUES(2227,3452,'2014-07-03 10:43:10.485557','2014-07-03 10:43:10.485557');
INSERT INTO "recording_views" VALUES(2230,3601,'2014-07-03 10:45:29.058633','2014-07-03 10:45:29.058633');
INSERT INTO "recording_views" VALUES(2231,3452,'2014-07-03 10:49:14.720524','2014-07-03 10:49:14.720524');
INSERT INTO "recording_views" VALUES(2232,3703,'2014-07-03 10:49:43.032421','2014-07-03 10:49:43.032421');
INSERT INTO "recording_views" VALUES(2233,3451,'2014-07-03 10:50:45.819016','2014-07-03 10:50:45.819016');
INSERT INTO "recording_views" VALUES(2234,3451,'2014-07-03 10:53:12.249121','2014-07-03 10:53:12.249121');
INSERT INTO "recording_views" VALUES(2235,3451,'2014-07-03 10:56:36.189552','2014-07-03 10:56:36.189552');
INSERT INTO "recording_views" VALUES(2236,3497,'2014-07-03 10:59:29.971784','2014-07-03 10:59:29.971784');
INSERT INTO "recording_views" VALUES(2237,3515,'2014-07-03 11:01:55.918714','2014-07-03 11:01:55.918714');
INSERT INTO "recording_views" VALUES(2238,3451,'2014-07-03 11:02:26.373281','2014-07-03 11:02:26.373281');
INSERT INTO "recording_views" VALUES(2239,3542,'2014-07-03 11:05:29.234088','2014-07-03 11:05:29.234088');
INSERT INTO "recording_views" VALUES(2241,3601,'2014-07-03 11:08:39.808285','2014-07-03 11:08:39.808285');
INSERT INTO "recording_views" VALUES(2244,3542,'2014-07-03 11:22:06.506919','2014-07-03 11:22:06.506919');
INSERT INTO "recording_views" VALUES(2246,3601,'2014-07-03 11:25:39.130009','2014-07-03 11:25:39.130009');
INSERT INTO "recording_views" VALUES(2248,3662,'2014-07-03 11:29:01.933664','2014-07-03 11:29:01.933664');
INSERT INTO "recording_views" VALUES(2249,3601,'2014-07-03 11:30:34.65448','2014-07-03 11:30:34.65448');
INSERT INTO "recording_views" VALUES(2251,3601,'2014-07-03 11:34:32.830224','2014-07-03 11:34:32.830224');
INSERT INTO "recording_views" VALUES(2255,3544,'2014-07-03 11:48:02.090716','2014-07-03 11:48:02.090716');
INSERT INTO "recording_views" VALUES(2257,3605,'2014-07-03 11:53:36.469947','2014-07-03 11:53:36.469947');
INSERT INTO "recording_views" VALUES(2259,3703,'2014-07-03 11:55:24.729512','2014-07-03 11:55:24.729512');
INSERT INTO "recording_views" VALUES(2260,3703,'2014-07-03 11:58:40.273931','2014-07-03 11:58:40.273931');
INSERT INTO "recording_views" VALUES(2261,3703,'2014-07-03 12:01:28.036668','2014-07-03 12:01:28.036668');
INSERT INTO "recording_views" VALUES(2263,3703,'2014-07-03 12:04:21.86802','2014-07-03 12:04:21.86802');
INSERT INTO "recording_views" VALUES(2264,3703,'2014-07-03 12:05:03.222889','2014-07-03 12:05:03.222889');
INSERT INTO "recording_views" VALUES(2267,3703,'2014-07-03 12:09:36.799624','2014-07-03 12:09:36.799624');
INSERT INTO "recording_views" VALUES(2269,3515,'2014-07-03 12:12:35.498642','2014-07-03 12:12:35.498642');
INSERT INTO "recording_views" VALUES(2270,3703,'2014-07-03 12:13:36.994432','2014-07-03 12:13:36.994432');
INSERT INTO "recording_views" VALUES(2271,3515,'2014-07-03 12:15:17.860971','2014-07-03 12:15:17.860971');
INSERT INTO "recording_views" VALUES(2272,3703,'2014-07-03 12:21:46.997838','2014-07-03 12:21:46.997838');
INSERT INTO "recording_views" VALUES(2273,3544,'2014-07-03 12:30:01.748222','2014-07-03 12:30:01.748222');
INSERT INTO "recording_views" VALUES(2280,1209,'2014-07-03 12:53:20.796417','2014-07-03 12:53:20.796417');
INSERT INTO "recording_views" VALUES(2282,1278,'2014-07-03 12:59:08.099639','2014-07-03 12:59:08.099639');
INSERT INTO "recording_views" VALUES(2286,3581,'2014-07-03 13:15:00.649981','2014-07-03 13:15:00.649981');
INSERT INTO "recording_views" VALUES(2287,3703,'2014-07-03 13:18:18.085541','2014-07-03 13:18:18.085541');
INSERT INTO "recording_views" VALUES(2298,3662,'2014-07-03 13:34:14.520979','2014-07-03 13:34:14.520979');
INSERT INTO "recording_views" VALUES(2299,3452,'2014-07-03 13:35:47.966421','2014-07-03 13:35:47.966421');
INSERT INTO "recording_views" VALUES(2300,3452,'2014-07-03 13:37:54.30328','2014-07-03 13:37:54.30328');
INSERT INTO "recording_views" VALUES(2302,1278,'2014-07-03 13:39:13.992822','2014-07-03 13:39:13.992822');
INSERT INTO "recording_views" VALUES(2304,1278,'2014-07-03 13:49:50.178936','2014-07-03 13:49:50.178936');
INSERT INTO "recording_views" VALUES(2305,3647,'2014-07-03 13:53:10.695556','2014-07-03 13:53:10.695556');
INSERT INTO "recording_views" VALUES(2306,1278,'2014-07-03 13:55:56.863502','2014-07-03 13:55:56.863502');
INSERT INTO "recording_views" VALUES(2307,3662,'2014-07-03 13:56:16.774939','2014-07-03 13:56:16.774939');
INSERT INTO "recording_views" VALUES(2309,1278,'2014-07-03 14:03:59.10285','2014-07-03 14:03:59.10285');
INSERT INTO "recording_views" VALUES(2310,3452,'2014-07-03 14:06:19.142929','2014-07-03 14:06:19.142929');
INSERT INTO "recording_views" VALUES(2311,3527,'2014-07-03 14:08:23.579095','2014-07-03 14:08:23.579095');
INSERT INTO "recording_views" VALUES(2312,3452,'2014-07-03 14:08:40.119917','2014-07-03 14:08:40.119917');
INSERT INTO "recording_views" VALUES(2313,3526,'2014-07-03 14:08:45.732674','2014-07-03 14:08:45.732674');
INSERT INTO "recording_views" VALUES(2314,3452,'2014-07-03 14:10:44.785831','2014-07-03 14:10:44.785831');
INSERT INTO "recording_views" VALUES(2316,3434,'2014-07-03 14:12:50.491284','2014-07-03 14:12:50.491284');
INSERT INTO "recording_views" VALUES(2317,3527,'2014-07-03 14:14:21.997214','2014-07-03 14:14:21.997214');
INSERT INTO "recording_views" VALUES(2318,3563,'2014-07-03 14:22:39.602602','2014-07-03 14:22:39.602602');
INSERT INTO "recording_views" VALUES(2319,3560,'2014-07-03 14:23:40.67636','2014-07-03 14:23:40.67636');
INSERT INTO "recording_views" VALUES(2320,3563,'2014-07-03 14:27:34.083042','2014-07-03 14:27:34.083042');
INSERT INTO "recording_views" VALUES(2321,3560,'2014-07-03 14:29:42.098667','2014-07-03 14:29:42.098667');
INSERT INTO "recording_views" VALUES(2325,3496,'2014-07-03 14:37:55.226631','2014-07-03 14:37:55.226631');
INSERT INTO "recording_views" VALUES(2328,3560,'2014-07-03 14:44:38.944302','2014-07-03 14:44:38.944302');
INSERT INTO "recording_views" VALUES(2329,3721,'2014-07-03 14:44:53.779972','2014-07-03 14:44:53.779972');
INSERT INTO "recording_views" VALUES(2331,3560,'2014-07-03 14:50:47.66608','2014-07-03 14:50:47.66608');
INSERT INTO "recording_views" VALUES(2344,3605,'2014-07-03 15:39:57.665949','2014-07-03 15:39:57.665949');
INSERT INTO "recording_views" VALUES(2345,3662,'2014-07-03 15:46:26.609934','2014-07-03 15:46:26.609934');
INSERT INTO "recording_views" VALUES(2346,3605,'2014-07-03 15:48:52.573101','2014-07-03 15:48:52.573101');
INSERT INTO "recording_views" VALUES(2347,3647,'2014-07-03 15:50:04.804157','2014-07-03 15:50:04.804157');
INSERT INTO "recording_views" VALUES(2358,3629,'2014-07-03 16:18:18.790229','2014-07-03 16:18:18.790229');
INSERT INTO "recording_views" VALUES(2364,3452,'2014-07-03 16:29:52.713314','2014-07-03 16:29:52.713314');
INSERT INTO "recording_views" VALUES(2370,3452,'2014-07-03 16:38:58.625281','2014-07-03 16:38:58.625281');
INSERT INTO "recording_views" VALUES(2374,3548,'2014-07-03 16:45:02.848046','2014-07-03 16:45:02.848046');
INSERT INTO "recording_views" VALUES(2375,3665,'2014-07-03 16:46:54.565083','2014-07-03 16:46:54.565083');
INSERT INTO "recording_views" VALUES(2379,3665,'2014-07-03 16:51:38.207741','2014-07-03 16:51:38.207741');
INSERT INTO "recording_views" VALUES(2380,3599,'2014-07-03 16:57:58.844683','2014-07-03 16:57:58.844683');
INSERT INTO "recording_views" VALUES(2381,3491,'2014-07-03 16:58:33.386019','2014-07-03 16:58:33.386019');
INSERT INTO "recording_views" VALUES(2382,3598,'2014-07-03 17:00:52.04665','2014-07-03 17:00:52.04665');
INSERT INTO "recording_views" VALUES(2383,3452,'2014-07-03 17:08:32.694513','2014-07-03 17:08:32.694513');
INSERT INTO "recording_views" VALUES(2384,3752,'2014-07-03 17:11:41.34324','2014-07-03 17:11:41.34324');
INSERT INTO "recording_views" VALUES(2385,3815,'2014-07-03 17:13:22.81954','2014-07-03 17:13:22.81954');
INSERT INTO "recording_views" VALUES(2386,3623,'2014-07-03 17:16:30.013306','2014-07-03 17:16:30.013306');
INSERT INTO "recording_views" VALUES(2393,3800,'2014-07-03 17:38:22.348254','2014-07-03 17:38:22.348254');
INSERT INTO "recording_views" VALUES(2395,3800,'2014-07-03 17:40:28.954294','2014-07-03 17:40:28.954294');
INSERT INTO "recording_views" VALUES(2396,3497,'2014-07-03 17:45:13.497494','2014-07-03 17:45:13.497494');
INSERT INTO "recording_views" VALUES(2397,3446,'2014-07-03 17:46:29.9735','2014-07-03 17:46:29.9735');
INSERT INTO "recording_views" VALUES(2399,3752,'2014-07-03 17:52:31.934375','2014-07-03 17:52:31.934375');
INSERT INTO "recording_views" VALUES(2400,3559,'2014-07-03 17:52:37.824314','2014-07-03 17:52:37.824314');
INSERT INTO "recording_views" VALUES(2405,3452,'2014-07-03 18:04:26.756252','2014-07-03 18:04:26.756252');
INSERT INTO "recording_views" VALUES(2406,3452,'2014-07-03 18:05:24.340604','2014-07-03 18:05:24.340604');
INSERT INTO "recording_views" VALUES(2412,3662,'2014-07-03 18:44:13.819058','2014-07-03 18:44:13.819058');
INSERT INTO "recording_views" VALUES(2415,3764,'2014-07-03 18:55:35.686427','2014-07-03 18:55:35.686427');
INSERT INTO "recording_views" VALUES(2416,3605,'2014-07-03 18:56:13.723353','2014-07-03 18:56:13.723353');
INSERT INTO "recording_views" VALUES(2417,3764,'2014-07-03 18:59:29.437258','2014-07-03 18:59:29.437258');
INSERT INTO "recording_views" VALUES(2418,3764,'2014-07-03 19:03:53.710458','2014-07-03 19:03:53.710458');
INSERT INTO "recording_views" VALUES(2419,3667,'2014-07-03 19:04:30.201476','2014-07-03 19:04:30.201476');
INSERT INTO "recording_views" VALUES(2420,3667,'2014-07-03 19:09:19.832287','2014-07-03 19:09:19.832287');
INSERT INTO "recording_views" VALUES(2421,3665,'2014-07-03 19:11:11.01627','2014-07-03 19:11:11.01627');
INSERT INTO "recording_views" VALUES(2424,3667,'2014-07-03 19:21:06.293917','2014-07-03 19:21:06.293917');
INSERT INTO "recording_views" VALUES(2425,3605,'2014-07-03 19:21:30.810061','2014-07-03 19:21:30.810061');
INSERT INTO "recording_views" VALUES(2427,3667,'2014-07-03 19:25:12.040913','2014-07-03 19:25:12.040913');
INSERT INTO "recording_views" VALUES(2429,3605,'2014-07-03 19:29:08.362703','2014-07-03 19:29:08.362703');
INSERT INTO "recording_views" VALUES(2430,3667,'2014-07-03 19:32:22.975372','2014-07-03 19:32:22.975372');
INSERT INTO "recording_views" VALUES(2431,3667,'2014-07-03 19:35:05.335101','2014-07-03 19:35:05.335101');
INSERT INTO "recording_views" VALUES(2433,3605,'2014-07-03 19:38:26.885366','2014-07-03 19:38:26.885366');
INSERT INTO "recording_views" VALUES(2434,3667,'2014-07-03 19:42:41.483308','2014-07-03 19:42:41.483308');
INSERT INTO "recording_views" VALUES(2435,3764,'2014-07-03 19:44:12.380178','2014-07-03 19:44:12.380178');
INSERT INTO "recording_views" VALUES(2436,3667,'2014-07-03 19:45:52.203999','2014-07-03 19:45:52.203999');
INSERT INTO "recording_views" VALUES(2441,3665,'2014-07-03 19:51:34.535438','2014-07-03 19:51:34.535438');
INSERT INTO "recording_views" VALUES(2442,3667,'2014-07-03 19:55:17.40521','2014-07-03 19:55:17.40521');
INSERT INTO "recording_views" VALUES(2443,3452,'2014-07-03 20:00:12.788442','2014-07-03 20:00:12.788442');
INSERT INTO "recording_views" VALUES(2444,3658,'2014-07-03 20:01:07.992772','2014-07-03 20:01:07.992772');
INSERT INTO "recording_views" VALUES(2448,3446,'2014-07-03 20:05:13.810411','2014-07-03 20:05:13.810411');
INSERT INTO "recording_views" VALUES(2449,3452,'2014-07-03 20:07:04.178871','2014-07-03 20:07:04.178871');
INSERT INTO "recording_views" VALUES(2450,1290,'2014-07-03 20:09:18.719608','2014-07-03 20:09:18.719608');
INSERT INTO "recording_views" VALUES(2451,3451,'2014-07-03 20:10:12.414763','2014-07-03 20:10:12.414763');
INSERT INTO "recording_views" VALUES(2452,1290,'2014-07-03 20:11:58.267439','2014-07-03 20:11:58.267439');
INSERT INTO "recording_views" VALUES(2457,3785,'2014-07-03 20:26:14.103301','2014-07-03 20:26:14.103301');
INSERT INTO "recording_views" VALUES(2463,3451,'2014-07-03 20:30:34.341848','2014-07-03 20:30:34.341848');
INSERT INTO "recording_views" VALUES(2467,3452,'2014-07-03 20:33:00.731352','2014-07-03 20:33:00.731352');
INSERT INTO "recording_views" VALUES(2470,3452,'2014-07-03 20:38:21.764117','2014-07-03 20:38:21.764117');
INSERT INTO "recording_views" VALUES(2477,3452,'2014-07-03 20:45:31.179234','2014-07-03 20:45:31.179234');
INSERT INTO "recording_views" VALUES(2478,3452,'2014-07-03 20:46:09.902009','2014-07-03 20:46:09.902009');
INSERT INTO "recording_views" VALUES(2482,3647,'2014-07-03 20:53:37.018465','2014-07-03 20:53:37.018465');
INSERT INTO "recording_views" VALUES(2483,3716,'2014-07-03 20:54:02.41549','2014-07-03 20:54:02.41549');
INSERT INTO "recording_views" VALUES(2488,3647,'2014-07-03 20:57:20.342959','2014-07-03 20:57:20.342959');
INSERT INTO "recording_views" VALUES(2489,3452,'2014-07-03 20:57:56.998504','2014-07-03 20:57:56.998504');
INSERT INTO "recording_views" VALUES(2492,3647,'2014-07-03 21:04:56.14086','2014-07-03 21:04:56.14086');
INSERT INTO "recording_views" VALUES(2496,3664,'2014-07-03 21:16:42.121427','2014-07-03 21:16:42.121427');
INSERT INTO "recording_views" VALUES(2499,3626,'2014-07-03 21:19:47.394891','2014-07-03 21:19:47.394891');
INSERT INTO "recording_views" VALUES(2501,3776,'2014-07-03 21:24:20.361463','2014-07-03 21:24:20.361463');
INSERT INTO "recording_views" VALUES(2503,3601,'2014-07-03 21:24:28.737564','2014-07-03 21:24:28.737564');
INSERT INTO "recording_views" VALUES(2506,3776,'2014-07-03 21:31:52.001555','2014-07-03 21:31:52.001555');
INSERT INTO "recording_views" VALUES(2507,3818,'2014-07-03 21:32:11.638444','2014-07-03 21:32:11.638444');
INSERT INTO "recording_views" VALUES(2513,3818,'2014-07-03 21:45:58.615482','2014-07-03 21:45:58.615482');
INSERT INTO "recording_views" VALUES(2514,3452,'2014-07-03 21:46:08.856383','2014-07-03 21:46:08.856383');
INSERT INTO "recording_views" VALUES(2516,3797,'2014-07-03 21:47:44.773873','2014-07-03 21:47:44.773873');
INSERT INTO "recording_views" VALUES(2517,3623,'2014-07-03 21:48:04.554403','2014-07-03 21:48:04.554403');
INSERT INTO "recording_views" VALUES(2521,3452,'2014-07-03 21:53:25.575282','2014-07-03 21:53:25.575282');
INSERT INTO "recording_views" VALUES(2523,3686,'2014-07-03 22:10:37.303904','2014-07-03 22:10:37.303904');
INSERT INTO "recording_views" VALUES(2524,3686,'2014-07-03 22:13:51.856261','2014-07-03 22:13:51.856261');
INSERT INTO "recording_views" VALUES(2525,3451,'2014-07-03 22:17:56.142556','2014-07-03 22:17:56.142556');
INSERT INTO "recording_views" VALUES(2527,3686,'2014-07-03 22:19:20.822877','2014-07-03 22:19:20.822877');
INSERT INTO "recording_views" VALUES(2528,3602,'2014-07-03 22:19:50.505144','2014-07-03 22:19:50.505144');
INSERT INTO "recording_views" VALUES(2529,3494,'2014-07-03 22:19:59.443358','2014-07-03 22:19:59.443358');
INSERT INTO "recording_views" VALUES(2532,3496,'2014-07-03 22:21:18.816416','2014-07-03 22:21:18.816416');
INSERT INTO "recording_views" VALUES(2533,3602,'2014-07-03 22:21:51.899009','2014-07-03 22:21:51.899009');
INSERT INTO "recording_views" VALUES(2534,3689,'2014-07-03 22:25:19.635601','2014-07-03 22:25:19.635601');
INSERT INTO "recording_views" VALUES(2535,3602,'2014-07-03 22:26:19.214458','2014-07-03 22:26:19.214458');
INSERT INTO "recording_views" VALUES(2536,3563,'2014-07-03 22:27:30.325157','2014-07-03 22:27:30.325157');
INSERT INTO "recording_views" VALUES(2537,218,'2014-07-03 22:28:18.899559','2014-07-03 22:28:18.899559');
INSERT INTO "recording_views" VALUES(2538,3602,'2014-07-03 22:29:41.622978','2014-07-03 22:29:41.622978');
INSERT INTO "recording_views" VALUES(2539,3467,'2014-07-03 22:31:50.577907','2014-07-03 22:31:50.577907');
INSERT INTO "recording_views" VALUES(2543,3715,'2014-07-03 22:42:38.099548','2014-07-03 22:42:38.099548');
INSERT INTO "recording_views" VALUES(2544,3473,'2014-07-03 22:49:18.400054','2014-07-03 22:49:18.400054');
INSERT INTO "recording_views" VALUES(2545,3542,'2014-07-03 22:54:19.667262','2014-07-03 22:54:19.667262');
INSERT INTO "recording_views" VALUES(2547,3467,'2014-07-03 22:56:09.916645','2014-07-03 22:56:09.916645');
INSERT INTO "recording_views" VALUES(2548,3542,'2014-07-03 22:56:20.325141','2014-07-03 22:56:20.325141');
INSERT INTO "recording_views" VALUES(2549,3497,'2014-07-03 22:58:08.576014','2014-07-03 22:58:08.576014');
INSERT INTO "recording_views" VALUES(2551,3542,'2014-07-03 23:04:43.726939','2014-07-03 23:04:43.726939');
INSERT INTO "recording_views" VALUES(2553,3601,'2014-07-03 23:05:48.193918','2014-07-03 23:05:48.193918');
INSERT INTO "recording_views" VALUES(2554,3728,'2014-07-03 23:06:48.942181','2014-07-03 23:06:48.942181');
INSERT INTO "recording_views" VALUES(2556,3560,'2014-07-03 23:13:34.06123','2014-07-03 23:13:34.06123');
INSERT INTO "recording_views" VALUES(2558,3542,'2014-07-03 23:22:26.734628','2014-07-03 23:22:26.734628');
INSERT INTO "recording_views" VALUES(2559,3542,'2014-07-03 23:24:28.21477','2014-07-03 23:24:28.21477');
INSERT INTO "recording_views" VALUES(2560,3542,'2014-07-03 23:26:29.497511','2014-07-03 23:26:29.497511');
INSERT INTO "recording_views" VALUES(2561,3728,'2014-07-03 23:31:51.43061','2014-07-03 23:31:51.43061');
INSERT INTO "recording_views" VALUES(2569,3632,'2014-07-04 00:07:12.199475','2014-07-04 00:07:12.199475');
INSERT INTO "recording_views" VALUES(2570,3818,'2014-07-04 01:04:16.36758','2014-07-04 01:04:16.36758');
INSERT INTO "recording_views" VALUES(2571,3512,'2014-07-04 01:16:54.152489','2014-07-04 01:16:54.152489');
INSERT INTO "recording_views" VALUES(2577,3497,'2014-07-04 03:20:09.296014','2014-07-04 03:20:09.296014');
INSERT INTO "recording_views" VALUES(2580,3473,'2014-07-04 03:47:13.011072','2014-07-04 03:47:13.011072');
INSERT INTO "recording_views" VALUES(2581,3473,'2014-07-04 03:49:53.123183','2014-07-04 03:49:53.123183');
INSERT INTO "recording_views" VALUES(2582,3602,'2014-07-04 04:01:54.269822','2014-07-04 04:01:54.269822');
INSERT INTO "recording_views" VALUES(2583,3689,'2014-07-04 04:14:09.698868','2014-07-04 04:14:09.698868');
INSERT INTO "recording_views" VALUES(2584,3716,'2014-07-04 04:17:22.99376','2014-07-04 04:17:22.99376');
INSERT INTO "recording_views" VALUES(2585,3473,'2014-07-04 04:21:56.448624','2014-07-04 04:21:56.448624');
INSERT INTO "recording_views" VALUES(2586,3716,'2014-07-04 04:27:04.451211','2014-07-04 04:27:04.451211');
INSERT INTO "recording_views" VALUES(2587,3559,'2014-07-04 04:41:53.421518','2014-07-04 04:41:53.421518');
INSERT INTO "recording_views" VALUES(2588,3496,'2014-07-04 04:45:35.491216','2014-07-04 04:45:35.491216');
INSERT INTO "recording_views" VALUES(2589,3559,'2014-07-04 04:46:59.632941','2014-07-04 04:46:59.632941');
INSERT INTO "recording_views" VALUES(2590,3452,'2014-07-04 05:14:59.962238','2014-07-04 05:14:59.962238');
INSERT INTO "recording_views" VALUES(2591,3452,'2014-07-04 05:36:52.596803','2014-07-04 05:36:52.596803');
INSERT INTO "recording_views" VALUES(2592,3452,'2014-07-04 05:38:58.459188','2014-07-04 05:38:58.459188');
INSERT INTO "recording_views" VALUES(2593,3452,'2014-07-04 05:44:18.430619','2014-07-04 05:44:18.430619');
INSERT INTO "recording_views" VALUES(2597,3800,'2014-07-04 05:54:15.537112','2014-07-04 05:54:15.537112');
INSERT INTO "recording_views" VALUES(2600,3452,'2014-07-04 06:02:04.349804','2014-07-04 06:02:04.349804');
INSERT INTO "recording_views" VALUES(2607,3497,'2014-07-04 06:24:07.223966','2014-07-04 06:24:07.223966');
INSERT INTO "recording_views" VALUES(2616,3452,'2014-07-04 06:49:32.841201','2014-07-04 06:49:32.841201');
INSERT INTO "recording_views" VALUES(2619,3647,'2014-07-04 07:06:47.815281','2014-07-04 07:06:47.815281');
INSERT INTO "recording_views" VALUES(2620,3544,'2014-07-04 07:07:25.565261','2014-07-04 07:07:25.565261');
INSERT INTO "recording_views" VALUES(2622,3544,'2014-07-04 07:09:40.092877','2014-07-04 07:09:40.092877');
INSERT INTO "recording_views" VALUES(2625,3800,'2014-07-04 07:15:54.945084','2014-07-04 07:15:54.945084');
INSERT INTO "recording_views" VALUES(2626,3544,'2014-07-04 07:16:31.715558','2014-07-04 07:16:31.715558');
INSERT INTO "recording_views" VALUES(2627,3647,'2014-07-04 07:17:57.253079','2014-07-04 07:17:57.253079');
INSERT INTO "recording_views" VALUES(2628,3544,'2014-07-04 07:23:45.810478','2014-07-04 07:23:45.810478');
INSERT INTO "recording_views" VALUES(2629,3452,'2014-07-04 07:28:38.077311','2014-07-04 07:28:38.077311');
INSERT INTO "recording_views" VALUES(2630,3647,'2014-07-04 07:32:58.73224','2014-07-04 07:32:58.73224');
INSERT INTO "recording_views" VALUES(2632,3779,'2014-07-04 07:41:02.436702','2014-07-04 07:41:02.436702');
INSERT INTO "recording_views" VALUES(2633,3779,'2014-07-04 07:43:55.071181','2014-07-04 07:43:55.071181');
INSERT INTO "recording_views" VALUES(2634,3815,'2014-07-04 07:44:17.456306','2014-07-04 07:44:17.456306');
INSERT INTO "recording_views" VALUES(2635,3449,'2014-07-04 07:45:47.495586','2014-07-04 07:45:47.495586');
INSERT INTO "recording_views" VALUES(2636,3818,'2014-07-04 07:47:06.104647','2014-07-04 07:47:06.104647');
INSERT INTO "recording_views" VALUES(2637,3716,'2014-07-04 07:49:52.018492','2014-07-04 07:49:52.018492');
INSERT INTO "recording_views" VALUES(2638,3818,'2014-07-04 07:50:21.696097','2014-07-04 07:50:21.696097');
INSERT INTO "recording_views" VALUES(2639,3797,'2014-07-04 07:52:41.280319','2014-07-04 07:52:41.280319');
INSERT INTO "recording_views" VALUES(2640,3623,'2014-07-04 07:53:03.783402','2014-07-04 07:53:03.783402');
INSERT INTO "recording_views" VALUES(2641,3503,'2014-07-04 07:53:40.199903','2014-07-04 07:53:40.199903');
INSERT INTO "recording_views" VALUES(2644,3647,'2014-07-04 08:00:13.291257','2014-07-04 08:00:13.291257');
INSERT INTO "recording_views" VALUES(2648,3542,'2014-07-04 08:22:58.497898','2014-07-04 08:22:58.497898');
INSERT INTO "recording_views" VALUES(2649,3451,'2014-07-04 08:33:41.965958','2014-07-04 08:33:41.965958');
INSERT INTO "recording_views" VALUES(2650,3452,'2014-07-04 08:42:59.100786','2014-07-04 08:42:59.100786');
INSERT INTO "recording_views" VALUES(2651,3682,'2014-07-04 09:00:49.884226','2014-07-04 09:00:49.884226');
INSERT INTO "recording_views" VALUES(2652,3544,'2014-07-04 09:01:07.111414','2014-07-04 09:01:07.111414');
INSERT INTO "recording_views" VALUES(2653,3514,'2014-07-04 09:02:08.683146','2014-07-04 09:02:08.683146');
INSERT INTO "recording_views" VALUES(2656,3514,'2014-07-04 09:11:32.796171','2014-07-04 09:11:32.796171');
INSERT INTO "recording_views" VALUES(2658,3623,'2014-07-04 09:14:26.723825','2014-07-04 09:14:26.723825');
INSERT INTO "recording_views" VALUES(2659,3605,'2014-07-04 09:16:26.758438','2014-07-04 09:16:26.758438');
INSERT INTO "recording_views" VALUES(2660,3604,'2014-07-04 09:16:37.586739','2014-07-04 09:16:37.586739');
INSERT INTO "recording_views" VALUES(2662,3604,'2014-07-04 09:19:43.823148','2014-07-04 09:19:43.823148');
INSERT INTO "recording_views" VALUES(2664,3604,'2014-07-04 09:22:07.075986','2014-07-04 09:22:07.075986');
INSERT INTO "recording_views" VALUES(2665,3601,'2014-07-04 09:23:15.229164','2014-07-04 09:23:15.229164');
INSERT INTO "recording_views" VALUES(2666,3722,'2014-07-04 09:25:18.602356','2014-07-04 09:25:18.602356');
INSERT INTO "recording_views" VALUES(2667,3452,'2014-07-04 09:26:08.315738','2014-07-04 09:26:08.315738');
INSERT INTO "recording_views" VALUES(2668,3601,'2014-07-04 09:27:07.545287','2014-07-04 09:27:07.545287');
INSERT INTO "recording_views" VALUES(2670,3640,'2014-07-04 09:32:19.798664','2014-07-04 09:32:19.798664');
INSERT INTO "recording_views" VALUES(2671,3601,'2014-07-04 09:34:15.474187','2014-07-04 09:34:15.474187');
INSERT INTO "recording_views" VALUES(2672,3640,'2014-07-04 09:37:36.573938','2014-07-04 09:37:36.573938');
INSERT INTO "recording_views" VALUES(2673,3601,'2014-07-04 09:37:52.716952','2014-07-04 09:37:52.716952');
INSERT INTO "recording_views" VALUES(2676,3514,'2014-07-04 09:41:43.084236','2014-07-04 09:41:43.084236');
INSERT INTO "recording_views" VALUES(2678,3752,'2014-07-04 09:56:58.106911','2014-07-04 09:56:58.106911');
INSERT INTO "recording_views" VALUES(2680,3451,'2014-07-04 09:59:27.544966','2014-07-04 09:59:27.544966');
INSERT INTO "recording_views" VALUES(2684,3604,'2014-07-04 10:37:10.159753','2014-07-04 10:37:10.159753');
INSERT INTO "recording_views" VALUES(2685,3664,'2014-07-04 10:38:53.026714','2014-07-04 10:38:53.026714');
INSERT INTO "recording_views" VALUES(2686,3752,'2014-07-04 10:40:38.337758','2014-07-04 10:40:38.337758');
INSERT INTO "recording_views" VALUES(2687,3452,'2014-07-04 10:43:12.891821','2014-07-04 10:43:12.891821');
INSERT INTO "recording_views" VALUES(2689,3752,'2014-07-04 10:43:58.268617','2014-07-04 10:43:58.268617');
INSERT INTO "recording_views" VALUES(2690,3452,'2014-07-04 10:50:35.639857','2014-07-04 10:50:35.639857');
INSERT INTO "recording_views" VALUES(2691,3623,'2014-07-04 10:52:43.645909','2014-07-04 10:52:43.645909');
INSERT INTO "recording_views" VALUES(2692,3452,'2014-07-04 10:54:34.519551','2014-07-04 10:54:34.519551');
INSERT INTO "recording_views" VALUES(2693,3452,'2014-07-04 10:56:14.006911','2014-07-04 10:56:14.006911');
INSERT INTO "recording_views" VALUES(2694,3452,'2014-07-04 11:01:12.345538','2014-07-04 11:01:12.345538');
INSERT INTO "recording_views" VALUES(2695,3452,'2014-07-04 11:06:09.45151','2014-07-04 11:06:09.45151');
INSERT INTO "recording_views" VALUES(2697,3452,'2014-07-04 11:16:23.196552','2014-07-04 11:16:23.196552');
INSERT INTO "recording_views" VALUES(2698,3632,'2014-07-04 11:22:53.602855','2014-07-04 11:22:53.602855');
INSERT INTO "recording_views" VALUES(2699,3452,'2014-07-04 11:25:13.731864','2014-07-04 11:25:13.731864');
INSERT INTO "recording_views" VALUES(2700,3452,'2014-07-04 11:31:48.111339','2014-07-04 11:31:48.111339');
INSERT INTO "recording_views" VALUES(2701,3662,'2014-07-04 11:33:49.368651','2014-07-04 11:33:49.368651');
INSERT INTO "recording_views" VALUES(2702,3662,'2014-07-04 11:37:08.968102','2014-07-04 11:37:08.968102');
INSERT INTO "recording_views" VALUES(2703,3668,'2014-07-04 11:42:32.83659','2014-07-04 11:42:32.83659');
INSERT INTO "recording_views" VALUES(2704,3500,'2014-07-04 11:42:39.727401','2014-07-04 11:42:39.727401');
INSERT INTO "recording_views" VALUES(2705,3452,'2014-07-04 11:50:37.837089','2014-07-04 11:50:37.837089');
INSERT INTO "recording_views" VALUES(2706,3500,'2014-07-04 11:52:34.084999','2014-07-04 11:52:34.084999');
INSERT INTO "recording_views" VALUES(2707,3725,'2014-07-04 12:06:41.652671','2014-07-04 12:06:41.652671');
INSERT INTO "recording_views" VALUES(2708,3773,'2014-07-04 12:10:29.56459','2014-07-04 12:10:29.56459');
INSERT INTO "recording_views" VALUES(2709,3605,'2014-07-04 12:11:23.548242','2014-07-04 12:11:23.548242');
INSERT INTO "recording_views" VALUES(2710,3818,'2014-07-04 12:11:43.342844','2014-07-04 12:11:43.342844');
INSERT INTO "recording_views" VALUES(2715,3560,'2014-07-04 12:43:36.09788','2014-07-04 12:43:36.09788');
INSERT INTO "recording_views" VALUES(2716,3560,'2014-07-04 12:45:48.538975','2014-07-04 12:45:48.538975');
INSERT INTO "recording_views" VALUES(2724,3560,'2014-07-04 13:17:58.561155','2014-07-04 13:17:58.561155');
INSERT INTO "recording_views" VALUES(2735,3452,'2014-07-04 14:00:45.474345','2014-07-04 14:00:45.474345');
INSERT INTO "recording_views" VALUES(2741,3542,'2014-07-04 14:17:42.811074','2014-07-04 14:17:42.811074');
INSERT INTO "recording_views" VALUES(2745,3689,'2014-07-04 14:21:50.343904','2014-07-04 14:21:50.343904');
INSERT INTO "recording_views" VALUES(2747,3800,'2014-07-04 14:22:19.645905','2014-07-04 14:22:19.645905');
INSERT INTO "recording_views" VALUES(2753,3497,'2014-07-04 14:30:18.276184','2014-07-04 14:30:18.276184');
INSERT INTO "recording_views" VALUES(2755,3497,'2014-07-04 14:36:24.411366','2014-07-04 14:36:24.411366');
INSERT INTO "recording_views" VALUES(2757,3703,'2014-07-04 14:41:11.261604','2014-07-04 14:41:11.261604');
INSERT INTO "recording_views" VALUES(2758,3703,'2014-07-04 14:43:32.311246','2014-07-04 14:43:32.311246');
INSERT INTO "recording_views" VALUES(2762,3446,'2014-07-04 15:01:41.700535','2014-07-04 15:01:41.700535');
INSERT INTO "recording_views" VALUES(2763,3452,'2014-07-04 15:03:02.06489','2014-07-04 15:03:02.06489');
INSERT INTO "recording_views" VALUES(2764,3452,'2014-07-04 15:05:49.397521','2014-07-04 15:05:49.397521');
INSERT INTO "recording_views" VALUES(2765,3515,'2014-07-04 15:07:50.386465','2014-07-04 15:07:50.386465');
INSERT INTO "recording_views" VALUES(2766,3703,'2014-07-04 15:08:19.090175','2014-07-04 15:08:19.090175');
INSERT INTO "recording_views" VALUES(2767,3635,'2014-07-04 15:08:39.50495','2014-07-04 15:08:39.50495');
INSERT INTO "recording_views" VALUES(2768,3800,'2014-07-04 15:09:00.349367','2014-07-04 15:09:00.349367');
INSERT INTO "recording_views" VALUES(2771,3647,'2014-07-04 15:21:05.606073','2014-07-04 15:21:05.606073');
INSERT INTO "recording_views" VALUES(2772,1203,'2014-07-04 15:22:51.802672','2014-07-04 15:22:51.802672');
INSERT INTO "recording_views" VALUES(2773,1203,'2014-07-04 15:24:55.710789','2014-07-04 15:24:55.710789');
INSERT INTO "recording_views" VALUES(2775,3703,'2014-07-04 15:27:35.2758','2014-07-04 15:27:35.2758');
INSERT INTO "recording_views" VALUES(2776,1203,'2014-07-04 15:28:17.164428','2014-07-04 15:28:17.164428');
INSERT INTO "recording_views" VALUES(2777,1203,'2014-07-04 15:30:18.094649','2014-07-04 15:30:18.094649');
INSERT INTO "recording_views" VALUES(2778,3703,'2014-07-04 15:30:19.757605','2014-07-04 15:30:19.757605');
INSERT INTO "recording_views" VALUES(2780,3553,'2014-07-04 15:34:45.478593','2014-07-04 15:34:45.478593');
INSERT INTO "recording_views" VALUES(2781,1244,'2014-07-04 15:35:58.165469','2014-07-04 15:35:58.165469');
INSERT INTO "recording_views" VALUES(2782,1241,'2014-07-04 15:36:55.86209','2014-07-04 15:36:55.86209');
INSERT INTO "recording_views" VALUES(2784,3770,'2014-07-04 15:52:26.545768','2014-07-04 15:52:26.545768');
INSERT INTO "recording_views" VALUES(2790,3497,'2014-07-04 15:59:41.539313','2014-07-04 15:59:41.539313');
INSERT INTO "recording_views" VALUES(2791,3497,'2014-07-04 16:02:01.103635','2014-07-04 16:02:01.103635');
INSERT INTO "recording_views" VALUES(2792,3653,'2014-07-04 16:02:49.864342','2014-07-04 16:02:49.864342');
INSERT INTO "recording_views" VALUES(2793,3515,'2014-07-04 16:04:29.456933','2014-07-04 16:04:29.456933');
INSERT INTO "recording_views" VALUES(2794,3734,'2014-07-04 16:05:42.174486','2014-07-04 16:05:42.174486');
INSERT INTO "recording_views" VALUES(2795,3548,'2014-07-04 16:07:51.515972','2014-07-04 16:07:51.515972');
INSERT INTO "recording_views" VALUES(2796,3452,'2014-07-04 16:15:41.4978','2014-07-04 16:15:41.4978');
INSERT INTO "recording_views" VALUES(2797,3659,'2014-07-04 16:20:12.532358','2014-07-04 16:20:12.532358');
INSERT INTO "recording_views" VALUES(2798,1206,'2014-07-04 16:33:47.107271','2014-07-04 16:33:47.107271');
INSERT INTO "recording_views" VALUES(2800,3659,'2014-07-04 16:55:59.273586','2014-07-04 16:55:59.273586');
INSERT INTO "recording_views" VALUES(2801,3659,'2014-07-04 16:58:57.596184','2014-07-04 16:58:57.596184');
INSERT INTO "recording_views" VALUES(2806,3751,'2014-07-04 17:08:46.631168','2014-07-04 17:08:46.631168');
INSERT INTO "recording_views" VALUES(2807,3656,'2014-07-04 17:19:43.904231','2014-07-04 17:19:43.904231');
INSERT INTO "recording_views" VALUES(2818,3646,'2014-07-04 18:13:54.088267','2014-07-04 18:13:54.088267');
INSERT INTO "recording_views" VALUES(2822,3646,'2014-07-04 18:25:38.608858','2014-07-04 18:25:38.608858');
INSERT INTO "recording_views" VALUES(2823,3452,'2014-07-04 18:26:11.609449','2014-07-04 18:26:11.609449');
INSERT INTO "recording_views" VALUES(2827,3646,'2014-07-04 18:46:29.571795','2014-07-04 18:46:29.571795');
INSERT INTO "recording_views" VALUES(2828,3602,'2014-07-04 18:53:28.419173','2014-07-04 18:53:28.419173');
INSERT INTO "recording_views" VALUES(2829,3562,'2014-07-04 18:59:47.320166','2014-07-04 18:59:47.320166');
INSERT INTO "recording_views" VALUES(2831,3562,'2014-07-04 19:02:32.842238','2014-07-04 19:02:32.842238');
INSERT INTO "recording_views" VALUES(2833,3646,'2014-07-04 19:04:39.169799','2014-07-04 19:04:39.169799');
INSERT INTO "recording_views" VALUES(2834,3806,'2014-07-04 19:05:24.17545','2014-07-04 19:05:24.17545');
INSERT INTO "recording_views" VALUES(2835,3646,'2014-07-04 19:09:46.602029','2014-07-04 19:09:46.602029');
INSERT INTO "recording_views" VALUES(2836,3521,'2014-07-04 19:10:56.165589','2014-07-04 19:10:56.165589');
INSERT INTO "recording_views" VALUES(2837,3446,'2014-07-04 19:20:48.624948','2014-07-04 19:20:48.624948');
INSERT INTO "recording_views" VALUES(2838,3446,'2014-07-04 19:23:09.915812','2014-07-04 19:23:09.915812');
INSERT INTO "recording_views" VALUES(2839,3446,'2014-07-04 19:29:28.55342','2014-07-04 19:29:28.55342');
INSERT INTO "recording_views" VALUES(2840,3446,'2014-07-04 19:32:05.095637','2014-07-04 19:32:05.095637');
INSERT INTO "recording_views" VALUES(2841,3646,'2014-07-04 19:35:11.829436','2014-07-04 19:35:11.829436');
INSERT INTO "recording_views" VALUES(2842,3446,'2014-07-04 19:35:38.908622','2014-07-04 19:35:38.908622');
INSERT INTO "recording_views" VALUES(2843,3475,'2014-07-04 19:36:54.808139','2014-07-04 19:36:54.808139');
INSERT INTO "recording_views" VALUES(2844,3475,'2014-07-04 19:38:59.385776','2014-07-04 19:38:59.385776');
INSERT INTO "recording_views" VALUES(2845,3475,'2014-07-04 19:39:32.557194','2014-07-04 19:39:32.557194');
INSERT INTO "recording_views" VALUES(2846,3475,'2014-07-04 19:41:36.51252','2014-07-04 19:41:36.51252');
INSERT INTO "recording_views" VALUES(2847,3656,'2014-07-04 19:42:41.843755','2014-07-04 19:42:41.843755');
INSERT INTO "recording_views" VALUES(2848,3659,'2014-07-04 19:42:50.345894','2014-07-04 19:42:50.345894');
INSERT INTO "recording_views" VALUES(2849,3430,'2014-07-04 19:43:21.655645','2014-07-04 19:43:21.655645');
INSERT INTO "recording_views" VALUES(2850,3430,'2014-07-04 19:45:22.219984','2014-07-04 19:45:22.219984');
INSERT INTO "recording_views" VALUES(2851,3646,'2014-07-04 19:47:35.93695','2014-07-04 19:47:35.93695');
INSERT INTO "recording_views" VALUES(2852,3452,'2014-07-04 19:48:27.254451','2014-07-04 19:48:27.254451');
INSERT INTO "recording_views" VALUES(2853,3497,'2014-07-04 19:48:44.394238','2014-07-04 19:48:44.394238');
INSERT INTO "recording_views" VALUES(2855,3646,'2014-07-04 19:56:57.938286','2014-07-04 19:56:57.938286');
INSERT INTO "recording_views" VALUES(2856,3430,'2014-07-04 19:59:05.168331','2014-07-04 19:59:05.168331');
INSERT INTO "recording_views" VALUES(2857,3430,'2014-07-04 20:01:05.649735','2014-07-04 20:01:05.649735');
INSERT INTO "recording_views" VALUES(2858,3505,'2014-07-04 20:01:22.651441','2014-07-04 20:01:22.651441');
INSERT INTO "recording_views" VALUES(2859,3646,'2014-07-04 20:01:47.14119','2014-07-04 20:01:47.14119');
INSERT INTO "recording_views" VALUES(2860,3646,'2014-07-04 20:06:59.644967','2014-07-04 20:06:59.644967');
INSERT INTO "recording_views" VALUES(2861,3833,'2014-07-04 20:07:19.473572','2014-07-04 20:07:19.473572');
INSERT INTO "recording_views" VALUES(2864,3722,'2014-07-04 20:09:40.541755','2014-07-04 20:09:40.541755');
INSERT INTO "recording_views" VALUES(2866,3646,'2014-07-04 20:12:50.231084','2014-07-04 20:12:50.231084');
INSERT INTO "recording_views" VALUES(2872,3646,'2014-07-04 20:28:23.247658','2014-07-04 20:28:23.247658');
INSERT INTO "recording_views" VALUES(2875,3430,'2014-07-04 20:35:43.574136','2014-07-04 20:35:43.574136');
INSERT INTO "recording_views" VALUES(2876,3646,'2014-07-04 20:35:59.258473','2014-07-04 20:35:59.258473');
INSERT INTO "recording_views" VALUES(2877,3646,'2014-07-04 20:50:58.508082','2014-07-04 20:50:58.508082');
INSERT INTO "recording_views" VALUES(2878,3430,'2014-07-04 20:51:12.602911','2014-07-04 20:51:12.602911');
INSERT INTO "recording_views" VALUES(2880,3497,'2014-07-04 20:56:41.50858','2014-07-04 20:56:41.50858');
INSERT INTO "recording_views" VALUES(2882,3479,'2014-07-04 20:58:53.134246','2014-07-04 20:58:53.134246');
INSERT INTO "recording_views" VALUES(2888,3452,'2014-07-04 21:04:56.631843','2014-07-04 21:04:56.631843');
INSERT INTO "recording_views" VALUES(2889,3479,'2014-07-04 21:05:09.044719','2014-07-04 21:05:09.044719');
INSERT INTO "recording_views" VALUES(2895,3479,'2014-07-04 21:16:44.512863','2014-07-04 21:16:44.512863');
INSERT INTO "recording_views" VALUES(2897,3497,'2014-07-04 21:19:25.375103','2014-07-04 21:19:25.375103');
INSERT INTO "recording_views" VALUES(2898,3479,'2014-07-04 21:22:07.850509','2014-07-04 21:22:07.850509');
INSERT INTO "recording_views" VALUES(2899,3452,'2014-07-04 21:22:49.01991','2014-07-04 21:22:49.01991');
INSERT INTO "recording_views" VALUES(2903,3496,'2014-07-04 21:29:02.420765','2014-07-04 21:29:02.420765');
INSERT INTO "recording_views" VALUES(2904,3550,'2014-07-04 21:30:05.260824','2014-07-04 21:30:05.260824');
INSERT INTO "recording_views" VALUES(2905,3640,'2014-07-04 21:32:23.292001','2014-07-04 21:32:23.292001');
INSERT INTO "recording_views" VALUES(2906,3479,'2014-07-04 21:36:46.122523','2014-07-04 21:36:46.122523');
INSERT INTO "recording_views" VALUES(2910,3479,'2014-07-04 21:41:31.699999','2014-07-04 21:41:31.699999');
INSERT INTO "recording_views" VALUES(2912,3430,'2014-07-04 21:42:45.893101','2014-07-04 21:42:45.893101');
INSERT INTO "recording_views" VALUES(2913,1224,'2014-07-04 21:44:25.388157','2014-07-04 21:44:25.388157');
INSERT INTO "recording_views" VALUES(2917,3488,'2014-07-04 22:00:12.043511','2014-07-04 22:00:12.043511');
INSERT INTO "recording_views" VALUES(2921,3640,'2014-07-04 22:10:41.562943','2014-07-04 22:10:41.562943');
INSERT INTO "recording_views" VALUES(2924,3497,'2014-07-04 22:27:03.445581','2014-07-04 22:27:03.445581');
INSERT INTO "recording_views" VALUES(2925,3640,'2014-07-04 22:31:51.48613','2014-07-04 22:31:51.48613');
INSERT INTO "recording_views" VALUES(2929,3703,'2014-07-04 22:52:46.378463','2014-07-04 22:52:46.378463');
INSERT INTO "recording_views" VALUES(2932,3740,'2014-07-04 23:18:44.409666','2014-07-04 23:18:44.409666');
INSERT INTO "recording_views" VALUES(2943,3667,'2014-07-04 23:57:24.106862','2014-07-04 23:57:24.106862');
INSERT INTO "recording_views" VALUES(2948,3986,'2014-07-05 00:34:29.413052','2014-07-05 00:34:29.413052');
INSERT INTO "recording_views" VALUES(2959,3773,'2014-07-05 03:23:57.575252','2014-07-05 03:23:57.575252');
INSERT INTO "recording_views" VALUES(2962,3497,'2014-07-05 05:13:38.948599','2014-07-05 05:13:38.948599');
INSERT INTO "recording_views" VALUES(2963,3497,'2014-07-05 05:24:01.66794','2014-07-05 05:24:01.66794');
INSERT INTO "recording_views" VALUES(2965,3497,'2014-07-05 05:56:16.662649','2014-07-05 05:56:16.662649');
INSERT INTO "recording_views" VALUES(2975,3773,'2014-07-05 07:31:42.952533','2014-07-05 07:31:42.952533');
INSERT INTO "recording_views" VALUES(2976,3767,'2014-07-05 07:35:19.130428','2014-07-05 07:35:19.130428');
INSERT INTO "recording_views" VALUES(2977,3767,'2014-07-05 07:46:13.923113','2014-07-05 07:46:13.923113');
INSERT INTO "recording_views" VALUES(2978,3452,'2014-07-05 07:55:26.94979','2014-07-05 07:55:26.94979');
INSERT INTO "recording_views" VALUES(2979,3452,'2014-07-05 08:01:59.517565','2014-07-05 08:01:59.517565');
INSERT INTO "recording_views" VALUES(2980,3800,'2014-07-05 08:03:22.176601','2014-07-05 08:03:22.176601');
INSERT INTO "recording_views" VALUES(2981,3800,'2014-07-05 08:05:42.709645','2014-07-05 08:05:42.709645');
INSERT INTO "recording_views" VALUES(2983,3452,'2014-07-05 08:37:41.15609','2014-07-05 08:37:41.15609');
INSERT INTO "recording_views" VALUES(2984,3751,'2014-07-05 08:39:41.202345','2014-07-05 08:39:41.202345');
INSERT INTO "recording_views" VALUES(2992,3560,'2014-07-05 09:26:27.676946','2014-07-05 09:26:27.676946');
INSERT INTO "recording_views" VALUES(3006,3782,'2014-07-05 09:59:53.429358','2014-07-05 09:59:53.429358');
INSERT INTO "recording_views" VALUES(3014,3782,'2014-07-05 10:28:30.217011','2014-07-05 10:28:30.217011');
INSERT INTO "recording_views" VALUES(3015,3452,'2014-07-05 10:35:12.571378','2014-07-05 10:35:12.571378');
INSERT INTO "recording_views" VALUES(3018,3689,'2014-07-05 11:12:17.597558','2014-07-05 11:12:17.597558');
INSERT INTO "recording_views" VALUES(3019,3496,'2014-07-05 11:22:02.259485','2014-07-05 11:22:02.259485');
INSERT INTO "recording_views" VALUES(3020,3601,'2014-07-05 11:22:15.04571','2014-07-05 11:22:15.04571');
INSERT INTO "recording_views" VALUES(3022,3751,'2014-07-05 11:48:35.458962','2014-07-05 11:48:35.458962');
INSERT INTO "recording_views" VALUES(3023,3751,'2014-07-05 11:58:45.496244','2014-07-05 11:58:45.496244');
INSERT INTO "recording_views" VALUES(3028,3475,'2014-07-05 12:12:27.750204','2014-07-05 12:12:27.750204');
INSERT INTO "recording_views" VALUES(3030,3560,'2014-07-05 12:14:03.647135','2014-07-05 12:14:03.647135');
INSERT INTO "recording_views" VALUES(3034,3509,'2014-07-05 12:16:35.151412','2014-07-05 12:16:35.151412');
INSERT INTO "recording_views" VALUES(3039,3475,'2014-07-05 12:20:08.701338','2014-07-05 12:20:08.701338');
INSERT INTO "recording_views" VALUES(3045,3647,'2014-07-05 12:23:56.339746','2014-07-05 12:23:56.339746');
INSERT INTO "recording_views" VALUES(3047,3751,'2014-07-05 12:32:19.363932','2014-07-05 12:32:19.363932');
INSERT INTO "recording_views" VALUES(3048,3659,'2014-07-05 12:32:47.163955','2014-07-05 12:32:47.163955');
INSERT INTO "recording_views" VALUES(3050,3475,'2014-07-05 12:34:18.137365','2014-07-05 12:34:18.137365');
INSERT INTO "recording_views" VALUES(3051,3647,'2014-07-05 12:34:45.567304','2014-07-05 12:34:45.567304');
INSERT INTO "recording_views" VALUES(3052,3475,'2014-07-05 12:37:14.179082','2014-07-05 12:37:14.179082');
INSERT INTO "recording_views" VALUES(3053,3475,'2014-07-05 12:39:56.259661','2014-07-05 12:39:56.259661');
INSERT INTO "recording_views" VALUES(3057,3475,'2014-07-05 12:48:25.131373','2014-07-05 12:48:25.131373');
INSERT INTO "recording_views" VALUES(3058,3698,'2014-07-05 12:49:47.217581','2014-07-05 12:49:47.217581');
INSERT INTO "recording_views" VALUES(3059,3452,'2014-07-05 12:51:47.315086','2014-07-05 12:51:47.315086');
INSERT INTO "recording_views" VALUES(3060,3751,'2014-07-05 12:51:59.221982','2014-07-05 12:51:59.221982');
INSERT INTO "recording_views" VALUES(3062,3751,'2014-07-05 12:56:12.640296','2014-07-05 12:56:12.640296');
INSERT INTO "recording_views" VALUES(3067,3751,'2014-07-05 13:01:46.947106','2014-07-05 13:01:46.947106');
INSERT INTO "recording_views" VALUES(3073,3773,'2014-07-05 13:21:49.109599','2014-07-05 13:21:49.109599');
INSERT INTO "recording_views" VALUES(3076,3446,'2014-07-05 13:23:51.322951','2014-07-05 13:23:51.322951');
INSERT INTO "recording_views" VALUES(3085,3773,'2014-07-05 13:44:06.800682','2014-07-05 13:44:06.800682');
INSERT INTO "recording_views" VALUES(3089,3497,'2014-07-05 13:48:05.397942','2014-07-05 13:48:05.397942');
INSERT INTO "recording_views" VALUES(3101,3659,'2014-07-05 13:59:06.437711','2014-07-05 13:59:06.437711');
INSERT INTO "recording_views" VALUES(3106,3497,'2014-07-05 14:02:40.94035','2014-07-05 14:02:40.94035');
INSERT INTO "recording_views" VALUES(3109,94,'2014-07-05 14:09:02.405964','2014-07-05 14:09:02.405964');
INSERT INTO "recording_views" VALUES(3114,3596,'2014-07-05 14:16:47.663687','2014-07-05 14:16:47.663687');
INSERT INTO "recording_views" VALUES(3115,3506,'2014-07-05 14:18:03.318534','2014-07-05 14:18:03.318534');
INSERT INTO "recording_views" VALUES(3117,3767,'2014-07-05 14:20:11.079983','2014-07-05 14:20:11.079983');
INSERT INTO "recording_views" VALUES(3119,3596,'2014-07-05 14:21:07.551415','2014-07-05 14:21:07.551415');
INSERT INTO "recording_views" VALUES(3122,3596,'2014-07-05 14:25:15.19868','2014-07-05 14:25:15.19868');
INSERT INTO "recording_views" VALUES(3125,3767,'2014-07-05 14:28:23.516545','2014-07-05 14:28:23.516545');
INSERT INTO "recording_views" VALUES(3126,3596,'2014-07-05 14:28:49.215553','2014-07-05 14:28:49.215553');
INSERT INTO "recording_views" VALUES(3142,3446,'2014-07-05 14:47:44.843428','2014-07-05 14:47:44.843428');
INSERT INTO "recording_views" VALUES(3144,3815,'2014-07-05 14:50:21.947661','2014-07-05 14:50:21.947661');
INSERT INTO "recording_views" VALUES(3145,3581,'2014-07-05 14:51:44.470353','2014-07-05 14:51:44.470353');
INSERT INTO "recording_views" VALUES(3146,3596,'2014-07-05 14:53:14.816822','2014-07-05 14:53:14.816822');
INSERT INTO "recording_views" VALUES(3148,3703,'2014-07-05 14:55:52.044326','2014-07-05 14:55:52.044326');
INSERT INTO "recording_views" VALUES(3149,3581,'2014-07-05 14:56:32.257693','2014-07-05 14:56:32.257693');
INSERT INTO "recording_views" VALUES(3150,3734,'2014-07-05 14:59:31.274842','2014-07-05 14:59:31.274842');
INSERT INTO "recording_views" VALUES(3151,3497,'2014-07-05 14:59:52.251503','2014-07-05 14:59:52.251503');
INSERT INTO "recording_views" VALUES(3152,3629,'2014-07-05 14:59:54.774051','2014-07-05 14:59:54.774051');
INSERT INTO "recording_views" VALUES(3153,3515,'2014-07-05 15:00:33.791709','2014-07-05 15:00:33.791709');
INSERT INTO "recording_views" VALUES(3154,3689,'2014-07-05 15:00:55.038701','2014-07-05 15:00:55.038701');
INSERT INTO "recording_views" VALUES(3155,3779,'2014-07-05 15:01:24.274467','2014-07-05 15:01:24.274467');
INSERT INTO "recording_views" VALUES(3156,3752,'2014-07-05 15:01:47.03518','2014-07-05 15:01:47.03518');
INSERT INTO "recording_views" VALUES(3157,3548,'2014-07-05 15:02:10.917296','2014-07-05 15:02:10.917296');
INSERT INTO "recording_views" VALUES(3158,3551,'2014-07-05 15:02:28.091','2014-07-05 15:02:28.091');
INSERT INTO "recording_views" VALUES(3159,3497,'2014-07-05 15:02:45.777813','2014-07-05 15:02:45.777813');
INSERT INTO "recording_views" VALUES(3160,3665,'2014-07-05 15:03:06.467053','2014-07-05 15:03:06.467053');
INSERT INTO "recording_views" VALUES(3161,3449,'2014-07-05 15:03:19.518276','2014-07-05 15:03:19.518276');
INSERT INTO "recording_views" VALUES(3162,3563,'2014-07-05 15:03:31.040876','2014-07-05 15:03:31.040876');
INSERT INTO "recording_views" VALUES(3163,3703,'2014-07-05 15:03:43.952957','2014-07-05 15:03:43.952957');
INSERT INTO "recording_views" VALUES(3164,3509,'2014-07-05 15:03:59.256521','2014-07-05 15:03:59.256521');
INSERT INTO "recording_views" VALUES(3166,3800,'2014-07-05 15:04:20.090977','2014-07-05 15:04:20.090977');
INSERT INTO "recording_views" VALUES(3167,3617,'2014-07-05 15:04:34.052023','2014-07-05 15:04:34.052023');
INSERT INTO "recording_views" VALUES(3168,3667,'2014-07-05 15:04:54.18485','2014-07-05 15:04:54.18485');
INSERT INTO "recording_views" VALUES(3169,3599,'2014-07-05 15:05:07.624329','2014-07-05 15:05:07.624329');
INSERT INTO "recording_views" VALUES(3170,3818,'2014-07-05 15:05:23.386728','2014-07-05 15:05:23.386728');
INSERT INTO "recording_views" VALUES(3171,3749,'2014-07-05 15:05:44.043315','2014-07-05 15:05:44.043315');
INSERT INTO "recording_views" VALUES(3172,3475,'2014-07-05 15:06:00.301782','2014-07-05 15:06:00.301782');
INSERT INTO "recording_views" VALUES(3173,3794,'2014-07-05 15:06:19.056578','2014-07-05 15:06:19.056578');
INSERT INTO "recording_views" VALUES(3174,3452,'2014-07-05 15:06:42.747457','2014-07-05 15:06:42.747457');
INSERT INTO "recording_views" VALUES(3175,3470,'2014-07-05 15:07:07.063367','2014-07-05 15:07:07.063367');
INSERT INTO "recording_views" VALUES(3176,3623,'2014-07-05 15:07:47.164973','2014-07-05 15:07:47.164973');
INSERT INTO "recording_views" VALUES(3177,3770,'2014-07-05 15:08:03.151817','2014-07-05 15:08:03.151817');
INSERT INTO "recording_views" VALUES(3178,3662,'2014-07-05 15:08:20.249588','2014-07-05 15:08:20.249588');
INSERT INTO "recording_views" VALUES(3179,3821,'2014-07-05 15:08:41.735699','2014-07-05 15:08:41.735699');
INSERT INTO "recording_views" VALUES(3180,3572,'2014-07-05 15:09:19.412703','2014-07-05 15:09:19.412703');
INSERT INTO "recording_views" VALUES(3182,3635,'2014-07-05 15:09:40.330813','2014-07-05 15:09:40.330813');
INSERT INTO "recording_views" VALUES(3183,3602,'2014-07-05 15:10:05.401454','2014-07-05 15:10:05.401454');
INSERT INTO "recording_views" VALUES(3184,3512,'2014-07-05 15:10:36.396895','2014-07-05 15:10:36.396895');
INSERT INTO "recording_views" VALUES(3185,3611,'2014-07-05 15:10:49.125272','2014-07-05 15:10:49.125272');
INSERT INTO "recording_views" VALUES(3186,3728,'2014-07-05 15:11:19.98599','2014-07-05 15:11:19.98599');
INSERT INTO "recording_views" VALUES(3187,3545,'2014-07-05 15:11:46.448559','2014-07-05 15:11:46.448559');
INSERT INTO "recording_views" VALUES(3188,3671,'2014-07-05 15:12:31.002783','2014-07-05 15:12:31.002783');
INSERT INTO "recording_views" VALUES(3193,3767,'2014-07-05 15:18:08.494697','2014-07-05 15:18:08.494697');
INSERT INTO "recording_views" VALUES(3198,3767,'2014-07-05 15:21:21.82259','2014-07-05 15:21:21.82259');
INSERT INTO "recording_views" VALUES(3221,3767,'2014-07-05 15:33:28.549876','2014-07-05 15:33:28.549876');
INSERT INTO "recording_views" VALUES(3229,3506,'2014-07-05 15:44:32.223707','2014-07-05 15:44:32.223707');
INSERT INTO "recording_views" VALUES(3231,3767,'2014-07-05 15:46:07.814059','2014-07-05 15:46:07.814059');
INSERT INTO "recording_views" VALUES(3234,3496,'2014-07-05 15:54:43.611374','2014-07-05 15:54:43.611374');
INSERT INTO "recording_views" VALUES(3240,3767,'2014-07-05 15:57:18.901461','2014-07-05 15:57:18.901461');
INSERT INTO "recording_views" VALUES(3241,3767,'2014-07-05 16:08:23.703494','2014-07-05 16:08:23.703494');
INSERT INTO "recording_views" VALUES(3242,3659,'2014-07-05 16:08:40.436663','2014-07-05 16:08:40.436663');
INSERT INTO "recording_views" VALUES(3244,3560,'2014-07-05 16:15:48.353007','2014-07-05 16:15:48.353007');
INSERT INTO "recording_views" VALUES(3245,3560,'2014-07-05 16:18:26.515009','2014-07-05 16:18:26.515009');
INSERT INTO "recording_views" VALUES(3246,3818,'2014-07-05 16:18:51.504289','2014-07-05 16:18:51.504289');
INSERT INTO "recording_views" VALUES(3247,3446,'2014-07-05 16:21:01.436475','2014-07-05 16:21:01.436475');
INSERT INTO "recording_views" VALUES(3249,3560,'2014-07-05 16:22:21.901376','2014-07-05 16:22:21.901376');
INSERT INTO "recording_views" VALUES(3250,3800,'2014-07-05 16:22:28.615297','2014-07-05 16:22:28.615297');
INSERT INTO "recording_views" VALUES(3251,3659,'2014-07-05 16:23:24.391637','2014-07-05 16:23:24.391637');
INSERT INTO "recording_views" VALUES(3252,3560,'2014-07-05 16:32:00.270488','2014-07-05 16:32:00.270488');
INSERT INTO "recording_views" VALUES(3253,3800,'2014-07-05 16:37:05.443962','2014-07-05 16:37:05.443962');
INSERT INTO "recording_views" VALUES(3254,3659,'2014-07-05 16:39:08.221008','2014-07-05 16:39:08.221008');
INSERT INTO "recording_views" VALUES(3255,3659,'2014-07-05 16:41:26.096262','2014-07-05 16:41:26.096262');
INSERT INTO "recording_views" VALUES(3256,3560,'2014-07-05 16:41:47.921185','2014-07-05 16:41:47.921185');
INSERT INTO "recording_views" VALUES(3257,3505,'2014-07-05 16:41:52.590448','2014-07-05 16:41:52.590448');
INSERT INTO "recording_views" VALUES(3258,3500,'2014-07-05 16:42:03.833386','2014-07-05 16:42:03.833386');
INSERT INTO "recording_views" VALUES(3261,3494,'2014-07-05 16:42:58.186337','2014-07-05 16:42:58.186337');
INSERT INTO "recording_views" VALUES(3262,3721,'2014-07-05 16:44:34.771','2014-07-05 16:44:34.771');
INSERT INTO "recording_views" VALUES(3263,3560,'2014-07-05 16:44:45.951248','2014-07-05 16:44:45.951248');
INSERT INTO "recording_views" VALUES(3265,3800,'2014-07-05 16:47:05.783071','2014-07-05 16:47:05.783071');
INSERT INTO "recording_views" VALUES(3266,3614,'2014-07-05 16:47:47.516487','2014-07-05 16:47:47.516487');
INSERT INTO "recording_views" VALUES(3269,3560,'2014-07-05 16:53:31.992777','2014-07-05 16:53:31.992777');
INSERT INTO "recording_views" VALUES(3277,3506,'2014-07-05 17:06:02.381906','2014-07-05 17:06:02.381906');
INSERT INTO "recording_views" VALUES(3288,78,'2014-07-05 17:25:56.119192','2014-07-05 17:25:56.119192');
INSERT INTO "recording_views" VALUES(3291,3506,'2014-07-05 17:28:19.959662','2014-07-05 17:28:19.959662');
INSERT INTO "recording_views" VALUES(3292,3743,'2014-07-05 17:29:43.844877','2014-07-05 17:29:43.844877');
INSERT INTO "recording_views" VALUES(3295,3506,'2014-07-05 17:37:00.659702','2014-07-05 17:37:00.659702');
INSERT INTO "recording_views" VALUES(3296,3475,'2014-07-05 17:37:12.850424','2014-07-05 17:37:12.850424');
INSERT INTO "recording_views" VALUES(3298,3743,'2014-07-05 17:39:15.028486','2014-07-05 17:39:15.028486');
INSERT INTO "recording_views" VALUES(3300,3506,'2014-07-05 17:42:50.458261','2014-07-05 17:42:50.458261');
INSERT INTO "recording_views" VALUES(3301,3605,'2014-07-05 17:43:57.82426','2014-07-05 17:43:57.82426');
INSERT INTO "recording_views" VALUES(3302,3506,'2014-07-05 17:48:50.875182','2014-07-05 17:48:50.875182');
INSERT INTO "recording_views" VALUES(3304,3815,'2014-07-05 17:51:43.924925','2014-07-05 17:51:43.924925');
INSERT INTO "recording_views" VALUES(3305,3434,'2014-07-05 17:51:49.408699','2014-07-05 17:51:49.408699');
INSERT INTO "recording_views" VALUES(3308,3668,'2014-07-05 17:58:29.491591','2014-07-05 17:58:29.491591');
INSERT INTO "recording_views" VALUES(3310,3505,'2014-07-05 18:00:32.257337','2014-07-05 18:00:32.257337');
INSERT INTO "recording_views" VALUES(3311,3452,'2014-07-05 18:07:11.055837','2014-07-05 18:07:11.055837');
INSERT INTO "recording_views" VALUES(3314,3605,'2014-07-05 18:14:00.391416','2014-07-05 18:14:00.391416');
INSERT INTO "recording_views" VALUES(3315,3743,'2014-07-05 18:15:15.187597','2014-07-05 18:15:15.187597');
INSERT INTO "recording_views" VALUES(3316,3605,'2014-07-05 18:18:51.659169','2014-07-05 18:18:51.659169');
INSERT INTO "recording_views" VALUES(3317,3434,'2014-07-05 18:20:31.578277','2014-07-05 18:20:31.578277');
INSERT INTO "recording_views" VALUES(3318,3808,'2014-07-05 18:21:11.480689','2014-07-05 18:21:11.480689');
INSERT INTO "recording_views" VALUES(3321,3770,'2014-07-05 18:27:34.556222','2014-07-05 18:27:34.556222');
INSERT INTO "recording_views" VALUES(3323,3605,'2014-07-05 18:32:09.182933','2014-07-05 18:32:09.182933');
INSERT INTO "recording_views" VALUES(3325,1314,'2014-07-05 18:38:16.223685','2014-07-05 18:38:16.223685');
INSERT INTO "recording_views" VALUES(3326,3605,'2014-07-05 18:40:29.586861','2014-07-05 18:40:29.586861');
INSERT INTO "recording_views" VALUES(3327,3434,'2014-07-05 18:42:01.379032','2014-07-05 18:42:01.379032');
INSERT INTO "recording_views" VALUES(3328,3808,'2014-07-05 18:43:48.697652','2014-07-05 18:43:48.697652');
INSERT INTO "recording_views" VALUES(3329,1314,'2014-07-05 18:45:20.519032','2014-07-05 18:45:20.519032');
INSERT INTO "recording_views" VALUES(3330,3808,'2014-07-05 18:46:40.806479','2014-07-05 18:46:40.806479');
INSERT INTO "recording_views" VALUES(3331,1314,'2014-07-05 18:47:43.268848','2014-07-05 18:47:43.268848');
INSERT INTO "recording_views" VALUES(3332,3808,'2014-07-05 18:49:17.083359','2014-07-05 18:49:17.083359');
INSERT INTO "recording_views" VALUES(3333,1314,'2014-07-05 18:50:38.75994','2014-07-05 18:50:38.75994');
INSERT INTO "recording_views" VALUES(3334,3562,'2014-07-05 18:51:53.022981','2014-07-05 18:51:53.022981');
INSERT INTO "recording_views" VALUES(3335,1314,'2014-07-05 18:52:58.909328','2014-07-05 18:52:58.909328');
INSERT INTO "recording_views" VALUES(3336,3808,'2014-07-05 18:53:01.119956','2014-07-05 18:53:01.119956');
INSERT INTO "recording_views" VALUES(3337,3808,'2014-07-05 18:55:28.813797','2014-07-05 18:55:28.813797');
INSERT INTO "recording_views" VALUES(3340,3808,'2014-07-05 18:57:34.08514','2014-07-05 18:57:34.08514');
INSERT INTO "recording_views" VALUES(3341,3751,'2014-07-05 18:59:02.701251','2014-07-05 18:59:02.701251');
INSERT INTO "recording_views" VALUES(3347,3779,'2014-07-05 19:04:07.523383','2014-07-05 19:04:07.523383');
INSERT INTO "recording_views" VALUES(3351,3779,'2014-07-05 19:06:07.842526','2014-07-05 19:06:07.842526');
INSERT INTO "recording_views" VALUES(3354,3632,'2014-07-05 19:09:03.611255','2014-07-05 19:09:03.611255');
INSERT INTO "recording_views" VALUES(3355,3806,'2014-07-05 19:15:20.277922','2014-07-05 19:15:20.277922');
INSERT INTO "recording_views" VALUES(3365,3716,'2014-07-05 19:31:20.634191','2014-07-05 19:31:20.634191');
INSERT INTO "recording_views" VALUES(3367,3806,'2014-07-05 19:31:31.771774','2014-07-05 19:31:31.771774');
INSERT INTO "recording_views" VALUES(3368,3752,'2014-07-05 19:31:32.831184','2014-07-05 19:31:32.831184');
INSERT INTO "recording_views" VALUES(3384,3650,'2014-07-05 19:54:05.976511','2014-07-05 19:54:05.976511');
INSERT INTO "recording_views" VALUES(3385,3650,'2014-07-05 19:56:09.188573','2014-07-05 19:56:09.188573');
INSERT INTO "recording_views" VALUES(3392,3650,'2014-07-05 20:12:30.687149','2014-07-05 20:12:30.687149');
INSERT INTO "recording_views" VALUES(3396,3452,'2014-07-05 20:13:52.880521','2014-07-05 20:13:52.880521');
INSERT INTO "recording_views" VALUES(3402,3452,'2014-07-05 20:16:05.441398','2014-07-05 20:16:05.441398');
INSERT INTO "recording_views" VALUES(3404,3800,'2014-07-05 20:16:59.588731','2014-07-05 20:16:59.588731');
INSERT INTO "recording_views" VALUES(3405,3524,'2014-07-05 20:17:13.473494','2014-07-05 20:17:13.473494');
INSERT INTO "recording_views" VALUES(3407,3497,'2014-07-05 20:17:50.319532','2014-07-05 20:17:50.319532');
INSERT INTO "recording_views" VALUES(3411,1257,'2014-07-05 20:24:42.272796','2014-07-05 20:24:42.272796');
INSERT INTO "recording_views" VALUES(3412,1275,'2014-07-05 20:25:11.006538','2014-07-05 20:25:11.006538');
INSERT INTO "recording_views" VALUES(3413,3772,'2014-07-05 20:27:22.125117','2014-07-05 20:27:22.125117');
INSERT INTO "recording_views" VALUES(3417,3772,'2014-07-05 20:30:07.822403','2014-07-05 20:30:07.822403');
INSERT INTO "recording_views" VALUES(3420,3772,'2014-07-05 20:32:37.462527','2014-07-05 20:32:37.462527');
INSERT INTO "recording_views" VALUES(3422,3772,'2014-07-05 20:34:37.84916','2014-07-05 20:34:37.84916');
INSERT INTO "recording_views" VALUES(3423,3772,'2014-07-05 20:37:03.938372','2014-07-05 20:37:03.938372');
INSERT INTO "recording_views" VALUES(3425,3560,'2014-07-05 20:40:15.569988','2014-07-05 20:40:15.569988');
INSERT INTO "recording_views" VALUES(3427,3662,'2014-07-05 20:43:57.43174','2014-07-05 20:43:57.43174');
INSERT INTO "recording_views" VALUES(3432,1221,'2014-07-05 20:58:18.825006','2014-07-05 20:58:18.825006');
INSERT INTO "recording_views" VALUES(3433,1323,'2014-07-05 21:00:13.243351','2014-07-05 21:00:13.243351');
INSERT INTO "recording_views" VALUES(3434,1230,'2014-07-05 21:00:43.163601','2014-07-05 21:00:43.163601');
INSERT INTO "recording_views" VALUES(3436,1329,'2014-07-05 21:02:58.559404','2014-07-05 21:02:58.559404');
INSERT INTO "recording_views" VALUES(3438,3683,'2014-07-05 21:04:18.133389','2014-07-05 21:04:18.133389');
INSERT INTO "recording_views" VALUES(3442,3683,'2014-07-05 21:18:05.744804','2014-07-05 21:18:05.744804');
INSERT INTO "recording_views" VALUES(3445,3464,'2014-07-05 21:19:27.947053','2014-07-05 21:19:27.947053');
INSERT INTO "recording_views" VALUES(3447,3464,'2014-07-05 21:22:57.513474','2014-07-05 21:22:57.513474');
INSERT INTO "recording_views" VALUES(3448,3497,'2014-07-05 21:25:35.673588','2014-07-05 21:25:35.673588');
INSERT INTO "recording_views" VALUES(3450,3464,'2014-07-05 21:27:10.313818','2014-07-05 21:27:10.313818');
INSERT INTO "recording_views" VALUES(3455,3650,'2014-07-05 21:29:42.9','2014-07-05 21:29:42.9');
INSERT INTO "recording_views" VALUES(3456,3683,'2014-07-05 21:29:53.249408','2014-07-05 21:29:53.249408');
INSERT INTO "recording_views" VALUES(3457,3758,'2014-07-05 21:30:22.798655','2014-07-05 21:30:22.798655');
INSERT INTO "recording_views" VALUES(3458,3758,'2014-07-05 21:33:04.349335','2014-07-05 21:33:04.349335');
INSERT INTO "recording_views" VALUES(3459,3650,'2014-07-05 21:33:14.766254','2014-07-05 21:33:14.766254');
INSERT INTO "recording_views" VALUES(3460,171,'2014-07-05 21:34:38.100546','2014-07-05 21:34:38.100546');
INSERT INTO "recording_views" VALUES(3461,3521,'2014-07-05 21:35:23.093183','2014-07-05 21:35:23.093183');
INSERT INTO "recording_views" VALUES(3463,3521,'2014-07-05 21:37:51.193066','2014-07-05 21:37:51.193066');
INSERT INTO "recording_views" VALUES(3465,3725,'2014-07-05 21:38:49.985852','2014-07-05 21:38:49.985852');
INSERT INTO "recording_views" VALUES(3468,3725,'2014-07-05 21:41:00.071492','2014-07-05 21:41:00.071492');
INSERT INTO "recording_views" VALUES(3470,3725,'2014-07-05 21:43:10.511178','2014-07-05 21:43:10.511178');
INSERT INTO "recording_views" VALUES(3473,3569,'2014-07-05 21:45:06.615746','2014-07-05 21:45:06.615746');
INSERT INTO "recording_views" VALUES(3474,3496,'2014-07-05 21:45:20.681632','2014-07-05 21:45:20.681632');
INSERT INTO "recording_views" VALUES(3479,3569,'2014-07-05 21:50:35.931668','2014-07-05 21:50:35.931668');
INSERT INTO "recording_views" VALUES(3481,3569,'2014-07-05 21:58:37.362399','2014-07-05 21:58:37.362399');
INSERT INTO "recording_views" VALUES(3482,3569,'2014-07-05 22:01:08.696431','2014-07-05 22:01:08.696431');
INSERT INTO "recording_views" VALUES(3483,3569,'2014-07-05 22:05:45.191368','2014-07-05 22:05:45.191368');
INSERT INTO "recording_views" VALUES(3484,3569,'2014-07-05 22:07:46.849706','2014-07-05 22:07:46.849706');
INSERT INTO "recording_views" VALUES(3485,3569,'2014-07-05 22:10:33.539009','2014-07-05 22:10:33.539009');
INSERT INTO "recording_views" VALUES(3486,3569,'2014-07-05 22:13:21.543849','2014-07-05 22:13:21.543849');
INSERT INTO "recording_views" VALUES(3487,3758,'2014-07-05 22:16:20.537166','2014-07-05 22:16:20.537166');
INSERT INTO "recording_views" VALUES(3489,3740,'2014-07-05 22:28:20.971992','2014-07-05 22:28:20.971992');
INSERT INTO "recording_views" VALUES(3490,3452,'2014-07-05 22:29:40.300288','2014-07-05 22:29:40.300288');
INSERT INTO "recording_views" VALUES(3493,3740,'2014-07-05 22:33:09.157658','2014-07-05 22:33:09.157658');
INSERT INTO "recording_views" VALUES(3495,3776,'2014-07-05 22:44:09.597196','2014-07-05 22:44:09.597196');
INSERT INTO "recording_views" VALUES(3501,3497,'2014-07-05 22:54:49.817907','2014-07-05 22:54:49.817907');
INSERT INTO "recording_views" VALUES(3502,3497,'2014-07-05 22:58:17.365658','2014-07-05 22:58:17.365658');
INSERT INTO "recording_views" VALUES(3503,3497,'2014-07-05 23:00:22.713949','2014-07-05 23:00:22.713949');
INSERT INTO "recording_views" VALUES(3506,3560,'2014-07-05 23:19:17.562231','2014-07-05 23:19:17.562231');
INSERT INTO "recording_views" VALUES(3507,3743,'2014-07-05 23:23:46.021436','2014-07-05 23:23:46.021436');
INSERT INTO "recording_views" VALUES(3515,3653,'2014-07-06 00:07:29.327565','2014-07-06 00:07:29.327565');
INSERT INTO "recording_views" VALUES(3516,3512,'2014-07-06 00:10:30.380019','2014-07-06 00:10:30.380019');
INSERT INTO "recording_views" VALUES(3517,3512,'2014-07-06 00:18:43.9029','2014-07-06 00:18:43.9029');
INSERT INTO "recording_views" VALUES(3518,3497,'2014-07-06 00:41:51.740804','2014-07-06 00:41:51.740804');
INSERT INTO "recording_views" VALUES(3521,3739,'2014-07-06 02:07:44.923903','2014-07-06 02:07:44.923903');
INSERT INTO "recording_views" VALUES(3522,3595,'2014-07-06 02:09:19.860015','2014-07-06 02:09:19.860015');
INSERT INTO "recording_views" VALUES(3523,3505,'2014-07-06 02:09:29.955358','2014-07-06 02:09:29.955358');
INSERT INTO "recording_views" VALUES(3524,3508,'2014-07-06 02:10:54.886546','2014-07-06 02:10:54.886546');
INSERT INTO "recording_views" VALUES(3525,3451,'2014-07-06 02:12:19.185251','2014-07-06 02:12:19.185251');
INSERT INTO "recording_views" VALUES(3526,3445,'2014-07-06 02:12:32.742903','2014-07-06 02:12:32.742903');
INSERT INTO "recording_views" VALUES(3527,3457,'2014-07-06 02:12:49.792421','2014-07-06 02:12:49.792421');
INSERT INTO "recording_views" VALUES(3528,3649,'2014-07-06 02:13:07.615289','2014-07-06 02:13:07.615289');
INSERT INTO "recording_views" VALUES(3529,3433,'2014-07-06 02:13:40.632774','2014-07-06 02:13:40.632774');
INSERT INTO "recording_views" VALUES(3530,3781,'2014-07-06 02:15:35.138622','2014-07-06 02:15:35.138622');
INSERT INTO "recording_views" VALUES(3531,3781,'2014-07-06 02:18:02.742619','2014-07-06 02:18:02.742619');
INSERT INTO "recording_views" VALUES(3532,3442,'2014-07-06 02:18:29.813945','2014-07-06 02:18:29.813945');
INSERT INTO "recording_views" VALUES(3533,3466,'2014-07-06 02:20:14.182759','2014-07-06 02:20:14.182759');
INSERT INTO "recording_views" VALUES(3541,3716,'2014-07-06 04:18:25.003029','2014-07-06 04:18:25.003029');
INSERT INTO "recording_views" VALUES(3542,3716,'2014-07-06 04:21:44.99826','2014-07-06 04:21:44.99826');
INSERT INTO "recording_views" VALUES(3553,3608,'2014-07-06 07:42:10.582615','2014-07-06 07:42:10.582615');
INSERT INTO "recording_views" VALUES(3557,1317,'2014-07-06 07:56:35.089551','2014-07-06 07:56:35.089551');
INSERT INTO "recording_views" VALUES(3558,3596,'2014-07-06 07:58:37.739509','2014-07-06 07:58:37.739509');
INSERT INTO "recording_views" VALUES(3559,3437,'2014-07-06 08:03:13.816599','2014-07-06 08:03:13.816599');
INSERT INTO "recording_views" VALUES(3560,3767,'2014-07-06 08:04:43.410203','2014-07-06 08:04:43.410203');
INSERT INTO "recording_views" VALUES(3561,3752,'2014-07-06 08:06:02.738307','2014-07-06 08:06:02.738307');
INSERT INTO "recording_views" VALUES(3563,3497,'2014-07-06 08:12:39.022241','2014-07-06 08:12:39.022241');
INSERT INTO "recording_views" VALUES(3564,3608,'2014-07-06 08:17:31.107773','2014-07-06 08:17:31.107773');
INSERT INTO "recording_views" VALUES(3570,3602,'2014-07-06 08:37:46.626371','2014-07-06 08:37:46.626371');
INSERT INTO "recording_views" VALUES(3573,3602,'2014-07-06 08:41:14.589797','2014-07-06 08:41:14.589797');
INSERT INTO "recording_views" VALUES(3574,3602,'2014-07-06 08:43:23.023476','2014-07-06 08:43:23.023476');
INSERT INTO "recording_views" VALUES(3575,3602,'2014-07-06 08:45:28.707297','2014-07-06 08:45:28.707297');
INSERT INTO "recording_views" VALUES(3576,3602,'2014-07-06 08:47:40.368721','2014-07-06 08:47:40.368721');
INSERT INTO "recording_views" VALUES(3585,3602,'2014-07-06 09:11:26.84359','2014-07-06 09:11:26.84359');
INSERT INTO "recording_views" VALUES(3590,3608,'2014-07-06 09:16:10.240763','2014-07-06 09:16:10.240763');
INSERT INTO "recording_views" VALUES(3592,3602,'2014-07-06 09:17:54.389805','2014-07-06 09:17:54.389805');
INSERT INTO "recording_views" VALUES(3594,3734,'2014-07-06 09:18:38.521413','2014-07-06 09:18:38.521413');
INSERT INTO "recording_views" VALUES(3595,3602,'2014-07-06 09:20:08.072806','2014-07-06 09:20:08.072806');
INSERT INTO "recording_views" VALUES(3597,3602,'2014-07-06 09:22:08.563822','2014-07-06 09:22:08.563822');
INSERT INTO "recording_views" VALUES(3598,3484,'2014-07-06 09:22:58.212526','2014-07-06 09:22:58.212526');
INSERT INTO "recording_views" VALUES(3601,3484,'2014-07-06 09:25:10.387695','2014-07-06 09:25:10.387695');
INSERT INTO "recording_views" VALUES(3608,3484,'2014-07-06 09:30:38.654623','2014-07-06 09:30:38.654623');
INSERT INTO "recording_views" VALUES(3612,3484,'2014-07-06 09:35:35.236231','2014-07-06 09:35:35.236231');
INSERT INTO "recording_views" VALUES(3613,3484,'2014-07-06 09:38:23.158245','2014-07-06 09:38:23.158245');
INSERT INTO "recording_views" VALUES(3614,3497,'2014-07-06 09:42:23.241478','2014-07-06 09:42:23.241478');
INSERT INTO "recording_views" VALUES(3617,3452,'2014-07-06 09:49:20.291047','2014-07-06 09:49:20.291047');
INSERT INTO "recording_views" VALUES(3635,3964,'2014-07-06 10:09:40.96066','2014-07-06 10:09:40.96066');
INSERT INTO "recording_views" VALUES(3646,3647,'2014-07-06 10:27:27.233311','2014-07-06 10:27:27.233311');
INSERT INTO "recording_views" VALUES(3650,3647,'2014-07-06 10:41:36.475733','2014-07-06 10:41:36.475733');
INSERT INTO "recording_views" VALUES(3655,3667,'2014-07-06 11:03:23.082021','2014-07-06 11:03:23.082021');
INSERT INTO "recording_views" VALUES(3656,1206,'2014-07-06 11:03:57.741723','2014-07-06 11:03:57.741723');
INSERT INTO "recording_views" VALUES(3662,3752,'2014-07-06 11:13:56.35907','2014-07-06 11:13:56.35907');
INSERT INTO "recording_views" VALUES(3664,3647,'2014-07-06 11:20:37.68416','2014-07-06 11:20:37.68416');
INSERT INTO "recording_views" VALUES(3666,3752,'2014-07-06 11:23:36.989854','2014-07-06 11:23:36.989854');
INSERT INTO "recording_views" VALUES(3669,3667,'2014-07-06 11:32:46.768615','2014-07-06 11:32:46.768615');
INSERT INTO "recording_views" VALUES(3672,3779,'2014-07-06 11:35:24.637888','2014-07-06 11:35:24.637888');
INSERT INTO "recording_views" VALUES(3675,3452,'2014-07-06 11:36:42.359509','2014-07-06 11:36:42.359509');
INSERT INTO "recording_views" VALUES(3677,3731,'2014-07-06 11:43:27.761907','2014-07-06 11:43:27.761907');
INSERT INTO "recording_views" VALUES(3683,3731,'2014-07-06 11:57:01.153794','2014-07-06 11:57:01.153794');
INSERT INTO "recording_views" VALUES(3685,3715,'2014-07-06 12:00:41.687803','2014-07-06 12:00:41.687803');
INSERT INTO "recording_views" VALUES(3687,3731,'2014-07-06 12:03:28.104683','2014-07-06 12:03:28.104683');
INSERT INTO "recording_views" VALUES(3688,3452,'2014-07-06 12:11:20.057006','2014-07-06 12:11:20.057006');
INSERT INTO "recording_views" VALUES(3689,3671,'2014-07-06 12:11:30.248902','2014-07-06 12:11:30.248902');
INSERT INTO "recording_views" VALUES(3691,3731,'2014-07-06 12:15:26.073218','2014-07-06 12:15:26.073218');
INSERT INTO "recording_views" VALUES(3693,3731,'2014-07-06 12:20:04.374434','2014-07-06 12:20:04.374434');
INSERT INTO "recording_views" VALUES(3694,3452,'2014-07-06 12:21:33.851651','2014-07-06 12:21:33.851651');
INSERT INTO "recording_views" VALUES(3695,3731,'2014-07-06 12:22:06.078711','2014-07-06 12:22:06.078711');
INSERT INTO "recording_views" VALUES(3696,3731,'2014-07-06 12:25:38.150719','2014-07-06 12:25:38.150719');
INSERT INTO "recording_views" VALUES(3697,3452,'2014-07-06 12:25:59.342957','2014-07-06 12:25:59.342957');
INSERT INTO "recording_views" VALUES(3701,3452,'2014-07-06 12:34:38.115022','2014-07-06 12:34:38.115022');
INSERT INTO "recording_views" VALUES(3704,3752,'2014-07-06 12:38:25.145553','2014-07-06 12:38:25.145553');
INSERT INTO "recording_views" VALUES(3706,3752,'2014-07-06 12:42:11.491913','2014-07-06 12:42:11.491913');
INSERT INTO "recording_views" VALUES(3708,3752,'2014-07-06 12:45:13.047854','2014-07-06 12:45:13.047854');
INSERT INTO "recording_views" VALUES(3711,3715,'2014-07-06 12:49:59.996667','2014-07-06 12:49:59.996667');
INSERT INTO "recording_views" VALUES(3716,3595,'2014-07-06 12:53:51.665065','2014-07-06 12:53:51.665065');
INSERT INTO "recording_views" VALUES(3724,3496,'2014-07-06 13:03:04.416003','2014-07-06 13:03:04.416003');
INSERT INTO "recording_views" VALUES(3726,3530,'2014-07-06 13:09:32.517624','2014-07-06 13:09:32.517624');
INSERT INTO "recording_views" VALUES(3730,3530,'2014-07-06 13:16:15.761414','2014-07-06 13:16:15.761414');
INSERT INTO "recording_views" VALUES(3740,3530,'2014-07-06 13:35:18.775808','2014-07-06 13:35:18.775808');
INSERT INTO "recording_views" VALUES(3741,3530,'2014-07-06 13:37:19.445078','2014-07-06 13:37:19.445078');
INSERT INTO "recording_views" VALUES(3743,3740,'2014-07-06 13:40:02.609848','2014-07-06 13:40:02.609848');
INSERT INTO "recording_views" VALUES(3750,3530,'2014-07-06 13:58:08.643144','2014-07-06 13:58:08.643144');
INSERT INTO "recording_views" VALUES(3753,3452,'2014-07-06 13:59:19.158967','2014-07-06 13:59:19.158967');
INSERT INTO "recording_views" VALUES(3763,3806,'2014-07-06 14:22:36.571891','2014-07-06 14:22:36.571891');
INSERT INTO "recording_views" VALUES(3765,3752,'2014-07-06 14:27:05.449','2014-07-06 14:27:05.449');
INSERT INTO "recording_views" VALUES(3768,3806,'2014-07-06 14:32:45.499157','2014-07-06 14:32:45.499157');
INSERT INTO "recording_views" VALUES(3773,3497,'2014-07-06 15:09:10.759912','2014-07-06 15:09:10.759912');
INSERT INTO "recording_views" VALUES(3777,3740,'2014-07-06 15:25:12.182162','2014-07-06 15:25:12.182162');
INSERT INTO "recording_views" VALUES(3781,3646,'2014-07-06 15:31:34.128364','2014-07-06 15:31:34.128364');
INSERT INTO "recording_views" VALUES(3782,3646,'2014-07-06 15:34:50.710989','2014-07-06 15:34:50.710989');
INSERT INTO "recording_views" VALUES(3785,3646,'2014-07-06 15:37:40.916774','2014-07-06 15:37:40.916774');
INSERT INTO "recording_views" VALUES(3786,3646,'2014-07-06 15:40:22.283548','2014-07-06 15:40:22.283548');
INSERT INTO "recording_views" VALUES(3790,3646,'2014-07-06 15:44:02.220749','2014-07-06 15:44:02.220749');
INSERT INTO "recording_views" VALUES(3792,3646,'2014-07-06 15:47:57.999203','2014-07-06 15:47:57.999203');
INSERT INTO "recording_views" VALUES(3794,3646,'2014-07-06 15:51:42.163771','2014-07-06 15:51:42.163771');
INSERT INTO "recording_views" VALUES(3795,3646,'2014-07-06 15:53:53.41109','2014-07-06 15:53:53.41109');
INSERT INTO "recording_views" VALUES(3797,3646,'2014-07-06 15:56:05.196011','2014-07-06 15:56:05.196011');
INSERT INTO "recording_views" VALUES(3798,3646,'2014-07-06 15:58:06.422337','2014-07-06 15:58:06.422337');
INSERT INTO "recording_views" VALUES(3799,3647,'2014-07-06 16:16:10.854335','2014-07-06 16:16:10.854335');
INSERT INTO "recording_views" VALUES(3801,3782,'2014-07-06 16:17:21.861362','2014-07-06 16:17:21.861362');
INSERT INTO "recording_views" VALUES(3807,3772,'2014-07-06 16:34:04.132112','2014-07-06 16:34:04.132112');
INSERT INTO "recording_views" VALUES(3809,3772,'2014-07-06 16:36:04.946713','2014-07-06 16:36:04.946713');
INSERT INTO "recording_views" VALUES(3810,3830,'2014-07-06 16:39:14.156963','2014-07-06 16:39:14.156963');
INSERT INTO "recording_views" VALUES(3811,3527,'2014-07-06 16:39:58.769042','2014-07-06 16:39:58.769042');
INSERT INTO "recording_views" VALUES(3817,3830,'2014-07-06 16:46:48.504012','2014-07-06 16:46:48.504012');
INSERT INTO "recording_views" VALUES(3818,3964,'2014-07-06 16:48:06.025874','2014-07-06 16:48:06.025874');
INSERT INTO "recording_views" VALUES(3820,3752,'2014-07-06 16:54:25.183288','2014-07-06 16:54:25.183288');
INSERT INTO "recording_views" VALUES(3825,3647,'2014-07-06 17:05:10.758833','2014-07-06 17:05:10.758833');
INSERT INTO "recording_views" VALUES(3826,3452,'2014-07-06 17:05:20.66177','2014-07-06 17:05:20.66177');
INSERT INTO "recording_views" VALUES(3832,3452,'2014-07-06 17:07:40.393021','2014-07-06 17:07:40.393021');
INSERT INTO "recording_views" VALUES(3837,3605,'2014-07-06 17:11:11.306256','2014-07-06 17:11:11.306256');
INSERT INTO "recording_views" VALUES(3841,3716,'2014-07-06 17:13:43.984864','2014-07-06 17:13:43.984864');
INSERT INTO "recording_views" VALUES(3844,3830,'2014-07-06 17:14:49.753259','2014-07-06 17:14:49.753259');
INSERT INTO "recording_views" VALUES(3846,3716,'2014-07-06 17:17:03.316663','2014-07-06 17:17:03.316663');
INSERT INTO "recording_views" VALUES(3850,3446,'2014-07-06 17:26:56.97733','2014-07-06 17:26:56.97733');
INSERT INTO "recording_views" VALUES(3855,94,'2014-07-06 17:36:35.521624','2014-07-06 17:36:35.521624');
INSERT INTO "recording_views" VALUES(3861,3752,'2014-07-06 17:49:48.696488','2014-07-06 17:49:48.696488');
INSERT INTO "recording_views" VALUES(3869,3437,'2014-07-06 18:08:17.123227','2014-07-06 18:08:17.123227');
INSERT INTO "recording_views" VALUES(3870,3437,'2014-07-06 18:10:17.495122','2014-07-06 18:10:17.495122');
INSERT INTO "recording_views" VALUES(3872,3671,'2014-07-06 18:13:36.537005','2014-07-06 18:13:36.537005');
INSERT INTO "recording_views" VALUES(3873,3527,'2014-07-06 18:19:33.178901','2014-07-06 18:19:33.178901');
INSERT INTO "recording_views" VALUES(3876,3437,'2014-07-06 18:25:06.791897','2014-07-06 18:25:06.791897');
INSERT INTO "recording_views" VALUES(3882,3521,'2014-07-06 18:57:26.042753','2014-07-06 18:57:26.042753');
INSERT INTO "recording_views" VALUES(3885,3497,'2014-07-06 19:05:54.075735','2014-07-06 19:05:54.075735');
INSERT INTO "recording_views" VALUES(3886,3467,'2014-07-06 19:07:44.293035','2014-07-06 19:07:44.293035');
INSERT INTO "recording_views" VALUES(3888,3467,'2014-07-06 19:10:34.527278','2014-07-06 19:10:34.527278');
INSERT INTO "recording_views" VALUES(3889,3716,'2014-07-06 19:14:56.26897','2014-07-06 19:14:56.26897');
INSERT INTO "recording_views" VALUES(3891,3815,'2014-07-06 19:20:51.977773','2014-07-06 19:20:51.977773');
INSERT INTO "recording_views" VALUES(3894,3521,'2014-07-06 19:26:53.326452','2014-07-06 19:26:53.326452');
INSERT INTO "recording_views" VALUES(3896,3800,'2014-07-06 19:35:27.259659','2014-07-06 19:35:27.259659');
INSERT INTO "recording_views" VALUES(3897,3497,'2014-07-06 19:35:53.607685','2014-07-06 19:35:53.607685');
INSERT INTO "recording_views" VALUES(3901,3554,'2014-07-06 19:43:20.177099','2014-07-06 19:43:20.177099');
INSERT INTO "recording_views" VALUES(3903,3779,'2014-07-06 19:45:49.517869','2014-07-06 19:45:49.517869');
INSERT INTO "recording_views" VALUES(3904,3554,'2014-07-06 19:48:12.621554','2014-07-06 19:48:12.621554');
INSERT INTO "recording_views" VALUES(3906,3815,'2014-07-06 20:02:40.933444','2014-07-06 20:02:40.933444');
INSERT INTO "recording_views" VALUES(3909,3815,'2014-07-06 20:05:31.774658','2014-07-06 20:05:31.774658');
INSERT INTO "recording_views" VALUES(3911,3497,'2014-07-06 20:08:52.333899','2014-07-06 20:08:52.333899');
INSERT INTO "recording_views" VALUES(3912,3572,'2014-07-06 20:09:20.208022','2014-07-06 20:09:20.208022');
INSERT INTO "recording_views" VALUES(3913,3572,'2014-07-06 20:11:21.324329','2014-07-06 20:11:21.324329');
INSERT INTO "recording_views" VALUES(3916,3452,'2014-07-06 20:11:58.262957','2014-07-06 20:11:58.262957');
INSERT INTO "recording_views" VALUES(3917,3554,'2014-07-06 20:13:23.432846','2014-07-06 20:13:23.432846');
INSERT INTO "recording_views" VALUES(3918,3665,'2014-07-06 20:13:51.801363','2014-07-06 20:13:51.801363');
INSERT INTO "recording_views" VALUES(3919,3587,'2014-07-06 20:14:55.384826','2014-07-06 20:14:55.384826');
INSERT INTO "recording_views" VALUES(3921,3554,'2014-07-06 20:15:23.492381','2014-07-06 20:15:23.492381');
INSERT INTO "recording_views" VALUES(3922,3452,'2014-07-06 20:15:24.35952','2014-07-06 20:15:24.35952');
INSERT INTO "recording_views" VALUES(3923,3451,'2014-07-06 20:15:30.022722','2014-07-06 20:15:30.022722');
INSERT INTO "recording_views" VALUES(3924,3659,'2014-07-06 20:16:01.361982','2014-07-06 20:16:01.361982');
INSERT INTO "recording_views" VALUES(3926,3692,'2014-07-06 20:16:44.879054','2014-07-06 20:16:44.879054');
INSERT INTO "recording_views" VALUES(3928,3692,'2014-07-06 20:18:46.43779','2014-07-06 20:18:46.43779');
INSERT INTO "recording_views" VALUES(3930,3692,'2014-07-06 20:20:47.551912','2014-07-06 20:20:47.551912');
INSERT INTO "recording_views" VALUES(3931,3452,'2014-07-06 20:22:40.341647','2014-07-06 20:22:40.341647');
INSERT INTO "recording_views" VALUES(3932,3821,'2014-07-06 20:22:55.787868','2014-07-06 20:22:55.787868');
INSERT INTO "recording_views" VALUES(3933,3728,'2014-07-06 20:23:09.394111','2014-07-06 20:23:09.394111');
INSERT INTO "recording_views" VALUES(3934,3821,'2014-07-06 20:24:58.055671','2014-07-06 20:24:58.055671');
INSERT INTO "recording_views" VALUES(3935,3524,'2014-07-06 20:25:46.712293','2014-07-06 20:25:46.712293');
INSERT INTO "recording_views" VALUES(3936,3452,'2014-07-06 20:26:15.015375','2014-07-06 20:26:15.015375');
INSERT INTO "recording_views" VALUES(3938,3497,'2014-07-06 20:31:14.43243','2014-07-06 20:31:14.43243');
INSERT INTO "recording_views" VALUES(3939,3524,'2014-07-06 20:31:15.27417','2014-07-06 20:31:15.27417');
INSERT INTO "recording_views" VALUES(3943,3524,'2014-07-06 20:36:14.056643','2014-07-06 20:36:14.056643');
INSERT INTO "recording_views" VALUES(3946,3452,'2014-07-06 20:39:08.096725','2014-07-06 20:39:08.096725');
INSERT INTO "recording_views" VALUES(3953,3497,'2014-07-06 20:53:59.227386','2014-07-06 20:53:59.227386');
INSERT INTO "recording_views" VALUES(3955,3524,'2014-07-06 20:55:13.950347','2014-07-06 20:55:13.950347');
INSERT INTO "recording_views" VALUES(3959,3497,'2014-07-06 21:02:29.246168','2014-07-06 21:02:29.246168');
INSERT INTO "recording_views" VALUES(3966,3524,'2014-07-06 21:11:07.240296','2014-07-06 21:11:07.240296');
INSERT INTO "recording_views" VALUES(3969,3524,'2014-07-06 21:18:56.936269','2014-07-06 21:18:56.936269');
INSERT INTO "recording_views" VALUES(3970,3770,'2014-07-06 21:19:40.850312','2014-07-06 21:19:40.850312');
INSERT INTO "recording_views" VALUES(3971,3452,'2014-07-06 21:20:27.996596','2014-07-06 21:20:27.996596');
INSERT INTO "recording_views" VALUES(3973,3770,'2014-07-06 21:22:03.733812','2014-07-06 21:22:03.733812');
INSERT INTO "recording_views" VALUES(3975,3494,'2014-07-06 21:23:46.876105','2014-07-06 21:23:46.876105');
INSERT INTO "recording_views" VALUES(3977,3494,'2014-07-06 21:25:57.773423','2014-07-06 21:25:57.773423');
INSERT INTO "recording_views" VALUES(3978,3791,'2014-07-06 21:27:24.835145','2014-07-06 21:27:24.835145');
INSERT INTO "recording_views" VALUES(3979,3497,'2014-07-06 21:27:38.325911','2014-07-06 21:27:38.325911');
INSERT INTO "recording_views" VALUES(3981,3590,'2014-07-06 21:30:45.208079','2014-07-06 21:30:45.208079');
INSERT INTO "recording_views" VALUES(3984,3773,'2014-07-06 21:32:00.352092','2014-07-06 21:32:00.352092');
INSERT INTO "recording_views" VALUES(3985,3497,'2014-07-06 21:34:26.929063','2014-07-06 21:34:26.929063');
INSERT INTO "recording_views" VALUES(3990,3497,'2014-07-06 21:48:26.968941','2014-07-06 21:48:26.968941');
INSERT INTO "recording_views" VALUES(3991,3791,'2014-07-06 21:50:36.771478','2014-07-06 21:50:36.771478');
INSERT INTO "recording_views" VALUES(3995,3791,'2014-07-06 21:55:33.492139','2014-07-06 21:55:33.492139');
INSERT INTO "recording_views" VALUES(3996,1287,'2014-07-06 21:56:18.58949','2014-07-06 21:56:18.58949');
INSERT INTO "recording_views" VALUES(3997,3791,'2014-07-06 21:58:27.718694','2014-07-06 21:58:27.718694');
INSERT INTO "recording_views" VALUES(4001,3785,'2014-07-06 22:06:18.814017','2014-07-06 22:06:18.814017');
INSERT INTO "recording_views" VALUES(4004,3662,'2014-07-06 22:14:50.319988','2014-07-06 22:14:50.319988');
INSERT INTO "recording_views" VALUES(4005,3662,'2014-07-06 22:17:26.671882','2014-07-06 22:17:26.671882');
INSERT INTO "recording_views" VALUES(4007,3560,'2014-07-06 22:21:55.919209','2014-07-06 22:21:55.919209');
INSERT INTO "recording_views" VALUES(4008,3560,'2014-07-06 22:26:13.639963','2014-07-06 22:26:13.639963');
INSERT INTO "recording_views" VALUES(4012,3662,'2014-07-06 22:30:48.394913','2014-07-06 22:30:48.394913');
INSERT INTO "recording_views" VALUES(4013,3746,'2014-07-06 22:39:51.426381','2014-07-06 22:39:51.426381');
INSERT INTO "recording_views" VALUES(4014,3560,'2014-07-06 22:40:48.526007','2014-07-06 22:40:48.526007');
INSERT INTO "recording_views" VALUES(4015,3662,'2014-07-06 22:41:28.384588','2014-07-06 22:41:28.384588');
INSERT INTO "recording_views" VALUES(4016,3767,'2014-07-06 22:43:30.84231','2014-07-06 22:43:30.84231');
INSERT INTO "recording_views" VALUES(4019,3560,'2014-07-06 22:49:45.107634','2014-07-06 22:49:45.107634');
INSERT INTO "recording_views" VALUES(4020,3605,'2014-07-06 22:50:20.769296','2014-07-06 22:50:20.769296');
INSERT INTO "recording_views" VALUES(4022,3767,'2014-07-06 22:51:45.978846','2014-07-06 22:51:45.978846');
INSERT INTO "recording_views" VALUES(4023,3646,'2014-07-06 22:52:50.363813','2014-07-06 22:52:50.363813');
INSERT INTO "recording_views" VALUES(4025,3560,'2014-07-06 22:54:47.52689','2014-07-06 22:54:47.52689');
INSERT INTO "recording_views" VALUES(4027,3646,'2014-07-06 22:55:05.999317','2014-07-06 22:55:05.999317');
INSERT INTO "recording_views" VALUES(4028,3497,'2014-07-06 22:56:15.139787','2014-07-06 22:56:15.139787');
INSERT INTO "recording_views" VALUES(4029,1233,'2014-07-06 22:56:15.616658','2014-07-06 22:56:15.616658');
INSERT INTO "recording_views" VALUES(4030,3646,'2014-07-06 22:57:07.307492','2014-07-06 22:57:07.307492');
INSERT INTO "recording_views" VALUES(4031,3560,'2014-07-06 22:57:15.247322','2014-07-06 22:57:15.247322');
INSERT INTO "recording_views" VALUES(4033,3646,'2014-07-06 22:59:22.380128','2014-07-06 22:59:22.380128');
INSERT INTO "recording_views" VALUES(4034,3646,'2014-07-06 23:02:10.216465','2014-07-06 23:02:10.216465');
INSERT INTO "recording_views" VALUES(4035,3646,'2014-07-06 23:05:06.915932','2014-07-06 23:05:06.915932');
INSERT INTO "recording_views" VALUES(4036,3646,'2014-07-06 23:07:56.89185','2014-07-06 23:07:56.89185');
INSERT INTO "recording_views" VALUES(4038,3646,'2014-07-06 23:10:13.669427','2014-07-06 23:10:13.669427');
INSERT INTO "recording_views" VALUES(4041,3560,'2014-07-06 23:13:25.546464','2014-07-06 23:13:25.546464');
INSERT INTO "recording_views" VALUES(4042,3563,'2014-07-06 23:13:41.396034','2014-07-06 23:13:41.396034');
INSERT INTO "recording_views" VALUES(4044,3563,'2014-07-06 23:15:58.185802','2014-07-06 23:15:58.185802');
INSERT INTO "recording_views" VALUES(4045,3728,'2014-07-06 23:16:15.203811','2014-07-06 23:16:15.203811');
INSERT INTO "recording_views" VALUES(4052,3646,'2014-07-07 00:07:13.629536','2014-07-07 00:07:13.629536');
INSERT INTO "recording_views" VALUES(4055,3560,'2014-07-07 00:24:24.062664','2014-07-07 00:24:24.062664');
INSERT INTO "recording_views" VALUES(4058,3667,'2014-07-07 00:33:52.282103','2014-07-07 00:33:52.282103');
INSERT INTO "recording_views" VALUES(4059,1242,'2014-07-07 00:39:21.699393','2014-07-07 00:39:21.699393');
INSERT INTO "recording_views" VALUES(4060,3646,'2014-07-07 00:44:06.363439','2014-07-07 00:44:06.363439');
INSERT INTO "recording_views" VALUES(4063,1239,'2014-07-07 01:02:24.51097','2014-07-07 01:02:24.51097');
INSERT INTO "recording_views" VALUES(4078,3743,'2014-07-07 02:24:40.420069','2014-07-07 02:24:40.420069');
INSERT INTO "recording_views" VALUES(4083,1239,'2014-07-07 02:27:42.429976','2014-07-07 02:27:42.429976');
INSERT INTO "recording_views" VALUES(4084,3743,'2014-07-07 02:28:23.861912','2014-07-07 02:28:23.861912');
INSERT INTO "recording_views" VALUES(4087,3743,'2014-07-07 02:31:52.336275','2014-07-07 02:31:52.336275');
INSERT INTO "recording_views" VALUES(4088,3743,'2014-07-07 02:46:14.363546','2014-07-07 02:46:14.363546');
INSERT INTO "recording_views" VALUES(4092,3743,'2014-07-07 03:27:09.094425','2014-07-07 03:27:09.094425');
INSERT INTO "recording_views" VALUES(4093,3560,'2014-07-07 03:35:04.190099','2014-07-07 03:35:04.190099');
INSERT INTO "recording_views" VALUES(4095,3647,'2014-07-07 04:20:17.979109','2014-07-07 04:20:17.979109');
INSERT INTO "recording_views" VALUES(4096,3647,'2014-07-07 04:22:24.101431','2014-07-07 04:22:24.101431');
INSERT INTO "recording_views" VALUES(4097,3614,'2014-07-07 04:23:02.913198','2014-07-07 04:23:02.913198');
INSERT INTO "recording_views" VALUES(4098,3614,'2014-07-07 04:27:08.380618','2014-07-07 04:27:08.380618');
INSERT INTO "recording_views" VALUES(4099,3614,'2014-07-07 04:29:39.274725','2014-07-07 04:29:39.274725');
INSERT INTO "recording_views" VALUES(4100,3614,'2014-07-07 04:36:06.051989','2014-07-07 04:36:06.051989');
INSERT INTO "recording_views" VALUES(4101,3614,'2014-07-07 04:40:40.091999','2014-07-07 04:40:40.091999');
INSERT INTO "recording_views" VALUES(4102,3614,'2014-07-07 04:45:13.306913','2014-07-07 04:45:13.306913');
INSERT INTO "recording_views" VALUES(4103,3614,'2014-07-07 04:48:40.269481','2014-07-07 04:48:40.269481');
INSERT INTO "recording_views" VALUES(4104,3614,'2014-07-07 04:50:59.949604','2014-07-07 04:50:59.949604');
INSERT INTO "recording_views" VALUES(4105,3509,'2014-07-07 04:54:03.439427','2014-07-07 04:54:03.439427');
INSERT INTO "recording_views" VALUES(4106,3509,'2014-07-07 05:00:11.578304','2014-07-07 05:00:11.578304');
INSERT INTO "recording_views" VALUES(4107,3509,'2014-07-07 05:02:21.933033','2014-07-07 05:02:21.933033');
INSERT INTO "recording_views" VALUES(4108,3509,'2014-07-07 05:04:45.461467','2014-07-07 05:04:45.461467');
INSERT INTO "recording_views" VALUES(4109,3431,'2014-07-07 05:04:50.820586','2014-07-07 05:04:50.820586');
INSERT INTO "recording_views" VALUES(4110,3509,'2014-07-07 05:06:45.604448','2014-07-07 05:06:45.604448');
INSERT INTO "recording_views" VALUES(4111,3452,'2014-07-07 05:12:13.521557','2014-07-07 05:12:13.521557');
INSERT INTO "recording_views" VALUES(4115,1257,'2014-07-07 06:31:48.107742','2014-07-07 06:31:48.107742');
INSERT INTO "recording_views" VALUES(4123,3769,'2014-07-07 07:45:06.715739','2014-07-07 07:45:06.715739');
INSERT INTO "recording_views" VALUES(4129,3637,'2014-07-07 08:06:28.431344','2014-07-07 08:06:28.431344');
INSERT INTO "recording_views" VALUES(4132,3709,'2014-07-07 08:07:31.050995','2014-07-07 08:07:31.050995');
INSERT INTO "recording_views" VALUES(4134,3637,'2014-07-07 08:11:00.44753','2014-07-07 08:11:00.44753');
INSERT INTO "recording_views" VALUES(4135,3715,'2014-07-07 08:12:15.238401','2014-07-07 08:12:15.238401');
INSERT INTO "recording_views" VALUES(4137,3637,'2014-07-07 08:17:35.708921','2014-07-07 08:17:35.708921');
INSERT INTO "recording_views" VALUES(4139,3637,'2014-07-07 08:20:03.539767','2014-07-07 08:20:03.539767');
INSERT INTO "recording_views" VALUES(4141,3637,'2014-07-07 08:29:32.015465','2014-07-07 08:29:32.015465');
INSERT INTO "recording_views" VALUES(4142,3752,'2014-07-07 08:48:22.112809','2014-07-07 08:48:22.112809');
INSERT INTO "recording_views" VALUES(4143,3829,'2014-07-07 08:57:43.91629','2014-07-07 08:57:43.91629');
INSERT INTO "recording_views" VALUES(4144,3452,'2014-07-07 08:59:10.262572','2014-07-07 08:59:10.262572');
INSERT INTO "recording_views" VALUES(4145,3829,'2014-07-07 09:04:19.551359','2014-07-07 09:04:19.551359');
INSERT INTO "recording_views" VALUES(4146,3560,'2014-07-07 09:05:10.076407','2014-07-07 09:05:10.076407');
INSERT INTO "recording_views" VALUES(4148,3829,'2014-07-07 09:11:35.190689','2014-07-07 09:11:35.190689');
INSERT INTO "recording_views" VALUES(4149,3829,'2014-07-07 09:11:35.192968','2014-07-07 09:11:35.192968');
INSERT INTO "recording_views" VALUES(4150,3602,'2014-07-07 09:13:05.201152','2014-07-07 09:13:05.201152');
INSERT INTO "recording_views" VALUES(4151,3560,'2014-07-07 09:13:40.718784','2014-07-07 09:13:40.718784');
INSERT INTO "recording_views" VALUES(4152,3446,'2014-07-07 09:14:09.578608','2014-07-07 09:14:09.578608');
INSERT INTO "recording_views" VALUES(4153,3829,'2014-07-07 09:16:11.017281','2014-07-07 09:16:11.017281');
INSERT INTO "recording_views" VALUES(4154,3749,'2014-07-07 09:18:48.1382','2014-07-07 09:18:48.1382');
INSERT INTO "recording_views" VALUES(4155,3829,'2014-07-07 09:35:34.172019','2014-07-07 09:35:34.172019');
INSERT INTO "recording_views" VALUES(4164,3829,'2014-07-07 09:53:00.304901','2014-07-07 09:53:00.304901');
INSERT INTO "recording_views" VALUES(4165,3709,'2014-07-07 09:53:12.471285','2014-07-07 09:53:12.471285');
INSERT INTO "recording_views" VALUES(4170,3773,'2014-07-07 10:01:03.568396','2014-07-07 10:01:03.568396');
INSERT INTO "recording_views" VALUES(4172,3773,'2014-07-07 10:03:42.413602','2014-07-07 10:03:42.413602');
INSERT INTO "recording_views" VALUES(4175,3809,'2014-07-07 10:24:42.507348','2014-07-07 10:24:42.507348');
INSERT INTO "recording_views" VALUES(4182,3667,'2014-07-07 10:52:53.95922','2014-07-07 10:52:53.95922');
INSERT INTO "recording_views" VALUES(4184,3497,'2014-07-07 11:01:26.202901','2014-07-07 11:01:26.202901');
INSERT INTO "recording_views" VALUES(4185,3659,'2014-07-07 11:03:19.894077','2014-07-07 11:03:19.894077');
INSERT INTO "recording_views" VALUES(4186,3506,'2014-07-07 11:05:43.151174','2014-07-07 11:05:43.151174');
INSERT INTO "recording_views" VALUES(4188,3497,'2014-07-07 11:07:32.352833','2014-07-07 11:07:32.352833');
INSERT INTO "recording_views" VALUES(4189,3800,'2014-07-07 11:16:34.335524','2014-07-07 11:16:34.335524');
INSERT INTO "recording_views" VALUES(4190,3821,'2014-07-07 11:17:38.396503','2014-07-07 11:17:38.396503');
INSERT INTO "recording_views" VALUES(4191,3821,'2014-07-07 11:19:55.39772','2014-07-07 11:19:55.39772');
INSERT INTO "recording_views" VALUES(4192,3550,'2014-07-07 11:22:02.586763','2014-07-07 11:22:02.586763');
INSERT INTO "recording_views" VALUES(4195,3743,'2014-07-07 11:33:06.800791','2014-07-07 11:33:06.800791');
INSERT INTO "recording_views" VALUES(4198,3452,'2014-07-07 11:35:54.584119','2014-07-07 11:35:54.584119');
INSERT INTO "recording_views" VALUES(4200,3452,'2014-07-07 11:55:35.800119','2014-07-07 11:55:35.800119');
INSERT INTO "recording_views" VALUES(4202,3452,'2014-07-07 11:59:08.963993','2014-07-07 11:59:08.963993');
INSERT INTO "recording_views" VALUES(4206,3960,'2014-07-07 12:27:50.487648','2014-07-07 12:27:50.487648');
INSERT INTO "recording_views" VALUES(4209,3497,'2014-07-07 12:38:45.045704','2014-07-07 12:38:45.045704');
INSERT INTO "recording_views" VALUES(4211,3497,'2014-07-07 12:41:44.361355','2014-07-07 12:41:44.361355');
INSERT INTO "recording_views" VALUES(4213,3445,'2014-07-07 12:53:25.735122','2014-07-07 12:53:25.735122');
INSERT INTO "recording_views" VALUES(4214,3497,'2014-07-07 12:54:57.310715','2014-07-07 12:54:57.310715');
INSERT INTO "recording_views" VALUES(4217,3752,'2014-07-07 13:00:42.527938','2014-07-07 13:00:42.527938');
INSERT INTO "recording_views" VALUES(4221,3536,'2014-07-07 13:06:32.598433','2014-07-07 13:06:32.598433');
INSERT INTO "recording_views" VALUES(4222,3536,'2014-07-07 13:09:48.975064','2014-07-07 13:09:48.975064');
INSERT INTO "recording_views" VALUES(4223,3452,'2014-07-07 13:13:26.701817','2014-07-07 13:13:26.701817');
INSERT INTO "recording_views" VALUES(4225,3536,'2014-07-07 13:19:40.614893','2014-07-07 13:19:40.614893');
INSERT INTO "recording_views" VALUES(4229,3728,'2014-07-07 13:23:49.966826','2014-07-07 13:23:49.966826');
INSERT INTO "recording_views" VALUES(4230,3473,'2014-07-07 13:24:56.819433','2014-07-07 13:24:56.819433');
INSERT INTO "recording_views" VALUES(4232,3473,'2014-07-07 13:28:10.917669','2014-07-07 13:28:10.917669');
INSERT INTO "recording_views" VALUES(4237,3497,'2014-07-07 13:33:05.506563','2014-07-07 13:33:05.506563');
INSERT INTO "recording_views" VALUES(4238,3688,'2014-07-07 13:37:27.080233','2014-07-07 13:37:27.080233');
INSERT INTO "recording_views" VALUES(4243,3452,'2014-07-07 13:59:45.283621','2014-07-07 13:59:45.283621');
INSERT INTO "recording_views" VALUES(4244,3536,'2014-07-07 14:04:20.208924','2014-07-07 14:04:20.208924');
INSERT INTO "recording_views" VALUES(4245,3536,'2014-07-07 14:06:27.816124','2014-07-07 14:06:27.816124');
INSERT INTO "recording_views" VALUES(4252,3497,'2014-07-07 14:20:32.932407','2014-07-07 14:20:32.932407');
INSERT INTO "recording_views" VALUES(4253,3773,'2014-07-07 14:21:00.375806','2014-07-07 14:21:00.375806');
INSERT INTO "recording_views" VALUES(4257,3688,'2014-07-07 14:36:36.389348','2014-07-07 14:36:36.389348');
INSERT INTO "recording_views" VALUES(4258,3467,'2014-07-07 14:37:07.47367','2014-07-07 14:37:07.47367');
INSERT INTO "recording_views" VALUES(4261,3467,'2014-07-07 14:50:25.481777','2014-07-07 14:50:25.481777');
INSERT INTO "recording_views" VALUES(4262,3964,'2014-07-07 14:50:32.912524','2014-07-07 14:50:32.912524');
INSERT INTO "recording_views" VALUES(4266,3602,'2014-07-07 15:14:47.178097','2014-07-07 15:14:47.178097');
INSERT INTO "recording_views" VALUES(4268,3668,'2014-07-07 15:26:57.951856','2014-07-07 15:26:57.951856');
INSERT INTO "recording_views" VALUES(4273,3668,'2014-07-07 15:32:17.849372','2014-07-07 15:32:17.849372');
INSERT INTO "recording_views" VALUES(4276,3725,'2014-07-07 15:44:00.782603','2014-07-07 15:44:00.782603');
INSERT INTO "recording_views" VALUES(4279,3683,'2014-07-07 15:49:17.349695','2014-07-07 15:49:17.349695');
INSERT INTO "recording_views" VALUES(4285,3803,'2014-07-07 15:56:35.568993','2014-07-07 15:56:35.568993');
INSERT INTO "recording_views" VALUES(4300,3605,'2014-07-07 16:33:53.360368','2014-07-07 16:33:53.360368');
INSERT INTO "recording_views" VALUES(4304,3452,'2014-07-07 16:37:01.597575','2014-07-07 16:37:01.597575');
INSERT INTO "recording_views" VALUES(4306,3452,'2014-07-07 16:46:31.55687','2014-07-07 16:46:31.55687');
INSERT INTO "recording_views" VALUES(4307,3709,'2014-07-07 16:46:52.142641','2014-07-07 16:46:52.142641');
INSERT INTO "recording_views" VALUES(4308,3709,'2014-07-07 16:49:10.687339','2014-07-07 16:49:10.687339');
INSERT INTO "recording_views" VALUES(4309,3709,'2014-07-07 16:52:10.196196','2014-07-07 16:52:10.196196');
INSERT INTO "recording_views" VALUES(4310,3740,'2014-07-07 16:52:45.200647','2014-07-07 16:52:45.200647');
INSERT INTO "recording_views" VALUES(4311,3506,'2014-07-07 16:54:48.684147','2014-07-07 16:54:48.684147');
INSERT INTO "recording_views" VALUES(4313,3725,'2014-07-07 16:54:55.585413','2014-07-07 16:54:55.585413');
INSERT INTO "recording_views" VALUES(4315,3527,'2014-07-07 16:56:22.66154','2014-07-07 16:56:22.66154');
INSERT INTO "recording_views" VALUES(4316,3752,'2014-07-07 16:57:22.592701','2014-07-07 16:57:22.592701');
INSERT INTO "recording_views" VALUES(4317,3709,'2014-07-07 16:57:39.472006','2014-07-07 16:57:39.472006');
INSERT INTO "recording_views" VALUES(4318,3725,'2014-07-07 16:57:43.964443','2014-07-07 16:57:43.964443');
INSERT INTO "recording_views" VALUES(4320,3689,'2014-07-07 17:02:26.360291','2014-07-07 17:02:26.360291');
INSERT INTO "recording_views" VALUES(4324,3452,'2014-07-07 17:08:26.640232','2014-07-07 17:08:26.640232');
INSERT INTO "recording_views" VALUES(4327,3725,'2014-07-07 17:11:26.314312','2014-07-07 17:11:26.314312');
INSERT INTO "recording_views" VALUES(4333,3725,'2014-07-07 17:15:18.045429','2014-07-07 17:15:18.045429');
INSERT INTO "recording_views" VALUES(4337,3667,'2014-07-07 17:17:48.525445','2014-07-07 17:17:48.525445');
INSERT INTO "recording_views" VALUES(4339,1212,'2014-07-07 17:20:59.403318','2014-07-07 17:20:59.403318');
INSERT INTO "recording_views" VALUES(4340,3709,'2014-07-07 17:21:33.746396','2014-07-07 17:21:33.746396');
INSERT INTO "recording_views" VALUES(4341,3667,'2014-07-07 17:21:54.82872','2014-07-07 17:21:54.82872');
INSERT INTO "recording_views" VALUES(4345,3496,'2014-07-07 17:24:09.818726','2014-07-07 17:24:09.818726');
INSERT INTO "recording_views" VALUES(4347,3667,'2014-07-07 17:25:05.394304','2014-07-07 17:25:05.394304');
INSERT INTO "recording_views" VALUES(4349,3667,'2014-07-07 17:27:30.118544','2014-07-07 17:27:30.118544');
INSERT INTO "recording_views" VALUES(4350,3688,'2014-07-07 17:29:51.200661','2014-07-07 17:29:51.200661');
INSERT INTO "recording_views" VALUES(4351,3667,'2014-07-07 17:30:47.440865','2014-07-07 17:30:47.440865');
INSERT INTO "recording_views" VALUES(4356,3805,'2014-07-07 17:38:08.767133','2014-07-07 17:38:08.767133');
INSERT INTO "recording_views" VALUES(4357,3805,'2014-07-07 17:40:14.684005','2014-07-07 17:40:14.684005');
INSERT INTO "recording_views" VALUES(4360,3497,'2014-07-07 17:41:40.608388','2014-07-07 17:41:40.608388');
INSERT INTO "recording_views" VALUES(4366,3506,'2014-07-07 17:48:31.901402','2014-07-07 17:48:31.901402');
INSERT INTO "recording_views" VALUES(4368,1212,'2014-07-07 17:52:30.814979','2014-07-07 17:52:30.814979');
INSERT INTO "recording_views" VALUES(4374,3809,'2014-07-07 18:09:34.95579','2014-07-07 18:09:34.95579');
INSERT INTO "recording_views" VALUES(4376,3626,'2014-07-07 18:15:40.093319','2014-07-07 18:15:40.093319');
INSERT INTO "recording_views" VALUES(4377,1212,'2014-07-07 18:16:19.642388','2014-07-07 18:16:19.642388');
INSERT INTO "recording_views" VALUES(4378,3623,'2014-07-07 18:16:26.559917','2014-07-07 18:16:26.559917');
INSERT INTO "recording_views" VALUES(4380,3803,'2014-07-07 18:17:39.754159','2014-07-07 18:17:39.754159');
INSERT INTO "recording_views" VALUES(4383,1212,'2014-07-07 18:21:41.588111','2014-07-07 18:21:41.588111');
INSERT INTO "recording_views" VALUES(4384,3623,'2014-07-07 18:22:45.883045','2014-07-07 18:22:45.883045');
INSERT INTO "recording_views" VALUES(4392,1212,'2014-07-07 18:50:47.175957','2014-07-07 18:50:47.175957');
INSERT INTO "recording_views" VALUES(4396,3560,'2014-07-07 19:06:16.970869','2014-07-07 19:06:16.970869');
INSERT INTO "recording_views" VALUES(4400,3497,'2014-07-07 19:11:27.353218','2014-07-07 19:11:27.353218');
INSERT INTO "recording_views" VALUES(4401,1212,'2014-07-07 19:12:49.063758','2014-07-07 19:12:49.063758');
INSERT INTO "recording_views" VALUES(4404,1212,'2014-07-07 19:16:13.379187','2014-07-07 19:16:13.379187');
INSERT INTO "recording_views" VALUES(4408,1212,'2014-07-07 19:30:08.285869','2014-07-07 19:30:08.285869');
INSERT INTO "recording_views" VALUES(4415,3560,'2014-07-07 19:44:25.151617','2014-07-07 19:44:25.151617');
INSERT INTO "recording_views" VALUES(4417,1212,'2014-07-07 19:48:32.891802','2014-07-07 19:48:32.891802');
INSERT INTO "recording_views" VALUES(4418,3497,'2014-07-07 19:49:25.937589','2014-07-07 19:49:25.937589');
INSERT INTO "recording_views" VALUES(4421,3689,'2014-07-07 20:12:26.668349','2014-07-07 20:12:26.668349');
INSERT INTO "recording_views" VALUES(4422,3748,'2014-07-07 20:15:19.868063','2014-07-07 20:15:19.868063');
INSERT INTO "recording_views" VALUES(4423,1320,'2014-07-07 20:15:59.832652','2014-07-07 20:15:59.832652');
INSERT INTO "recording_views" VALUES(4424,3689,'2014-07-07 20:17:02.813701','2014-07-07 20:17:02.813701');
INSERT INTO "recording_views" VALUES(4425,3748,'2014-07-07 20:17:44.679962','2014-07-07 20:17:44.679962');
INSERT INTO "recording_views" VALUES(4427,3748,'2014-07-07 20:23:31.149028','2014-07-07 20:23:31.149028');
INSERT INTO "recording_views" VALUES(4429,3476,'2014-07-07 20:27:40.82317','2014-07-07 20:27:40.82317');
INSERT INTO "recording_views" VALUES(4432,3803,'2014-07-07 20:34:14.760886','2014-07-07 20:34:14.760886');
INSERT INTO "recording_views" VALUES(4435,3764,'2014-07-07 20:37:57.896662','2014-07-07 20:37:57.896662');
INSERT INTO "recording_views" VALUES(4440,3497,'2014-07-07 20:48:01.06572','2014-07-07 20:48:01.06572');
INSERT INTO "recording_views" VALUES(4441,3497,'2014-07-07 20:52:00.333321','2014-07-07 20:52:00.333321');
INSERT INTO "recording_views" VALUES(4442,3824,'2014-07-07 21:03:50.94497','2014-07-07 21:03:50.94497');
INSERT INTO "recording_views" VALUES(4444,3811,'2014-07-07 21:15:31.946255','2014-07-07 21:15:31.946255');
INSERT INTO "recording_views" VALUES(4446,3602,'2014-07-07 21:19:44.804488','2014-07-07 21:19:44.804488');
INSERT INTO "recording_views" VALUES(4447,3497,'2014-07-07 21:20:34.918535','2014-07-07 21:20:34.918535');
INSERT INTO "recording_views" VALUES(4449,1275,'2014-07-07 21:26:17.737071','2014-07-07 21:26:17.737071');
INSERT INTO "recording_views" VALUES(4451,1275,'2014-07-07 21:29:42.989352','2014-07-07 21:29:42.989352');
INSERT INTO "recording_views" VALUES(4456,1341,'2014-07-07 21:37:36.773777','2014-07-07 21:37:36.773777');
INSERT INTO "recording_views" VALUES(4458,3710,'2014-07-07 21:39:59.347107','2014-07-07 21:39:59.347107');
INSERT INTO "recording_views" VALUES(4459,3710,'2014-07-07 21:42:17.343589','2014-07-07 21:42:17.343589');
INSERT INTO "recording_views" VALUES(4460,3754,'2014-07-07 21:43:00.209917','2014-07-07 21:43:00.209917');
INSERT INTO "recording_views" VALUES(4461,1275,'2014-07-07 21:43:25.072873','2014-07-07 21:43:25.072873');
INSERT INTO "recording_views" VALUES(4462,3497,'2014-07-07 21:44:33.540526','2014-07-07 21:44:33.540526');
INSERT INTO "recording_views" VALUES(4463,3710,'2014-07-07 21:45:05.809512','2014-07-07 21:45:05.809512');
INSERT INTO "recording_views" VALUES(4466,3560,'2014-07-07 21:49:17.058347','2014-07-07 21:49:17.058347');
INSERT INTO "recording_views" VALUES(4467,1275,'2014-07-07 21:55:01.372818','2014-07-07 21:55:01.372818');
INSERT INTO "recording_views" VALUES(4468,3542,'2014-07-07 21:55:51.867043','2014-07-07 21:55:51.867043');
INSERT INTO "recording_views" VALUES(4470,3527,'2014-07-07 22:14:05.469993','2014-07-07 22:14:05.469993');
INSERT INTO "recording_views" VALUES(4473,3710,'2014-07-07 22:16:19.648973','2014-07-07 22:16:19.648973');
INSERT INTO "recording_views" VALUES(4474,1275,'2014-07-07 22:17:14.293912','2014-07-07 22:17:14.293912');
INSERT INTO "recording_views" VALUES(4475,3527,'2014-07-07 22:17:39.666737','2014-07-07 22:17:39.666737');
INSERT INTO "recording_views" VALUES(4476,154,'2014-07-07 22:23:17.665313','2014-07-07 22:23:17.665313');
INSERT INTO "recording_views" VALUES(4477,3575,'2014-07-07 22:23:22.38849','2014-07-07 22:23:22.38849');
INSERT INTO "recording_views" VALUES(4478,3497,'2014-07-07 22:24:03.731812','2014-07-07 22:24:03.731812');
INSERT INTO "recording_views" VALUES(4479,3710,'2014-07-07 22:25:25.248026','2014-07-07 22:25:25.248026');
INSERT INTO "recording_views" VALUES(4480,3811,'2014-07-07 22:25:54.455893','2014-07-07 22:25:54.455893');
INSERT INTO "recording_views" VALUES(4483,3623,'2014-07-07 22:28:15.659908','2014-07-07 22:28:15.659908');
INSERT INTO "recording_views" VALUES(4484,154,'2014-07-07 22:28:34.036745','2014-07-07 22:28:34.036745');
INSERT INTO "recording_views" VALUES(4486,3710,'2014-07-07 22:32:16.074946','2014-07-07 22:32:16.074946');
INSERT INTO "recording_views" VALUES(4488,3452,'2014-07-07 22:39:19.552062','2014-07-07 22:39:19.552062');
INSERT INTO "recording_views" VALUES(4489,3452,'2014-07-07 22:42:14.829856','2014-07-07 22:42:14.829856');
INSERT INTO "recording_views" VALUES(4490,3452,'2014-07-07 22:44:28.475075','2014-07-07 22:44:28.475075');
INSERT INTO "recording_views" VALUES(4492,3710,'2014-07-07 22:50:03.014228','2014-07-07 22:50:03.014228');
INSERT INTO "recording_views" VALUES(4493,3596,'2014-07-07 22:51:31.310492','2014-07-07 22:51:31.310492');
INSERT INTO "recording_views" VALUES(4494,3736,'2014-07-07 22:53:53.25194','2014-07-07 22:53:53.25194');
INSERT INTO "recording_views" VALUES(4495,1241,'2014-07-07 22:57:25.836686','2014-07-07 22:57:25.836686');
INSERT INTO "recording_views" VALUES(4496,3497,'2014-07-07 22:58:14.752177','2014-07-07 22:58:14.752177');
INSERT INTO "recording_views" VALUES(4498,3497,'2014-07-07 23:01:18.004172','2014-07-07 23:01:18.004172');
INSERT INTO "recording_views" VALUES(4499,3446,'2014-07-07 23:03:39.390374','2014-07-07 23:03:39.390374');
INSERT INTO "recording_views" VALUES(4500,3602,'2014-07-07 23:05:06.373539','2014-07-07 23:05:06.373539');
INSERT INTO "recording_views" VALUES(4501,3710,'2014-07-07 23:05:11.498395','2014-07-07 23:05:11.498395');
INSERT INTO "recording_views" VALUES(4502,3602,'2014-07-07 23:08:50.728276','2014-07-07 23:08:50.728276');
INSERT INTO "recording_views" VALUES(4503,3752,'2014-07-07 23:10:40.177423','2014-07-07 23:10:40.177423');
INSERT INTO "recording_views" VALUES(4504,3491,'2014-07-07 23:11:05.175366','2014-07-07 23:11:05.175366');
INSERT INTO "recording_views" VALUES(4505,3530,'2014-07-07 23:11:40.551836','2014-07-07 23:11:40.551836');
INSERT INTO "recording_views" VALUES(4506,3470,'2014-07-07 23:12:04.472044','2014-07-07 23:12:04.472044');
INSERT INTO "recording_views" VALUES(4507,3533,'2014-07-07 23:14:03.628314','2014-07-07 23:14:03.628314');
INSERT INTO "recording_views" VALUES(4508,3659,'2014-07-07 23:27:16.833444','2014-07-07 23:27:16.833444');
INSERT INTO "recording_views" VALUES(4509,3497,'2014-07-07 23:37:22.099308','2014-07-07 23:37:22.099308');
INSERT INTO "recording_views" VALUES(4510,3986,'2014-07-07 23:55:58.553428','2014-07-07 23:55:58.553428');
INSERT INTO "recording_views" VALUES(4511,3446,'2014-07-08 00:24:06.280828','2014-07-08 00:24:06.280828');
INSERT INTO "recording_views" VALUES(4513,3446,'2014-07-08 00:30:16.224651','2014-07-08 00:30:16.224651');
INSERT INTO "recording_views" VALUES(4517,3446,'2014-07-08 00:38:42.493084','2014-07-08 00:38:42.493084');
INSERT INTO "recording_views" VALUES(4519,3446,'2014-07-08 00:41:25.019462','2014-07-08 00:41:25.019462');
INSERT INTO "recording_views" VALUES(4521,3452,'2014-07-08 00:45:56.622578','2014-07-08 00:45:56.622578');
INSERT INTO "recording_views" VALUES(4522,3497,'2014-07-08 00:46:58.056828','2014-07-08 00:46:58.056828');
INSERT INTO "recording_views" VALUES(4523,3605,'2014-07-08 00:47:10.217826','2014-07-08 00:47:10.217826');
INSERT INTO "recording_views" VALUES(4525,3452,'2014-07-08 00:56:24.707259','2014-07-08 00:56:24.707259');
INSERT INTO "recording_views" VALUES(4526,3805,'2014-07-08 00:58:55.53621','2014-07-08 00:58:55.53621');
INSERT INTO "recording_views" VALUES(4534,3560,'2014-07-08 02:07:11.702382','2014-07-08 02:07:11.702382');
INSERT INTO "recording_views" VALUES(4536,3713,'2014-07-08 03:39:46.663372','2014-07-08 03:39:46.663372');
INSERT INTO "recording_views" VALUES(4540,3605,'2014-07-08 04:15:15.878546','2014-07-08 04:15:15.878546');
INSERT INTO "recording_views" VALUES(4543,3605,'2014-07-08 04:29:01.630937','2014-07-08 04:29:01.630937');
INSERT INTO "recording_views" VALUES(4544,3605,'2014-07-08 04:32:28.462363','2014-07-08 04:32:28.462363');
INSERT INTO "recording_views" VALUES(4546,3605,'2014-07-08 04:34:49.024093','2014-07-08 04:34:49.024093');
INSERT INTO "recording_views" VALUES(4547,3608,'2014-07-08 04:36:42.796617','2014-07-08 04:36:42.796617');
INSERT INTO "recording_views" VALUES(4548,3608,'2014-07-08 04:57:18.812692','2014-07-08 04:57:18.812692');
INSERT INTO "recording_views" VALUES(4552,1266,'2014-07-08 05:15:04.216154','2014-07-08 05:15:04.216154');
INSERT INTO "recording_views" VALUES(4555,1242,'2014-07-08 05:20:03.199679','2014-07-08 05:20:03.199679');
INSERT INTO "recording_views" VALUES(4556,3758,'2014-07-08 05:27:48.701708','2014-07-08 05:27:48.701708');
INSERT INTO "recording_views" VALUES(4558,3779,'2014-07-08 05:43:18.409247','2014-07-08 05:43:18.409247');
INSERT INTO "recording_views" VALUES(4559,3758,'2014-07-08 05:47:09.598696','2014-07-08 05:47:09.598696');
INSERT INTO "recording_views" VALUES(4561,3602,'2014-07-08 05:59:59.573566','2014-07-08 05:59:59.573566');
INSERT INTO "recording_views" VALUES(4564,3736,'2014-07-08 06:21:56.559137','2014-07-08 06:21:56.559137');
INSERT INTO "recording_views" VALUES(4565,3758,'2014-07-08 06:26:30.852147','2014-07-08 06:26:30.852147');
INSERT INTO "recording_views" VALUES(4566,3736,'2014-07-08 06:29:20.758613','2014-07-08 06:29:20.758613');
INSERT INTO "recording_views" VALUES(4567,3758,'2014-07-08 06:39:34.341674','2014-07-08 06:39:34.341674');
INSERT INTO "recording_views" VALUES(4568,3758,'2014-07-08 06:42:58.434194','2014-07-08 06:42:58.434194');
INSERT INTO "recording_views" VALUES(4569,3758,'2014-07-08 06:52:16.353638','2014-07-08 06:52:16.353638');
INSERT INTO "recording_views" VALUES(4570,3736,'2014-07-08 06:52:42.371211','2014-07-08 06:52:42.371211');
INSERT INTO "recording_views" VALUES(4571,3646,'2014-07-08 06:55:30.726423','2014-07-08 06:55:30.726423');
INSERT INTO "recording_views" VALUES(4573,3559,'2014-07-08 07:10:39.105859','2014-07-08 07:10:39.105859');
INSERT INTO "recording_views" VALUES(4574,3560,'2014-07-08 07:11:10.474493','2014-07-08 07:11:10.474493');
INSERT INTO "recording_views" VALUES(4575,3560,'2014-07-08 07:14:28.358618','2014-07-08 07:14:28.358618');
INSERT INTO "recording_views" VALUES(4576,3646,'2014-07-08 07:14:41.137302','2014-07-08 07:14:41.137302');
INSERT INTO "recording_views" VALUES(4577,3560,'2014-07-08 07:17:39.910107','2014-07-08 07:17:39.910107');
INSERT INTO "recording_views" VALUES(4578,3560,'2014-07-08 07:20:00.701818','2014-07-08 07:20:00.701818');
INSERT INTO "recording_views" VALUES(4579,3497,'2014-07-08 07:21:14.846424','2014-07-08 07:21:14.846424');
INSERT INTO "recording_views" VALUES(4582,3475,'2014-07-08 07:29:43.813955','2014-07-08 07:29:43.813955');
INSERT INTO "recording_views" VALUES(4584,3646,'2014-07-08 07:45:09.904428','2014-07-08 07:45:09.904428');
INSERT INTO "recording_views" VALUES(4587,3646,'2014-07-08 08:03:50.587329','2014-07-08 08:03:50.587329');
INSERT INTO "recording_views" VALUES(4591,3758,'2014-07-08 08:23:24.279897','2014-07-08 08:23:24.279897');
INSERT INTO "recording_views" VALUES(4595,3758,'2014-07-08 08:40:57.246795','2014-07-08 08:40:57.246795');
INSERT INTO "recording_views" VALUES(4597,3758,'2014-07-08 08:48:27.230617','2014-07-08 08:48:27.230617');
INSERT INTO "recording_views" VALUES(4598,3716,'2014-07-08 08:51:04.719976','2014-07-08 08:51:04.719976');
INSERT INTO "recording_views" VALUES(4599,3452,'2014-07-08 08:51:53.696322','2014-07-08 08:51:53.696322');
INSERT INTO "recording_views" VALUES(4601,3758,'2014-07-08 08:54:47.094536','2014-07-08 08:54:47.094536');
INSERT INTO "recording_views" VALUES(4603,3758,'2014-07-08 08:57:31.939584','2014-07-08 08:57:31.939584');
INSERT INTO "recording_views" VALUES(4604,3559,'2014-07-08 08:57:50.222379','2014-07-08 08:57:50.222379');
INSERT INTO "recording_views" VALUES(4606,3559,'2014-07-08 09:02:18.99412','2014-07-08 09:02:18.99412');
INSERT INTO "recording_views" VALUES(4607,3758,'2014-07-08 09:02:24.196531','2014-07-08 09:02:24.196531');
INSERT INTO "recording_views" VALUES(4608,3758,'2014-07-08 09:04:27.369965','2014-07-08 09:04:27.369965');
INSERT INTO "recording_views" VALUES(4609,3559,'2014-07-08 09:05:05.224434','2014-07-08 09:05:05.224434');
INSERT INTO "recording_views" VALUES(4612,3559,'2014-07-08 09:15:43.937027','2014-07-08 09:15:43.937027');
INSERT INTO "recording_views" VALUES(4614,3559,'2014-07-08 09:21:35.279918','2014-07-08 09:21:35.279918');
INSERT INTO "recording_views" VALUES(4615,3559,'2014-07-08 09:24:25.929001','2014-07-08 09:24:25.929001');
INSERT INTO "recording_views" VALUES(4616,3559,'2014-07-08 09:30:55.598002','2014-07-08 09:30:55.598002');
INSERT INTO "recording_views" VALUES(4617,3559,'2014-07-08 09:35:09.633475','2014-07-08 09:35:09.633475');
INSERT INTO "recording_views" VALUES(4618,3677,'2014-07-08 09:52:57.872164','2014-07-08 09:52:57.872164');
INSERT INTO "recording_views" VALUES(4619,3677,'2014-07-08 09:55:30.7551','2014-07-08 09:55:30.7551');
INSERT INTO "recording_views" VALUES(4621,3809,'2014-07-08 10:05:39.257525','2014-07-08 10:05:39.257525');
INSERT INTO "recording_views" VALUES(4622,3677,'2014-07-08 10:05:42.42366','2014-07-08 10:05:42.42366');
INSERT INTO "recording_views" VALUES(4623,3809,'2014-07-08 10:07:51.253205','2014-07-08 10:07:51.253205');
INSERT INTO "recording_views" VALUES(4624,3559,'2014-07-08 10:09:03.389456','2014-07-08 10:09:03.389456');
INSERT INTO "recording_views" VALUES(4625,3677,'2014-07-08 10:09:19.798916','2014-07-08 10:09:19.798916');
INSERT INTO "recording_views" VALUES(4626,3665,'2014-07-08 10:09:48.082013','2014-07-08 10:09:48.082013');
INSERT INTO "recording_views" VALUES(4627,3665,'2014-07-08 10:12:09.177368','2014-07-08 10:12:09.177368');
INSERT INTO "recording_views" VALUES(4628,3677,'2014-07-08 10:12:40.046881','2014-07-08 10:12:40.046881');
INSERT INTO "recording_views" VALUES(4630,3475,'2014-07-08 10:14:49.647636','2014-07-08 10:14:49.647636');
INSERT INTO "recording_views" VALUES(4632,3452,'2014-07-08 10:16:36.144973','2014-07-08 10:16:36.144973');
INSERT INTO "recording_views" VALUES(4633,3677,'2014-07-08 10:16:36.367331','2014-07-08 10:16:36.367331');
INSERT INTO "recording_views" VALUES(4636,3677,'2014-07-08 10:20:28.68143','2014-07-08 10:20:28.68143');
INSERT INTO "recording_views" VALUES(4637,3452,'2014-07-08 10:38:36.705187','2014-07-08 10:38:36.705187');
INSERT INTO "recording_views" VALUES(4638,3452,'2014-07-08 10:40:55.75461','2014-07-08 10:40:55.75461');
INSERT INTO "recording_views" VALUES(4640,3560,'2014-07-08 10:48:30.499776','2014-07-08 10:48:30.499776');
INSERT INTO "recording_views" VALUES(4643,3667,'2014-07-08 10:51:25.050301','2014-07-08 10:51:25.050301');
INSERT INTO "recording_views" VALUES(4644,3667,'2014-07-08 10:53:34.072163','2014-07-08 10:53:34.072163');
INSERT INTO "recording_views" VALUES(4647,3755,'2014-07-08 10:58:26.278281','2014-07-08 10:58:26.278281');
INSERT INTO "recording_views" VALUES(4655,3722,'2014-07-08 11:25:52.798976','2014-07-08 11:25:52.798976');
INSERT INTO "recording_views" VALUES(4656,3542,'2014-07-08 11:27:49.75595','2014-07-08 11:27:49.75595');
INSERT INTO "recording_views" VALUES(4657,3722,'2014-07-08 11:28:43.563078','2014-07-08 11:28:43.563078');
INSERT INTO "recording_views" VALUES(4677,3689,'2014-07-08 12:00:13.268035','2014-07-08 12:00:13.268035');
INSERT INTO "recording_views" VALUES(4678,3560,'2014-07-08 12:01:16.021025','2014-07-08 12:01:16.021025');
INSERT INTO "recording_views" VALUES(4679,3815,'2014-07-08 12:03:51.509943','2014-07-08 12:03:51.509943');
INSERT INTO "recording_views" VALUES(4683,3467,'2014-07-08 12:06:07.202853','2014-07-08 12:06:07.202853');
INSERT INTO "recording_views" VALUES(4689,3710,'2014-07-08 12:12:53.917759','2014-07-08 12:12:53.917759');
INSERT INTO "recording_views" VALUES(4690,3467,'2014-07-08 12:15:01.348401','2014-07-08 12:15:01.348401');
INSERT INTO "recording_views" VALUES(4691,3734,'2014-07-08 12:16:03.81072','2014-07-08 12:16:03.81072');
INSERT INTO "recording_views" VALUES(4692,3560,'2014-07-08 12:16:50.600344','2014-07-08 12:16:50.600344');
INSERT INTO "recording_views" VALUES(4694,3709,'2014-07-08 12:18:34.237766','2014-07-08 12:18:34.237766');
INSERT INTO "recording_views" VALUES(4695,3560,'2014-07-08 12:18:52.512471','2014-07-08 12:18:52.512471');
INSERT INTO "recording_views" VALUES(4696,3734,'2014-07-08 12:19:38.955351','2014-07-08 12:19:38.955351');
INSERT INTO "recording_views" VALUES(4697,3437,'2014-07-08 12:22:31.846871','2014-07-08 12:22:31.846871');
INSERT INTO "recording_views" VALUES(4698,3602,'2014-07-08 12:23:29.475669','2014-07-08 12:23:29.475669');
INSERT INTO "recording_views" VALUES(4699,3451,'2014-07-08 12:23:30.927136','2014-07-08 12:23:30.927136');
INSERT INTO "recording_views" VALUES(4700,3602,'2014-07-08 12:30:08.906734','2014-07-08 12:30:08.906734');
INSERT INTO "recording_views" VALUES(4705,3560,'2014-07-08 12:42:58.85197','2014-07-08 12:42:58.85197');
INSERT INTO "recording_views" VALUES(4708,3560,'2014-07-08 12:45:04.427515','2014-07-08 12:45:04.427515');
INSERT INTO "recording_views" VALUES(4714,3710,'2014-07-08 12:58:52.905367','2014-07-08 12:58:52.905367');
INSERT INTO "recording_views" VALUES(4715,3710,'2014-07-08 13:00:17.018908','2014-07-08 13:00:17.018908');
INSERT INTO "recording_views" VALUES(4717,166,'2014-07-08 13:02:05.778362','2014-07-08 13:02:05.778362');
INSERT INTO "recording_views" VALUES(4718,166,'2014-07-08 13:02:08.535461','2014-07-08 13:02:08.535461');
INSERT INTO "recording_views" VALUES(4719,166,'2014-07-08 13:02:10.243304','2014-07-08 13:02:10.243304');
INSERT INTO "recording_views" VALUES(4720,166,'2014-07-08 13:02:12.369699','2014-07-08 13:02:12.369699');
INSERT INTO "recording_views" VALUES(4721,166,'2014-07-08 13:02:15.234157','2014-07-08 13:02:15.234157');
INSERT INTO "recording_views" VALUES(4722,166,'2014-07-08 13:02:16.368439','2014-07-08 13:02:16.368439');
INSERT INTO "recording_views" VALUES(4723,166,'2014-07-08 13:02:18.255462','2014-07-08 13:02:18.255462');
INSERT INTO "recording_views" VALUES(4724,166,'2014-07-08 13:02:26.608622','2014-07-08 13:02:26.608622');
INSERT INTO "recording_views" VALUES(4735,3692,'2014-07-08 13:06:35.500756','2014-07-08 13:06:35.500756');
INSERT INTO "recording_views" VALUES(4738,3692,'2014-07-08 13:10:13.120448','2014-07-08 13:10:13.120448');
INSERT INTO "recording_views" VALUES(4740,3785,'2014-07-08 13:11:26.839983','2014-07-08 13:11:26.839983');
INSERT INTO "recording_views" VALUES(4741,3692,'2014-07-08 13:12:14.14994','2014-07-08 13:12:14.14994');
INSERT INTO "recording_views" VALUES(4743,3710,'2014-07-08 13:13:37.913957','2014-07-08 13:13:37.913957');
INSERT INTO "recording_views" VALUES(4744,3692,'2014-07-08 13:14:41.331429','2014-07-08 13:14:41.331429');
INSERT INTO "recording_views" VALUES(4746,3710,'2014-07-08 13:15:36.966132','2014-07-08 13:15:36.966132');
INSERT INTO "recording_views" VALUES(4747,3602,'2014-07-08 13:15:37.971441','2014-07-08 13:15:37.971441');
INSERT INTO "recording_views" VALUES(4749,3710,'2014-07-08 13:17:52.135263','2014-07-08 13:17:52.135263');
INSERT INTO "recording_views" VALUES(4751,3602,'2014-07-08 13:19:51.518021','2014-07-08 13:19:51.518021');
INSERT INTO "recording_views" VALUES(4754,3602,'2014-07-08 13:24:18.847037','2014-07-08 13:24:18.847037');
INSERT INTO "recording_views" VALUES(4755,3602,'2014-07-08 13:26:54.549837','2014-07-08 13:26:54.549837');
INSERT INTO "recording_views" VALUES(4756,3692,'2014-07-08 13:27:15.594369','2014-07-08 13:27:15.594369');
INSERT INTO "recording_views" VALUES(4757,3728,'2014-07-08 13:27:42.166101','2014-07-08 13:27:42.166101');
INSERT INTO "recording_views" VALUES(4759,3692,'2014-07-08 13:30:33.91827','2014-07-08 13:30:33.91827');
INSERT INTO "recording_views" VALUES(4760,3602,'2014-07-08 13:30:53.718298','2014-07-08 13:30:53.718298');
INSERT INTO "recording_views" VALUES(4761,3451,'2014-07-08 13:31:19.674373','2014-07-08 13:31:19.674373');
INSERT INTO "recording_views" VALUES(4762,3451,'2014-07-08 13:34:46.167009','2014-07-08 13:34:46.167009');
INSERT INTO "recording_views" VALUES(4763,3602,'2014-07-08 13:35:23.856342','2014-07-08 13:35:23.856342');
INSERT INTO "recording_views" VALUES(4764,3451,'2014-07-08 13:37:38.485606','2014-07-08 13:37:38.485606');
INSERT INTO "recording_views" VALUES(4765,3692,'2014-07-08 13:38:24.348684','2014-07-08 13:38:24.348684');
INSERT INTO "recording_views" VALUES(4766,3677,'2014-07-08 13:39:51.126225','2014-07-08 13:39:51.126225');
INSERT INTO "recording_views" VALUES(4767,3602,'2014-07-08 13:40:07.762916','2014-07-08 13:40:07.762916');
INSERT INTO "recording_views" VALUES(4768,3497,'2014-07-08 13:40:13.264061','2014-07-08 13:40:13.264061');
INSERT INTO "recording_views" VALUES(4769,3692,'2014-07-08 13:40:34.361898','2014-07-08 13:40:34.361898');
INSERT INTO "recording_views" VALUES(4770,3451,'2014-07-08 13:41:27.548779','2014-07-08 13:41:27.548779');
INSERT INTO "recording_views" VALUES(4771,3677,'2014-07-08 13:42:31.077868','2014-07-08 13:42:31.077868');
INSERT INTO "recording_views" VALUES(4773,177,'2014-07-08 13:43:51.069887','2014-07-08 13:43:51.069887');
INSERT INTO "recording_views" VALUES(4774,3692,'2014-07-08 13:44:14.324473','2014-07-08 13:44:14.324473');
INSERT INTO "recording_views" VALUES(4775,3451,'2014-07-08 13:44:46.775781','2014-07-08 13:44:46.775781');
INSERT INTO "recording_views" VALUES(4776,177,'2014-07-08 13:46:03.252013','2014-07-08 13:46:03.252013');
INSERT INTO "recording_views" VALUES(4777,3811,'2014-07-08 13:46:43.083436','2014-07-08 13:46:43.083436');
INSERT INTO "recording_views" VALUES(4778,3451,'2014-07-08 13:47:21.244539','2014-07-08 13:47:21.244539');
INSERT INTO "recording_views" VALUES(4779,3451,'2014-07-08 13:49:28.886','2014-07-08 13:49:28.886');
INSERT INTO "recording_views" VALUES(4781,3451,'2014-07-08 13:52:41.546239','2014-07-08 13:52:41.546239');
INSERT INTO "recording_views" VALUES(4784,3709,'2014-07-08 13:57:05.092202','2014-07-08 13:57:05.092202');
INSERT INTO "recording_views" VALUES(4785,3602,'2014-07-08 13:57:19.065298','2014-07-08 13:57:19.065298');
INSERT INTO "recording_views" VALUES(4790,3451,'2014-07-08 14:01:15.089707','2014-07-08 14:01:15.089707');
INSERT INTO "recording_views" VALUES(4794,3451,'2014-07-08 14:04:04.371221','2014-07-08 14:04:04.371221');
INSERT INTO "recording_views" VALUES(4801,3602,'2014-07-08 14:12:17.43037','2014-07-08 14:12:17.43037');
INSERT INTO "recording_views" VALUES(4803,3497,'2014-07-08 14:15:49.678727','2014-07-08 14:15:49.678727');
INSERT INTO "recording_views" VALUES(4804,3709,'2014-07-08 14:15:54.354034','2014-07-08 14:15:54.354034');
INSERT INTO "recording_views" VALUES(4805,3451,'2014-07-08 14:17:15.404172','2014-07-08 14:17:15.404172');
INSERT INTO "recording_views" VALUES(4806,3602,'2014-07-08 14:17:51.401481','2014-07-08 14:17:51.401481');
INSERT INTO "recording_views" VALUES(4807,3960,'2014-07-08 14:18:27.677571','2014-07-08 14:18:27.677571');
INSERT INTO "recording_views" VALUES(4808,3709,'2014-07-08 14:21:04.490541','2014-07-08 14:21:04.490541');
INSERT INTO "recording_views" VALUES(4809,3960,'2014-07-08 14:23:16.656659','2014-07-08 14:23:16.656659');
INSERT INTO "recording_views" VALUES(4812,3667,'2014-07-08 14:26:22.658332','2014-07-08 14:26:22.658332');
INSERT INTO "recording_views" VALUES(4814,3602,'2014-07-08 14:28:47.806073','2014-07-08 14:28:47.806073');
INSERT INTO "recording_views" VALUES(4832,3602,'2014-07-08 15:04:39.714342','2014-07-08 15:04:39.714342');
INSERT INTO "recording_views" VALUES(4833,3602,'2014-07-08 15:06:07.532522','2014-07-08 15:06:07.532522');
INSERT INTO "recording_views" VALUES(4834,3488,'2014-07-08 15:07:26.669609','2014-07-08 15:07:26.669609');
INSERT INTO "recording_views" VALUES(4835,3632,'2014-07-08 15:07:56.593636','2014-07-08 15:07:56.593636');
INSERT INTO "recording_views" VALUES(4837,3632,'2014-07-08 15:11:16.489226','2014-07-08 15:11:16.489226');
INSERT INTO "recording_views" VALUES(4838,3746,'2014-07-08 15:12:51.810576','2014-07-08 15:12:51.810576');
INSERT INTO "recording_views" VALUES(4839,3725,'2014-07-08 15:13:09.057675','2014-07-08 15:13:09.057675');
INSERT INTO "recording_views" VALUES(4840,3824,'2014-07-08 15:13:52.864775','2014-07-08 15:13:52.864775');
INSERT INTO "recording_views" VALUES(4843,3725,'2014-07-08 15:22:32.044778','2014-07-08 15:22:32.044778');
INSERT INTO "recording_views" VALUES(4847,3725,'2014-07-08 15:31:43.157703','2014-07-08 15:31:43.157703');
INSERT INTO "recording_views" VALUES(4849,3728,'2014-07-08 15:38:26.494099','2014-07-08 15:38:26.494099');
INSERT INTO "recording_views" VALUES(4850,3452,'2014-07-08 15:38:28.687932','2014-07-08 15:38:28.687932');
INSERT INTO "recording_views" VALUES(4851,3725,'2014-07-08 15:40:47.268041','2014-07-08 15:40:47.268041');
INSERT INTO "recording_views" VALUES(4865,3548,'2014-07-08 16:13:37.637616','2014-07-08 16:13:37.637616');
INSERT INTO "recording_views" VALUES(4866,3548,'2014-07-08 16:16:27.574675','2014-07-08 16:16:27.574675');
INSERT INTO "recording_views" VALUES(4867,103,'2014-07-08 16:17:41.720985','2014-07-08 16:17:41.720985');
INSERT INTO "recording_views" VALUES(4868,3806,'2014-07-08 16:19:32.75498','2014-07-08 16:19:32.75498');
INSERT INTO "recording_views" VALUES(4870,3716,'2014-07-08 16:20:42.488496','2014-07-08 16:20:42.488496');
INSERT INTO "recording_views" VALUES(4875,3731,'2014-07-08 16:46:22.562345','2014-07-08 16:46:22.562345');
INSERT INTO "recording_views" VALUES(4879,3731,'2014-07-08 16:53:53.949937','2014-07-08 16:53:53.949937');
INSERT INTO "recording_views" VALUES(4891,3542,'2014-07-08 17:33:37.054125','2014-07-08 17:33:37.054125');
INSERT INTO "recording_views" VALUES(4892,3647,'2014-07-08 17:34:31.508281','2014-07-08 17:34:31.508281');
INSERT INTO "recording_views" VALUES(4893,3626,'2014-07-08 17:35:07.414454','2014-07-08 17:35:07.414454');
INSERT INTO "recording_views" VALUES(4894,3716,'2014-07-08 17:35:40.602301','2014-07-08 17:35:40.602301');
INSERT INTO "recording_views" VALUES(4895,3662,'2014-07-08 17:35:42.926907','2014-07-08 17:35:42.926907');
INSERT INTO "recording_views" VALUES(4896,3647,'2014-07-08 17:36:44.318815','2014-07-08 17:36:44.318815');
INSERT INTO "recording_views" VALUES(4899,3716,'2014-07-08 17:40:31.722511','2014-07-08 17:40:31.722511');
INSERT INTO "recording_views" VALUES(4900,3806,'2014-07-08 17:40:56.890115','2014-07-08 17:40:56.890115');
INSERT INTO "recording_views" VALUES(4901,3715,'2014-07-08 17:41:30.843133','2014-07-08 17:41:30.843133');
INSERT INTO "recording_views" VALUES(4903,3488,'2014-07-08 17:46:01.811069','2014-07-08 17:46:01.811069');
INSERT INTO "recording_views" VALUES(4904,3716,'2014-07-08 17:47:02.64169','2014-07-08 17:47:02.64169');
INSERT INTO "recording_views" VALUES(4905,3497,'2014-07-08 17:49:13.421372','2014-07-08 17:49:13.421372');
INSERT INTO "recording_views" VALUES(4908,3488,'2014-07-08 17:57:22.688622','2014-07-08 17:57:22.688622');
INSERT INTO "recording_views" VALUES(4909,3566,'2014-07-08 17:58:28.421634','2014-07-08 17:58:28.421634');
INSERT INTO "recording_views" VALUES(4910,3452,'2014-07-08 18:00:01.250926','2014-07-08 18:00:01.250926');
INSERT INTO "recording_views" VALUES(4911,3728,'2014-07-08 18:08:45.018542','2014-07-08 18:08:45.018542');
INSERT INTO "recording_views" VALUES(4912,3809,'2014-07-08 18:09:14.146579','2014-07-08 18:09:14.146579');
INSERT INTO "recording_views" VALUES(4913,3506,'2014-07-08 18:09:56.724283','2014-07-08 18:09:56.724283');
INSERT INTO "recording_views" VALUES(4914,3506,'2014-07-08 18:11:57.089894','2014-07-08 18:11:57.089894');
INSERT INTO "recording_views" VALUES(4915,3437,'2014-07-08 18:13:37.976263','2014-07-08 18:13:37.976263');
INSERT INTO "recording_views" VALUES(4916,3647,'2014-07-08 18:16:19.752753','2014-07-08 18:16:19.752753');
INSERT INTO "recording_views" VALUES(4919,3806,'2014-07-08 18:29:04.623498','2014-07-08 18:29:04.623498');
INSERT INTO "recording_views" VALUES(4920,3809,'2014-07-08 18:30:44.870951','2014-07-08 18:30:44.870951');
INSERT INTO "recording_views" VALUES(4922,3496,'2014-07-08 18:33:18.575627','2014-07-08 18:33:18.575627');
INSERT INTO "recording_views" VALUES(4927,3596,'2014-07-08 18:55:35.219729','2014-07-08 18:55:35.219729');
INSERT INTO "recording_views" VALUES(4931,3620,'2014-07-08 18:59:38.320112','2014-07-08 18:59:38.320112');
INSERT INTO "recording_views" VALUES(4935,3623,'2014-07-08 19:03:25.463922','2014-07-08 19:03:25.463922');
INSERT INTO "recording_views" VALUES(4936,3806,'2014-07-08 19:03:26.678961','2014-07-08 19:03:26.678961');
INSERT INTO "recording_views" VALUES(4939,3661,'2014-07-08 19:08:24.752779','2014-07-08 19:08:24.752779');
INSERT INTO "recording_views" VALUES(4941,3620,'2014-07-08 19:08:56.986485','2014-07-08 19:08:56.986485');
INSERT INTO "recording_views" VALUES(4944,3620,'2014-07-08 19:13:04.791017','2014-07-08 19:13:04.791017');
INSERT INTO "recording_views" VALUES(4947,3623,'2014-07-08 19:15:40.482154','2014-07-08 19:15:40.482154');
INSERT INTO "recording_views" VALUES(4951,3620,'2014-07-08 19:17:36.042961','2014-07-08 19:17:36.042961');
INSERT INTO "recording_views" VALUES(4953,3623,'2014-07-08 19:19:19.177259','2014-07-08 19:19:19.177259');
INSERT INTO "recording_views" VALUES(4954,3467,'2014-07-08 19:19:34.782912','2014-07-08 19:19:34.782912');
INSERT INTO "recording_views" VALUES(4957,3620,'2014-07-08 19:21:37.450556','2014-07-08 19:21:37.450556');
INSERT INTO "recording_views" VALUES(4959,233,'2014-07-08 19:21:56.858766','2014-07-08 19:21:56.858766');
INSERT INTO "recording_views" VALUES(4960,3623,'2014-07-08 19:23:21.693369','2014-07-08 19:23:21.693369');
INSERT INTO "recording_views" VALUES(4962,3620,'2014-07-08 19:27:50.805367','2014-07-08 19:27:50.805367');
INSERT INTO "recording_views" VALUES(4964,3602,'2014-07-08 19:29:44.975596','2014-07-08 19:29:44.975596');
INSERT INTO "recording_views" VALUES(4968,3806,'2014-07-08 19:37:27.198156','2014-07-08 19:37:27.198156');
INSERT INTO "recording_views" VALUES(4970,3620,'2014-07-08 19:37:33.082589','2014-07-08 19:37:33.082589');
INSERT INTO "recording_views" VALUES(4974,3596,'2014-07-08 19:40:05.239269','2014-07-08 19:40:05.239269');
INSERT INTO "recording_views" VALUES(4976,3806,'2014-07-08 19:42:00.321281','2014-07-08 19:42:00.321281');
INSERT INTO "recording_views" VALUES(4977,3668,'2014-07-08 19:42:10.819573','2014-07-08 19:42:10.819573');
INSERT INTO "recording_views" VALUES(4983,3661,'2014-07-08 19:46:28.531952','2014-07-08 19:46:28.531952');
INSERT INTO "recording_views" VALUES(4984,3806,'2014-07-08 19:46:38.115492','2014-07-08 19:46:38.115492');
INSERT INTO "recording_views" VALUES(4985,3497,'2014-07-08 19:46:52.675545','2014-07-08 19:46:52.675545');
INSERT INTO "recording_views" VALUES(4997,3620,'2014-07-08 19:54:27.804464','2014-07-08 19:54:27.804464');
INSERT INTO "recording_views" VALUES(5008,3620,'2014-07-08 20:04:56.236213','2014-07-08 20:04:56.236213');
INSERT INTO "recording_views" VALUES(5009,3434,'2014-07-08 20:06:06.282361','2014-07-08 20:06:06.282361');
INSERT INTO "recording_views" VALUES(5014,3452,'2014-07-08 20:08:59.655113','2014-07-08 20:08:59.655113');
INSERT INTO "recording_views" VALUES(5016,3620,'2014-07-08 20:10:12.673276','2014-07-08 20:10:12.673276');
INSERT INTO "recording_views" VALUES(5017,3452,'2014-07-08 20:10:59.84334','2014-07-08 20:10:59.84334');
INSERT INTO "recording_views" VALUES(5018,3761,'2014-07-08 20:11:03.183007','2014-07-08 20:11:03.183007');
INSERT INTO "recording_views" VALUES(5020,3683,'2014-07-08 20:11:55.244812','2014-07-08 20:11:55.244812');
INSERT INTO "recording_views" VALUES(5022,3452,'2014-07-08 20:13:04.383984','2014-07-08 20:13:04.383984');
INSERT INTO "recording_views" VALUES(5023,3443,'2014-07-08 20:13:23.993471','2014-07-08 20:13:23.993471');
INSERT INTO "recording_views" VALUES(5024,3434,'2014-07-08 20:14:08.928297','2014-07-08 20:14:08.928297');
INSERT INTO "recording_views" VALUES(5025,3683,'2014-07-08 20:14:33.197847','2014-07-08 20:14:33.197847');
INSERT INTO "recording_views" VALUES(5035,3653,'2014-07-08 20:34:11.875793','2014-07-08 20:34:11.875793');
INSERT INTO "recording_views" VALUES(5036,3467,'2014-07-08 20:36:31.601594','2014-07-08 20:36:31.601594');
INSERT INTO "recording_views" VALUES(5048,3722,'2014-07-08 20:54:37.842539','2014-07-08 20:54:37.842539');
INSERT INTO "recording_views" VALUES(5052,3758,'2014-07-08 20:58:55.287685','2014-07-08 20:58:55.287685');
INSERT INTO "recording_views" VALUES(5056,3640,'2014-07-08 21:01:13.178906','2014-07-08 21:01:13.178906');
INSERT INTO "recording_views" VALUES(5058,3758,'2014-07-08 21:05:54.744428','2014-07-08 21:05:54.744428');
INSERT INTO "recording_views" VALUES(5060,3683,'2014-07-08 21:12:57.332751','2014-07-08 21:12:57.332751');
INSERT INTO "recording_views" VALUES(5061,3437,'2014-07-08 21:16:33.382954','2014-07-08 21:16:33.382954');
INSERT INTO "recording_views" VALUES(5062,3640,'2014-07-08 21:22:10.768995','2014-07-08 21:22:10.768995');
INSERT INTO "recording_views" VALUES(5063,3659,'2014-07-08 21:22:11.320758','2014-07-08 21:22:11.320758');
INSERT INTO "recording_views" VALUES(5064,3752,'2014-07-08 21:22:22.239306','2014-07-08 21:22:22.239306');
INSERT INTO "recording_views" VALUES(5065,3640,'2014-07-08 21:30:37.470414','2014-07-08 21:30:37.470414');
INSERT INTO "recording_views" VALUES(5066,3752,'2014-07-08 21:36:59.195099','2014-07-08 21:36:59.195099');
INSERT INTO "recording_views" VALUES(5067,3640,'2014-07-08 21:40:36.700883','2014-07-08 21:40:36.700883');
INSERT INTO "recording_views" VALUES(5068,3640,'2014-07-08 21:42:36.716342','2014-07-08 21:42:36.716342');
INSERT INTO "recording_views" VALUES(5069,3635,'2014-07-08 21:45:26.644206','2014-07-08 21:45:26.644206');
INSERT INTO "recording_views" VALUES(5070,3560,'2014-07-08 21:47:39.436022','2014-07-08 21:47:39.436022');
INSERT INTO "recording_views" VALUES(5071,3620,'2014-07-08 21:48:54.846273','2014-07-08 21:48:54.846273');
INSERT INTO "recording_views" VALUES(5072,3806,'2014-07-08 22:02:06.143515','2014-07-08 22:02:06.143515');
INSERT INTO "recording_views" VALUES(5073,3806,'2014-07-08 22:06:38.499135','2014-07-08 22:06:38.499135');
INSERT INTO "recording_views" VALUES(5077,3509,'2014-07-08 22:20:12.290157','2014-07-08 22:20:12.290157');
INSERT INTO "recording_views" VALUES(5078,3806,'2014-07-08 22:20:25.956212','2014-07-08 22:20:25.956212');
INSERT INTO "recording_views" VALUES(5081,3509,'2014-07-08 22:24:49.57073','2014-07-08 22:24:49.57073');
INSERT INTO "recording_views" VALUES(5082,3833,'2014-07-08 22:25:04.082975','2014-07-08 22:25:04.082975');
INSERT INTO "recording_views" VALUES(5083,3806,'2014-07-08 22:25:49.336587','2014-07-08 22:25:49.336587');
INSERT INTO "recording_views" VALUES(5084,3806,'2014-07-08 22:27:08.833475','2014-07-08 22:27:08.833475');
INSERT INTO "recording_views" VALUES(5085,3640,'2014-07-08 22:27:29.639694','2014-07-08 22:27:29.639694');
INSERT INTO "recording_views" VALUES(5086,3452,'2014-07-08 22:28:55.102997','2014-07-08 22:28:55.102997');
INSERT INTO "recording_views" VALUES(5088,3640,'2014-07-08 22:30:05.997894','2014-07-08 22:30:05.997894');
INSERT INTO "recording_views" VALUES(5090,3640,'2014-07-08 22:33:15.75262','2014-07-08 22:33:15.75262');
INSERT INTO "recording_views" VALUES(5091,3818,'2014-07-08 22:33:41.705035','2014-07-08 22:33:41.705035');
INSERT INTO "recording_views" VALUES(5092,3803,'2014-07-08 22:34:25.300285','2014-07-08 22:34:25.300285');
INSERT INTO "recording_views" VALUES(5093,3818,'2014-07-08 22:36:59.526376','2014-07-08 22:36:59.526376');
INSERT INTO "recording_views" VALUES(5094,3785,'2014-07-08 22:37:05.406755','2014-07-08 22:37:05.406755');
INSERT INTO "recording_views" VALUES(5095,3803,'2014-07-08 22:37:23.158745','2014-07-08 22:37:23.158745');
INSERT INTO "recording_views" VALUES(5096,3794,'2014-07-08 22:38:18.564638','2014-07-08 22:38:18.564638');
INSERT INTO "recording_views" VALUES(5097,3806,'2014-07-08 22:39:21.153348','2014-07-08 22:39:21.153348');
INSERT INTO "recording_views" VALUES(5099,3755,'2014-07-08 22:40:26.657301','2014-07-08 22:40:26.657301');
INSERT INTO "recording_views" VALUES(5100,3755,'2014-07-08 22:54:13.129737','2014-07-08 22:54:13.129737');
INSERT INTO "recording_views" VALUES(5101,3661,'2014-07-08 22:57:32.206941','2014-07-08 22:57:32.206941');
INSERT INTO "recording_views" VALUES(5102,3806,'2014-07-08 23:01:12.477996','2014-07-08 23:01:12.477996');
INSERT INTO "recording_views" VALUES(5103,3560,'2014-07-08 23:03:39.367699','2014-07-08 23:03:39.367699');
INSERT INTO "recording_views" VALUES(5104,3755,'2014-07-08 23:08:38.459907','2014-07-08 23:08:38.459907');
INSERT INTO "recording_views" VALUES(5105,3755,'2014-07-08 23:11:27.526192','2014-07-08 23:11:27.526192');
INSERT INTO "recording_views" VALUES(5106,3473,'2014-07-08 23:27:28.755898','2014-07-08 23:27:28.755898');
INSERT INTO "recording_views" VALUES(5108,3521,'2014-07-08 23:28:57.71972','2014-07-08 23:28:57.71972');
INSERT INTO "recording_views" VALUES(5109,3433,'2014-07-08 23:29:33.548518','2014-07-08 23:29:33.548518');
INSERT INTO "recording_views" VALUES(5110,3433,'2014-07-08 23:32:18.667729','2014-07-08 23:32:18.667729');
INSERT INTO "recording_views" VALUES(5111,3560,'2014-07-08 23:36:13.192274','2014-07-08 23:36:13.192274');
INSERT INTO "recording_views" VALUES(5112,3521,'2014-07-08 23:37:37.573732','2014-07-08 23:37:37.573732');
INSERT INTO "recording_views" VALUES(5114,3521,'2014-07-08 23:43:25.019745','2014-07-08 23:43:25.019745');
INSERT INTO "recording_views" VALUES(5115,3521,'2014-07-08 23:46:50.645566','2014-07-08 23:46:50.645566');
INSERT INTO "recording_views" VALUES(5116,3814,'2014-07-08 23:47:55.233321','2014-07-08 23:47:55.233321');
INSERT INTO "recording_views" VALUES(5118,3821,'2014-07-09 00:29:54.9085','2014-07-09 00:29:54.9085');
INSERT INTO "recording_views" VALUES(5120,3620,'2014-07-09 01:38:33.817539','2014-07-09 01:38:33.817539');
INSERT INTO "recording_views" VALUES(5121,3620,'2014-07-09 01:56:35.073889','2014-07-09 01:56:35.073889');
INSERT INTO "recording_views" VALUES(5122,3518,'2014-07-09 02:24:40.56061','2014-07-09 02:24:40.56061');
INSERT INTO "recording_views" VALUES(5123,3806,'2014-07-09 02:42:19.111437','2014-07-09 02:42:19.111437');
INSERT INTO "recording_views" VALUES(5124,3548,'2014-07-09 02:58:19.666393','2014-07-09 02:58:19.666393');
INSERT INTO "recording_views" VALUES(5125,3548,'2014-07-09 03:03:57.221948','2014-07-09 03:03:57.221948');
INSERT INTO "recording_views" VALUES(5126,3548,'2014-07-09 03:08:41.893046','2014-07-09 03:08:41.893046');
INSERT INTO "recording_views" VALUES(5127,3638,'2014-07-09 03:09:16.18861','2014-07-09 03:09:16.18861');
INSERT INTO "recording_views" VALUES(5131,3833,'2014-07-09 04:21:17.001939','2014-07-09 04:21:17.001939');
INSERT INTO "recording_views" VALUES(5132,3560,'2014-07-09 04:22:44.683721','2014-07-09 04:22:44.683721');
INSERT INTO "recording_views" VALUES(5133,1230,'2014-07-09 04:25:28.28386','2014-07-09 04:25:28.28386');
INSERT INTO "recording_views" VALUES(5134,1230,'2014-07-09 04:31:26.070375','2014-07-09 04:31:26.070375');
INSERT INTO "recording_views" VALUES(5135,3833,'2014-07-09 04:37:22.111529','2014-07-09 04:37:22.111529');
INSERT INTO "recording_views" VALUES(5136,3833,'2014-07-09 04:39:33.00795','2014-07-09 04:39:33.00795');
INSERT INTO "recording_views" VALUES(5137,3437,'2014-07-09 04:41:25.986486','2014-07-09 04:41:25.986486');
INSERT INTO "recording_views" VALUES(5138,3833,'2014-07-09 04:48:59.40417','2014-07-09 04:48:59.40417');
INSERT INTO "recording_views" VALUES(5139,3452,'2014-07-09 05:26:51.609601','2014-07-09 05:26:51.609601');
INSERT INTO "recording_views" VALUES(5141,3452,'2014-07-09 05:53:27.105157','2014-07-09 05:53:27.105157');
INSERT INTO "recording_views" VALUES(5142,3452,'2014-07-09 05:55:04.92965','2014-07-09 05:55:04.92965');
INSERT INTO "recording_views" VALUES(5143,3677,'2014-07-09 06:14:11.288789','2014-07-09 06:14:11.288789');
INSERT INTO "recording_views" VALUES(5144,3814,'2014-07-09 06:22:29.334133','2014-07-09 06:22:29.334133');
INSERT INTO "recording_views" VALUES(5145,3814,'2014-07-09 06:32:59.580882','2014-07-09 06:32:59.580882');
INSERT INTO "recording_views" VALUES(5146,3452,'2014-07-09 07:02:32.139064','2014-07-09 07:02:32.139064');
INSERT INTO "recording_views" VALUES(5147,3773,'2014-07-09 07:06:09.864676','2014-07-09 07:06:09.864676');
INSERT INTO "recording_views" VALUES(5149,3814,'2014-07-09 07:18:58.34542','2014-07-09 07:18:58.34542');
INSERT INTO "recording_views" VALUES(5150,3559,'2014-07-09 07:31:33.910185','2014-07-09 07:31:33.910185');
INSERT INTO "recording_views" VALUES(5151,3748,'2014-07-09 07:32:28.055761','2014-07-09 07:32:28.055761');
INSERT INTO "recording_views" VALUES(5152,3713,'2014-07-09 07:33:57.169947','2014-07-09 07:33:57.169947');
INSERT INTO "recording_views" VALUES(5153,3715,'2014-07-09 07:35:15.106347','2014-07-09 07:35:15.106347');
INSERT INTO "recording_views" VALUES(5154,3688,'2014-07-09 07:39:47.636111','2014-07-09 07:39:47.636111');
INSERT INTO "recording_views" VALUES(5155,3452,'2014-07-09 07:43:12.049961','2014-07-09 07:43:12.049961');
INSERT INTO "recording_views" VALUES(5156,3559,'2014-07-09 07:43:19.510669','2014-07-09 07:43:19.510669');
INSERT INTO "recording_views" VALUES(5157,3688,'2014-07-09 07:44:28.396101','2014-07-09 07:44:28.396101');
INSERT INTO "recording_views" VALUES(5158,3452,'2014-07-09 07:47:52.674436','2014-07-09 07:47:52.674436');
INSERT INTO "recording_views" VALUES(5159,3688,'2014-07-09 07:48:08.266412','2014-07-09 07:48:08.266412');
INSERT INTO "recording_views" VALUES(5160,3541,'2014-07-09 07:49:06.263914','2014-07-09 07:49:06.263914');
INSERT INTO "recording_views" VALUES(5161,3452,'2014-07-09 07:51:57.860735','2014-07-09 07:51:57.860735');
INSERT INTO "recording_views" VALUES(5162,3541,'2014-07-09 08:10:28.045765','2014-07-09 08:10:28.045765');
INSERT INTO "recording_views" VALUES(5163,3452,'2014-07-09 08:11:51.890756','2014-07-09 08:11:51.890756');
INSERT INTO "recording_views" VALUES(5165,3541,'2014-07-09 08:17:53.308774','2014-07-09 08:17:53.308774');
INSERT INTO "recording_views" VALUES(5166,3772,'2014-07-09 08:18:25.476546','2014-07-09 08:18:25.476546');
INSERT INTO "recording_views" VALUES(5167,3452,'2014-07-09 08:18:34.638951','2014-07-09 08:18:34.638951');
INSERT INTO "recording_views" VALUES(5170,3803,'2014-07-09 08:21:48.757239','2014-07-09 08:21:48.757239');
INSERT INTO "recording_views" VALUES(5176,3740,'2014-07-09 08:41:29.563554','2014-07-09 08:41:29.563554');
INSERT INTO "recording_views" VALUES(5179,3560,'2014-07-09 08:45:09.411595','2014-07-09 08:45:09.411595');
INSERT INTO "recording_views" VALUES(5184,3740,'2014-07-09 08:52:34.636214','2014-07-09 08:52:34.636214');
INSERT INTO "recording_views" VALUES(5185,3752,'2014-07-09 08:54:16.958615','2014-07-09 08:54:16.958615');
INSERT INTO "recording_views" VALUES(5187,3740,'2014-07-09 08:59:16.673346','2014-07-09 08:59:16.673346');
INSERT INTO "recording_views" VALUES(5188,3451,'2014-07-09 09:04:24.672268','2014-07-09 09:04:24.672268');
INSERT INTO "recording_views" VALUES(5189,3740,'2014-07-09 09:04:47.730751','2014-07-09 09:04:47.730751');
INSERT INTO "recording_views" VALUES(5191,3602,'2014-07-09 09:08:48.847894','2014-07-09 09:08:48.847894');
INSERT INTO "recording_views" VALUES(5194,3740,'2014-07-09 09:15:59.090395','2014-07-09 09:15:59.090395');
INSERT INTO "recording_views" VALUES(5195,3715,'2014-07-09 09:17:31.097345','2014-07-09 09:17:31.097345');
INSERT INTO "recording_views" VALUES(5196,3677,'2014-07-09 09:24:09.742934','2014-07-09 09:24:09.742934');
INSERT INTO "recording_views" VALUES(5197,3452,'2014-07-09 09:25:53.472805','2014-07-09 09:25:53.472805');
INSERT INTO "recording_views" VALUES(5198,3677,'2014-07-09 09:27:42.155625','2014-07-09 09:27:42.155625');
INSERT INTO "recording_views" VALUES(5201,3677,'2014-07-09 09:31:06.295527','2014-07-09 09:31:06.295527');
INSERT INTO "recording_views" VALUES(5202,3653,'2014-07-09 09:36:23.91435','2014-07-09 09:36:23.91435');
INSERT INTO "recording_views" VALUES(5203,3677,'2014-07-09 09:36:33.662347','2014-07-09 09:36:33.662347');
INSERT INTO "recording_views" VALUES(5205,3833,'2014-07-09 09:38:27.239455','2014-07-09 09:38:27.239455');
INSERT INTO "recording_views" VALUES(5206,3715,'2014-07-09 09:38:33.908373','2014-07-09 09:38:33.908373');
INSERT INTO "recording_views" VALUES(5207,3451,'2014-07-09 09:39:17.970025','2014-07-09 09:39:17.970025');
INSERT INTO "recording_views" VALUES(5210,3752,'2014-07-09 09:49:42.765964','2014-07-09 09:49:42.765964');
INSERT INTO "recording_views" VALUES(5212,3452,'2014-07-09 09:53:22.708511','2014-07-09 09:53:22.708511');
INSERT INTO "recording_views" VALUES(5213,1206,'2014-07-09 09:57:23.277658','2014-07-09 09:57:23.277658');
INSERT INTO "recording_views" VALUES(5215,3752,'2014-07-09 10:00:48.9065','2014-07-09 10:00:48.9065');
INSERT INTO "recording_views" VALUES(5217,1206,'2014-07-09 10:04:39.445738','2014-07-09 10:04:39.445738');
INSERT INTO "recording_views" VALUES(5218,1206,'2014-07-09 10:13:08.720237','2014-07-09 10:13:08.720237');
INSERT INTO "recording_views" VALUES(5219,3452,'2014-07-09 10:16:14.705148','2014-07-09 10:16:14.705148');
INSERT INTO "recording_views" VALUES(5220,3452,'2014-07-09 10:19:11.805011','2014-07-09 10:19:11.805011');
INSERT INTO "recording_views" VALUES(5221,1206,'2014-07-09 10:21:36.229782','2014-07-09 10:21:36.229782');
INSERT INTO "recording_views" VALUES(5222,3560,'2014-07-09 10:31:01.554648','2014-07-09 10:31:01.554648');
INSERT INTO "recording_views" VALUES(5225,3602,'2014-07-09 10:50:58.346554','2014-07-09 10:50:58.346554');
INSERT INTO "recording_views" VALUES(5226,3752,'2014-07-09 10:52:32.467927','2014-07-09 10:52:32.467927');
INSERT INTO "recording_views" VALUES(5227,3452,'2014-07-09 10:52:39.458018','2014-07-09 10:52:39.458018');
INSERT INTO "recording_views" VALUES(5228,3452,'2014-07-09 10:55:37.96072','2014-07-09 10:55:37.96072');
INSERT INTO "recording_views" VALUES(5229,3778,'2014-07-09 10:56:23.687407','2014-07-09 10:56:23.687407');
INSERT INTO "recording_views" VALUES(5230,3452,'2014-07-09 11:01:09.187353','2014-07-09 11:01:09.187353');
INSERT INTO "recording_views" VALUES(5232,3437,'2014-07-09 11:17:25.800212','2014-07-09 11:17:25.800212');
INSERT INTO "recording_views" VALUES(5233,3667,'2014-07-09 11:18:25.401267','2014-07-09 11:18:25.401267');
INSERT INTO "recording_views" VALUES(5240,3497,'2014-07-09 11:25:07.78686','2014-07-09 11:25:07.78686');
INSERT INTO "recording_views" VALUES(5242,3778,'2014-07-09 11:34:58.773377','2014-07-09 11:34:58.773377');
INSERT INTO "recording_views" VALUES(5243,3770,'2014-07-09 11:45:05.060041','2014-07-09 11:45:05.060041');
INSERT INTO "recording_views" VALUES(5244,3752,'2014-07-09 11:51:46.549466','2014-07-09 11:51:46.549466');
INSERT INTO "recording_views" VALUES(5245,3805,'2014-07-09 12:02:11.659819','2014-07-09 12:02:11.659819');
INSERT INTO "recording_views" VALUES(5246,3545,'2014-07-09 12:06:47.202824','2014-07-09 12:06:47.202824');
INSERT INTO "recording_views" VALUES(5248,3451,'2014-07-09 12:15:23.498082','2014-07-09 12:15:23.498082');
INSERT INTO "recording_views" VALUES(5249,3451,'2014-07-09 12:20:59.929012','2014-07-09 12:20:59.929012');
INSERT INTO "recording_views" VALUES(5251,3451,'2014-07-09 12:24:49.943481','2014-07-09 12:24:49.943481');
INSERT INTO "recording_views" VALUES(5252,3773,'2014-07-09 12:25:01.300047','2014-07-09 12:25:01.300047');
INSERT INTO "recording_views" VALUES(5253,3805,'2014-07-09 12:26:42.798971','2014-07-09 12:26:42.798971');
INSERT INTO "recording_views" VALUES(5254,3806,'2014-07-09 12:37:04.120746','2014-07-09 12:37:04.120746');
INSERT INTO "recording_views" VALUES(5255,3602,'2014-07-09 12:40:42.786581','2014-07-09 12:40:42.786581');
INSERT INTO "recording_views" VALUES(5256,3452,'2014-07-09 12:45:54.410566','2014-07-09 12:45:54.410566');
INSERT INTO "recording_views" VALUES(5257,3602,'2014-07-09 12:46:11.948044','2014-07-09 12:46:11.948044');
INSERT INTO "recording_views" VALUES(5259,3496,'2014-07-09 12:59:16.654155','2014-07-09 12:59:16.654155');
INSERT INTO "recording_views" VALUES(5260,3767,'2014-07-09 13:00:55.106814','2014-07-09 13:00:55.106814');
INSERT INTO "recording_views" VALUES(5261,3500,'2014-07-09 13:05:33.872936','2014-07-09 13:05:33.872936');
INSERT INTO "recording_views" VALUES(5262,3806,'2014-07-09 13:09:49.927395','2014-07-09 13:09:49.927395');
INSERT INTO "recording_views" VALUES(5263,3452,'2014-07-09 13:11:14.291099','2014-07-09 13:11:14.291099');
INSERT INTO "recording_views" VALUES(5266,3452,'2014-07-09 13:20:55.332506','2014-07-09 13:20:55.332506');
INSERT INTO "recording_views" VALUES(5268,3452,'2014-07-09 13:21:36.515064','2014-07-09 13:21:36.515064');
INSERT INTO "recording_views" VALUES(5269,3806,'2014-07-09 13:23:17.322818','2014-07-09 13:23:17.322818');
INSERT INTO "recording_views" VALUES(5270,3452,'2014-07-09 13:25:13.036917','2014-07-09 13:25:13.036917');
INSERT INTO "recording_views" VALUES(5271,3779,'2014-07-09 13:26:01.548953','2014-07-09 13:26:01.548953');
INSERT INTO "recording_views" VALUES(5272,3818,'2014-07-09 13:27:58.451626','2014-07-09 13:27:58.451626');
INSERT INTO "recording_views" VALUES(5273,3566,'2014-07-09 13:28:08.982899','2014-07-09 13:28:08.982899');
INSERT INTO "recording_views" VALUES(5274,3451,'2014-07-09 13:29:07.242531','2014-07-09 13:29:07.242531');
INSERT INTO "recording_views" VALUES(5275,3566,'2014-07-09 13:30:23.530718','2014-07-09 13:30:23.530718');
INSERT INTO "recording_views" VALUES(5276,3496,'2014-07-09 13:31:10.968173','2014-07-09 13:31:10.968173');
INSERT INTO "recording_views" VALUES(5278,3566,'2014-07-09 13:39:23.879574','2014-07-09 13:39:23.879574');
INSERT INTO "recording_views" VALUES(5279,3566,'2014-07-09 13:45:49.859679','2014-07-09 13:45:49.859679');
INSERT INTO "recording_views" VALUES(5280,3451,'2014-07-09 13:47:51.949059','2014-07-09 13:47:51.949059');
INSERT INTO "recording_views" VALUES(5281,3806,'2014-07-09 13:48:42.828755','2014-07-09 13:48:42.828755');
INSERT INTO "recording_views" VALUES(5282,3451,'2014-07-09 13:53:33.615659','2014-07-09 13:53:33.615659');
INSERT INTO "recording_views" VALUES(5284,3452,'2014-07-09 13:55:22.281922','2014-07-09 13:55:22.281922');
INSERT INTO "recording_views" VALUES(5285,3602,'2014-07-09 14:07:45.919484','2014-07-09 14:07:45.919484');
INSERT INTO "recording_views" VALUES(5288,3773,'2014-07-09 14:13:16.117912','2014-07-09 14:13:16.117912');
INSERT INTO "recording_views" VALUES(5290,3728,'2014-07-09 14:27:39.010126','2014-07-09 14:27:39.010126');
INSERT INTO "recording_views" VALUES(5291,3809,'2014-07-09 14:29:03.310261','2014-07-09 14:29:03.310261');
INSERT INTO "recording_views" VALUES(5292,3620,'2014-07-09 14:29:30.151261','2014-07-09 14:29:30.151261');
INSERT INTO "recording_views" VALUES(5293,3451,'2014-07-09 14:33:31.968329','2014-07-09 14:33:31.968329');
INSERT INTO "recording_views" VALUES(5294,3451,'2014-07-09 14:37:34.715891','2014-07-09 14:37:34.715891');
INSERT INTO "recording_views" VALUES(5296,3620,'2014-07-09 14:38:58.770357','2014-07-09 14:38:58.770357');
INSERT INTO "recording_views" VALUES(5297,3451,'2014-07-09 14:39:40.41525','2014-07-09 14:39:40.41525');
INSERT INTO "recording_views" VALUES(5299,3451,'2014-07-09 14:42:04.388526','2014-07-09 14:42:04.388526');
INSERT INTO "recording_views" VALUES(5301,3451,'2014-07-09 14:45:21.479071','2014-07-09 14:45:21.479071');
INSERT INTO "recording_views" VALUES(5303,3451,'2014-07-09 14:47:23.97489','2014-07-09 14:47:23.97489');
INSERT INTO "recording_views" VALUES(5306,3451,'2014-07-09 14:49:27.027868','2014-07-09 14:49:27.027868');
INSERT INTO "recording_views" VALUES(5311,3451,'2014-07-09 14:54:10.205082','2014-07-09 14:54:10.205082');
INSERT INTO "recording_views" VALUES(5313,3451,'2014-07-09 14:56:43.205413','2014-07-09 14:56:43.205413');
INSERT INTO "recording_views" VALUES(5314,3560,'2014-07-09 15:00:19.427012','2014-07-09 15:00:19.427012');
INSERT INTO "recording_views" VALUES(5316,3451,'2014-07-09 15:02:06.645187','2014-07-09 15:02:06.645187');
INSERT INTO "recording_views" VALUES(5318,3451,'2014-07-09 15:04:21.841606','2014-07-09 15:04:21.841606');
INSERT INTO "recording_views" VALUES(5320,3451,'2014-07-09 15:06:31.963149','2014-07-09 15:06:31.963149');
INSERT INTO "recording_views" VALUES(5321,3451,'2014-07-09 15:09:35.32637','2014-07-09 15:09:35.32637');
INSERT INTO "recording_views" VALUES(5323,3620,'2014-07-09 15:11:03.961933','2014-07-09 15:11:03.961933');
INSERT INTO "recording_views" VALUES(5326,3710,'2014-07-09 15:17:00.250445','2014-07-09 15:17:00.250445');
INSERT INTO "recording_views" VALUES(5332,3496,'2014-07-09 15:53:06.414574','2014-07-09 15:53:06.414574');
INSERT INTO "recording_views" VALUES(5333,3667,'2014-07-09 15:53:36.79743','2014-07-09 15:53:36.79743');
INSERT INTO "recording_views" VALUES(5335,3709,'2014-07-09 16:03:26.468308','2014-07-09 16:03:26.468308');
INSERT INTO "recording_views" VALUES(5336,3818,'2014-07-09 16:06:26.375811','2014-07-09 16:06:26.375811');
INSERT INTO "recording_views" VALUES(5337,3770,'2014-07-09 16:11:03.303641','2014-07-09 16:11:03.303641');
INSERT INTO "recording_views" VALUES(5340,3722,'2014-07-09 16:18:12.362204','2014-07-09 16:18:12.362204');
INSERT INTO "recording_views" VALUES(5346,3452,'2014-07-09 16:20:22.606828','2014-07-09 16:20:22.606828');
INSERT INTO "recording_views" VALUES(5347,3709,'2014-07-09 16:22:21.049914','2014-07-09 16:22:21.049914');
INSERT INTO "recording_views" VALUES(5349,3818,'2014-07-09 16:24:09.620716','2014-07-09 16:24:09.620716');
INSERT INTO "recording_views" VALUES(5350,1296,'2014-07-09 16:24:12.568299','2014-07-09 16:24:12.568299');
INSERT INTO "recording_views" VALUES(5352,1296,'2014-07-09 16:27:26.739525','2014-07-09 16:27:26.739525');
INSERT INTO "recording_views" VALUES(5353,1296,'2014-07-09 16:31:28.031197','2014-07-09 16:31:28.031197');
INSERT INTO "recording_views" VALUES(5354,3452,'2014-07-09 16:31:58.241258','2014-07-09 16:31:58.241258');
INSERT INTO "recording_views" VALUES(5355,1296,'2014-07-09 16:33:43.692861','2014-07-09 16:33:43.692861');
INSERT INTO "recording_views" VALUES(5356,3764,'2014-07-09 16:36:22.370064','2014-07-09 16:36:22.370064');
INSERT INTO "recording_views" VALUES(5357,1215,'2014-07-09 16:37:28.561504','2014-07-09 16:37:28.561504');
INSERT INTO "recording_views" VALUES(5358,1215,'2014-07-09 16:39:38.611084','2014-07-09 16:39:38.611084');
INSERT INTO "recording_views" VALUES(5359,1215,'2014-07-09 16:42:33.684846','2014-07-09 16:42:33.684846');
INSERT INTO "recording_views" VALUES(5360,1254,'2014-07-09 16:43:27.44028','2014-07-09 16:43:27.44028');
INSERT INTO "recording_views" VALUES(5361,1206,'2014-07-09 16:45:14.711621','2014-07-09 16:45:14.711621');
INSERT INTO "recording_views" VALUES(5362,1206,'2014-07-09 16:47:33.267161','2014-07-09 16:47:33.267161');
INSERT INTO "recording_views" VALUES(5363,1206,'2014-07-09 16:50:11.310784','2014-07-09 16:50:11.310784');
INSERT INTO "recording_views" VALUES(5364,1206,'2014-07-09 16:52:35.994139','2014-07-09 16:52:35.994139');
INSERT INTO "recording_views" VALUES(5365,1206,'2014-07-09 16:54:53.663692','2014-07-09 16:54:53.663692');
INSERT INTO "recording_views" VALUES(5366,1341,'2014-07-09 16:56:08.036042','2014-07-09 16:56:08.036042');
INSERT INTO "recording_views" VALUES(5367,3733,'2014-07-09 16:56:48.531363','2014-07-09 16:56:48.531363');
INSERT INTO "recording_views" VALUES(5368,1341,'2014-07-09 16:58:30.679755','2014-07-09 16:58:30.679755');
INSERT INTO "recording_views" VALUES(5369,3646,'2014-07-09 17:08:34.256629','2014-07-09 17:08:34.256629');
INSERT INTO "recording_views" VALUES(5370,1317,'2014-07-09 17:09:39.055137','2014-07-09 17:09:39.055137');
INSERT INTO "recording_views" VALUES(5372,3646,'2014-07-09 17:13:04.685629','2014-07-09 17:13:04.685629');
INSERT INTO "recording_views" VALUES(5373,3781,'2014-07-09 17:14:58.42678','2014-07-09 17:14:58.42678');
INSERT INTO "recording_views" VALUES(5374,3781,'2014-07-09 17:21:43.187134','2014-07-09 17:21:43.187134');
INSERT INTO "recording_views" VALUES(5375,3781,'2014-07-09 17:23:52.718787','2014-07-09 17:23:52.718787');
INSERT INTO "recording_views" VALUES(5376,3781,'2014-07-09 17:25:55.78588','2014-07-09 17:25:55.78588');
INSERT INTO "recording_views" VALUES(5377,3602,'2014-07-09 17:26:08.689289','2014-07-09 17:26:08.689289');
INSERT INTO "recording_views" VALUES(5378,3781,'2014-07-09 17:28:38.509452','2014-07-09 17:28:38.509452');
INSERT INTO "recording_views" VALUES(5379,3578,'2014-07-09 17:30:05.746435','2014-07-09 17:30:05.746435');
INSERT INTO "recording_views" VALUES(5380,3728,'2014-07-09 17:30:31.278887','2014-07-09 17:30:31.278887');
INSERT INTO "recording_views" VALUES(5381,3781,'2014-07-09 17:35:02.771527','2014-07-09 17:35:02.771527');
INSERT INTO "recording_views" VALUES(5382,94,'2014-07-09 17:36:20.574341','2014-07-09 17:36:20.574341');
INSERT INTO "recording_views" VALUES(5383,3781,'2014-07-09 17:37:35.786951','2014-07-09 17:37:35.786951');
INSERT INTO "recording_views" VALUES(5384,3431,'2014-07-09 17:50:01.839096','2014-07-09 17:50:01.839096');
INSERT INTO "recording_views" VALUES(5386,3758,'2014-07-09 17:54:40.282945','2014-07-09 17:54:40.282945');
INSERT INTO "recording_views" VALUES(5389,3640,'2014-07-09 17:55:24.081128','2014-07-09 17:55:24.081128');
INSERT INTO "recording_views" VALUES(5390,3620,'2014-07-09 17:55:51.872634','2014-07-09 17:55:51.872634');
INSERT INTO "recording_views" VALUES(5391,3542,'2014-07-09 17:56:03.59807','2014-07-09 17:56:03.59807');
INSERT INTO "recording_views" VALUES(5392,3452,'2014-07-09 17:57:12.441651','2014-07-09 17:57:12.441651');
INSERT INTO "recording_views" VALUES(5393,3458,'2014-07-09 17:57:15.114902','2014-07-09 17:57:15.114902');
INSERT INTO "recording_views" VALUES(5395,3560,'2014-07-09 17:58:47.137775','2014-07-09 17:58:47.137775');
INSERT INTO "recording_views" VALUES(5400,3752,'2014-07-09 18:01:56.464131','2014-07-09 18:01:56.464131');
INSERT INTO "recording_views" VALUES(5402,3749,'2014-07-09 18:03:41.172657','2014-07-09 18:03:41.172657');
INSERT INTO "recording_views" VALUES(5403,3752,'2014-07-09 18:05:14.041054','2014-07-09 18:05:14.041054');
INSERT INTO "recording_views" VALUES(5404,3668,'2014-07-09 18:05:43.781083','2014-07-09 18:05:43.781083');
INSERT INTO "recording_views" VALUES(5407,151,'2014-07-09 18:18:51.984824','2014-07-09 18:18:51.984824');
INSERT INTO "recording_views" VALUES(5408,142,'2014-07-09 18:20:09.879028','2014-07-09 18:20:09.879028');
INSERT INTO "recording_views" VALUES(5410,3668,'2014-07-09 18:20:44.294462','2014-07-09 18:20:44.294462');
INSERT INTO "recording_views" VALUES(5419,3475,'2014-07-09 18:48:00.688658','2014-07-09 18:48:00.688658');
INSERT INTO "recording_views" VALUES(5421,3764,'2014-07-09 18:58:36.726205','2014-07-09 18:58:36.726205');
INSERT INTO "recording_views" VALUES(5422,3752,'2014-07-09 18:59:30.126535','2014-07-09 18:59:30.126535');
INSERT INTO "recording_views" VALUES(5423,3475,'2014-07-09 19:03:34.003884','2014-07-09 19:03:34.003884');
INSERT INTO "recording_views" VALUES(5425,3770,'2014-07-09 19:14:22.077692','2014-07-09 19:14:22.077692');
INSERT INTO "recording_views" VALUES(5433,3770,'2014-07-09 19:33:53.736919','2014-07-09 19:33:53.736919');
INSERT INTO "recording_views" VALUES(5436,3770,'2014-07-09 19:47:01.232484','2014-07-09 19:47:01.232484');
INSERT INTO "recording_views" VALUES(5440,3815,'2014-07-09 20:07:29.784775','2014-07-09 20:07:29.784775');
INSERT INTO "recording_views" VALUES(5441,1209,'2014-07-09 20:08:14.765971','2014-07-09 20:08:14.765971');
INSERT INTO "recording_views" VALUES(5445,3728,'2014-07-09 20:29:24.614691','2014-07-09 20:29:24.614691');
INSERT INTO "recording_views" VALUES(5447,3689,'2014-07-09 20:30:19.026656','2014-07-09 20:30:19.026656');
INSERT INTO "recording_views" VALUES(5448,3752,'2014-07-09 20:31:05.512631','2014-07-09 20:31:05.512631');
INSERT INTO "recording_views" VALUES(5451,3560,'2014-07-09 20:45:00.299073','2014-07-09 20:45:00.299073');
INSERT INTO "recording_views" VALUES(5452,3779,'2014-07-09 20:45:09.153837','2014-07-09 20:45:09.153837');
INSERT INTO "recording_views" VALUES(5453,3551,'2014-07-09 20:47:36.034572','2014-07-09 20:47:36.034572');
INSERT INTO "recording_views" VALUES(5455,3551,'2014-07-09 20:50:22.435725','2014-07-09 20:50:22.435725');
INSERT INTO "recording_views" VALUES(5457,3548,'2014-07-09 20:52:46.152325','2014-07-09 20:52:46.152325');
INSERT INTO "recording_views" VALUES(5458,3815,'2014-07-09 20:53:23.529934','2014-07-09 20:53:23.529934');
INSERT INTO "recording_views" VALUES(5459,3815,'2014-07-09 20:55:23.683758','2014-07-09 20:55:23.683758');
INSERT INTO "recording_views" VALUES(5460,3560,'2014-07-09 20:55:53.316121','2014-07-09 20:55:53.316121');
INSERT INTO "recording_views" VALUES(5461,3779,'2014-07-09 20:57:38.677863','2014-07-09 20:57:38.677863');
INSERT INTO "recording_views" VALUES(5462,3779,'2014-07-09 20:59:55.54996','2014-07-09 20:59:55.54996');
INSERT INTO "recording_views" VALUES(5463,3779,'2014-07-09 21:04:18.736045','2014-07-09 21:04:18.736045');
INSERT INTO "recording_views" VALUES(5464,3770,'2014-07-09 21:04:24.306664','2014-07-09 21:04:24.306664');
INSERT INTO "recording_views" VALUES(5465,3779,'2014-07-09 21:06:33.581155','2014-07-09 21:06:33.581155');
INSERT INTO "recording_views" VALUES(5466,3779,'2014-07-09 21:08:33.900778','2014-07-09 21:08:33.900778');
INSERT INTO "recording_views" VALUES(5468,3779,'2014-07-09 21:11:00.97689','2014-07-09 21:11:00.97689');
INSERT INTO "recording_views" VALUES(5469,3659,'2014-07-09 21:12:21.545772','2014-07-09 21:12:21.545772');
INSERT INTO "recording_views" VALUES(5470,3560,'2014-07-09 21:13:03.95598','2014-07-09 21:13:03.95598');
INSERT INTO "recording_views" VALUES(5471,3659,'2014-07-09 21:14:22.154519','2014-07-09 21:14:22.154519');
INSERT INTO "recording_views" VALUES(5473,3452,'2014-07-09 21:19:33.037775','2014-07-09 21:19:33.037775');
INSERT INTO "recording_views" VALUES(5475,3452,'2014-07-09 21:23:05.635673','2014-07-09 21:23:05.635673');
INSERT INTO "recording_views" VALUES(5486,3734,'2014-07-09 22:12:10.712561','2014-07-09 22:12:10.712561');
INSERT INTO "recording_views" VALUES(5487,3683,'2014-07-09 22:17:28.590529','2014-07-09 22:17:28.590529');
INSERT INTO "recording_views" VALUES(5488,3683,'2014-07-09 22:25:08.771351','2014-07-09 22:25:08.771351');
INSERT INTO "recording_views" VALUES(5495,1215,'2014-07-09 22:39:47.630259','2014-07-09 22:39:47.630259');
INSERT INTO "recording_views" VALUES(5496,1215,'2014-07-09 22:43:15.063844','2014-07-09 22:43:15.063844');
INSERT INTO "recording_views" VALUES(5497,3646,'2014-07-09 22:44:54.65866','2014-07-09 22:44:54.65866');
INSERT INTO "recording_views" VALUES(5498,1215,'2014-07-09 22:45:16.650589','2014-07-09 22:45:16.650589');
INSERT INTO "recording_views" VALUES(5499,1344,'2014-07-09 22:45:51.499327','2014-07-09 22:45:51.499327');
INSERT INTO "recording_views" VALUES(5506,3646,'2014-07-09 23:34:30.468783','2014-07-09 23:34:30.468783');
INSERT INTO "recording_views" VALUES(5508,3770,'2014-07-10 00:03:08.463042','2014-07-10 00:03:08.463042');
INSERT INTO "recording_views" VALUES(5510,3646,'2014-07-10 00:13:02.210603','2014-07-10 00:13:02.210603');
INSERT INTO "recording_views" VALUES(5518,3560,'2014-07-10 00:47:14.816133','2014-07-10 00:47:14.816133');
INSERT INTO "recording_views" VALUES(5519,3799,'2014-07-10 00:47:24.371265','2014-07-10 00:47:24.371265');
INSERT INTO "recording_views" VALUES(5525,3560,'2014-07-10 00:58:13.347306','2014-07-10 00:58:13.347306');
INSERT INTO "recording_views" VALUES(5527,3560,'2014-07-10 01:02:38.146229','2014-07-10 01:02:38.146229');
INSERT INTO "recording_views" VALUES(5528,3560,'2014-07-10 01:05:29.878679','2014-07-10 01:05:29.878679');
INSERT INTO "recording_views" VALUES(5529,3560,'2014-07-10 01:07:51.845372','2014-07-10 01:07:51.845372');
INSERT INTO "recording_views" VALUES(5530,3779,'2014-07-10 01:46:11.228283','2014-07-10 01:46:11.228283');
INSERT INTO "recording_views" VALUES(5532,3779,'2014-07-10 01:49:43.755858','2014-07-10 01:49:43.755858');
INSERT INTO "recording_views" VALUES(5533,3779,'2014-07-10 01:51:50.072002','2014-07-10 01:51:50.072002');
INSERT INTO "recording_views" VALUES(5534,3779,'2014-07-10 01:54:33.054488','2014-07-10 01:54:33.054488');
INSERT INTO "recording_views" VALUES(5537,3779,'2014-07-10 02:06:44.777803','2014-07-10 02:06:44.777803');
INSERT INTO "recording_views" VALUES(5538,3497,'2014-07-10 02:39:11.857579','2014-07-10 02:39:11.857579');
INSERT INTO "recording_views" VALUES(5541,3446,'2014-07-10 03:36:43.688309','2014-07-10 03:36:43.688309');
INSERT INTO "recording_views" VALUES(5544,3497,'2014-07-10 03:49:46.731723','2014-07-10 03:49:46.731723');
INSERT INTO "recording_views" VALUES(5547,3752,'2014-07-10 04:47:11.865859','2014-07-10 04:47:11.865859');
INSERT INTO "recording_views" VALUES(5548,3752,'2014-07-10 04:51:05.434867','2014-07-10 04:51:05.434867');
INSERT INTO "recording_views" VALUES(5551,3662,'2014-07-10 05:24:06.39354','2014-07-10 05:24:06.39354');
INSERT INTO "recording_views" VALUES(5553,3662,'2014-07-10 06:44:56.383564','2014-07-10 06:44:56.383564');
INSERT INTO "recording_views" VALUES(5554,3662,'2014-07-10 06:47:09.474571','2014-07-10 06:47:09.474571');
INSERT INTO "recording_views" VALUES(5555,3662,'2014-07-10 06:49:14.437036','2014-07-10 06:49:14.437036');
INSERT INTO "recording_views" VALUES(5556,3662,'2014-07-10 06:51:16.173069','2014-07-10 06:51:16.173069');
INSERT INTO "recording_views" VALUES(5557,3662,'2014-07-10 06:53:30.453507','2014-07-10 06:53:30.453507');
INSERT INTO "recording_views" VALUES(5558,3662,'2014-07-10 06:55:51.230269','2014-07-10 06:55:51.230269');
INSERT INTO "recording_views" VALUES(5559,3662,'2014-07-10 06:58:05.77517','2014-07-10 06:58:05.77517');
INSERT INTO "recording_views" VALUES(5560,3662,'2014-07-10 07:00:09.377083','2014-07-10 07:00:09.377083');
INSERT INTO "recording_views" VALUES(5561,3662,'2014-07-10 07:02:13.386567','2014-07-10 07:02:13.386567');
INSERT INTO "recording_views" VALUES(5562,3662,'2014-07-10 07:04:17.705238','2014-07-10 07:04:17.705238');
INSERT INTO "recording_views" VALUES(5567,3602,'2014-07-10 07:33:09.682994','2014-07-10 07:33:09.682994');
INSERT INTO "recording_views" VALUES(5569,3770,'2014-07-10 08:00:48.595404','2014-07-10 08:00:48.595404');
INSERT INTO "recording_views" VALUES(5571,3605,'2014-07-10 08:52:15.648153','2014-07-10 08:52:15.648153');
INSERT INTO "recording_views" VALUES(5572,3734,'2014-07-10 08:52:22.420565','2014-07-10 08:52:22.420565');
INSERT INTO "recording_views" VALUES(5578,3644,'2014-07-10 09:38:17.563614','2014-07-10 09:38:17.563614');
INSERT INTO "recording_views" VALUES(5579,3661,'2014-07-10 09:41:05.194315','2014-07-10 09:41:05.194315');
INSERT INTO "recording_views" VALUES(5580,3725,'2014-07-10 09:43:01.903294','2014-07-10 09:43:01.903294');
INSERT INTO "recording_views" VALUES(5581,3496,'2014-07-10 09:45:42.502087','2014-07-10 09:45:42.502087');
INSERT INTO "recording_views" VALUES(5582,3725,'2014-07-10 09:48:12.35758','2014-07-10 09:48:12.35758');
INSERT INTO "recording_views" VALUES(5583,3725,'2014-07-10 09:50:29.298122','2014-07-10 09:50:29.298122');
INSERT INTO "recording_views" VALUES(5584,3725,'2014-07-10 09:54:13.628574','2014-07-10 09:54:13.628574');
INSERT INTO "recording_views" VALUES(5589,3725,'2014-07-10 10:19:16.769642','2014-07-10 10:19:16.769642');
INSERT INTO "recording_views" VALUES(5590,3725,'2014-07-10 10:33:17.083343','2014-07-10 10:33:17.083343');
INSERT INTO "recording_views" VALUES(5597,3451,'2014-07-10 10:59:27.56543','2014-07-10 10:59:27.56543');
INSERT INTO "recording_views" VALUES(5598,3467,'2014-07-10 11:02:26.368881','2014-07-10 11:02:26.368881');
INSERT INTO "recording_views" VALUES(5599,3560,'2014-07-10 11:05:58.620826','2014-07-10 11:05:58.620826');
INSERT INTO "recording_views" VALUES(5600,3467,'2014-07-10 11:11:44.321568','2014-07-10 11:11:44.321568');
INSERT INTO "recording_views" VALUES(5603,3467,'2014-07-10 11:21:48.352954','2014-07-10 11:21:48.352954');
INSERT INTO "recording_views" VALUES(5604,3467,'2014-07-10 11:25:16.299491','2014-07-10 11:25:16.299491');
INSERT INTO "recording_views" VALUES(5605,1299,'2014-07-10 11:30:34.499601','2014-07-10 11:30:34.499601');
INSERT INTO "recording_views" VALUES(5606,3661,'2014-07-10 11:32:05.295909','2014-07-10 11:32:05.295909');
INSERT INTO "recording_views" VALUES(5607,3506,'2014-07-10 11:32:31.934454','2014-07-10 11:32:31.934454');
INSERT INTO "recording_views" VALUES(5608,3467,'2014-07-10 11:40:28.647769','2014-07-10 11:40:28.647769');
INSERT INTO "recording_views" VALUES(5609,3434,'2014-07-10 11:44:01.100241','2014-07-10 11:44:01.100241');
INSERT INTO "recording_views" VALUES(5611,3566,'2014-07-10 11:47:11.969885','2014-07-10 11:47:11.969885');
INSERT INTO "recording_views" VALUES(5612,3467,'2014-07-10 11:47:41.938787','2014-07-10 11:47:41.938787');
INSERT INTO "recording_views" VALUES(5613,3788,'2014-07-10 11:48:31.961775','2014-07-10 11:48:31.961775');
INSERT INTO "recording_views" VALUES(5615,3779,'2014-07-10 11:51:49.371252','2014-07-10 11:51:49.371252');
INSERT INTO "recording_views" VALUES(5616,1299,'2014-07-10 11:52:36.197578','2014-07-10 11:52:36.197578');
INSERT INTO "recording_views" VALUES(5617,3779,'2014-07-10 11:53:51.840159','2014-07-10 11:53:51.840159');
INSERT INTO "recording_views" VALUES(5619,3725,'2014-07-10 12:00:43.826628','2014-07-10 12:00:43.826628');
INSERT INTO "recording_views" VALUES(5620,3779,'2014-07-10 12:10:35.428877','2014-07-10 12:10:35.428877');
INSERT INTO "recording_views" VALUES(5621,3722,'2014-07-10 12:10:56.789511','2014-07-10 12:10:56.789511');
INSERT INTO "recording_views" VALUES(5624,3722,'2014-07-10 12:12:59.164272','2014-07-10 12:12:59.164272');
INSERT INTO "recording_views" VALUES(5626,3722,'2014-07-10 12:19:45.427776','2014-07-10 12:19:45.427776');
INSERT INTO "recording_views" VALUES(5627,1299,'2014-07-10 12:25:08.595168','2014-07-10 12:25:08.595168');
INSERT INTO "recording_views" VALUES(5628,3451,'2014-07-10 12:25:59.16125','2014-07-10 12:25:59.16125');
INSERT INTO "recording_views" VALUES(5629,1299,'2014-07-10 12:28:26.639067','2014-07-10 12:28:26.639067');
INSERT INTO "recording_views" VALUES(5630,3446,'2014-07-10 12:29:16.456417','2014-07-10 12:29:16.456417');
INSERT INTO "recording_views" VALUES(5631,3452,'2014-07-10 12:36:52.829563','2014-07-10 12:36:52.829563');
INSERT INTO "recording_views" VALUES(5632,3752,'2014-07-10 12:39:21.933749','2014-07-10 12:39:21.933749');
INSERT INTO "recording_views" VALUES(5633,3451,'2014-07-10 12:41:01.113129','2014-07-10 12:41:01.113129');
INSERT INTO "recording_views" VALUES(5634,3647,'2014-07-10 12:42:06.863831','2014-07-10 12:42:06.863831');
INSERT INTO "recording_views" VALUES(5636,3452,'2014-07-10 12:51:20.705399','2014-07-10 12:51:20.705399');
INSERT INTO "recording_views" VALUES(5638,3452,'2014-07-10 13:04:35.045718','2014-07-10 13:04:35.045718');
INSERT INTO "recording_views" VALUES(5640,3452,'2014-07-10 13:13:16.618662','2014-07-10 13:13:16.618662');
INSERT INTO "recording_views" VALUES(5641,3452,'2014-07-10 13:17:54.307272','2014-07-10 13:17:54.307272');
INSERT INTO "recording_views" VALUES(5642,3571,'2014-07-10 13:39:12.507199','2014-07-10 13:39:12.507199');
INSERT INTO "recording_views" VALUES(5644,3662,'2014-07-10 13:53:21.16643','2014-07-10 13:53:21.16643');
INSERT INTO "recording_views" VALUES(5645,3788,'2014-07-10 13:56:50.910133','2014-07-10 13:56:50.910133');
INSERT INTO "recording_views" VALUES(5646,3677,'2014-07-10 13:57:30.399941','2014-07-10 13:57:30.399941');
INSERT INTO "recording_views" VALUES(5647,3497,'2014-07-10 14:08:25.425592','2014-07-10 14:08:25.425592');
INSERT INTO "recording_views" VALUES(5648,3758,'2014-07-10 14:17:40.711599','2014-07-10 14:17:40.711599');
INSERT INTO "recording_views" VALUES(5649,3452,'2014-07-10 14:18:19.463222','2014-07-10 14:18:19.463222');
INSERT INTO "recording_views" VALUES(5650,3830,'2014-07-10 14:18:58.749506','2014-07-10 14:18:58.749506');
INSERT INTO "recording_views" VALUES(5652,3452,'2014-07-10 14:34:40.037052','2014-07-10 14:34:40.037052');
INSERT INTO "recording_views" VALUES(5655,3452,'2014-07-10 14:56:07.633537','2014-07-10 14:56:07.633537');
INSERT INTO "recording_views" VALUES(5657,3451,'2014-07-10 14:58:26.219002','2014-07-10 14:58:26.219002');
INSERT INTO "recording_views" VALUES(5659,3739,'2014-07-10 15:02:56.181533','2014-07-10 15:02:56.181533');
INSERT INTO "recording_views" VALUES(5661,3739,'2014-07-10 15:04:58.469633','2014-07-10 15:04:58.469633');
INSERT INTO "recording_views" VALUES(5664,3560,'2014-07-10 15:20:04.681557','2014-07-10 15:20:04.681557');
INSERT INTO "recording_views" VALUES(5665,3809,'2014-07-10 15:21:35.403149','2014-07-10 15:21:35.403149');
INSERT INTO "recording_views" VALUES(5666,3725,'2014-07-10 15:22:27.845955','2014-07-10 15:22:27.845955');
INSERT INTO "recording_views" VALUES(5667,3491,'2014-07-10 15:26:41.539373','2014-07-10 15:26:41.539373');
INSERT INTO "recording_views" VALUES(5668,3452,'2014-07-10 15:34:30.735921','2014-07-10 15:34:30.735921');
INSERT INTO "recording_views" VALUES(5671,3796,'2014-07-10 15:46:04.382718','2014-07-10 15:46:04.382718');
INSERT INTO "recording_views" VALUES(5672,3505,'2014-07-10 15:46:50.348198','2014-07-10 15:46:50.348198');
INSERT INTO "recording_views" VALUES(5674,3452,'2014-07-10 15:49:40.478235','2014-07-10 15:49:40.478235');
INSERT INTO "recording_views" VALUES(5675,3430,'2014-07-10 15:57:40.310601','2014-07-10 15:57:40.310601');
INSERT INTO "recording_views" VALUES(5676,3430,'2014-07-10 15:59:41.647672','2014-07-10 15:59:41.647672');
INSERT INTO "recording_views" VALUES(5678,3574,'2014-07-10 16:00:34.17477','2014-07-10 16:00:34.17477');
INSERT INTO "recording_views" VALUES(5679,3574,'2014-07-10 16:02:34.370273','2014-07-10 16:02:34.370273');
INSERT INTO "recording_views" VALUES(5681,3574,'2014-07-10 16:07:01.30407','2014-07-10 16:07:01.30407');
INSERT INTO "recording_views" VALUES(5682,3491,'2014-07-10 16:10:37.593013','2014-07-10 16:10:37.593013');
INSERT INTO "recording_views" VALUES(5685,3491,'2014-07-10 16:14:04.838185','2014-07-10 16:14:04.838185');
INSERT INTO "recording_views" VALUES(5687,3452,'2014-07-10 16:37:37.186802','2014-07-10 16:37:37.186802');
INSERT INTO "recording_views" VALUES(5688,3452,'2014-07-10 16:41:13.437721','2014-07-10 16:41:13.437721');
INSERT INTO "recording_views" VALUES(5690,3476,'2014-07-10 16:59:56.493509','2014-07-10 16:59:56.493509');
INSERT INTO "recording_views" VALUES(5691,3452,'2014-07-10 17:01:49.164664','2014-07-10 17:01:49.164664');
INSERT INTO "recording_views" VALUES(5692,3476,'2014-07-10 17:03:21.506499','2014-07-10 17:03:21.506499');
INSERT INTO "recording_views" VALUES(5693,3476,'2014-07-10 17:05:41.092597','2014-07-10 17:05:41.092597');
INSERT INTO "recording_views" VALUES(5697,3476,'2014-07-10 17:07:49.276244','2014-07-10 17:07:49.276244');
INSERT INTO "recording_views" VALUES(5699,3667,'2014-07-10 17:13:42.240075','2014-07-10 17:13:42.240075');
INSERT INTO "recording_views" VALUES(5700,3667,'2014-07-10 17:18:39.302817','2014-07-10 17:18:39.302817');
INSERT INTO "recording_views" VALUES(5701,3667,'2014-07-10 17:20:40.782313','2014-07-10 17:20:40.782313');
INSERT INTO "recording_views" VALUES(5703,3806,'2014-07-10 17:28:14.905479','2014-07-10 17:28:14.905479');
INSERT INTO "recording_views" VALUES(5704,3806,'2014-07-10 17:33:12.654737','2014-07-10 17:33:12.654737');
INSERT INTO "recording_views" VALUES(5708,3497,'2014-07-10 17:38:08.243551','2014-07-10 17:38:08.243551');
INSERT INTO "recording_views" VALUES(5710,3560,'2014-07-10 17:48:52.35762','2014-07-10 17:48:52.35762');
INSERT INTO "recording_views" VALUES(5711,3710,'2014-07-10 17:52:21.158125','2014-07-10 17:52:21.158125');
INSERT INTO "recording_views" VALUES(5714,3452,'2014-07-10 18:17:23.786175','2014-07-10 18:17:23.786175');
INSERT INTO "recording_views" VALUES(5715,3467,'2014-07-10 18:19:52.217323','2014-07-10 18:19:52.217323');
INSERT INTO "recording_views" VALUES(5717,3632,'2014-07-10 18:26:09.91038','2014-07-10 18:26:09.91038');
INSERT INTO "recording_views" VALUES(5718,3632,'2014-07-10 18:28:59.008123','2014-07-10 18:28:59.008123');
INSERT INTO "recording_views" VALUES(5723,3560,'2014-07-10 18:43:40.535102','2014-07-10 18:43:40.535102');
INSERT INTO "recording_views" VALUES(5727,3659,'2014-07-10 19:06:33.385676','2014-07-10 19:06:33.385676');
INSERT INTO "recording_views" VALUES(5729,3437,'2014-07-10 19:13:46.429996','2014-07-10 19:13:46.429996');
INSERT INTO "recording_views" VALUES(5730,3794,'2014-07-10 19:15:15.283842','2014-07-10 19:15:15.283842');
INSERT INTO "recording_views" VALUES(5732,3791,'2014-07-10 19:18:48.058438','2014-07-10 19:18:48.058438');
INSERT INTO "recording_views" VALUES(5733,3713,'2014-07-10 19:21:54.653892','2014-07-10 19:21:54.653892');
INSERT INTO "recording_views" VALUES(5734,3773,'2014-07-10 19:22:27.780869','2014-07-10 19:22:27.780869');
INSERT INTO "recording_views" VALUES(5736,3662,'2014-07-10 19:25:26.34471','2014-07-10 19:25:26.34471');
INSERT INTO "recording_views" VALUES(5739,3710,'2014-07-10 19:32:10.471558','2014-07-10 19:32:10.471558');
INSERT INTO "recording_views" VALUES(5741,3710,'2014-07-10 19:34:11.992909','2014-07-10 19:34:11.992909');
INSERT INTO "recording_views" VALUES(5742,1296,'2014-07-10 19:37:10.890413','2014-07-10 19:37:10.890413');
INSERT INTO "recording_views" VALUES(5743,3710,'2014-07-10 19:38:07.413299','2014-07-10 19:38:07.413299');
INSERT INTO "recording_views" VALUES(5744,3710,'2014-07-10 19:47:11.142724','2014-07-10 19:47:11.142724');
INSERT INTO "recording_views" VALUES(5745,3437,'2014-07-10 19:51:29.208512','2014-07-10 19:51:29.208512');
INSERT INTO "recording_views" VALUES(5746,3452,'2014-07-10 19:58:34.07576','2014-07-10 19:58:34.07576');
INSERT INTO "recording_views" VALUES(5750,3452,'2014-07-10 20:08:38.663175','2014-07-10 20:08:38.663175');
INSERT INTO "recording_views" VALUES(5754,3430,'2014-07-10 20:19:38.257993','2014-07-10 20:19:38.257993');
INSERT INTO "recording_views" VALUES(5760,3710,'2014-07-10 20:25:11.28915','2014-07-10 20:25:11.28915');
INSERT INTO "recording_views" VALUES(5766,3452,'2014-07-10 20:36:19.49608','2014-07-10 20:36:19.49608');
INSERT INTO "recording_views" VALUES(5772,3452,'2014-07-10 20:40:28.44701','2014-07-10 20:40:28.44701');
INSERT INTO "recording_views" VALUES(5781,3452,'2014-07-10 20:50:08.649763','2014-07-10 20:50:08.649763');
INSERT INTO "recording_views" VALUES(5788,3803,'2014-07-10 20:55:14.867015','2014-07-10 20:55:14.867015');
INSERT INTO "recording_views" VALUES(5793,3452,'2014-07-10 20:56:28.435122','2014-07-10 20:56:28.435122');
INSERT INTO "recording_views" VALUES(5799,3560,'2014-07-10 21:05:36.911805','2014-07-10 21:05:36.911805');
INSERT INTO "recording_views" VALUES(5802,3452,'2014-07-10 21:07:26.896098','2014-07-10 21:07:26.896098');
INSERT INTO "recording_views" VALUES(5804,3560,'2014-07-10 21:08:22.013194','2014-07-10 21:08:22.013194');
INSERT INTO "recording_views" VALUES(5807,3452,'2014-07-10 21:09:31.321442','2014-07-10 21:09:31.321442');
INSERT INTO "recording_views" VALUES(5813,3710,'2014-07-10 21:13:31.501672','2014-07-10 21:13:31.501672');
INSERT INTO "recording_views" VALUES(5818,3770,'2014-07-10 21:16:48.951133','2014-07-10 21:16:48.951133');
INSERT INTO "recording_views" VALUES(5823,3560,'2014-07-10 21:28:09.62949','2014-07-10 21:28:09.62949');
INSERT INTO "recording_views" VALUES(5832,3662,'2014-07-10 21:43:06.547986','2014-07-10 21:43:06.547986');
INSERT INTO "recording_views" VALUES(5835,3803,'2014-07-10 21:46:39.137488','2014-07-10 21:46:39.137488');
INSERT INTO "recording_views" VALUES(5837,3803,'2014-07-10 21:47:30.405278','2014-07-10 21:47:30.405278');
INSERT INTO "recording_views" VALUES(5839,3713,'2014-07-10 21:51:22.365794','2014-07-10 21:51:22.365794');
INSERT INTO "recording_views" VALUES(5846,3770,'2014-07-10 21:57:38.751846','2014-07-10 21:57:38.751846');
INSERT INTO "recording_views" VALUES(5848,3710,'2014-07-10 21:58:58.680279','2014-07-10 21:58:58.680279');
INSERT INTO "recording_views" VALUES(5855,3710,'2014-07-10 22:04:55.309927','2014-07-10 22:04:55.309927');
INSERT INTO "recording_views" VALUES(5862,3743,'2014-07-10 22:19:09.695893','2014-07-10 22:19:09.695893');
INSERT INTO "recording_views" VALUES(5891,3743,'2014-07-10 23:06:34.338429','2014-07-10 23:06:34.338429');
INSERT INTO "recording_views" VALUES(5909,227,'2014-07-11 00:09:03.747344','2014-07-11 00:09:03.747344');
INSERT INTO "recording_views" VALUES(5913,3722,'2014-07-11 01:14:43.553108','2014-07-11 01:14:43.553108');
INSERT INTO "recording_views" VALUES(5918,3560,'2014-07-11 02:11:03.105165','2014-07-11 02:11:03.105165');
INSERT INTO "recording_views" VALUES(5919,3560,'2014-07-11 02:19:16.193592','2014-07-11 02:19:16.193592');
INSERT INTO "recording_views" VALUES(5920,3560,'2014-07-11 02:21:22.596917','2014-07-11 02:21:22.596917');
INSERT INTO "recording_views" VALUES(5921,3560,'2014-07-11 02:22:57.996668','2014-07-11 02:22:57.996668');
INSERT INTO "recording_views" VALUES(5927,3506,'2014-07-11 03:51:08.275148','2014-07-11 03:51:08.275148');
INSERT INTO "recording_views" VALUES(5928,3710,'2014-07-11 03:53:34.812951','2014-07-11 03:53:34.812951');
INSERT INTO "recording_views" VALUES(5930,3710,'2014-07-11 04:24:23.150397','2014-07-11 04:24:23.150397');
INSERT INTO "recording_views" VALUES(5935,3743,'2014-07-11 05:13:23.585658','2014-07-11 05:13:23.585658');
INSERT INTO "recording_views" VALUES(5938,3434,'2014-07-11 05:25:12.011809','2014-07-11 05:25:12.011809');
INSERT INTO "recording_views" VALUES(5954,3452,'2014-07-11 06:59:36.371297','2014-07-11 06:59:36.371297');
INSERT INTO "recording_views" VALUES(5962,3452,'2014-07-11 07:18:07.966219','2014-07-11 07:18:07.966219');
INSERT INTO "recording_views" VALUES(5968,3596,'2014-07-11 07:27:57.231715','2014-07-11 07:27:57.231715');
INSERT INTO "recording_views" VALUES(5971,3727,'2014-07-11 07:36:47.18718','2014-07-11 07:36:47.18718');
INSERT INTO "recording_views" VALUES(5976,3452,'2014-07-11 07:47:24.66454','2014-07-11 07:47:24.66454');
INSERT INTO "recording_views" VALUES(5982,3452,'2014-07-11 07:58:59.303048','2014-07-11 07:58:59.303048');
INSERT INTO "recording_views" VALUES(5984,3506,'2014-07-11 08:08:33.717978','2014-07-11 08:08:33.717978');
INSERT INTO "recording_views" VALUES(5986,3506,'2014-07-11 08:10:58.487955','2014-07-11 08:10:58.487955');
INSERT INTO "recording_views" VALUES(5991,3788,'2014-07-11 08:11:57.934746','2014-07-11 08:11:57.934746');
INSERT INTO "recording_views" VALUES(5994,3452,'2014-07-11 08:15:01.982003','2014-07-11 08:15:01.982003');
INSERT INTO "recording_views" VALUES(6002,3452,'2014-07-11 08:22:36.913087','2014-07-11 08:22:36.913087');
INSERT INTO "recording_views" VALUES(6005,3434,'2014-07-11 08:24:10.103698','2014-07-11 08:24:10.103698');
INSERT INTO "recording_views" VALUES(6012,3452,'2014-07-11 08:29:54.594211','2014-07-11 08:29:54.594211');
INSERT INTO "recording_views" VALUES(6023,3434,'2014-07-11 08:39:00.511572','2014-07-11 08:39:00.511572');
INSERT INTO "recording_views" VALUES(6025,3434,'2014-07-11 08:44:23.042962','2014-07-11 08:44:23.042962');
INSERT INTO "recording_views" VALUES(6027,3506,'2014-07-11 08:45:27.908011','2014-07-11 08:45:27.908011');
INSERT INTO "recording_views" VALUES(6030,3506,'2014-07-11 08:51:05.372017','2014-07-11 08:51:05.372017');
INSERT INTO "recording_views" VALUES(6035,3506,'2014-07-11 08:53:55.521777','2014-07-11 08:53:55.521777');
INSERT INTO "recording_views" VALUES(6039,3452,'2014-07-11 08:58:43.80152','2014-07-11 08:58:43.80152');
INSERT INTO "recording_views" VALUES(6042,3506,'2014-07-11 09:02:12.460948','2014-07-11 09:02:12.460948');
INSERT INTO "recording_views" VALUES(6085,3536,'2014-07-11 10:31:02.575976','2014-07-11 10:31:02.575976');
INSERT INTO "recording_views" VALUES(6098,3446,'2014-07-11 10:52:39.454861','2014-07-11 10:52:39.454861');
INSERT INTO "recording_views" VALUES(6099,3667,'2014-07-11 10:57:17.147405','2014-07-11 10:57:17.147405');
INSERT INTO "recording_views" VALUES(6100,3452,'2014-07-11 11:01:56.835933','2014-07-11 11:01:56.835933');
INSERT INTO "recording_views" VALUES(6103,3452,'2014-07-11 11:04:03.133133','2014-07-11 11:04:03.133133');
INSERT INTO "recording_views" VALUES(6105,3667,'2014-07-11 11:08:47.390114','2014-07-11 11:08:47.390114');
INSERT INTO "recording_views" VALUES(6107,3452,'2014-07-11 11:13:22.935509','2014-07-11 11:13:22.935509');
INSERT INTO "recording_views" VALUES(6125,3806,'2014-07-11 11:45:46.033694','2014-07-11 11:45:46.033694');
INSERT INTO "recording_views" VALUES(6128,3806,'2014-07-11 11:54:54.345166','2014-07-11 11:54:54.345166');
INSERT INTO "recording_views" VALUES(6129,3806,'2014-07-11 11:58:24.847089','2014-07-11 11:58:24.847089');
INSERT INTO "recording_views" VALUES(6131,3806,'2014-07-11 12:00:48.930986','2014-07-11 12:00:48.930986');
INSERT INTO "recording_views" VALUES(6133,3986,'2014-07-11 12:07:46.04521','2014-07-11 12:07:46.04521');
INSERT INTO "recording_views" VALUES(6134,3806,'2014-07-11 12:07:46.632759','2014-07-11 12:07:46.632759');
INSERT INTO "recording_views" VALUES(6136,3497,'2014-07-11 12:12:50.876704','2014-07-11 12:12:50.876704');
INSERT INTO "recording_views" VALUES(6137,3602,'2014-07-11 12:15:10.707002','2014-07-11 12:15:10.707002');
INSERT INTO "recording_views" VALUES(6138,3602,'2014-07-11 12:17:50.453997','2014-07-11 12:17:50.453997');
INSERT INTO "recording_views" VALUES(6139,3602,'2014-07-11 12:23:21.343657','2014-07-11 12:23:21.343657');
INSERT INTO "recording_views" VALUES(6144,3452,'2014-07-11 12:35:07.75847','2014-07-11 12:35:07.75847');
INSERT INTO "recording_views" VALUES(6145,3452,'2014-07-11 12:36:48.676015','2014-07-11 12:36:48.676015');
INSERT INTO "recording_views" VALUES(6146,3497,'2014-07-11 12:37:18.881367','2014-07-11 12:37:18.881367');
INSERT INTO "recording_views" VALUES(6148,3527,'2014-07-11 12:38:40.166306','2014-07-11 12:38:40.166306');
INSERT INTO "recording_views" VALUES(6153,3437,'2014-07-11 12:53:42.191658','2014-07-11 12:53:42.191658');
INSERT INTO "recording_views" VALUES(6156,3437,'2014-07-11 12:56:13.385639','2014-07-11 12:56:13.385639');
INSERT INTO "recording_views" VALUES(6158,3451,'2014-07-11 13:03:31.05849','2014-07-11 13:03:31.05849');
INSERT INTO "recording_views" VALUES(6160,1236,'2014-07-11 13:14:29.356306','2014-07-11 13:14:29.356306');
INSERT INTO "recording_views" VALUES(6161,3452,'2014-07-11 13:16:31.649793','2014-07-11 13:16:31.649793');
INSERT INTO "recording_views" VALUES(6171,3451,'2014-07-11 13:36:55.385074','2014-07-11 13:36:55.385074');
INSERT INTO "recording_views" VALUES(6173,3452,'2014-07-11 13:42:17.407512','2014-07-11 13:42:17.407512');
INSERT INTO "recording_views" VALUES(6174,1236,'2014-07-11 13:42:23.564818','2014-07-11 13:42:23.564818');
INSERT INTO "recording_views" VALUES(6175,3514,'2014-07-11 13:43:43.304872','2014-07-11 13:43:43.304872');
INSERT INTO "recording_views" VALUES(6179,1236,'2014-07-11 13:53:54.278828','2014-07-11 13:53:54.278828');
INSERT INTO "recording_views" VALUES(6181,1206,'2014-07-11 13:57:46.577245','2014-07-11 13:57:46.577245');
INSERT INTO "recording_views" VALUES(6186,3452,'2014-07-11 14:03:06.109095','2014-07-11 14:03:06.109095');
INSERT INTO "recording_views" VALUES(6187,1206,'2014-07-11 14:03:29.343136','2014-07-11 14:03:29.343136');
INSERT INTO "recording_views" VALUES(6189,3452,'2014-07-11 14:10:47.124771','2014-07-11 14:10:47.124771');
INSERT INTO "recording_views" VALUES(6190,3452,'2014-07-11 14:14:48.555868','2014-07-11 14:14:48.555868');
INSERT INTO "recording_views" VALUES(6191,3727,'2014-07-11 14:16:52.665794','2014-07-11 14:16:52.665794');
INSERT INTO "recording_views" VALUES(6192,3536,'2014-07-11 14:19:18.82038','2014-07-11 14:19:18.82038');
INSERT INTO "recording_views" VALUES(6194,3452,'2014-07-11 14:22:04.777168','2014-07-11 14:22:04.777168');
INSERT INTO "recording_views" VALUES(6196,3452,'2014-07-11 14:24:15.897839','2014-07-11 14:24:15.897839');
INSERT INTO "recording_views" VALUES(6198,3452,'2014-07-11 14:26:31.51702','2014-07-11 14:26:31.51702');
INSERT INTO "recording_views" VALUES(6200,3536,'2014-07-11 14:41:09.349861','2014-07-11 14:41:09.349861');
INSERT INTO "recording_views" VALUES(6201,3593,'2014-07-11 14:41:15.636271','2014-07-11 14:41:15.636271');
INSERT INTO "recording_views" VALUES(6207,3452,'2014-07-11 14:56:58.677821','2014-07-11 14:56:58.677821');
INSERT INTO "recording_views" VALUES(6210,3452,'2014-07-11 15:03:48.003503','2014-07-11 15:03:48.003503');
INSERT INTO "recording_views" VALUES(6211,3662,'2014-07-11 15:04:21.968681','2014-07-11 15:04:21.968681');
INSERT INTO "recording_views" VALUES(6212,3452,'2014-07-11 15:05:56.287942','2014-07-11 15:05:56.287942');
INSERT INTO "recording_views" VALUES(6216,3452,'2014-07-11 15:10:07.979725','2014-07-11 15:10:07.979725');
INSERT INTO "recording_views" VALUES(6222,3710,'2014-07-11 15:34:44.371806','2014-07-11 15:34:44.371806');
INSERT INTO "recording_views" VALUES(6226,3710,'2014-07-11 15:45:28.619198','2014-07-11 15:45:28.619198');
INSERT INTO "recording_views" VALUES(6232,3710,'2014-07-11 15:53:33.589016','2014-07-11 15:53:33.589016');
INSERT INTO "recording_views" VALUES(6238,3710,'2014-07-11 16:03:11.930297','2014-07-11 16:03:11.930297');
INSERT INTO "recording_views" VALUES(6241,3452,'2014-07-11 16:05:22.640594','2014-07-11 16:05:22.640594');
INSERT INTO "recording_views" VALUES(6248,3734,'2014-07-11 16:11:50.175445','2014-07-11 16:11:50.175445');
INSERT INTO "recording_views" VALUES(6249,3491,'2014-07-11 16:12:43.944694','2014-07-11 16:12:43.944694');
INSERT INTO "recording_views" VALUES(6255,3491,'2014-07-11 16:19:45.868856','2014-07-11 16:19:45.868856');
INSERT INTO "recording_views" VALUES(6259,3548,'2014-07-11 16:23:49.812848','2014-07-11 16:23:49.812848');
INSERT INTO "recording_views" VALUES(6260,3548,'2014-07-11 16:28:15.715772','2014-07-11 16:28:15.715772');
INSERT INTO "recording_views" VALUES(6262,3491,'2014-07-11 16:34:54.820384','2014-07-11 16:34:54.820384');
INSERT INTO "recording_views" VALUES(6265,3752,'2014-07-11 16:40:37.097445','2014-07-11 16:40:37.097445');
INSERT INTO "recording_views" VALUES(6272,3452,'2014-07-11 16:45:45.831023','2014-07-11 16:45:45.831023');
INSERT INTO "recording_views" VALUES(6276,3452,'2014-07-11 16:52:14.778986','2014-07-11 16:52:14.778986');
INSERT INTO "recording_views" VALUES(6278,3452,'2014-07-11 16:54:27.566629','2014-07-11 16:54:27.566629');
INSERT INTO "recording_views" VALUES(6286,3548,'2014-07-11 17:08:51.381962','2014-07-11 17:08:51.381962');
INSERT INTO "recording_views" VALUES(6287,3548,'2014-07-11 17:11:24.614556','2014-07-11 17:11:24.614556');
INSERT INTO "recording_views" VALUES(6295,3632,'2014-07-11 17:27:13.767507','2014-07-11 17:27:13.767507');
INSERT INTO "recording_views" VALUES(6299,3710,'2014-07-11 17:32:08.096941','2014-07-11 17:32:08.096941');
INSERT INTO "recording_views" VALUES(6301,3710,'2014-07-11 17:34:10.573404','2014-07-11 17:34:10.573404');
INSERT INTO "recording_views" VALUES(6307,3710,'2014-07-11 17:41:27.880211','2014-07-11 17:41:27.880211');
INSERT INTO "recording_views" VALUES(6309,3710,'2014-07-11 17:55:40.901972','2014-07-11 17:55:40.901972');
INSERT INTO "recording_views" VALUES(6310,3770,'2014-07-11 17:58:21.535243','2014-07-11 17:58:21.535243');
INSERT INTO "recording_views" VALUES(6311,3770,'2014-07-11 18:00:46.109745','2014-07-11 18:00:46.109745');
INSERT INTO "recording_views" VALUES(6312,3770,'2014-07-11 18:01:07.706702','2014-07-11 18:01:07.706702');
INSERT INTO "recording_views" VALUES(6313,3800,'2014-07-11 18:01:59.586741','2014-07-11 18:01:59.586741');
INSERT INTO "recording_views" VALUES(6314,3647,'2014-07-11 18:02:58.379974','2014-07-11 18:02:58.379974');
INSERT INTO "recording_views" VALUES(6317,3770,'2014-07-11 18:13:05.578025','2014-07-11 18:13:05.578025');
INSERT INTO "recording_views" VALUES(6319,3818,'2014-07-11 18:14:17.953382','2014-07-11 18:14:17.953382');
INSERT INTO "recording_views" VALUES(6321,3770,'2014-07-11 18:18:35.355703','2014-07-11 18:18:35.355703');
INSERT INTO "recording_views" VALUES(6322,3818,'2014-07-11 18:20:32.645852','2014-07-11 18:20:32.645852');
INSERT INTO "recording_views" VALUES(6326,3542,'2014-07-11 18:27:46.679988','2014-07-11 18:27:46.679988');
INSERT INTO "recording_views" VALUES(6329,3452,'2014-07-11 18:42:24.83652','2014-07-11 18:42:24.83652');
INSERT INTO "recording_views" VALUES(6342,3779,'2014-07-11 19:10:39.660453','2014-07-11 19:10:39.660453');
INSERT INTO "recording_views" VALUES(6344,3716,'2014-07-11 19:12:58.393662','2014-07-11 19:12:58.393662');
INSERT INTO "recording_views" VALUES(6348,3800,'2014-07-11 19:18:03.720853','2014-07-11 19:18:03.720853');
INSERT INTO "recording_views" VALUES(6353,3800,'2014-07-11 19:33:11.81011','2014-07-11 19:33:11.81011');
INSERT INTO "recording_views" VALUES(6354,3452,'2014-07-11 19:35:15.741353','2014-07-11 19:35:15.741353');
INSERT INTO "recording_views" VALUES(6357,3452,'2014-07-11 19:43:01.954488','2014-07-11 19:43:01.954488');
INSERT INTO "recording_views" VALUES(6358,3601,'2014-07-11 19:43:51.48916','2014-07-11 19:43:51.48916');
INSERT INTO "recording_views" VALUES(6359,3452,'2014-07-11 19:45:51.215879','2014-07-11 19:45:51.215879');
INSERT INTO "recording_views" VALUES(6360,3800,'2014-07-11 19:46:23.640289','2014-07-11 19:46:23.640289');
INSERT INTO "recording_views" VALUES(6361,3602,'2014-07-11 19:47:56.840999','2014-07-11 19:47:56.840999');
INSERT INTO "recording_views" VALUES(6362,3452,'2014-07-11 19:48:22.447006','2014-07-11 19:48:22.447006');
INSERT INTO "recording_views" VALUES(6363,3452,'2014-07-11 19:50:40.967725','2014-07-11 19:50:40.967725');
INSERT INTO "recording_views" VALUES(6364,3602,'2014-07-11 19:53:51.232842','2014-07-11 19:53:51.232842');
INSERT INTO "recording_views" VALUES(6365,3602,'2014-07-11 19:54:17.643959','2014-07-11 19:54:17.643959');
INSERT INTO "recording_views" VALUES(6366,1266,'2014-07-11 19:54:28.255734','2014-07-11 19:54:28.255734');
INSERT INTO "recording_views" VALUES(6368,3602,'2014-07-11 19:56:01.24157','2014-07-11 19:56:01.24157');
INSERT INTO "recording_views" VALUES(6369,3452,'2014-07-11 19:56:38.028365','2014-07-11 19:56:38.028365');
INSERT INTO "recording_views" VALUES(6370,3602,'2014-07-11 19:58:03.854924','2014-07-11 19:58:03.854924');
INSERT INTO "recording_views" VALUES(6371,3800,'2014-07-11 19:58:12.175895','2014-07-11 19:58:12.175895');
INSERT INTO "recording_views" VALUES(6372,1266,'2014-07-11 19:59:30.512146','2014-07-11 19:59:30.512146');
INSERT INTO "recording_views" VALUES(6374,218,'2014-07-11 20:03:56.957389','2014-07-11 20:03:56.957389');
INSERT INTO "recording_views" VALUES(6375,3452,'2014-07-11 20:07:32.077597','2014-07-11 20:07:32.077597');
INSERT INTO "recording_views" VALUES(6378,3602,'2014-07-11 20:14:10.22022','2014-07-11 20:14:10.22022');
INSERT INTO "recording_views" VALUES(6379,218,'2014-07-11 20:14:56.765451','2014-07-11 20:14:56.765451');
INSERT INTO "recording_views" VALUES(6381,3602,'2014-07-11 20:16:10.28926','2014-07-11 20:16:10.28926');
INSERT INTO "recording_views" VALUES(6382,3622,'2014-07-11 20:22:27.082892','2014-07-11 20:22:27.082892');
INSERT INTO "recording_views" VALUES(6385,3434,'2014-07-11 20:38:32.671375','2014-07-11 20:38:32.671375');
INSERT INTO "recording_views" VALUES(6386,3800,'2014-07-11 20:38:42.72525','2014-07-11 20:38:42.72525');
INSERT INTO "recording_views" VALUES(6388,3602,'2014-07-11 20:40:29.262354','2014-07-11 20:40:29.262354');
INSERT INTO "recording_views" VALUES(6389,3620,'2014-07-11 20:43:01.877086','2014-07-11 20:43:01.877086');
INSERT INTO "recording_views" VALUES(6391,3506,'2014-07-11 20:43:25.708839','2014-07-11 20:43:25.708839');
INSERT INTO "recording_views" VALUES(6394,3602,'2014-07-11 20:44:49.541115','2014-07-11 20:44:49.541115');
INSERT INTO "recording_views" VALUES(6396,3602,'2014-07-11 20:50:28.985203','2014-07-11 20:50:28.985203');
INSERT INTO "recording_views" VALUES(6399,3602,'2014-07-11 21:03:21.99403','2014-07-11 21:03:21.99403');
INSERT INTO "recording_views" VALUES(6400,3560,'2014-07-11 21:05:26.111762','2014-07-11 21:05:26.111762');
INSERT INTO "recording_views" VALUES(6403,3602,'2014-07-11 21:13:33.459265','2014-07-11 21:13:33.459265');
INSERT INTO "recording_views" VALUES(6405,3455,'2014-07-11 21:16:37.887739','2014-07-11 21:16:37.887739');
INSERT INTO "recording_views" VALUES(6406,3452,'2014-07-11 21:16:48.144966','2014-07-11 21:16:48.144966');
INSERT INTO "recording_views" VALUES(6408,3455,'2014-07-11 21:18:38.484654','2014-07-11 21:18:38.484654');
INSERT INTO "recording_views" VALUES(6409,3752,'2014-07-11 21:18:43.654213','2014-07-11 21:18:43.654213');
INSERT INTO "recording_views" VALUES(6410,3497,'2014-07-11 21:18:45.740112','2014-07-11 21:18:45.740112');
INSERT INTO "recording_views" VALUES(6413,3622,'2014-07-11 21:19:49.95313','2014-07-11 21:19:49.95313');
INSERT INTO "recording_views" VALUES(6414,3455,'2014-07-11 21:20:46.137813','2014-07-11 21:20:46.137813');
INSERT INTO "recording_views" VALUES(6415,3452,'2014-07-11 21:22:04.998601','2014-07-11 21:22:04.998601');
INSERT INTO "recording_views" VALUES(6416,3799,'2014-07-11 21:22:07.110531','2014-07-11 21:22:07.110531');
INSERT INTO "recording_views" VALUES(6417,3710,'2014-07-11 21:22:58.832789','2014-07-11 21:22:58.832789');
INSERT INTO "recording_views" VALUES(6418,3800,'2014-07-11 21:23:38.09266','2014-07-11 21:23:38.09266');
INSERT INTO "recording_views" VALUES(6420,3752,'2014-07-11 21:25:14.976432','2014-07-11 21:25:14.976432');
INSERT INTO "recording_views" VALUES(6421,3617,'2014-07-11 21:26:08.519933','2014-07-11 21:26:08.519933');
INSERT INTO "recording_views" VALUES(6422,3524,'2014-07-11 21:26:53.513119','2014-07-11 21:26:53.513119');
INSERT INTO "recording_views" VALUES(6430,3452,'2014-07-11 21:40:09.310176','2014-07-11 21:40:09.310176');
INSERT INTO "recording_views" VALUES(6431,3535,'2014-07-11 21:41:58.886882','2014-07-11 21:41:58.886882');
INSERT INTO "recording_views" VALUES(6432,3535,'2014-07-11 21:42:18.702617','2014-07-11 21:42:18.702617');
INSERT INTO "recording_views" VALUES(6433,3452,'2014-07-11 21:43:16.116178','2014-07-11 21:43:16.116178');
INSERT INTO "recording_views" VALUES(6434,3535,'2014-07-11 21:44:34.791046','2014-07-11 21:44:34.791046');
INSERT INTO "recording_views" VALUES(6436,3452,'2014-07-11 21:49:40.422092','2014-07-11 21:49:40.422092');
INSERT INTO "recording_views" VALUES(6440,3779,'2014-07-11 21:56:10.006534','2014-07-11 21:56:10.006534');
INSERT INTO "recording_views" VALUES(6441,3497,'2014-07-11 21:56:22.825698','2014-07-11 21:56:22.825698');
INSERT INTO "recording_views" VALUES(6442,3664,'2014-07-11 21:57:56.013569','2014-07-11 21:57:56.013569');
INSERT INTO "recording_views" VALUES(6443,3452,'2014-07-11 22:00:14.837985','2014-07-11 22:00:14.837985');
INSERT INTO "recording_views" VALUES(6446,3799,'2014-07-11 22:08:06.272516','2014-07-11 22:08:06.272516');
INSERT INTO "recording_views" VALUES(6450,3452,'2014-07-11 22:11:23.682695','2014-07-11 22:11:23.682695');
INSERT INTO "recording_views" VALUES(6451,3752,'2014-07-11 22:12:46.372459','2014-07-11 22:12:46.372459');
INSERT INTO "recording_views" VALUES(6457,3752,'2014-07-11 22:20:01.583494','2014-07-11 22:20:01.583494');
INSERT INTO "recording_views" VALUES(6458,3452,'2014-07-11 22:20:45.815514','2014-07-11 22:20:45.815514');
INSERT INTO "recording_views" VALUES(6459,3799,'2014-07-11 22:21:18.999773','2014-07-11 22:21:18.999773');
INSERT INTO "recording_views" VALUES(6460,3799,'2014-07-11 22:21:27.330252','2014-07-11 22:21:27.330252');
INSERT INTO "recording_views" VALUES(6462,1295,'2014-07-11 22:23:42.584957','2014-07-11 22:23:42.584957');
INSERT INTO "recording_views" VALUES(6465,3452,'2014-07-11 22:36:13.354577','2014-07-11 22:36:13.354577');
INSERT INTO "recording_views" VALUES(6470,3602,'2014-07-11 22:49:56.279084','2014-07-11 22:49:56.279084');
INSERT INTO "recording_views" VALUES(6471,3575,'2014-07-11 22:51:42.099623','2014-07-11 22:51:42.099623');
INSERT INTO "recording_views" VALUES(6472,3497,'2014-07-11 22:55:16.968231','2014-07-11 22:55:16.968231');
INSERT INTO "recording_views" VALUES(6473,3575,'2014-07-11 22:58:12.817352','2014-07-11 22:58:12.817352');
INSERT INTO "recording_views" VALUES(6474,3575,'2014-07-11 23:04:34.788477','2014-07-11 23:04:34.788477');
INSERT INTO "recording_views" VALUES(6475,3506,'2014-07-11 23:05:58.70006','2014-07-11 23:05:58.70006');
INSERT INTO "recording_views" VALUES(6476,3497,'2014-07-11 23:08:19.23563','2014-07-11 23:08:19.23563');
INSERT INTO "recording_views" VALUES(6477,3506,'2014-07-11 23:09:03.430552','2014-07-11 23:09:03.430552');
INSERT INTO "recording_views" VALUES(6479,3551,'2014-07-11 23:13:02.512063','2014-07-11 23:13:02.512063');
INSERT INTO "recording_views" VALUES(6480,3506,'2014-07-11 23:15:55.516026','2014-07-11 23:15:55.516026');
INSERT INTO "recording_views" VALUES(6481,3629,'2014-07-11 23:24:11.807437','2014-07-11 23:24:11.807437');
INSERT INTO "recording_views" VALUES(6482,3653,'2014-07-11 23:24:43.242078','2014-07-11 23:24:43.242078');
INSERT INTO "recording_views" VALUES(6483,3653,'2014-07-11 23:28:08.205097','2014-07-11 23:28:08.205097');
INSERT INTO "recording_views" VALUES(6484,3653,'2014-07-11 23:31:13.22252','2014-07-11 23:31:13.22252');
INSERT INTO "recording_views" VALUES(6486,3554,'2014-07-11 23:39:23.770814','2014-07-11 23:39:23.770814');
INSERT INTO "recording_views" VALUES(6487,3512,'2014-07-11 23:50:35.198733','2014-07-11 23:50:35.198733');
INSERT INTO "recording_views" VALUES(6488,3548,'2014-07-11 23:54:46.851888','2014-07-11 23:54:46.851888');
INSERT INTO "recording_views" VALUES(6489,3488,'2014-07-11 23:57:59.135776','2014-07-11 23:57:59.135776');
INSERT INTO "recording_views" VALUES(6491,3653,'2014-07-12 00:01:37.425444','2014-07-12 00:01:37.425444');
INSERT INTO "recording_views" VALUES(6492,3653,'2014-07-12 00:04:03.086186','2014-07-12 00:04:03.086186');
INSERT INTO "recording_views" VALUES(6493,3794,'2014-07-12 00:04:31.500287','2014-07-12 00:04:31.500287');
INSERT INTO "recording_views" VALUES(6494,3794,'2014-07-12 00:07:04.73127','2014-07-12 00:07:04.73127');
INSERT INTO "recording_views" VALUES(6495,3488,'2014-07-12 00:07:19.890541','2014-07-12 00:07:19.890541');
INSERT INTO "recording_views" VALUES(6496,3488,'2014-07-12 00:10:24.665559','2014-07-12 00:10:24.665559');
INSERT INTO "recording_views" VALUES(6497,3455,'2014-07-12 00:12:08.852551','2014-07-12 00:12:08.852551');
INSERT INTO "recording_views" VALUES(6500,3794,'2014-07-12 00:22:50.758292','2014-07-12 00:22:50.758292');
INSERT INTO "recording_views" VALUES(6502,3455,'2014-07-12 00:31:49.574743','2014-07-12 00:31:49.574743');
INSERT INTO "recording_views" VALUES(6505,3497,'2014-07-12 01:01:55.742718','2014-07-12 01:01:55.742718');
INSERT INTO "recording_views" VALUES(6513,3752,'2014-07-12 02:31:52.393737','2014-07-12 02:31:52.393737');
INSERT INTO "recording_views" VALUES(6517,1341,'2014-07-12 03:17:52.165023','2014-07-12 03:17:52.165023');
INSERT INTO "recording_views" VALUES(6518,1326,'2014-07-12 03:18:42.814077','2014-07-12 03:18:42.814077');
INSERT INTO "recording_views" VALUES(6519,1326,'2014-07-12 03:29:35.882968','2014-07-12 03:29:35.882968');
INSERT INTO "recording_views" VALUES(6520,3752,'2014-07-12 04:13:59.849107','2014-07-12 04:13:59.849107');
INSERT INTO "recording_views" VALUES(6521,3602,'2014-07-12 04:14:09.26571','2014-07-12 04:14:09.26571');
INSERT INTO "recording_views" VALUES(6522,3752,'2014-07-12 04:20:21.397829','2014-07-12 04:20:21.397829');
INSERT INTO "recording_views" VALUES(6524,1209,'2014-07-12 04:55:56.880499','2014-07-12 04:55:56.880499');
INSERT INTO "recording_views" VALUES(6525,3451,'2014-07-12 05:47:29.204095','2014-07-12 05:47:29.204095');
INSERT INTO "recording_views" VALUES(6526,3809,'2014-07-12 06:03:30.765099','2014-07-12 06:03:30.765099');
INSERT INTO "recording_views" VALUES(6533,1266,'2014-07-12 07:01:03.678539','2014-07-12 07:01:03.678539');
INSERT INTO "recording_views" VALUES(6534,1328,'2014-07-12 07:03:31.959627','2014-07-12 07:03:31.959627');
INSERT INTO "recording_views" VALUES(6535,1347,'2014-07-12 07:04:03.840763','2014-07-12 07:04:03.840763');
INSERT INTO "recording_views" VALUES(6537,3770,'2014-07-12 07:16:56.516318','2014-07-12 07:16:56.516318');
INSERT INTO "recording_views" VALUES(6538,3497,'2014-07-12 07:23:25.33252','2014-07-12 07:23:25.33252');
INSERT INTO "recording_views" VALUES(6540,1328,'2014-07-12 07:24:36.83568','2014-07-12 07:24:36.83568');
INSERT INTO "recording_views" VALUES(6541,1328,'2014-07-12 07:26:58.007455','2014-07-12 07:26:58.007455');
INSERT INTO "recording_views" VALUES(6543,3662,'2014-07-12 07:27:36.758452','2014-07-12 07:27:36.758452');
INSERT INTO "recording_views" VALUES(6545,3703,'2014-07-12 07:35:12.913622','2014-07-12 07:35:12.913622');
INSERT INTO "recording_views" VALUES(6548,3452,'2014-07-12 07:41:32.292318','2014-07-12 07:41:32.292318');
INSERT INTO "recording_views" VALUES(6549,3452,'2014-07-12 07:43:33.096169','2014-07-12 07:43:33.096169');
INSERT INTO "recording_views" VALUES(6550,3452,'2014-07-12 07:45:33.814001','2014-07-12 07:45:33.814001');
INSERT INTO "recording_views" VALUES(6551,3805,'2014-07-12 07:46:39.804667','2014-07-12 07:46:39.804667');
INSERT INTO "recording_views" VALUES(6552,3662,'2014-07-12 07:48:44.734854','2014-07-12 07:48:44.734854');
INSERT INTO "recording_views" VALUES(6553,3452,'2014-07-12 07:50:02.965419','2014-07-12 07:50:02.965419');
INSERT INTO "recording_views" VALUES(6554,3452,'2014-07-12 07:51:02.330596','2014-07-12 07:51:02.330596');
INSERT INTO "recording_views" VALUES(6555,3451,'2014-07-12 07:54:18.500994','2014-07-12 07:54:18.500994');
INSERT INTO "recording_views" VALUES(6556,3620,'2014-07-12 07:55:43.587065','2014-07-12 07:55:43.587065');
INSERT INTO "recording_views" VALUES(6559,3674,'2014-07-12 08:07:25.685227','2014-07-12 08:07:25.685227');
INSERT INTO "recording_views" VALUES(6560,3674,'2014-07-12 08:12:56.29289','2014-07-12 08:12:56.29289');
INSERT INTO "recording_views" VALUES(6561,3560,'2014-07-12 08:14:19.198808','2014-07-12 08:14:19.198808');
INSERT INTO "recording_views" VALUES(6562,3506,'2014-07-12 08:14:56.295387','2014-07-12 08:14:56.295387');
INSERT INTO "recording_views" VALUES(6563,3703,'2014-07-12 08:15:10.677479','2014-07-12 08:15:10.677479');
INSERT INTO "recording_views" VALUES(6564,3506,'2014-07-12 08:17:23.796955','2014-07-12 08:17:23.796955');
INSERT INTO "recording_views" VALUES(6566,3746,'2014-07-12 08:20:08.676387','2014-07-12 08:20:08.676387');
INSERT INTO "recording_views" VALUES(6567,3746,'2014-07-12 08:25:52.235121','2014-07-12 08:25:52.235121');
INSERT INTO "recording_views" VALUES(6568,3800,'2014-07-12 08:29:13.230637','2014-07-12 08:29:13.230637');
INSERT INTO "recording_views" VALUES(6569,3451,'2014-07-12 08:30:07.09575','2014-07-12 08:30:07.09575');
INSERT INTO "recording_views" VALUES(6570,3506,'2014-07-12 08:32:43.923715','2014-07-12 08:32:43.923715');
INSERT INTO "recording_views" VALUES(6571,3746,'2014-07-12 08:35:57.598073','2014-07-12 08:35:57.598073');
INSERT INTO "recording_views" VALUES(6573,3746,'2014-07-12 08:38:26.562635','2014-07-12 08:38:26.562635');
INSERT INTO "recording_views" VALUES(6574,3602,'2014-07-12 08:42:01.858568','2014-07-12 08:42:01.858568');
INSERT INTO "recording_views" VALUES(6575,3506,'2014-07-12 08:43:10.147425','2014-07-12 08:43:10.147425');
INSERT INTO "recording_views" VALUES(6577,3689,'2014-07-12 08:44:40.857195','2014-07-12 08:44:40.857195');
INSERT INTO "recording_views" VALUES(6578,3452,'2014-07-12 08:45:55.866672','2014-07-12 08:45:55.866672');
INSERT INTO "recording_views" VALUES(6579,3800,'2014-07-12 08:47:12.17936','2014-07-12 08:47:12.17936');
INSERT INTO "recording_views" VALUES(6580,3629,'2014-07-12 08:47:14.633716','2014-07-12 08:47:14.633716');
INSERT INTO "recording_views" VALUES(6581,3800,'2014-07-12 08:49:44.640827','2014-07-12 08:49:44.640827');
INSERT INTO "recording_views" VALUES(6582,3629,'2014-07-12 08:49:55.126375','2014-07-12 08:49:55.126375');
INSERT INTO "recording_views" VALUES(6583,3506,'2014-07-12 08:52:42.602933','2014-07-12 08:52:42.602933');
INSERT INTO "recording_views" VALUES(6584,3451,'2014-07-12 08:54:40.950341','2014-07-12 08:54:40.950341');
INSERT INTO "recording_views" VALUES(6585,3629,'2014-07-12 08:55:29.138766','2014-07-12 08:55:29.138766');
INSERT INTO "recording_views" VALUES(6586,3629,'2014-07-12 08:57:42.305828','2014-07-12 08:57:42.305828');
INSERT INTO "recording_views" VALUES(6589,3452,'2014-07-12 09:17:20.135346','2014-07-12 09:17:20.135346');
INSERT INTO "recording_views" VALUES(6613,3497,'2014-07-12 10:13:46.069709','2014-07-12 10:13:46.069709');
INSERT INTO "recording_views" VALUES(6616,3497,'2014-07-12 10:25:07.369932','2014-07-12 10:25:07.369932');
INSERT INTO "recording_views" VALUES(6617,3497,'2014-07-12 10:27:47.739676','2014-07-12 10:27:47.739676');
INSERT INTO "recording_views" VALUES(6619,3779,'2014-07-12 10:47:50.033515','2014-07-12 10:47:50.033515');
INSERT INTO "recording_views" VALUES(6622,3779,'2014-07-12 10:52:33.584908','2014-07-12 10:52:33.584908');
INSERT INTO "recording_views" VALUES(6633,3602,'2014-07-12 11:33:34.969228','2014-07-12 11:33:34.969228');
CREATE TABLE "recordings" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "size" integer, "length" integer, "mime_type" varchar(255), "event_id" integer, "created_at" datetime, "updated_at" datetime, "filename" varchar(255), "original_url" varchar(255), "state" varchar(255) DEFAULT 'new' NOT NULL, "folder" varchar(255), "width" integer, "height" integer);
INSERT INTO "recordings" VALUES(49,432,4236,'video/webm',124,'2014-05-10 13:26:12.363889','2014-05-10 13:26:12.363889','cccamp11-4500-reviving_smart_card_analysis-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(50,432,4236,'video/mp4',124,'2014-05-10 13:26:12.369686','2014-05-10 13:26:12.369686','cccamp11-4500-reviving_smart_card_analysis-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(51,432,4236,'video/ogg',124,'2014-05-10 13:26:12.375269','2014-05-10 13:26:12.375269','cccamp11-4500-reviving_smart_card_analysis-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(52,425,2932,'video/webm',125,'2014-05-10 13:26:12.39284','2014-05-10 13:26:12.39284','cccamp11-4597-moonbounce_radio_communication-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(53,425,2932,'video/mp4',125,'2014-05-10 13:26:12.398533','2014-05-10 13:26:12.398533','cccamp11-4597-moonbounce_radio_communication-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(54,425,2932,'video/ogg',125,'2014-05-10 13:26:12.404105','2014-05-10 13:26:12.404105','cccamp11-4597-moonbounce_radio_communication-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(55,430,3802,'video/webm',126,'2014-05-10 13:26:12.421644','2014-05-10 13:26:12.421644','cccamp11-4487-she_hackers-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(56,430,3802,'video/mp4',126,'2014-05-10 13:26:12.427329','2014-05-10 13:26:12.427329','cccamp11-4487-she_hackers-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(57,430,3802,'video/ogg',126,'2014-05-10 13:26:12.511007','2014-05-10 13:26:12.511007','cccamp11-4487-she_hackers-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(58,426,3885,'video/webm',127,'2014-05-10 13:26:12.530429','2014-05-10 13:26:12.530429','cccamp11-4418-cyberpeace_and_datalove-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(59,426,3885,'video/mp4',127,'2014-05-10 13:26:12.536344','2014-05-10 13:26:12.536344','cccamp11-4418-cyberpeace_and_datalove-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(60,426,3885,'video/ogg',127,'2014-05-10 13:26:12.542159','2014-05-10 13:26:12.542159','cccamp11-4418-cyberpeace_and_datalove-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(61,430,3466,'video/webm',128,'2014-05-10 13:26:12.559902','2014-05-10 13:26:12.559902','cccamp11-4467-design_and_implementation_of_flight_electronics-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(62,430,3466,'video/mp4',128,'2014-05-10 13:26:12.565753','2014-05-10 13:26:12.565753','cccamp11-4467-design_and_implementation_of_flight_electronics-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(63,430,3466,'video/ogg',128,'2014-05-10 13:26:12.571449','2014-05-10 13:26:12.571449','cccamp11-4467-design_and_implementation_of_flight_electronics-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(64,421,2431,'video/webm',129,'2014-05-10 13:26:12.589109','2014-05-10 13:26:12.589109','cccamp11-4428-the_joy_of_intellectual_vampirism-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(65,421,2431,'video/mp4',129,'2014-05-10 13:26:12.594878','2014-05-10 13:26:12.594878','cccamp11-4428-the_joy_of_intellectual_vampirism-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(66,421,2431,'video/ogg',129,'2014-05-10 13:26:12.600473','2014-05-10 13:26:12.600473','cccamp11-4428-the_joy_of_intellectual_vampirism-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(67,424,3533,'video/webm',130,'2014-05-10 13:26:12.617849','2014-05-10 13:26:12.617849','cccamp11-4427-the_blackbox_in_your_phone-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(68,424,3533,'video/mp4',130,'2014-05-10 13:26:12.623535','2014-05-10 13:26:12.623535','cccamp11-4427-the_blackbox_in_your_phone-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(69,424,3533,'video/ogg',130,'2014-05-10 13:26:12.62906','2014-05-10 13:26:12.62906','cccamp11-4427-the_blackbox_in_your_phone-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(70,75,143,'video/mp4',131,'2014-05-10 13:26:12.645852','2014-06-19 09:48:46.443398','camp2011_trailer.m4v',NULL,'downloaded','trailer',1248,702);
INSERT INTO "recordings" VALUES(71,427,3386,'video/webm',132,'2014-05-10 13:26:12.663289','2014-05-10 13:26:12.663289','cccamp11-4491-rethinking_online_news-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(72,427,3386,'video/mp4',132,'2014-05-10 13:26:12.668947','2014-05-10 13:26:12.668947','cccamp11-4491-rethinking_online_news-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(73,427,3386,'video/ogg',132,'2014-05-10 13:26:12.674448','2014-05-10 13:26:12.674448','cccamp11-4491-rethinking_online_news-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(74,419,2236,'video/webm',133,'2014-05-10 13:26:12.691665','2014-05-10 13:26:12.691665','cccamp11-4458-inertial_navigation-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(75,419,2236,'video/mp4',133,'2014-05-10 13:26:12.697309','2014-05-10 13:26:12.697309','cccamp11-4458-inertial_navigation-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(76,419,2236,'video/ogg',133,'2014-05-10 13:26:12.702813','2014-05-10 13:26:12.702813','cccamp11-4458-inertial_navigation-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(77,426,3097,'video/webm',134,'2014-05-10 13:26:12.719946','2014-05-10 13:26:12.719946','cccamp11-4455-the-arguna-rocket-family-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(78,426,3097,'video/mp4',134,'2014-05-10 13:26:12.725561','2014-05-10 13:26:12.725561','cccamp11-4455-the-arguna-rocket-family-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(79,426,3097,'video/ogg',134,'2014-05-10 13:26:12.731025','2014-05-10 13:26:12.731025','cccamp11-4455-the-arguna-rocket-family-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(80,439,4482,'video/webm',135,'2014-05-10 13:26:12.748272','2014-05-10 13:26:12.748272','cccamp11-4459-transition_telecom-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(81,439,4482,'video/mp4',135,'2014-05-10 13:26:12.753891','2014-05-10 13:26:12.753891','cccamp11-4459-transition_telecom-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(82,439,4482,'video/ogg',135,'2014-05-10 13:26:12.759359','2014-05-10 13:26:12.759359','cccamp11-4459-transition_telecom-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(83,435,4142,'video/webm',136,'2014-05-10 13:26:12.776491','2014-05-10 13:26:12.776491','cccamp11-4591-financing_the_revolution-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(84,435,4142,'video/mp4',136,'2014-05-10 13:26:12.782113','2014-05-10 13:26:12.782113','cccamp11-4591-financing_the_revolution-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(85,435,4142,'video/ogg',136,'2014-05-10 13:26:12.787573','2014-05-10 13:26:12.787573','cccamp11-4591-financing_the_revolution-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(86,427,3175,'video/webm',137,'2014-05-10 13:26:12.804657','2014-05-10 13:26:12.804657','cccamp11-4453-stuff_you_dont_see_every_day-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(87,427,3175,'video/mp4',137,'2014-05-10 13:26:12.81021','2014-05-10 13:26:12.81021','cccamp11-4453-stuff_you_dont_see_every_day-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(88,427,3175,'video/ogg',137,'2014-05-10 13:26:12.815653','2014-05-10 13:26:12.815653','cccamp11-4453-stuff_you_dont_see_every_day-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(89,428,3367,'video/webm',138,'2014-05-10 13:26:12.832642','2014-05-10 13:26:12.832642','cccamp11-4495-introduction_to_multicast_security-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(90,428,3367,'video/mp4',138,'2014-05-10 13:26:12.838239','2014-05-10 13:26:12.838239','cccamp11-4495-introduction_to_multicast_security-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(91,428,3367,'video/ogg',138,'2014-05-10 13:26:12.843695','2014-05-10 13:26:12.843695','cccamp11-4495-introduction_to_multicast_security-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(92,435,4667,'video/webm',139,'2014-05-10 13:26:12.860774','2014-05-10 13:26:12.860774','cccamp11-4450-imagine_the_future_of_money-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(93,435,4667,'video/mp4',139,'2014-05-10 13:26:12.866365','2014-05-10 13:26:12.866365','cccamp11-4450-imagine_the_future_of_money-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(94,435,4667,'video/ogg',139,'2014-05-10 13:26:12.871793','2014-05-10 13:26:12.871793','cccamp11-4450-imagine_the_future_of_money-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(95,423,2702,'video/webm',140,'2014-05-10 13:26:12.888958','2014-05-10 13:26:12.888958','cccamp11-4439-maching_to_machine_security-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(96,423,2702,'video/mp4',140,'2014-05-10 13:26:12.894529','2014-05-10 13:26:12.894529','cccamp11-4439-maching_to_machine_security-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(97,423,2702,'video/ogg',140,'2014-05-10 13:26:12.899921','2014-05-10 13:26:12.899921','cccamp11-4439-maching_to_machine_security-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(98,425,3143,'video/webm',141,'2014-05-10 13:26:12.9169','2014-05-10 13:26:12.9169','cccamp11-4438-mehrseitig_sichere_web_20_umfragen-de.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(99,425,3143,'video/mp4',141,'2014-05-10 13:26:12.922476','2014-05-10 13:26:12.922476','cccamp11-4438-mehrseitig_sichere_web_20_umfragen-de.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(100,425,3143,'video/ogg',141,'2014-05-10 13:26:12.92791','2014-05-10 13:26:12.92791','cccamp11-4438-mehrseitig_sichere_web_20_umfragen-de.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(101,439,4495,'video/webm',142,'2014-05-10 13:26:12.945014','2014-05-10 13:26:12.945014','cccamp11-4560-post_hacker_ethics_cyberwar-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(102,439,4495,'video/mp4',142,'2014-05-10 13:26:12.950587','2014-05-10 13:26:12.950587','cccamp11-4560-post_hacker_ethics_cyberwar-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(103,439,4495,'video/ogg',142,'2014-05-10 13:26:12.956033','2014-05-10 13:26:12.956033','cccamp11-4560-post_hacker_ethics_cyberwar-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(104,430,3456,'video/webm',143,'2014-05-10 13:26:12.973218','2014-05-10 13:26:12.973218','cccamp11-4552-openleaks-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(105,430,3456,'video/mp4',143,'2014-05-10 13:26:12.97898','2014-05-10 13:26:12.97898','cccamp11-4552-openleaks-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(106,430,3456,'video/ogg',143,'2014-05-10 13:26:12.984439','2014-05-10 13:26:12.984439','cccamp11-4552-openleaks-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(107,423,3027,'video/webm',144,'2014-05-10 13:26:13.001723','2014-05-10 13:26:13.001723','cccamp11-4411-space_debris-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(108,423,3027,'video/mp4',144,'2014-05-10 13:26:13.090901','2014-05-10 13:26:13.090901','cccamp11-4411-space_debris-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(109,423,3027,'video/ogg',144,'2014-05-10 13:26:13.097264','2014-05-10 13:26:13.097264','cccamp11-4411-space_debris-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(110,421,3080,'video/webm',145,'2014-05-10 13:26:13.115271','2014-05-10 13:26:13.115271','cccamp11-4421-strong_encryption_of_credit_card_information-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(111,421,3080,'video/mp4',145,'2014-05-10 13:26:13.122053','2014-05-10 13:26:13.122053','cccamp11-4421-strong_encryption_of_credit_card_information-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(112,421,3080,'video/ogg',145,'2014-05-10 13:26:13.127933','2014-05-10 13:26:13.127933','cccamp11-4421-strong_encryption_of_credit_card_information-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(113,417,2215,'video/webm',146,'2014-05-10 13:26:13.145875','2014-05-10 13:26:13.145875','cccamp11-4471-who_is_snitching_my_milk-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(114,417,2215,'video/mp4',146,'2014-05-10 13:26:13.151706','2014-05-10 13:26:13.151706','cccamp11-4471-who_is_snitching_my_milk-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(115,417,2215,'video/ogg',146,'2014-05-10 13:26:13.158128','2014-05-10 13:26:13.158128','cccamp11-4471-who_is_snitching_my_milk-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(116,436,3997,'video/webm',147,'2014-05-10 13:26:13.175967','2014-05-10 13:26:13.175967','cccamp11-4472-hacking_dna-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(117,436,3997,'video/mp4',147,'2014-05-10 13:26:13.181711','2014-05-10 13:26:13.181711','cccamp11-4472-hacking_dna-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(118,436,3997,'video/ogg',147,'2014-05-10 13:26:13.187358','2014-05-10 13:26:13.187358','cccamp11-4472-hacking_dna-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(119,427,3404,'video/webm',148,'2014-05-10 13:26:13.205305','2014-05-10 13:26:13.205305','cccamp11-4549-sport_fuer_nerds-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(120,427,3404,'video/mp4',148,'2014-05-10 13:26:13.211006','2014-05-10 13:26:13.211006','cccamp11-4549-sport_fuer_nerds-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(121,427,3404,'video/ogg',148,'2014-05-10 13:26:13.216612','2014-05-10 13:26:13.216612','cccamp11-4549-sport_fuer_nerds-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(122,430,3426,'video/webm',149,'2014-05-10 13:26:13.234221','2014-05-10 13:26:13.234221','cccamp11-4406-giving_great_workshops-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(123,430,3426,'video/mp4',149,'2014-05-10 13:26:13.239912','2014-05-10 13:26:13.239912','cccamp11-4406-giving_great_workshops-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(124,430,3426,'video/ogg',149,'2014-05-10 13:26:13.245427','2014-05-10 13:26:13.245427','cccamp11-4406-giving_great_workshops-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(125,418,1947,'video/webm',150,'2014-05-10 13:26:13.262677','2014-05-10 13:26:13.262677','cccamp11-4502-is_this_the_mobile_gadget_world_we_created-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(126,418,1947,'video/mp4',150,'2014-05-10 13:26:13.268343','2014-05-10 13:26:13.268343','cccamp11-4502-is_this_the_mobile_gadget_world_we_created-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(127,418,1947,'video/ogg',150,'2014-05-10 13:26:13.273847','2014-05-10 13:26:13.273847','cccamp11-4502-is_this_the_mobile_gadget_world_we_created-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(128,428,3181,'video/webm',151,'2014-05-10 13:26:13.291394','2014-05-10 13:26:13.291394','cccamp11-4449-digitale_gesellschaft_ev-de.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(129,428,3181,'video/mp4',151,'2014-05-10 13:26:13.297366','2014-05-10 13:26:13.297366','cccamp11-4449-digitale_gesellschaft_ev-de.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(130,428,3181,'video/ogg',151,'2014-05-10 13:26:13.3029','2014-05-10 13:26:13.3029','cccamp11-4449-digitale_gesellschaft_ev-de.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(131,417,2092,'video/webm',152,'2014-05-10 13:26:13.320073','2014-05-10 13:26:13.320073','cccamp11-4399-runtine_reconfigurable_processors-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(132,417,2092,'video/mp4',152,'2014-05-10 13:26:13.325698','2014-05-10 13:26:13.325698','cccamp11-4399-runtine_reconfigurable_processors-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(133,417,2092,'video/ogg',152,'2014-05-10 13:26:13.331188','2014-05-10 13:26:13.331188','cccamp11-4399-runtine_reconfigurable_processors-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(134,382,2016,'video/webm',153,'2014-05-10 13:26:13.348529','2014-05-10 13:26:13.348529','cccamp11-4503-ich_und_23-de.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(135,382,2016,'video/mp4',153,'2014-05-10 13:26:13.35413','2014-05-10 13:26:13.35413','cccamp11-4503-ich_und_23-de.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(136,382,2016,'video/ogg',153,'2014-05-10 13:26:13.359605','2014-05-10 13:26:13.359605','cccamp11-4503-ich_und_23-de.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(137,431,3665,'video/webm',154,'2014-05-10 13:26:13.376977','2014-05-10 13:26:13.376977','cccamp11-4594-from_oscar_1_to_mars_and_beyond-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(138,431,3665,'video/mp4',154,'2014-05-10 13:26:13.382603','2014-05-10 13:26:13.382603','cccamp11-4594-from_oscar_1_to_mars_and_beyond-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(139,431,3665,'video/ogg',154,'2014-05-10 13:26:13.388072','2014-05-10 13:26:13.388072','cccamp11-4594-from_oscar_1_to_mars_and_beyond-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(140,423,2870,'video/webm',155,'2014-05-10 13:26:13.40537','2014-05-10 13:26:13.40537','cccamp11-4506-wie_finanziere_ich_eine_mondmission-de.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(141,423,2870,'video/mp4',155,'2014-05-10 13:26:13.410987','2014-05-10 13:26:13.410987','cccamp11-4506-wie_finanziere_ich_eine_mondmission-de.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(142,423,2870,'video/ogg',155,'2014-05-10 13:26:13.416461','2014-05-10 13:26:13.416461','cccamp11-4506-wie_finanziere_ich_eine_mondmission-de.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(143,461,7502,'video/webm',156,'2014-05-10 13:26:13.433622','2014-05-10 13:26:13.433622','cccamp11-4561-hacker_jeopardy-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(144,461,7502,'video/mp4',156,'2014-05-10 13:26:13.439181','2014-05-10 13:26:13.439181','cccamp11-4561-hacker_jeopardy-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(145,461,7502,'video/ogg',156,'2014-05-10 13:26:13.444586','2014-05-10 13:26:13.444586','cccamp11-4561-hacker_jeopardy-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(146,434,3908,'video/webm',157,'2014-05-10 13:26:13.461632','2014-05-10 13:26:13.461632','cccamp11-4478-die_psychologischen_grundlagen_des_social_engineerings-de.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(147,434,3908,'video/mp4',157,'2014-05-10 13:26:13.467226','2014-05-10 13:26:13.467226','cccamp11-4478-die_psychologischen_grundlagen_des_social_engineerings-de.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(148,434,3908,'video/ogg',157,'2014-05-10 13:26:13.472858','2014-05-10 13:26:13.472858','cccamp11-4478-die_psychologischen_grundlagen_des_social_engineerings-de.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(149,430,3357,'video/webm',158,'2014-05-10 13:26:13.489965','2014-05-10 13:26:13.489965','cccamp11-4488-steal_everything_kill_everyone_cause_financial_ruin-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(150,430,3357,'video/mp4',158,'2014-05-10 13:26:13.495579','2014-05-10 13:26:13.495579','cccamp11-4488-steal_everything_kill_everyone_cause_financial_ruin-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(151,430,3357,'video/ogg',158,'2014-05-10 13:26:13.501012','2014-05-10 13:26:13.501012','cccamp11-4488-steal_everything_kill_everyone_cause_financial_ruin-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(152,417,2257,'video/webm',159,'2014-05-10 13:26:13.518012','2014-05-10 13:26:13.518012','cccamp11-4389-decentralized_clustering-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(153,417,2257,'video/mp4',159,'2014-05-10 13:26:13.523602','2014-05-10 13:26:13.523602','cccamp11-4389-decentralized_clustering-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(154,417,2257,'video/ogg',159,'2014-05-10 13:26:13.529051','2014-05-10 13:26:13.529051','cccamp11-4389-decentralized_clustering-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(155,419,2409,'video/webm',160,'2014-05-10 13:26:13.546311','2014-05-10 13:26:13.546311','cccamp11-4412-latest_developments_around_the_milkymist_system_on_chip-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(156,419,2409,'video/mp4',160,'2014-05-10 13:26:13.551937','2014-05-10 13:26:13.551937','cccamp11-4412-latest_developments_around_the_milkymist_system_on_chip-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(157,419,2409,'video/ogg',160,'2014-05-10 13:26:13.557441','2014-05-10 13:26:13.557441','cccamp11-4412-latest_developments_around_the_milkymist_system_on_chip-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(158,409,1270,'video/webm',161,'2014-05-10 13:26:13.574405','2014-05-10 13:26:13.574405','cccamp11-4554-closing_event-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(159,409,1270,'video/mp4',161,'2014-05-10 13:26:13.58003','2014-05-10 13:26:13.58003','cccamp11-4554-closing_event-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(160,409,1270,'video/ogg',161,'2014-05-10 13:26:13.668792','2014-05-10 13:26:13.668792','cccamp11-4554-closing_event-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(161,420,2383,'video/webm',162,'2014-05-10 13:26:13.687727','2014-05-10 13:26:13.687727','cccamp11-4497-a_short_history_of_ipv4-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(162,420,2383,'video/mp4',162,'2014-05-10 13:26:13.693651','2014-05-10 13:26:13.693651','cccamp11-4497-a_short_history_of_ipv4-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(163,420,2383,'video/ogg',162,'2014-05-10 13:26:13.699498','2014-05-10 13:26:13.699498','cccamp11-4497-a_short_history_of_ipv4-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(164,421,3131,'video/webm',163,'2014-05-10 13:26:13.717196','2014-05-10 13:26:13.717196','cccamp11-4447-hybrid_rocket_engines-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(165,421,3131,'video/mp4',163,'2014-05-10 13:26:13.723054','2014-05-10 13:26:13.723054','cccamp11-4447-hybrid_rocket_engines-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(166,421,3131,'video/ogg',163,'2014-05-10 13:26:13.728743','2014-05-10 13:26:13.728743','cccamp11-4447-hybrid_rocket_engines-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(168,77,4286,'video/ogg',164,'2014-05-10 13:26:13.751978','2014-05-10 13:26:13.751978','cccamp11-4442-introduction-to-satellite_communications-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(169,430,3735,'video/webm',165,'2014-05-10 13:26:13.76988','2014-05-10 13:26:13.76988','cccamp11-4492-die-strugazki-brueder-oder-das-homoeostatische-weltbild-de.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(170,430,3735,'video/mp4',165,'2014-05-10 13:26:13.775625','2014-05-10 13:26:13.775625','cccamp11-4492-die-strugazki-brueder-oder-das-homoeostatische-weltbild-de.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(171,430,3735,'video/ogg',165,'2014-05-10 13:26:13.781202','2014-05-10 13:26:13.781202','cccamp11-4492-die-strugazki-brueder-oder-das-homoeostatische-weltbild-de.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(172,430,3750,'video/webm',166,'2014-05-10 13:26:13.798553','2014-05-10 13:26:13.798553','cccamp11-4588-what_is_brewing_in_brussels-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(173,430,3750,'video/mp4',166,'2014-05-10 13:26:13.80425','2014-05-10 13:26:13.80425','cccamp11-4588-what_is_brewing_in_brussels-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(174,430,3750,'video/ogg',166,'2014-05-10 13:26:13.809764','2014-05-10 13:26:13.809764','cccamp11-4588-what_is_brewing_in_brussels-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(175,432,4287,'video/webm',167,'2014-05-10 13:26:13.827313','2014-05-10 13:26:13.827313','cccamp11-4424-poker_bots-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(176,432,4287,'video/mp4',167,'2014-05-10 13:26:13.83307','2014-05-10 13:26:13.83307','cccamp11-4424-poker_bots-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(177,432,4287,'video/ogg',167,'2014-05-10 13:26:13.838575','2014-05-10 13:26:13.838575','cccamp11-4424-poker_bots-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(178,440,5211,'video/webm',168,'2014-05-10 13:26:13.85584','2014-05-10 13:26:13.85584','cccamp11-4426-certified_programming_with_dependent_types-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(179,440,5211,'video/mp4',168,'2014-05-10 13:26:13.861562','2014-05-10 13:26:13.861562','cccamp11-4426-certified_programming_with_dependent_types-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(180,440,5211,'video/ogg',168,'2014-05-10 13:26:13.867124','2014-05-10 13:26:13.867124','cccamp11-4426-certified_programming_with_dependent_types-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(181,434,4186,'video/webm',169,'2014-05-10 13:26:13.884364','2014-05-10 13:26:13.884364','cccamp11-4555-black_ops_of_tcpip_2011-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(182,434,4186,'video/mp4',169,'2014-05-10 13:26:13.889983','2014-05-10 13:26:13.889983','cccamp11-4555-black_ops_of_tcpip_2011-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(183,434,4186,'video/ogg',169,'2014-05-10 13:26:13.89546','2014-05-10 13:26:13.89546','cccamp11-4555-black_ops_of_tcpip_2011-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(184,430,3418,'video/webm',170,'2014-05-10 13:26:13.913751','2014-05-10 13:26:13.913751','cccamp11-4493-space_federation-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(185,430,3418,'video/mp4',170,'2014-05-10 13:26:13.920015','2014-05-10 13:26:13.920015','cccamp11-4493-space_federation-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(186,430,3418,'video/ogg',170,'2014-05-10 13:26:13.925708','2014-05-10 13:26:13.925708','cccamp11-4493-space_federation-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(187,428,4122,'video/webm',171,'2014-05-10 13:26:13.943001','2014-05-10 13:26:13.943001','cccamp11-4436-rocket_propulsion_basics-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(188,428,4122,'video/mp4',171,'2014-05-10 13:26:13.948669','2014-05-10 13:26:13.948669','cccamp11-4436-rocket_propulsion_basics-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(189,428,4122,'video/ogg',171,'2014-05-10 13:26:13.954417','2014-05-10 13:26:13.954417','cccamp11-4436-rocket_propulsion_basics-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(190,420,2444,'video/webm',172,'2014-05-10 13:26:13.972333','2014-05-10 13:26:13.972333','cccamp11-4451-a_modern_manifest_of_cyberspace-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(191,420,2444,'video/mp4',172,'2014-05-10 13:26:13.978035','2014-05-10 13:26:13.978035','cccamp11-4451-a_modern_manifest_of_cyberspace-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(192,420,2444,'video/ogg',172,'2014-05-10 13:26:13.983557','2014-05-10 13:26:13.983557','cccamp11-4451-a_modern_manifest_of_cyberspace-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(193,420,2427,'video/webm',173,'2014-05-10 13:26:14.000832','2014-05-10 13:26:14.000832','cccamp11-4445-data_mining_your_city-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(194,420,2427,'video/mp4',173,'2014-05-10 13:26:14.006595','2014-05-10 13:26:14.006595','cccamp11-4445-data_mining_your_city-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(195,420,2427,'video/ogg',173,'2014-05-10 13:26:14.01215','2014-05-10 13:26:14.01215','cccamp11-4445-data_mining_your_city-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(196,429,3547,'video/webm',174,'2014-05-10 13:26:14.029916','2014-05-10 13:26:14.029916','cccamp11-4435-windkraftanlagen-de.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(197,429,3547,'video/mp4',174,'2014-05-10 13:26:14.035683','2014-05-10 13:26:14.035683','cccamp11-4435-windkraftanlagen-de.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(198,429,3547,'video/ogg',174,'2014-05-10 13:26:14.041193','2014-05-10 13:26:14.041193','cccamp11-4435-windkraftanlagen-de.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(199,430,3601,'video/webm',175,'2014-05-10 13:26:14.058514','2014-05-10 13:26:14.058514','cccamp11-4462-counter-lobbying_in_the_eu_parliament-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(200,430,3601,'video/mp4',175,'2014-05-10 13:26:14.064155','2014-05-10 13:26:14.064155','cccamp11-4462-counter-lobbying_in_the_eu_parliament-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(201,430,3601,'video/ogg',175,'2014-05-10 13:26:14.0696','2014-05-10 13:26:14.0696','cccamp11-4462-counter-lobbying_in_the_eu_parliament-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(202,426,3759,'video/webm',176,'2014-05-10 13:26:14.086593','2014-05-10 13:26:14.086593','cccamp11-4486-building_and_giving_away-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(203,426,3759,'video/mp4',176,'2014-05-10 13:26:14.092158','2014-05-10 13:26:14.092158','cccamp11-4486-building_and_giving_away-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(204,426,3759,'video/ogg',176,'2014-05-10 13:26:14.097581','2014-05-10 13:26:14.097581','cccamp11-4486-building_and_giving_away-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(205,418,2608,'video/webm',177,'2014-05-10 13:26:14.11484','2014-05-10 13:26:14.11484','cccamp11-4505-strahlung_im_weltall-de.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(206,418,2608,'video/mp4',177,'2014-05-10 13:26:14.120421','2014-05-10 13:26:14.120421','cccamp11-4505-strahlung_im_weltall-de.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(207,418,2608,'video/ogg',177,'2014-05-10 13:26:14.125824','2014-05-10 13:26:14.125824','cccamp11-4505-strahlung_im_weltall-de.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(208,424,2890,'video/webm',178,'2014-05-10 13:26:14.142704','2014-05-10 13:26:14.142704','cccamp11-4589-a_brief_history_of_european_internet_surveillance_policy_and_what_maybe_next-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(209,424,2890,'video/mp4',178,'2014-05-10 13:26:14.148346','2014-05-10 13:26:14.148346','cccamp11-4589-a_brief_history_of_european_internet_surveillance_policy_and_what_maybe_next-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(210,424,2890,'video/ogg',178,'2014-05-10 13:26:14.153821','2014-05-10 13:26:14.153821','cccamp11-4589-a_brief_history_of_european_internet_surveillance_policy_and_what_maybe_next-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(211,428,3238,'video/webm',179,'2014-05-10 13:26:14.255695','2014-05-10 13:26:14.255695','cccamp11-4466-rocket_telemetry-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(212,428,3238,'video/mp4',179,'2014-05-10 13:26:14.261762','2014-05-10 13:26:14.261762','cccamp11-4466-rocket_telemetry-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(213,428,3238,'video/ogg',179,'2014-05-10 13:26:14.26758','2014-05-10 13:26:14.26758','cccamp11-4466-rocket_telemetry-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(214,421,3078,'video/webm',180,'2014-05-10 13:26:14.285752','2014-05-10 13:26:14.285752','cccamp11-4490-ios_application_security-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(215,421,3078,'video/mp4',180,'2014-05-10 13:26:14.291746','2014-05-10 13:26:14.291746','cccamp11-4490-ios_application_security-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(216,421,3078,'video/ogg',180,'2014-05-10 13:26:14.297504','2014-05-10 13:26:14.297504','cccamp11-4490-ios_application_security-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(217,425,3368,'video/webm',181,'2014-05-10 13:26:14.315077','2014-05-10 13:26:14.315077','cccamp11-4496-applied_research_on_security_of_tetra_radio.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(218,425,3368,'video/mp4',181,'2014-05-10 13:26:14.320889','2014-05-10 13:26:14.320889','cccamp11-4496-applied_research_on_security_of_tetra_radio.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(219,428,3395,'video/webm',182,'2014-05-10 13:26:14.338502','2014-05-10 13:26:14.338502','cccamp11-4575-mursat-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(220,428,3395,'video/mp4',182,'2014-05-10 13:26:14.344289','2014-05-10 13:26:14.344289','cccamp11-4575-mursat-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(221,428,3395,'video/ogg',182,'2014-05-10 13:26:14.349867','2014-05-10 13:26:14.349867','cccamp11-4575-mursat-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(222,431,3669,'video/webm',183,'2014-05-10 13:26:14.367337','2014-05-10 13:26:14.367337','cccamp11-4429-life_foods-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(223,431,3669,'video/mp4',183,'2014-05-10 13:26:14.373048','2014-05-10 13:26:14.373048','cccamp11-4429-life_foods-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(224,431,3669,'video/ogg',183,'2014-05-10 13:26:14.378588','2014-05-10 13:26:14.378588','cccamp11-4429-life_foods-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(225,434,3940,'video/webm',184,'2014-05-10 13:26:14.395987','2014-05-10 13:26:14.395987','cccamp11-4443-theres_gold_in_them_circuit_boards-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(226,434,3940,'video/mp4',184,'2014-05-10 13:26:14.401688','2014-05-10 13:26:14.401688','cccamp11-4443-theres_gold_in_them_circuit_boards-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(227,434,3940,'video/ogg',184,'2014-05-10 13:26:14.407215','2014-05-10 13:26:14.407215','cccamp11-4443-theres_gold_in_them_circuit_boards-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(228,421,3078,'video/webm',185,'2014-05-10 13:26:14.424978','2014-05-10 13:26:14.424978','cccamp11-4504-gprs_intercept-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(229,421,3078,'video/mp4',185,'2014-05-10 13:26:14.430656','2014-05-10 13:26:14.430656','cccamp11-4504-gprs_intercept-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(230,421,3078,'video/ogg',185,'2014-05-10 13:26:14.436199','2014-05-10 13:26:14.436199','cccamp11-4504-gprs_intercept-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(231,428,3223,'video/webm',186,'2014-05-10 13:26:14.453784','2014-05-10 13:26:14.453784','cccamp11-4440-solid_rocket_engines-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(232,428,3223,'video/mp4',186,'2014-05-10 13:26:14.459533','2014-05-10 13:26:14.459533','cccamp11-4440-solid_rocket_engines-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(233,428,3223,'video/ogg',186,'2014-05-10 13:26:14.465079','2014-05-10 13:26:14.465079','cccamp11-4440-solid_rocket_engines-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(234,428,3382,'video/webm',187,'2014-05-10 13:26:14.482859','2014-05-10 13:26:14.482859','cccamp11-4564-r0ket-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(235,428,3382,'video/mp4',187,'2014-05-10 13:26:14.488674','2014-05-10 13:26:14.488674','cccamp11-4564-r0ket-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(236,428,3382,'video/ogg',187,'2014-05-10 13:26:14.494168','2014-05-10 13:26:14.494168','cccamp11-4564-r0ket-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(237,416,1822,'video/webm',188,'2014-05-10 13:26:14.511526','2014-05-10 13:26:14.511526','cccamp11-4476-open_source_photovoltaics-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(238,416,1822,'video/mp4',188,'2014-05-10 13:26:14.517255','2014-05-10 13:26:14.517255','cccamp11-4476-open_source_photovoltaics-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(239,416,1822,'video/ogg',188,'2014-05-10 13:26:14.522776','2014-05-10 13:26:14.522776','cccamp11-4476-open_source_photovoltaics-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(240,430,4054,'video/webm',189,'2014-05-10 13:26:14.540041','2014-05-10 13:26:14.540041','cccamp11-4494-laptop_and_electronics_searches_at_the_us_border-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(241,430,4054,'video/mp4',189,'2014-05-10 13:26:14.545672','2014-05-10 13:26:14.545672','cccamp11-4494-laptop_and_electronics_searches_at_the_us_border-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(242,430,4054,'video/ogg',189,'2014-05-10 13:26:14.551176','2014-05-10 13:26:14.551176','cccamp11-4494-laptop_and_electronics_searches_at_the_us_border-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(243,423,2792,'video/webm',190,'2014-05-10 13:26:14.568366','2014-05-10 13:26:14.568366','cccamp11-4395-counselling_mischief_as_thought_crime-en.webm',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(244,423,2792,'video/mp4',190,'2014-05-10 13:26:14.573994','2014-05-10 13:26:14.573994','cccamp11-4395-counselling_mischief_as_thought_crime-en.mp4',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(245,423,2792,'video/ogg',190,'2014-05-10 13:26:14.579469','2014-05-10 13:26:14.579469','cccamp11-4395-counselling_mischief_as_thought_crime-en.ogv',NULL,'downloaded','video',720,576);
INSERT INTO "recordings" VALUES(1196,957,6301,'video/webm',653,'2014-05-10 13:26:28.183609','2014-05-10 13:26:28.183609','saal_mp7_og_-_2013-07-06_19:00_-_game_of_drones_i_ii_-_mark_-_5064.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1197,957,6301,'video/mp4',653,'2014-05-10 13:26:28.191534','2014-05-10 13:26:28.191534','saal_mp7_og_-_2013-07-06_19:00_-_game_of_drones_i_ii_-_mark_-_5064.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1198,957,6301,'audio/ogg',653,'2014-05-10 13:26:28.197568','2014-06-19 09:51:07.180329','saal_mp7_og_-_2013-07-06_19:00_-_game_of_drones_i_ii_-_mark_-_5064.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1199,360,2372,'video/webm',654,'2014-05-10 13:26:28.216083','2014-05-10 13:26:28.216083','saal_mp7_og_-_2013-07-07_14:00_-_analog_computing_-_bernd_ulmann_-_5056.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1200,360,2372,'video/mp4',654,'2014-05-10 13:26:28.221998','2014-05-10 13:26:28.221998','saal_mp7_og_-_2013-07-07_14:00_-_analog_computing_-_bernd_ulmann_-_5056.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1201,360,2372,'audio/ogg',654,'2014-05-10 13:26:28.228084','2014-06-19 09:51:07.188301','saal_mp7_og_-_2013-07-07_14:00_-_analog_computing_-_bernd_ulmann_-_5056.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1202,444,2897,'video/webm',655,'2014-05-10 13:26:28.246154','2014-05-10 13:26:28.246154','konferenz_mp6_og_-_2013-07-06_20:00_-_hpfriends_real-time_social_data-sharing_-_mark_schloesser_-_johannes_gilger_-_5070.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1203,444,2897,'video/mp4',655,'2014-05-10 13:26:28.252119','2014-05-10 13:26:28.252119','konferenz_mp6_og_-_2013-07-06_20:00_-_hpfriends_real-time_social_data-sharing_-_mark_schloesser_-_johannes_gilger_-_5070.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1204,444,2897,'audio/ogg',655,'2014-05-10 13:26:28.257939','2014-06-19 09:51:07.19398','konferenz_mp6_og_-_2013-07-06_20:00_-_hpfriends_real-time_social_data-sharing_-_mark_schloesser_-_johannes_gilger_-_5070.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1205,423,2779,'video/webm',656,'2014-05-10 13:26:28.275669','2014-05-10 13:26:28.275669','konferenz_mp6_og_-_2013-07-05_17:00_-_car_immobilizer_hacking_-_karsten_nohl_-_5034.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1206,423,2779,'video/mp4',656,'2014-05-10 13:26:28.281521','2014-05-10 13:26:28.281521','konferenz_mp6_og_-_2013-07-05_17:00_-_car_immobilizer_hacking_-_karsten_nohl_-_5034.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1207,423,2779,'audio/ogg',656,'2014-05-10 13:26:28.287213','2014-06-19 09:51:07.199948','konferenz_mp6_og_-_2013-07-05_17:00_-_car_immobilizer_hacking_-_karsten_nohl_-_5034.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1208,414,2720,'video/webm',657,'2014-05-10 13:26:28.305276','2014-05-10 13:26:28.305276','saal_mp7_og_-_2013-07-05_12:00_-_adblocker_an_schranke_runter_paywall_hoch_-_katharina_borchert_-_stefan_plochinger_-_jochen_wegner_-_jens_ihlenfeld_-_geraldine_de_bastion_-_5093.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1209,414,2720,'video/mp4',657,'2014-05-10 13:26:28.311193','2014-05-10 13:26:28.311193','saal_mp7_og_-_2013-07-05_12:00_-_adblocker_an_schranke_runter_paywall_hoch_-_katharina_borchert_-_stefan_plochinger_-_jochen_wegner_-_jens_ihlenfeld_-_geraldine_de_bastion_-_5093.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1210,414,2720,'audio/ogg',657,'2014-05-10 13:26:28.316968','2014-06-19 09:51:07.206064','saal_mp7_og_-_2013-07-05_12:00_-_adblocker_an_schranke_runter_paywall_hoch_-_katharina_borchert_-_stefan_plochinger_-_jochen_wegner_-_jens_ihlenfeld_-_geraldine_de_bastion_-_5093.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1211,542,3557,'video/webm',658,'2014-05-10 13:26:28.334529','2014-05-10 13:26:28.334529','konferenz_mp6_og_-_2013-07-06_11:00_-_the_step_into_cyborgism_-_ennomane_-_5082.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1212,542,3557,'video/mp4',658,'2014-05-10 13:26:28.340351','2014-05-10 13:26:28.340351','konferenz_mp6_og_-_2013-07-06_11:00_-_the_step_into_cyborgism_-_ennomane_-_5082.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1213,542,3557,'audio/ogg',658,'2014-05-10 13:26:28.345977','2014-06-19 09:51:07.212145','konferenz_mp6_og_-_2013-07-06_11:00_-_the_step_into_cyborgism_-_ennomane_-_5082.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1214,609,3997,'video/webm',659,'2014-05-10 13:26:28.363555','2014-05-10 13:26:28.363555','vortrag_mp6_og_-_2013-07-07_16:00_-_through_the_google_glass_and_what_malice_found_there_-_tante_-_5048.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1215,609,3997,'video/mp4',659,'2014-05-10 13:26:28.369323','2014-05-10 13:26:28.369323','vortrag_mp6_og_-_2013-07-07_16:00_-_through_the_google_glass_and_what_malice_found_there_-_tante_-_5048.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1216,609,3997,'audio/ogg',659,'2014-05-10 13:26:28.374941','2014-06-19 09:51:07.217857','vortrag_mp6_og_-_2013-07-07_16:00_-_through_the_google_glass_and_what_malice_found_there_-_tante_-_5048.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1217,455,2993,'video/webm',660,'2014-05-10 13:26:28.392526','2014-05-10 13:26:28.392526','konferenz_mp6_og_-_2013-07-06_15:00_-_e-mobility_as_a_privacy_game_changer_-_tilman_frosch_-_5068.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1218,455,2993,'video/mp4',660,'2014-05-10 13:26:28.398344','2014-05-10 13:26:28.398344','konferenz_mp6_og_-_2013-07-06_15:00_-_e-mobility_as_a_privacy_game_changer_-_tilman_frosch_-_5068.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1219,455,2993,'audio/ogg',660,'2014-05-10 13:26:28.403977','2014-06-19 09:51:07.223856','konferenz_mp6_og_-_2013-07-06_15:00_-_e-mobility_as_a_privacy_game_changer_-_tilman_frosch_-_5068.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1220,563,3718,'video/webm',661,'2014-05-10 13:26:28.421391','2014-05-10 13:26:28.421391','saal_mp7_og_-_2013-07-06_12:00_-_eu_data_protection_reform_-_achim_klabunde_-_5081.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1221,563,3718,'video/mp4',661,'2014-05-10 13:26:28.427361','2014-05-10 13:26:28.427361','saal_mp7_og_-_2013-07-06_12:00_-_eu_data_protection_reform_-_achim_klabunde_-_5081.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1222,563,3718,'audio/ogg',661,'2014-05-10 13:26:28.432987','2014-06-19 09:51:07.22957','saal_mp7_og_-_2013-07-06_12:00_-_eu_data_protection_reform_-_achim_klabunde_-_5081.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1223,585,3857,'video/webm',662,'2014-05-10 13:26:28.450657','2014-05-10 13:26:28.450657','saal_mp7_og_-_2013-07-07_16:00_-_revolution_in_military_affairs_--_why_computer_professionals_should_be_concerned_-_dietrich_rik_meyer-ebrecht_-_hans-jorg_kreowski_-_5076.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1224,585,3857,'video/mp4',662,'2014-05-10 13:26:28.456427','2014-05-10 13:26:28.456427','saal_mp7_og_-_2013-07-07_16:00_-_revolution_in_military_affairs_--_why_computer_professionals_should_be_concerned_-_dietrich_rik_meyer-ebrecht_-_hans-jorg_kreowski_-_5076.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1225,585,3857,'audio/ogg',662,'2014-05-10 13:26:28.462031','2014-06-19 09:51:07.235075','saal_mp7_og_-_2013-07-07_16:00_-_revolution_in_military_affairs_--_why_computer_professionals_should_be_concerned_-_dietrich_rik_meyer-ebrecht_-_hans-jorg_kreowski_-_5076.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1226,465,3060,'video/webm',663,'2014-05-10 13:26:28.479653','2014-05-10 13:26:28.479653','vortrag_mp6_og_-_2013-07-05_16:00_-_remote_exploits_fur_die_briefwahl_in_deutschland_-_arnim_-_5104.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1227,465,3060,'video/mp4',663,'2014-05-10 13:26:28.485384','2014-05-10 13:26:28.485384','vortrag_mp6_og_-_2013-07-05_16:00_-_remote_exploits_fur_die_briefwahl_in_deutschland_-_arnim_-_5104.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1228,465,3060,'audio/ogg',663,'2014-05-10 13:26:28.490944','2014-06-19 09:51:07.24044','vortrag_mp6_og_-_2013-07-05_16:00_-_remote_exploits_fur_die_briefwahl_in_deutschland_-_arnim_-_5104.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1229,535,3523,'video/webm',664,'2014-05-10 13:26:28.508441','2014-05-10 13:26:28.508441','saal_mp7_og_-_2013-07-07_15:00_-_how_to_wiretap_the_cloud_without_anybody_noticing_-_caspar_bowden_-_5088.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1230,535,3523,'video/mp4',664,'2014-05-10 13:26:28.514189','2014-05-10 13:26:28.514189','saal_mp7_og_-_2013-07-07_15:00_-_how_to_wiretap_the_cloud_without_anybody_noticing_-_caspar_bowden_-_5088.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1231,535,3523,'audio/ogg',664,'2014-05-10 13:26:28.519773','2014-06-19 09:51:07.245822','saal_mp7_og_-_2013-07-07_15:00_-_how_to_wiretap_the_cloud_without_anybody_noticing_-_caspar_bowden_-_5088.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1232,437,2859,'video/webm',665,'2014-05-10 13:26:28.537316','2014-05-10 13:26:28.537316','konferenz_mp6_og_-_2013-07-06_14:00_-_der_kampf_um_die_netzneutralitat_-_markus_beckedahl_-_5054.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1233,437,2859,'video/mp4',665,'2014-05-10 13:26:28.543012','2014-05-10 13:26:28.543012','konferenz_mp6_og_-_2013-07-06_14:00_-_der_kampf_um_die_netzneutralitat_-_markus_beckedahl_-_5054.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1234,437,2859,'audio/ogg',665,'2014-05-10 13:26:28.548565','2014-06-19 09:51:07.25148','konferenz_mp6_og_-_2013-07-06_14:00_-_der_kampf_um_die_netzneutralitat_-_markus_beckedahl_-_5054.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1235,428,2812,'video/webm',666,'2014-05-10 13:26:28.565722','2014-05-10 13:26:28.565722','konferenz_mp6_og_-_2013-07-06_21:00_-_docpatch_entdecke_unsere_verfassung_-_ben_-_5092.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1236,428,2812,'video/mp4',666,'2014-05-10 13:26:28.571401','2014-05-10 13:26:28.571401','konferenz_mp6_og_-_2013-07-06_21:00_-_docpatch_entdecke_unsere_verfassung_-_ben_-_5092.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1237,428,2812,'audio/ogg',666,'2014-05-10 13:26:28.576948','2014-06-19 09:51:07.256951','konferenz_mp6_og_-_2013-07-06_21:00_-_docpatch_entdecke_unsere_verfassung_-_ben_-_5092.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1238,504,3310,'video/webm',667,'2014-05-10 13:26:28.663228','2014-05-10 13:26:28.663228','konferenz_mp6_og_-_2013-07-06_17:00_-_independents_unite_inside_the_freelancers_movement_-_joel_dullroy_-_5038.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1239,504,3310,'video/mp4',667,'2014-05-10 13:26:28.670629','2014-05-10 13:26:28.670629','konferenz_mp6_og_-_2013-07-06_17:00_-_independents_unite_inside_the_freelancers_movement_-_joel_dullroy_-_5038.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1240,504,3310,'audio/ogg',667,'2014-05-10 13:26:28.676535','2014-06-19 09:51:07.268549','konferenz_mp6_og_-_2013-07-06_17:00_-_independents_unite_inside_the_freelancers_movement_-_joel_dullroy_-_5038.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1241,488,3205,'video/webm',668,'2014-05-10 13:26:28.695421','2014-05-10 13:26:28.695421','saal_mp7_og_-_2013-07-06_15:00_-_making_music_with_a_c_compiler_-_erlehmann_-_5067.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1242,488,3205,'video/mp4',668,'2014-05-10 13:26:28.702839','2014-05-10 13:26:28.702839','saal_mp7_og_-_2013-07-06_15:00_-_making_music_with_a_c_compiler_-_erlehmann_-_5067.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1243,488,3205,'audio/ogg',668,'2014-05-10 13:26:28.708778','2014-06-19 09:51:07.274362','saal_mp7_og_-_2013-07-06_15:00_-_making_music_with_a_c_compiler_-_erlehmann_-_5067.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1244,435,2861,'video/webm',669,'2014-05-10 13:26:28.728116','2014-05-10 13:26:28.728116','konferenz_mp6_og_-_2013-07-07_11:00_-_gute_arbeit_-_stephan_otten_-_5052.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1245,435,2861,'video/mp4',669,'2014-05-10 13:26:28.735699','2014-05-10 13:26:28.735699','konferenz_mp6_og_-_2013-07-07_11:00_-_gute_arbeit_-_stephan_otten_-_5052.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1246,435,2861,'audio/ogg',669,'2014-05-10 13:26:28.741828','2014-06-19 09:51:07.279715','konferenz_mp6_og_-_2013-07-07_11:00_-_gute_arbeit_-_stephan_otten_-_5052.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1247,524,3452,'video/webm',670,'2014-05-10 13:26:28.761716','2014-05-10 13:26:28.761716','saal_mp7_og_-_2013-07-07_11:00_-_it_s_my_party_and_i_crypt_if_i_want_to_-_jochim_selzer_-_5058.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1248,524,3452,'video/mp4',670,'2014-05-10 13:26:28.769064','2014-05-10 13:26:28.769064','saal_mp7_og_-_2013-07-07_11:00_-_it_s_my_party_and_i_crypt_if_i_want_to_-_jochim_selzer_-_5058.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1249,524,3452,'audio/ogg',670,'2014-05-10 13:26:28.871797','2014-06-19 09:51:07.285','saal_mp7_og_-_2013-07-07_11:00_-_it_s_my_party_and_i_crypt_if_i_want_to_-_jochim_selzer_-_5058.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1250,270,1776,'video/webm',671,'2014-05-10 13:26:28.891118','2014-05-10 13:26:28.891118','saal_mp7_og_-_2013-07-05_13:00_-_information_wants_to_be_free_versus_privacy_as_the_right_to_be_left_alone_-_hanspeter_schmidt_-_5121.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1251,270,1776,'video/mp4',671,'2014-05-10 13:26:28.897126','2014-05-10 13:26:28.897126','saal_mp7_og_-_2013-07-05_13:00_-_information_wants_to_be_free_versus_privacy_as_the_right_to_be_left_alone_-_hanspeter_schmidt_-_5121.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1252,270,1776,'audio/ogg',671,'2014-05-10 13:26:28.902969','2014-06-19 09:51:07.290327','saal_mp7_og_-_2013-07-05_13:00_-_information_wants_to_be_free_versus_privacy_as_the_right_to_be_left_alone_-_hanspeter_schmidt_-_5121.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1253,276,1807,'video/webm',672,'2014-05-10 13:26:28.921012','2014-05-10 13:26:28.921012','konferenz_mp6_og_-_2013-07-05_16:00_-_ruby_is_magic_-_sebastian_cohnen_-_dirk_breuer_-_5065.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1254,276,1807,'video/mp4',672,'2014-05-10 13:26:28.927017','2014-05-10 13:26:28.927017','konferenz_mp6_og_-_2013-07-05_16:00_-_ruby_is_magic_-_sebastian_cohnen_-_dirk_breuer_-_5065.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1255,276,1807,'audio/ogg',672,'2014-05-10 13:26:28.932881','2014-06-19 09:51:07.295747','konferenz_mp6_og_-_2013-07-05_16:00_-_ruby_is_magic_-_sebastian_cohnen_-_dirk_breuer_-_5065.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1256,224,1468,'video/webm',673,'2014-05-10 13:26:28.951167','2014-05-10 13:26:28.951167','konferenz_mp6_og_-_2013-07-05_14:00_-_parabolic_plane_flights_research_in_weightlessness_-_dr_jens_hauslage_-_5047.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1257,224,1468,'video/mp4',673,'2014-05-10 13:26:28.957152','2014-05-10 13:26:28.957152','konferenz_mp6_og_-_2013-07-05_14:00_-_parabolic_plane_flights_research_in_weightlessness_-_dr_jens_hauslage_-_5047.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1258,224,1468,'audio/ogg',673,'2014-05-10 13:26:28.962987','2014-06-19 09:51:07.301376','konferenz_mp6_og_-_2013-07-05_14:00_-_parabolic_plane_flights_research_in_weightlessness_-_dr_jens_hauslage_-_5047.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1259,482,3182,'video/webm',674,'2014-05-10 13:26:28.980701','2014-05-10 13:26:28.980701','saal_mp7_og_-_2013-07-06_16:00_-_vm32_a_cpu_simulator_for_demonstrational_purposes_of_virtualization_technologies_-_andreas_galauner_-_5101.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1260,482,3182,'video/mp4',674,'2014-05-10 13:26:28.986603','2014-05-10 13:26:28.986603','saal_mp7_og_-_2013-07-06_16:00_-_vm32_a_cpu_simulator_for_demonstrational_purposes_of_virtualization_technologies_-_andreas_galauner_-_5101.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1261,482,3182,'audio/ogg',674,'2014-05-10 13:26:28.992344','2014-06-19 09:51:07.307211','saal_mp7_og_-_2013-07-06_16:00_-_vm32_a_cpu_simulator_for_demonstrational_purposes_of_virtualization_technologies_-_andreas_galauner_-_5101.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1262,553,3640,'video/webm',675,'2014-05-10 13:26:29.010527','2014-05-10 13:26:29.010527','saal_mp7_og_-_2013-07-06_22:00_-_benutze_krake_mit_gerat_-_ths_-_nedos_-_5042.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1263,553,3640,'video/mp4',675,'2014-05-10 13:26:29.016474','2014-05-10 13:26:29.016474','saal_mp7_og_-_2013-07-06_22:00_-_benutze_krake_mit_gerat_-_ths_-_nedos_-_5042.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1264,553,3640,'audio/ogg',675,'2014-05-10 13:26:29.022459','2014-06-19 09:51:07.312664','saal_mp7_og_-_2013-07-06_22:00_-_benutze_krake_mit_gerat_-_ths_-_nedos_-_5042.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1265,207,1356,'video/webm',676,'2014-05-10 13:26:29.039996','2014-05-10 13:26:29.039996','konferenz_mp6_og_-_2013-07-06_16:00_-_pressfreedom_surveillance_and_international_campaigning_-_hauke_gierow_-_5072.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1266,207,1356,'video/mp4',676,'2014-05-10 13:26:29.045779','2014-05-10 13:26:29.045779','konferenz_mp6_og_-_2013-07-06_16:00_-_pressfreedom_surveillance_and_international_campaigning_-_hauke_gierow_-_5072.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1267,207,1356,'audio/ogg',676,'2014-05-10 13:26:29.051419','2014-06-19 09:51:07.318586','konferenz_mp6_og_-_2013-07-06_16:00_-_pressfreedom_surveillance_and_international_campaigning_-_hauke_gierow_-_5072.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1268,416,2738,'video/webm',677,'2014-05-10 13:26:29.06887','2014-05-10 13:26:29.06887','vortrag_mp6_og_-_2013-07-05_15:00_-_web_security_101_or_how_to_hack_security_conferences_-_sander_bos_-_5107.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1269,416,2738,'video/mp4',677,'2014-05-10 13:26:29.074628','2014-05-10 13:26:29.074628','vortrag_mp6_og_-_2013-07-05_15:00_-_web_security_101_or_how_to_hack_security_conferences_-_sander_bos_-_5107.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1270,416,2738,'audio/ogg',677,'2014-05-10 13:26:29.08023','2014-06-19 09:51:07.323945','vortrag_mp6_og_-_2013-07-05_15:00_-_web_security_101_or_how_to_hack_security_conferences_-_sander_bos_-_5107.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1271,466,3062,'video/webm',678,'2014-05-10 13:26:29.09742','2014-05-10 13:26:29.09742','vortrag_mp6_og_-_2013-07-06_19:00_-_lightning_talks_-_day_2_-_5090.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1272,466,3062,'video/mp4',678,'2014-05-10 13:26:29.103169','2014-05-10 13:26:29.103169','vortrag_mp6_og_-_2013-07-06_19:00_-_lightning_talks_-_day_2_-_5090.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1273,466,3062,'audio/ogg',678,'2014-05-10 13:26:29.108742','2014-06-19 09:51:07.329293','vortrag_mp6_og_-_2013-07-06_19:00_-_lightning_talks_-_day_2_-_5090.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1274,295,1942,'video/webm',679,'2014-05-10 13:26:29.126077','2014-05-10 13:26:29.126077','saal_mp7_og_-_2013-07-05_11:00_-_nearly_everything_that_matters_is_a_side_effect_-_mlp_-_5060.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1275,295,1942,'video/mp4',679,'2014-05-10 13:26:29.1318','2014-05-10 13:26:29.1318','saal_mp7_og_-_2013-07-05_11:00_-_nearly_everything_that_matters_is_a_side_effect_-_mlp_-_5060.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1276,295,1942,'audio/ogg',679,'2014-05-10 13:26:29.137364','2014-06-19 09:51:07.334665','saal_mp7_og_-_2013-07-05_11:00_-_nearly_everything_that_matters_is_a_side_effect_-_mlp_-_5060.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1277,488,3216,'video/webm',680,'2014-05-10 13:26:29.154719','2014-05-10 13:26:29.154719','saal_mp7_og_-_2013-07-05_16:00_-_offshoreleaks_-_the_how_and_why_of_a_global_investigation_-_kappuchino_-_5044.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1278,488,3216,'video/mp4',680,'2014-05-10 13:26:29.160461','2014-05-10 13:26:29.160461','saal_mp7_og_-_2013-07-05_16:00_-_offshoreleaks_-_the_how_and_why_of_a_global_investigation_-_kappuchino_-_5044.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1279,488,3216,'audio/ogg',680,'2014-05-10 13:26:29.166177','2014-06-19 09:51:07.340173','saal_mp7_og_-_2013-07-05_16:00_-_offshoreleaks_-_the_how_and_why_of_a_global_investigation_-_kappuchino_-_5044.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1280,424,2792,'video/webm',681,'2014-05-10 13:26:29.183909','2014-05-10 13:26:29.183909','saal_mp7_og_-_2013-07-05_20:00_-_let_s_tear_down_these_walls_-_angelo_veltens_-_5051.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1281,424,2792,'video/mp4',681,'2014-05-10 13:26:29.189634','2014-05-10 13:26:29.189634','saal_mp7_og_-_2013-07-05_20:00_-_let_s_tear_down_these_walls_-_angelo_veltens_-_5051.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1282,424,2792,'audio/ogg',681,'2014-05-10 13:26:29.19522','2014-06-19 09:51:07.345576','saal_mp7_og_-_2013-07-05_20:00_-_let_s_tear_down_these_walls_-_angelo_veltens_-_5051.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1283,469,3084,'video/webm',682,'2014-05-10 13:26:29.212572','2014-05-10 13:26:29.212572','vortrag_mp6_og_-_2013-07-05_12:00_-_cisco_in_the_sky_with_diamonds_-_fx_-_greg_-_5115.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1284,469,3084,'video/mp4',682,'2014-05-10 13:26:29.218249','2014-05-10 13:26:29.218249','vortrag_mp6_og_-_2013-07-05_12:00_-_cisco_in_the_sky_with_diamonds_-_fx_-_greg_-_5115.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1285,469,3084,'audio/ogg',682,'2014-05-10 13:26:29.223791','2014-06-19 09:51:07.350785','vortrag_mp6_og_-_2013-07-05_12:00_-_cisco_in_the_sky_with_diamonds_-_fx_-_greg_-_5115.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1286,416,2743,'video/webm',683,'2014-05-10 13:26:29.241191','2014-05-10 13:26:29.241191','saal_mp7_og_-_2013-07-05_17:00_-_funkzellenabfrage_-_ilf_-_5062.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1287,416,2743,'video/mp4',683,'2014-05-10 13:26:29.246838','2014-05-10 13:26:29.246838','saal_mp7_og_-_2013-07-05_17:00_-_funkzellenabfrage_-_ilf_-_5062.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1288,416,2743,'audio/ogg',683,'2014-05-10 13:26:29.25235','2014-06-19 09:51:07.356026','saal_mp7_og_-_2013-07-05_17:00_-_funkzellenabfrage_-_ilf_-_5062.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1289,423,2783,'video/webm',684,'2014-05-10 13:26:29.337817','2014-05-10 13:26:29.337817','saal_mp7_og_-_2013-07-07_12:00_-_embedded_device_security_nightmares_-_sven_f0f_-_5080.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1290,423,2783,'video/mp4',684,'2014-05-10 13:26:29.3453','2014-05-10 13:26:29.3453','saal_mp7_og_-_2013-07-07_12:00_-_embedded_device_security_nightmares_-_sven_f0f_-_5080.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1291,423,2783,'audio/ogg',684,'2014-05-10 13:26:29.352668','2014-06-19 09:51:07.361056','saal_mp7_og_-_2013-07-07_12:00_-_embedded_device_security_nightmares_-_sven_f0f_-_5080.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1292,660,4328,'video/webm',685,'2014-05-10 13:26:29.371062','2014-05-10 13:26:29.371062','vortrag_mp6_og_-_2013-07-05_19:00_-_q_a_with_nadim_on_cryptocat_-_5089.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1293,660,4328,'video/mp4',685,'2014-05-10 13:26:29.378527','2014-05-10 13:26:29.378527','vortrag_mp6_og_-_2013-07-05_19:00_-_q_a_with_nadim_on_cryptocat_-_5089.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1294,660,4328,'audio/ogg',685,'2014-05-10 13:26:29.385793','2014-06-19 09:51:07.366331','vortrag_mp6_og_-_2013-07-05_19:00_-_q_a_with_nadim_on_cryptocat_-_5089.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1295,454,2988,'video/webm',686,'2014-05-10 13:26:29.404469','2014-05-10 13:26:29.404469','saal_mp7_og_-_2013-07-06_11:00_-_home_network_horror_stories_-_m-1-k-3_-_5030.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1296,454,2988,'video/mp4',686,'2014-05-10 13:26:29.411992','2014-05-10 13:26:29.411992','saal_mp7_og_-_2013-07-06_11:00_-_home_network_horror_stories_-_m-1-k-3_-_5030.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1297,454,2988,'audio/ogg',686,'2014-05-10 13:26:29.419372','2014-06-19 09:51:07.371598','saal_mp7_og_-_2013-07-06_11:00_-_home_network_horror_stories_-_m-1-k-3_-_5030.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1298,439,2883,'video/webm',687,'2014-05-10 13:26:29.438732','2014-05-10 13:26:29.438732','konferenz_mp6_og_-_2013-07-05_20:00_-_programming_fpgas_with_pshdl_-_karsten_becker_-_5033.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1299,439,2883,'video/mp4',687,'2014-05-10 13:26:29.446233','2014-05-10 13:26:29.446233','konferenz_mp6_og_-_2013-07-05_20:00_-_programming_fpgas_with_pshdl_-_karsten_becker_-_5033.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1300,439,2883,'audio/ogg',687,'2014-05-10 13:26:29.453609','2014-06-19 09:51:07.376844','konferenz_mp6_og_-_2013-07-05_20:00_-_programming_fpgas_with_pshdl_-_karsten_becker_-_5033.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1301,450,3146,'video/webm',688,'2014-05-10 13:26:29.570091','2014-05-10 13:26:29.570091','konferenz_mp6_og_-_2013-07-07_16:00_-_besser_leben_fur_geeks_-_moeffju_-_5085.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1302,450,3146,'video/mp4',688,'2014-05-10 13:26:29.576153','2014-05-10 13:26:29.576153','konferenz_mp6_og_-_2013-07-07_16:00_-_besser_leben_fur_geeks_-_moeffju_-_5085.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1303,450,3146,'audio/ogg',688,'2014-05-10 13:26:29.582032','2014-06-19 09:51:07.382183','konferenz_mp6_og_-_2013-07-07_16:00_-_besser_leben_fur_geeks_-_moeffju_-_5085.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1304,357,2344,'video/webm',689,'2014-05-10 13:26:29.599962','2014-05-10 13:26:29.599962','konferenz_mp6_og_-_2013-07-06_22:00_-_transparenzgesetz_-_quo_vadis_-_dodger_-_thorsten_sterk_-_5105.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1305,357,2344,'video/mp4',689,'2014-05-10 13:26:29.605932','2014-05-10 13:26:29.605932','konferenz_mp6_og_-_2013-07-06_22:00_-_transparenzgesetz_-_quo_vadis_-_dodger_-_thorsten_sterk_-_5105.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1306,357,2344,'audio/ogg',689,'2014-05-10 13:26:29.611801','2014-06-19 09:51:07.387379','konferenz_mp6_og_-_2013-07-06_22:00_-_transparenzgesetz_-_quo_vadis_-_dodger_-_thorsten_sterk_-_5105.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1307,549,3597,'video/webm',690,'2014-05-10 13:26:29.629609','2014-05-10 13:26:29.629609','konferenz_mp6_og_-_2013-07-05_22:00_-_why_we_fight_each_other_-_mspro_-_5049.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1308,549,3597,'video/mp4',690,'2014-05-10 13:26:29.635518','2014-05-10 13:26:29.635518','konferenz_mp6_og_-_2013-07-05_22:00_-_why_we_fight_each_other_-_mspro_-_5049.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1309,549,3597,'audio/ogg',690,'2014-05-10 13:26:29.64128','2014-06-19 09:51:07.392523','konferenz_mp6_og_-_2013-07-05_22:00_-_why_we_fight_each_other_-_mspro_-_5049.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1310,288,1893,'video/webm',691,'2014-05-10 13:26:29.659556','2014-05-10 13:26:29.659556','konferenz_mp6_og_-_2013-07-07_15:00_-_c_r_o_p_combined_regenerative_organic-food_production_-_dr_jens_hauslage_-_5046.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1311,288,1893,'video/mp4',691,'2014-05-10 13:26:29.665499','2014-05-10 13:26:29.665499','konferenz_mp6_og_-_2013-07-07_15:00_-_c_r_o_p_combined_regenerative_organic-food_production_-_dr_jens_hauslage_-_5046.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1312,288,1893,'audio/ogg',691,'2014-05-10 13:26:29.671303','2014-06-19 09:51:07.397882','konferenz_mp6_og_-_2013-07-07_15:00_-_c_r_o_p_combined_regenerative_organic-food_production_-_dr_jens_hauslage_-_5046.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1313,512,3356,'video/webm',692,'2014-05-10 13:26:29.689016','2014-05-10 13:26:29.689016','saal_mp7_og_-_2013-07-06_21:00_-_cuckoo_sandbox_-_malware_beware_-_mark_schloesser_-_nex_-_skier_-_5074.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1314,512,3356,'video/mp4',692,'2014-05-10 13:26:29.694893','2014-05-10 13:26:29.694893','saal_mp7_og_-_2013-07-06_21:00_-_cuckoo_sandbox_-_malware_beware_-_mark_schloesser_-_nex_-_skier_-_5074.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1315,512,3356,'audio/ogg',692,'2014-05-10 13:26:29.700608','2014-06-19 09:51:07.402876','saal_mp7_og_-_2013-07-06_21:00_-_cuckoo_sandbox_-_malware_beware_-_mark_schloesser_-_nex_-_skier_-_5074.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1316,480,3155,'video/webm',693,'2014-05-10 13:26:29.718269','2014-05-10 13:26:29.718269','konferenz_mp6_og_-_2013-07-06_12:00_-_sdr_gsm_openbts_-_ralph_a_schmid_-_5099.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1317,480,3155,'video/mp4',693,'2014-05-10 13:26:29.724081','2014-05-10 13:26:29.724081','konferenz_mp6_og_-_2013-07-06_12:00_-_sdr_gsm_openbts_-_ralph_a_schmid_-_5099.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1318,480,3155,'audio/ogg',693,'2014-05-10 13:26:29.729715','2014-06-19 09:51:07.262883','konferenz_mp6_og_-_2013-07-06_12:00_-_sdr_gsm_openbts_-_ralph_a_schmid_-_5099.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1319,454,2982,'video/webm',694,'2014-05-10 13:26:29.747193','2014-05-10 13:26:29.747193','konferenz_mp6_og_-_2013-07-05_15:00_-_cryptocat_the_social_and_technical_challenges_of_making_crypto_accessible_to_everyone_-_nadim_kobeissi_-_5050.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1320,454,2982,'video/mp4',694,'2014-05-10 13:26:29.753127','2014-05-10 13:26:29.753127','konferenz_mp6_og_-_2013-07-05_15:00_-_cryptocat_the_social_and_technical_challenges_of_making_crypto_accessible_to_everyone_-_nadim_kobeissi_-_5050.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1321,454,2982,'audio/ogg',694,'2014-05-10 13:26:29.758771','2014-06-19 09:51:07.408486','konferenz_mp6_og_-_2013-07-05_15:00_-_cryptocat_the_social_and_technical_challenges_of_making_crypto_accessible_to_everyone_-_nadim_kobeissi_-_5050.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1322,439,2884,'video/webm',695,'2014-05-10 13:26:29.776331','2014-05-10 13:26:29.776331','vortrag_mp6_og_-_2013-07-07_11:00_-_transcending_places_-_moritz_heidkamp_-_5102.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1323,439,2884,'video/mp4',695,'2014-05-10 13:26:29.782096','2014-05-10 13:26:29.782096','vortrag_mp6_og_-_2013-07-07_11:00_-_transcending_places_-_moritz_heidkamp_-_5102.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1324,439,2884,'audio/ogg',695,'2014-05-10 13:26:29.787702','2014-06-19 09:51:07.413874','vortrag_mp6_og_-_2013-07-07_11:00_-_transcending_places_-_moritz_heidkamp_-_5102.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1325,414,2723,'video/webm',696,'2014-05-10 13:26:29.8053','2014-05-10 13:26:29.8053','vortrag_mp6_og_-_2013-07-05_17:00_-_aufbau_freier_netze_-_yanosz_-_nomaster_-_5100.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1326,414,2723,'video/mp4',696,'2014-05-10 13:26:29.811042','2014-05-10 13:26:29.811042','vortrag_mp6_og_-_2013-07-05_17:00_-_aufbau_freier_netze_-_yanosz_-_nomaster_-_5100.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1327,414,2723,'audio/ogg',696,'2014-05-10 13:26:29.816624','2014-06-19 09:51:07.419139','vortrag_mp6_og_-_2013-07-05_17:00_-_aufbau_freier_netze_-_yanosz_-_nomaster_-_5100.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1328,465,3068,'video/webm',697,'2014-05-10 13:26:29.833943','2014-05-10 13:26:29.833943','saal_mp7_og_-_2013-07-05_21:00_-_the_politics_of_surveillance_understanding_the_national_security_agency_-_rainey_reitman_-_5125.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1329,465,3068,'video/mp4',697,'2014-05-10 13:26:29.839736','2014-05-10 13:26:29.839736','saal_mp7_og_-_2013-07-05_21:00_-_the_politics_of_surveillance_understanding_the_national_security_agency_-_rainey_reitman_-_5125.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1330,465,3068,'audio/ogg',697,'2014-05-10 13:26:29.845344','2014-06-19 09:51:07.424354','saal_mp7_og_-_2013-07-05_21:00_-_the_politics_of_surveillance_understanding_the_national_security_agency_-_rainey_reitman_-_5125.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1331,376,2457,'video/webm',698,'2014-05-10 13:26:29.862831','2014-05-10 13:26:29.862831','konferenz_mp6_og_-_2013-07-05_21:00_-_internet-meme_geschichte_und_forschungsstand_-_erlehmann_-_plomlompom_-_5084.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1332,376,2457,'video/mp4',698,'2014-05-10 13:26:29.868596','2014-05-10 13:26:29.868596','konferenz_mp6_og_-_2013-07-05_21:00_-_internet-meme_geschichte_und_forschungsstand_-_erlehmann_-_plomlompom_-_5084.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1333,376,2457,'audio/ogg',698,'2014-05-10 13:26:29.874193','2014-06-19 09:51:07.429582','konferenz_mp6_og_-_2013-07-05_21:00_-_internet-meme_geschichte_und_forschungsstand_-_erlehmann_-_plomlompom_-_5084.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1334,283,1863,'video/webm',699,'2014-05-10 13:26:29.891752','2014-05-10 13:26:29.891752','saal_mp7_og_-_2013-07-06_14:00_-_the_drm_of_pacman_-_peter_franky_smets_-_5055.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1335,283,1863,'video/mp4',699,'2014-05-10 13:26:29.897443','2014-05-10 13:26:29.897443','saal_mp7_og_-_2013-07-06_14:00_-_the_drm_of_pacman_-_peter_franky_smets_-_5055.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1336,283,1863,'audio/ogg',699,'2014-05-10 13:26:29.903018','2014-06-19 09:51:07.434726','saal_mp7_og_-_2013-07-06_14:00_-_the_drm_of_pacman_-_peter_franky_smets_-_5055.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1337,403,2641,'video/webm',700,'2014-05-10 13:26:29.92032','2014-05-10 13:26:29.92032','konferenz_mp6_og_-_2013-07-05_19:00_-_ui_redressing_attacks_on_android_devices_-_mniemietz_-_5059.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1338,403,2641,'video/mp4',700,'2014-05-10 13:26:29.925982','2014-05-10 13:26:29.925982','konferenz_mp6_og_-_2013-07-05_19:00_-_ui_redressing_attacks_on_android_devices_-_mniemietz_-_5059.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1339,403,2641,'audio/ogg',700,'2014-05-10 13:26:29.93152','2014-06-19 09:51:07.440339','konferenz_mp6_og_-_2013-07-05_19:00_-_ui_redressing_attacks_on_android_devices_-_mniemietz_-_5059.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1340,280,1842,'video/webm',701,'2014-05-10 13:26:30.017301','2014-05-10 13:26:30.017301','vortrag_mp6_og_-_2013-07-07_12:00_-_introduction_to_bitcoin_-_mark_van_cuijk_-_5035.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1341,280,1842,'video/mp4',701,'2014-05-10 13:26:30.024336','2014-05-10 13:26:30.024336','vortrag_mp6_og_-_2013-07-07_12:00_-_introduction_to_bitcoin_-_mark_van_cuijk_-_5035.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1342,280,1842,'audio/ogg',701,'2014-05-10 13:26:30.031678','2014-06-19 09:51:07.445744','vortrag_mp6_og_-_2013-07-07_12:00_-_introduction_to_bitcoin_-_mark_van_cuijk_-_5035.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1343,760,4996,'video/webm',702,'2014-05-10 13:26:30.050325','2014-05-10 13:26:30.050325','saal_mp7_og_-_2013-07-06_17:00_-_i_o_capture_treiber_framework_-_viviane_-_5073.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1344,760,4996,'video/mp4',702,'2014-05-10 13:26:30.058108','2014-05-10 13:26:30.058108','saal_mp7_og_-_2013-07-06_17:00_-_i_o_capture_treiber_framework_-_viviane_-_5073.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1345,760,4996,'audio/ogg',702,'2014-05-10 13:26:30.06544','2014-06-19 09:51:07.450878','saal_mp7_og_-_2013-07-06_17:00_-_i_o_capture_treiber_framework_-_viviane_-_5073.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(1346,528,3474,'video/webm',703,'2014-05-10 13:26:30.083975','2014-05-10 13:26:30.083975','konferenz_mp6_og_-_2013-07-05_12:00_-_automatisierte_videouberwachung_-_benjamin_kees_-_5053.webm',NULL,'downloaded','webm',720,576);
INSERT INTO "recordings" VALUES(1347,528,3474,'video/mp4',703,'2014-05-10 13:26:30.091665','2014-05-10 13:26:30.091665','konferenz_mp6_og_-_2013-07-05_12:00_-_automatisierte_videouberwachung_-_benjamin_kees_-_5053.mp4',NULL,'downloaded','mp4-h264',720,576);
INSERT INTO "recordings" VALUES(1348,528,3474,'audio/ogg',703,'2014-05-10 13:26:30.09892','2014-06-19 09:51:07.456114','konferenz_mp6_og_-_2013-07-05_12:00_-_automatisierte_videouberwachung_-_benjamin_kees_-_5053.opus',NULL,'downloaded','opus',720,576);
INSERT INTO "recordings" VALUES(3430,NULL,3093,'video/webm',1721,'2014-05-10 13:27:00.785502','2014-06-28 22:22:04.258458','30c3-5552-en-India_s_Surveillance_State_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3431,NULL,3093,'video/mp4',1721,'2014-05-10 13:27:00.791127','2014-06-28 22:22:06.578327','30c3-5552-en-India_s_Surveillance_State_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3432,NULL,3075,'audio/mpeg',1721,'2014-05-10 13:27:00.796588','2014-06-28 22:22:04.301694','30c3-5552-en-India_s_Surveillance_State_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3433,NULL,3783,'video/webm',1722,'2014-05-10 13:27:00.814557','2014-06-28 22:22:04.340863','30c3-5533-en-Fast_Internet-wide_Scanning_and_its_Security_Applications_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3434,NULL,3783,'video/mp4',1722,'2014-05-10 13:27:00.820238','2014-06-28 22:22:04.41433','30c3-5533-en-Fast_Internet-wide_Scanning_and_its_Security_Applications_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3435,NULL,3765,'audio/mpeg',1722,'2014-05-10 13:27:00.825751','2014-06-28 22:22:04.465629','30c3-5533-en-Fast_Internet-wide_Scanning_and_its_Security_Applications_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3436,NULL,8851,'video/webm',1723,'2014-05-10 13:27:00.843464','2014-06-28 22:22:04.50794','30c3-5577-de-en-Hacker_Jeopardy_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3437,NULL,8851,'video/mp4',1723,'2014-05-10 13:27:00.849031','2014-06-28 22:22:04.630911','30c3-5577-de-en-Hacker_Jeopardy_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3438,NULL,8842,'audio/mpeg',1723,'2014-05-10 13:27:00.854464','2014-06-28 22:22:04.672682','30c3-5577-de-en-Hacker_Jeopardy_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3439,NULL,2940,'video/webm',1724,'2014-05-10 13:27:00.872277','2014-06-28 22:22:04.712475','30c3-5394-BREACH_in_Agda_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3440,NULL,2940,'video/mp4',1724,'2014-05-10 13:27:00.877895','2014-06-28 22:22:04.774774','30c3-5394-BREACH_in_Agda_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3441,NULL,2439,'audio/mpeg',1724,'2014-05-10 13:27:00.883358','2014-06-28 22:22:04.818214','30c3-5394-BREACH_in_Agda_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3442,NULL,3740,'video/webm',1725,'2014-05-10 13:27:00.900929','2014-06-28 22:22:04.859761','30c3-5550-en-Beyond_the_Tech_Building_Internet_Freedom_Tools_for_Real_People_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3443,NULL,3740,'video/mp4',1725,'2014-05-10 13:27:00.906568','2014-06-28 22:22:04.930705','30c3-5550-en-Beyond_the_Tech_Building_Internet_Freedom_Tools_for_Real_People_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3444,NULL,3722,'audio/mpeg',1725,'2014-05-10 13:27:00.912049','2014-06-28 22:22:04.974476','30c3-5550-en-Beyond_the_Tech_Building_Internet_Freedom_Tools_for_Real_People_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3445,NULL,3378,'video/webm',1726,'2014-05-10 13:27:00.929987','2014-06-28 22:22:05.015501','30c3-5476-en-Electronic_Bank_Robberies_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3446,NULL,3378,'video/mp4',1726,'2014-05-10 13:27:00.93555','2014-06-28 22:22:05.08688','30c3-5476-en-Electronic_Bank_Robberies_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3447,NULL,3360,'audio/mpeg',1726,'2014-05-10 13:27:00.940989','2014-06-28 22:22:05.130522','30c3-5476-en-Electronic_Bank_Robberies_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3448,NULL,2135,'video/webm',1727,'2014-05-10 13:27:00.958499','2014-06-28 22:22:05.1707','30c3-5475-en-_SOPA_NSA_and_the_New_Internet_Lobby_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3449,NULL,2135,'video/mp4',1727,'2014-05-10 13:27:00.964052','2014-06-28 22:22:05.236204','30c3-5475-en-_SOPA_NSA_and_the_New_Internet_Lobby_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3450,NULL,2117,'audio/mpeg',1727,'2014-05-10 13:27:00.969429','2014-06-28 22:22:05.282521','30c3-5475-en-_SOPA_NSA_and_the_New_Internet_Lobby_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3451,NULL,3648,'video/webm',1728,'2014-05-10 13:27:00.987125','2014-06-28 22:22:05.324241','30c3-5210-de-en-Bullshit_made_in_Germany_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3452,NULL,3648,'video/mp4',1728,'2014-05-10 13:27:00.992831','2014-06-28 22:22:05.407243','30c3-5210-de-en-Bullshit_made_in_Germany_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3453,NULL,3630,'audio/mpeg',1728,'2014-05-10 13:27:01.113667','2014-06-28 22:22:05.451906','30c3-5210-de-en-Bullshit_made_in_Germany_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3454,NULL,2906,'video/webm',1729,'2014-05-10 13:27:01.143084','2014-06-28 22:22:05.483415','30c3-5307-en-Reverse_engineering_of_CHIASMUS_from_GSTOOL_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3455,NULL,2906,'video/mp4',1729,'2014-05-10 13:27:01.149049','2014-06-28 22:22:05.549695','30c3-5307-en-Reverse_engineering_of_CHIASMUS_from_GSTOOL_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3456,NULL,2888,'audio/mpeg',1729,'2014-05-10 13:27:01.154832','2014-06-28 22:22:05.585737','30c3-5307-en-Reverse_engineering_of_CHIASMUS_from_GSTOOL_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3457,NULL,3118,'video/webm',1730,'2014-05-10 13:27:01.173199','2014-06-28 22:22:05.624472','30c3-5212-en-The_GNU_Name_System_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3458,NULL,3118,'video/mp4',1730,'2014-05-10 13:27:01.179117','2014-06-28 22:22:05.69168','30c3-5212-en-The_GNU_Name_System_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3459,NULL,3100,'audio/mpeg',1730,'2014-05-10 13:27:01.184887','2014-06-28 22:22:05.728528','30c3-5212-en-The_GNU_Name_System_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3460,NULL,1837,'video/webm',1731,'2014-05-10 13:27:01.203288','2014-06-28 22:22:05.763111','30c3-5479-en-Building_a_safe_NFC_ticketing_system_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3461,NULL,1837,'video/mp4',1731,'2014-05-10 13:27:01.209206','2014-06-28 22:22:05.82873','30c3-5479-en-Building_a_safe_NFC_ticketing_system_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3462,NULL,1819,'audio/mpeg',1731,'2014-05-10 13:27:01.214989','2014-06-28 22:22:05.871899','30c3-5479-en-Building_a_safe_NFC_ticketing_system_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3463,NULL,1985,'video/webm',1732,'2014-05-10 13:27:01.23337','2014-06-28 22:22:05.905499','30c3-5425-en-Hacking_as_Artistic_Practice_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3464,NULL,1985,'video/mp4',1732,'2014-05-10 13:27:01.239318','2014-06-28 22:22:05.968135','30c3-5425-en-Hacking_as_Artistic_Practice_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3465,NULL,1967,'audio/mpeg',1732,'2014-05-10 13:27:01.245105','2014-06-28 22:22:06.004948','30c3-5425-en-Hacking_as_Artistic_Practice_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3466,NULL,2865,'video/webm',1733,'2014-05-10 13:27:01.322392','2014-06-28 22:22:06.037149','30c3-5529-en-Hardening_hardware_and_choosing_a_goodBIOS_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3467,NULL,2865,'video/mp4',1733,'2014-05-10 13:27:01.328213','2014-06-28 22:22:06.125055','30c3-5529-en-Hardening_hardware_and_choosing_a_goodBIOS_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3468,NULL,2847,'audio/mpeg',1733,'2014-05-10 13:27:01.333845','2014-06-28 22:22:06.164727','30c3-5529-en-Hardening_hardware_and_choosing_a_goodBIOS_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3469,NULL,9487,'video/webm',1734,'2014-05-10 13:27:01.351725','2014-06-28 22:22:06.200952','30c3-5563-en-de-Lightning_Talks_Day_3_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3470,NULL,9487,'video/mp4',1734,'2014-05-10 13:27:01.357427','2014-06-28 22:22:06.325232','30c3-5563-en-de-Lightning_Talks_Day_3_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3471,NULL,9469,'audio/mpeg',1734,'2014-05-10 13:27:01.362963','2014-06-28 22:22:06.365237','30c3-5563-en-de-Lightning_Talks_Day_3_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3472,NULL,1762,'video/webm',1735,'2014-05-10 13:27:01.380811','2014-06-28 22:22:06.406943','30c3-5311-en-lasers_in_space_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3473,NULL,1762,'video/mp4',1735,'2014-05-10 13:27:01.38647','2014-06-28 22:22:06.469228','30c3-5311-en-lasers_in_space_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3474,NULL,1744,'audio/mpeg',1735,'2014-05-10 13:27:01.391979','2014-06-28 22:22:06.509505','30c3-5311-en-lasers_in_space_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3475,NULL,3561,'video/webm',1736,'2014-05-10 13:27:01.409838','2014-06-28 22:21:48.096953','30c3-5444-en-Attacking_HomeMatic_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3476,NULL,3561,'video/mp4',1736,'2014-05-10 13:27:01.415517','2014-06-28 22:22:06.64355','30c3-5444-en-Attacking_HomeMatic_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3477,NULL,3543,'audio/mpeg',1736,'2014-05-10 13:27:01.421054','2014-06-28 22:22:06.680657','30c3-5444-en-Attacking_HomeMatic_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3478,NULL,2501,'video/webm',1737,'2014-05-10 13:27:01.43912','2014-06-28 22:22:06.717599','30c3-5582-en-SCADA_StrangeLove_2_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3479,NULL,2501,'video/mp4',1737,'2014-05-10 13:27:01.444813','2014-06-28 22:22:06.783895','30c3-5582-en-SCADA_StrangeLove_2_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3480,NULL,2483,'audio/mpeg',1737,'2014-05-10 13:27:01.450338','2014-06-28 22:22:06.823917','30c3-5582-en-SCADA_StrangeLove_2_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3481,NULL,3790,'video/webm',1738,'2014-05-10 13:27:01.467983','2014-06-28 22:22:20.707202','30c3-5483-en-Europe_the_USA_and_Identity_Ecosystems_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3482,NULL,3790,'video/mp4',1738,'2014-05-10 13:27:01.473831','2014-06-28 22:22:20.781612','30c3-5483-en-Europe_the_USA_and_Identity_Ecosystems_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3483,NULL,3772,'audio/mpeg',1738,'2014-05-10 13:27:01.479311','2014-06-28 22:22:20.822635','30c3-5483-en-Europe_the_USA_and_Identity_Ecosystems_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3484,NULL,1999,'video/webm',1739,'2014-05-10 13:27:01.497106','2014-06-28 22:22:06.864567','30c3-5566-en-Open_source_experimental_incubator_build_up_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3485,NULL,1999,'video/mp4',1739,'2014-05-10 13:27:01.502746','2014-06-28 22:22:06.933147','30c3-5566-en-Open_source_experimental_incubator_build_up_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3486,NULL,1981,'audio/mpeg',1739,'2014-05-10 13:27:01.508252','2014-06-28 22:22:06.966686','30c3-5566-en-Open_source_experimental_incubator_build_up_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3487,NULL,3705,'video/webm',1740,'2014-05-10 13:27:01.525881','2014-06-28 22:22:07.005705','30c3-5186-en-Programming_FPGAs_with_PSHDL_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3488,NULL,3705,'video/mp4',1740,'2014-05-10 13:27:01.531602','2014-06-28 22:22:07.076264','30c3-5186-en-Programming_FPGAs_with_PSHDL_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3489,NULL,3687,'audio/mpeg',1740,'2014-05-10 13:27:01.537098','2014-06-28 22:22:07.124294','30c3-5186-en-Programming_FPGAs_with_PSHDL_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3490,NULL,1603,'video/webm',1741,'2014-05-10 13:27:01.554739','2014-06-28 22:22:07.156234','30c3-5319-en-Technomonopolies_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3491,NULL,1603,'video/mp4',1741,'2014-05-10 13:27:01.560318','2014-06-28 22:22:07.220392','30c3-5319-en-Technomonopolies_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3492,NULL,1585,'audio/mpeg',1741,'2014-05-10 13:27:01.565711','2014-06-28 22:22:07.261248','30c3-5319-en-Technomonopolies_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3493,NULL,1849,'video/webm',1742,'2014-05-10 13:27:01.58336','2014-06-28 22:22:07.301187','30c3-5420-de-en-calcpw_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3494,NULL,1849,'video/mp4',1742,'2014-05-10 13:27:01.588955','2014-06-28 22:22:07.373708','30c3-5420-de-en-calcpw_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3495,NULL,1831,'audio/mpeg',1742,'2014-05-10 13:27:01.594385','2014-06-28 22:22:07.417909','30c3-5420-de-en-calcpw_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3496,NULL,3771,'video/webm',1743,'2014-05-10 13:27:01.611916','2014-06-28 22:22:07.456356','30c3-5713-en-de-To_Protect_And_Infect_Part_2_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3497,NULL,3771,'video/mp4',1743,'2014-05-10 13:27:01.617456','2014-06-28 22:22:07.54138','30c3-5713-en-de-To_Protect_And_Infect_Part_2_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3498,NULL,3753,'audio/mpeg',1743,'2014-05-10 13:27:01.62285','2014-06-28 22:22:07.586083','30c3-5713-en-de-To_Protect_And_Infect_Part_2_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3499,NULL,3498,'video/webm',1744,'2014-05-10 13:27:01.640337','2014-06-28 22:22:07.626144','30c3-5440-en-de-Art_of_the_Exploit_An_Introduction_to_Critical_Engineering_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3500,NULL,3498,'video/mp4',1744,'2014-05-10 13:27:01.645914','2014-06-28 22:22:07.709179','30c3-5440-en-de-Art_of_the_Exploit_An_Introduction_to_Critical_Engineering_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3501,NULL,3480,'audio/mpeg',1744,'2014-05-10 13:27:01.651376','2014-06-28 22:22:07.754439','30c3-5440-en-de-Art_of_the_Exploit_An_Introduction_to_Critical_Engineering_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3502,NULL,1572,'video/webm',1745,'2014-05-10 13:27:01.669025','2014-06-28 22:22:07.78996','30c3-5453-en-Against_Metadata_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3503,NULL,1572,'video/mp4',1745,'2014-05-10 13:27:01.674663','2014-06-28 22:22:07.849972','30c3-5453-en-Against_Metadata_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3504,NULL,1554,'audio/mpeg',1745,'2014-05-10 13:27:01.680262','2014-06-28 22:22:07.894166','30c3-5453-en-Against_Metadata_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3505,NULL,2795,'video/webm',1746,'2014-05-10 13:27:01.823136','2014-06-28 22:22:07.932773','30c3-5304-en-CounterStrike_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3506,NULL,2795,'video/mp4',1746,'2014-05-10 13:27:01.829048','2014-06-28 22:22:08.005039','30c3-5304-en-CounterStrike_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3507,NULL,2786,'audio/mpeg',1746,'2014-05-10 13:27:01.834816','2014-06-28 22:22:08.046474','30c3-5304-en-CounterStrike_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3508,NULL,1772,'video/webm',1747,'2014-05-10 13:27:01.853396','2014-06-28 22:22:08.08665','30c3-5607-en-The_Pirate_Cinema_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3509,NULL,1772,'video/mp4',1747,'2014-05-10 13:27:01.859326','2014-06-28 22:21:47.666158','30c3-5607-en-The_Pirate_Cinema_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3510,NULL,1754,'audio/mpeg',1747,'2014-05-10 13:27:01.865108','2014-06-28 22:22:08.129714','30c3-5607-en-The_Pirate_Cinema_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3511,NULL,3595,'video/webm',1748,'2014-05-10 13:27:01.884224','2014-06-28 22:22:08.172579','30c3-5502-de-en-Zwischen_supersicherer_Verschluesselung_und_Klartext_liegt_nur_ein_falsches_Bit__webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3512,NULL,3595,'video/mp4',1748,'2014-05-10 13:27:01.890547','2014-06-28 22:22:08.253291','30c3-5502-de-en-Zwischen_supersicherer_Verschluesselung_und_Klartext_liegt_nur_ein_falsches_Bit__h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3513,NULL,3577,'audio/mpeg',1748,'2014-05-10 13:27:01.896568','2014-06-28 22:22:08.296098','30c3-5502-de-en-Zwischen_supersicherer_Verschluesselung_und_Klartext_liegt_nur_ein_falsches_Bit__mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3514,NULL,3984,'video/webm',1749,'2014-05-10 13:27:01.915662','2014-06-28 22:22:08.338861','30c3-5281-de-en-Keine_Anhaltspunkte_fuer_flaechendeckende_UEberwachung_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3515,NULL,3984,'video/mp4',1749,'2014-05-10 13:27:01.926157','2014-06-28 22:22:08.433389','30c3-5281-de-en-Keine_Anhaltspunkte_fuer_flaechendeckende_UEberwachung_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3516,NULL,3957,'audio/mpeg',1749,'2014-05-10 13:27:01.934739','2014-06-28 22:22:08.477312','30c3-5281-de-en-Keine_Anhaltspunkte_fuer_flaechendeckende_UEberwachung_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3517,NULL,1938,'video/webm',1750,'2014-05-10 13:27:01.957717','2014-06-28 22:22:08.516511','30c3-5289-en-Coding_your_body_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3518,NULL,1938,'video/mp4',1750,'2014-05-10 13:27:01.964242','2014-06-28 22:22:08.581706','30c3-5289-en-Coding_your_body_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3519,NULL,1920,'audio/mpeg',1750,'2014-05-10 13:27:01.970712','2014-06-28 22:22:08.622704','30c3-5289-en-Coding_your_body_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3520,NULL,3356,'video/webm',1751,'2014-05-10 13:27:01.991429','2014-06-28 22:22:08.662175','30c3-5526-en-How_to_Build_a_Mind_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3521,NULL,3356,'video/mp4',1751,'2014-05-10 13:27:01.998224','2014-06-28 22:22:08.732935','30c3-5526-en-How_to_Build_a_Mind_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3522,NULL,3338,'audio/mpeg',1751,'2014-05-10 13:27:02.005113','2014-06-28 22:22:08.77434','30c3-5526-en-How_to_Build_a_Mind_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3523,NULL,3243,'video/webm',1752,'2014-05-10 13:27:02.024593','2014-06-28 22:22:08.809783','30c3-5376-en-Do_You_Think_That_s_Funny__webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3524,NULL,3243,'video/mp4',1752,'2014-05-10 13:27:02.031346','2014-06-28 22:22:08.878916','30c3-5376-en-Do_You_Think_That_s_Funny__h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3525,NULL,3234,'audio/mpeg',1752,'2014-05-10 13:27:02.038277','2014-06-28 22:22:08.922209','30c3-5376-en-Do_You_Think_That_s_Funny__mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3526,NULL,691,'video/webm',1753,'2014-05-10 13:27:02.058673','2014-06-28 22:22:08.96215','30c3-5605-en-Opening_Event_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3527,NULL,691,'video/mp4',1753,'2014-05-10 13:27:02.064548','2014-06-28 22:22:09.020881','30c3-5605-en-Opening_Event_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3528,NULL,673,'audio/mpeg',1753,'2014-05-10 13:27:02.070114','2014-06-28 22:22:09.062353','30c3-5605-en-Opening_Event_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3529,NULL,2653,'video/webm',1754,'2014-05-10 13:27:02.089479','2014-06-28 22:22:09.099217','30c3-5361-en-Disclosure_DOs_Disclosure_DON_Ts_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3530,NULL,2653,'video/mp4',1754,'2014-05-10 13:27:02.096188','2014-06-28 22:22:09.165192','30c3-5361-en-Disclosure_DOs_Disclosure_DON_Ts_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3531,NULL,2635,'audio/mpeg',1754,'2014-05-10 13:27:02.102762','2014-06-28 22:22:09.20839','30c3-5361-en-Disclosure_DOs_Disclosure_DON_Ts_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3532,NULL,2990,'video/webm',1755,'2014-05-10 13:27:02.121045','2014-06-28 22:22:09.322753','30c3-5387-en-Toward_a_Cognitive_Quantified_Self__webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3533,NULL,2990,'video/mp4',1755,'2014-05-10 13:27:02.126776','2014-06-28 22:22:09.387966','30c3-5387-en-Toward_a_Cognitive_Quantified_Self__h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3534,NULL,2972,'audio/mpeg',1755,'2014-05-10 13:27:02.132368','2014-06-28 22:22:09.435293','30c3-5387-en-Toward_a_Cognitive_Quantified_Self__mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3535,NULL,2740,'video/webm',1756,'2014-05-10 13:27:02.154337','2014-06-28 22:22:09.480567','30c3-5491-en-de-No_Neutral_Ground_in_a_Burning_World_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3536,NULL,2740,'video/mp4',1756,'2014-05-10 13:27:02.160498','2014-06-28 22:22:09.5688','30c3-5491-en-de-No_Neutral_Ground_in_a_Burning_World_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3537,NULL,2713,'audio/mpeg',1756,'2014-05-10 13:27:02.166295','2014-06-28 22:22:09.615289','30c3-5491-en-de-No_Neutral_Ground_in_a_Burning_World_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3538,NULL,4342,'video/webm',1757,'2014-05-10 13:27:02.184676','2014-06-28 22:22:09.662301','30c3-5601-en-de-EUDataP_State_of_the_Union_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3539,NULL,4342,'video/mp4',1757,'2014-05-10 13:27:02.19044','2014-06-28 22:22:09.753339','30c3-5601-en-de-EUDataP_State_of_the_Union_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3540,NULL,4324,'audio/mpeg',1757,'2014-05-10 13:27:02.19605','2014-06-28 22:22:09.793679','30c3-5601-en-de-EUDataP_State_of_the_Union_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3541,NULL,2710,'video/webm',1758,'2014-05-10 13:27:02.214702','2014-06-28 22:22:09.829753','30c3-5398-en-HbbTV_Security_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3542,NULL,2710,'video/mp4',1758,'2014-05-10 13:27:02.220429','2014-06-28 22:22:09.902543','30c3-5398-en-HbbTV_Security_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3543,NULL,2692,'audio/mpeg',1758,'2014-05-10 13:27:02.22593','2014-06-28 22:22:09.9497','30c3-5398-en-HbbTV_Security_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3544,NULL,3249,'video/webm',1759,'2014-05-10 13:27:02.243822','2014-06-28 22:22:09.989441','30c3-5348-de-en-Der_Kampf_um_Netzneutralitaet_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3545,NULL,3249,'video/mp4',1759,'2014-05-10 13:27:02.249626','2014-06-28 22:22:10.073367','30c3-5348-de-en-Der_Kampf_um_Netzneutralitaet_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3546,NULL,3231,'audio/mpeg',1759,'2014-05-10 13:27:02.255129','2014-06-28 22:22:10.119382','30c3-5348-de-en-Der_Kampf_um_Netzneutralitaet_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3547,NULL,1463,'video/webm',1760,'2014-05-10 13:27:02.272745','2014-06-28 22:22:10.16393','30c3-5295-en-de-The_Four_Wars_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3548,NULL,1463,'video/mp4',1760,'2014-05-10 13:27:02.278294','2014-06-28 22:22:10.245436','30c3-5295-en-de-The_Four_Wars_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3549,NULL,1436,'audio/mpeg',1760,'2014-05-10 13:27:02.283691','2014-06-28 22:22:10.288985','30c3-5295-en-The_Four_Wars_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3550,NULL,3682,'video/webm',1761,'2014-05-10 13:27:02.301355','2014-06-28 22:22:10.333873','30c3-5293-de-en-Dead_Man_Edition_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3551,NULL,3682,'video/mp4',1761,'2014-05-10 13:27:02.306958','2014-06-28 22:22:10.421266','30c3-5293-de-en-Dead_Man_Edition_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3552,NULL,3664,'audio/mpeg',1761,'2014-05-10 13:27:02.312409','2014-06-28 22:22:10.466951','30c3-5293-de-en-Dead_Man_Edition_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3553,NULL,3664,'video/webm',1762,'2014-05-10 13:27:02.330004','2014-06-28 22:22:10.512168','30c3-5467-de-en-Warum_die_Digitale_Revolution_des_Lernens_gescheitert_ist_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3554,NULL,3664,'video/mp4',1762,'2014-05-10 13:27:02.33555','2014-06-28 22:22:10.595269','30c3-5467-de-en-Warum_die_Digitale_Revolution_des_Lernens_gescheitert_ist_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3555,NULL,3646,'audio/mpeg',1762,'2014-05-10 13:27:02.341149','2014-06-28 22:22:10.638102','30c3-5467-de-en-Warum_die_Digitale_Revolution_des_Lernens_gescheitert_ist_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3556,NULL,4297,'video/webm',1763,'2014-05-10 13:27:02.358685','2014-06-28 22:22:11.732461','30c3-5609-en-Infrastructure_Review_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3557,NULL,4297,'video/mp4',1763,'2014-05-10 13:27:02.364276','2014-06-28 22:22:11.807713','30c3-5609-en-Infrastructure_Review_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3558,NULL,4279,'audio/mpeg',1763,'2014-05-10 13:27:02.369728','2014-06-28 22:22:11.849208','30c3-5609-en-Infrastructure_Review_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3559,NULL,3625,'video/webm',1764,'2014-05-10 13:27:02.514459','2014-06-28 22:22:10.6783','30c3-5294-en-The_Exploration_and_Exploitation_of_an_SD_Memory_Card_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3560,NULL,3625,'video/mp4',1764,'2014-05-10 13:27:02.52055','2014-06-28 22:22:10.75692','30c3-5294-en-The_Exploration_and_Exploitation_of_an_SD_Memory_Card_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3561,NULL,3598,'audio/mpeg',1764,'2014-05-10 13:27:02.526414','2014-06-28 22:22:10.803379','30c3-5294-en-The_Exploration_and_Exploitation_of_an_SD_Memory_Card_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3562,NULL,3626,'video/webm',1765,'2014-05-10 13:27:02.544815','2014-06-28 22:22:10.844328','30c3-5406-en-Drones_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3563,NULL,3626,'video/mp4',1765,'2014-05-10 13:27:02.55073','2014-06-28 22:22:10.923124','30c3-5406-en-Drones_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3564,NULL,3617,'audio/mpeg',1765,'2014-05-10 13:27:02.556538','2014-06-28 22:22:10.970418','30c3-5406-en-Drones_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3565,NULL,1605,'video/webm',1766,'2014-05-10 13:27:02.574835','2014-06-28 22:22:11.011312','30c3-5545-en-Trezor_Bitcoin_hardware_wallet_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3566,NULL,1605,'video/mp4',1766,'2014-05-10 13:27:02.580725','2014-06-28 22:22:11.083655','30c3-5545-en-Trezor_Bitcoin_hardware_wallet_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3567,NULL,1578,'audio/mpeg',1766,'2014-05-10 13:27:02.58653','2014-06-28 22:22:11.126615','30c3-5545-en-Trezor_Bitcoin_hardware_wallet_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3568,NULL,3629,'video/webm',1767,'2014-05-10 13:27:02.604851','2014-06-28 22:22:11.16926','30c3-5537-en-Glass_Hacks_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3569,NULL,3629,'video/mp4',1767,'2014-05-10 13:27:02.610756','2014-06-28 22:22:11.253511','30c3-5537-en-Glass_Hacks_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3570,NULL,3602,'audio/mpeg',1767,'2014-05-10 13:27:02.61659','2014-06-28 22:22:11.289331','30c3-5537-en-Glass_Hacks_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3571,NULL,1749,'video/webm',1768,'2014-05-10 13:27:02.634964','2014-06-28 22:22:11.331877','30c3-5469-de-en-2_Takte_spaeter_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3572,NULL,1749,'video/mp4',1768,'2014-05-10 13:27:02.640827','2014-06-28 22:22:11.403523','30c3-5469-de-en-2_Takte_spaeter_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3573,NULL,1731,'audio/mpeg',1768,'2014-05-10 13:27:02.646511','2014-06-28 22:22:11.448762','30c3-5469-de-en-2_Takte_spaeter_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3574,NULL,3753,'video/webm',1769,'2014-05-10 13:27:02.664766','2014-06-28 22:22:11.484974','30c3-5421-en-THE_DATABASE_NATION_aka_THE_STATE_OF_SURVEILLANCE_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3575,NULL,3753,'video/mp4',1769,'2014-05-10 13:27:02.670631','2014-06-28 22:21:47.914327','30c3-5421-en-THE_DATABASE_NATION_aka_THE_STATE_OF_SURVEILLANCE_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3576,NULL,3735,'audio/mpeg',1769,'2014-05-10 13:27:02.676331','2014-06-28 22:22:11.526566','30c3-5421-en-THE_DATABASE_NATION_aka_THE_STATE_OF_SURVEILLANCE_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3577,NULL,3373,'video/webm',1770,'2014-05-10 13:27:02.694581','2014-06-28 22:22:11.570957','30c3-5298-en-de-Rock_em_Graphic_Cards_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3578,NULL,3373,'video/mp4',1770,'2014-05-10 13:27:02.70032','2014-06-28 22:22:11.648929','30c3-5298-en-de-Rock_em_Graphic_Cards_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3579,NULL,3355,'audio/mpeg',1770,'2014-05-10 13:27:02.705891','2014-06-28 22:22:11.691746','30c3-5298-en-de-Rock_em_Graphic_Cards_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3580,NULL,2857,'video/webm',1771,'2014-05-10 13:27:02.758822','2014-06-28 22:22:11.889034','30c3-5192-en-Android_DDI_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3581,NULL,2857,'video/mp4',1771,'2014-05-10 13:27:02.764853','2014-06-28 22:22:11.965357','30c3-5192-en-Android_DDI_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3582,NULL,2848,'audio/mpeg',1771,'2014-05-10 13:27:02.770696','2014-06-28 22:22:12.014169','30c3-5192-en-Android_DDI_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3583,NULL,1607,'video/webm',1772,'2014-05-10 13:27:02.788886','2014-06-28 22:22:12.055611','30c3-5405-en-Data_Mining_for_Good_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3584,NULL,1607,'video/mp4',1772,'2014-05-10 13:27:02.794602','2014-06-28 22:22:12.120335','30c3-5405-en-Data_Mining_for_Good_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3585,NULL,1589,'audio/mpeg',1772,'2014-05-10 13:27:02.800269','2014-06-28 22:22:12.169274','30c3-5405-en-Data_Mining_for_Good_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3586,NULL,3338,'video/webm',1773,'2014-05-10 13:27:02.818335','2014-06-28 22:22:12.212252','30c3-5214-en-The_Gospel_of_IRMA__webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3587,NULL,3338,'video/mp4',1773,'2014-05-10 13:27:02.824052','2014-06-28 22:22:12.296698','30c3-5214-en-The_Gospel_of_IRMA__h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3588,NULL,3329,'audio/mpeg',1773,'2014-05-10 13:27:02.835324','2014-06-28 22:22:12.341196','30c3-5214-en-The_Gospel_of_IRMA__mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3589,NULL,9187,'video/webm',1774,'2014-05-10 13:27:02.864223','2014-06-28 22:22:12.386846','30c3-5564-en-de-Lightning_Talks_Day_4_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3590,NULL,9187,'video/mp4',1774,'2014-05-10 13:27:02.870067','2014-06-28 22:22:12.511128','30c3-5564-en-de-Lightning_Talks_Day_4_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3591,NULL,9169,'audio/mpeg',1774,'2014-05-10 13:27:02.875516','2014-06-28 22:22:12.557014','30c3-5564-en-de-Lightning_Talks_Day_4_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3592,NULL,1983,'video/webm',1775,'2014-05-10 13:27:02.893287','2014-06-28 22:22:12.598311','30c3-5594-en-Structuring_open_hardware_projects_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3593,NULL,1983,'video/mp4',1775,'2014-05-10 13:27:02.898938','2014-06-28 22:22:12.663887','30c3-5594-en-Structuring_open_hardware_projects_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3594,NULL,1965,'audio/mpeg',1775,'2014-05-10 13:27:02.904409','2014-06-28 22:22:12.710278','30c3-5594-en-Structuring_open_hardware_projects_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3595,NULL,3285,'video/webm',1776,'2014-05-10 13:27:02.922099','2014-06-28 22:22:12.756745','30c3-5380-en-de-Persistent_Stealthy_Remote-controlled_Dedicated_Hardware_Malware_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3596,NULL,3285,'video/mp4',1776,'2014-05-10 13:27:02.927714','2014-06-28 22:22:12.84125','30c3-5380-en-de-Persistent_Stealthy_Remote-controlled_Dedicated_Hardware_Malware_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3597,NULL,3267,'audio/mpeg',1776,'2014-05-10 13:27:02.933166','2014-06-28 22:22:12.888934','30c3-5380-en-de-Persistent_Stealthy_Remote-controlled_Dedicated_Hardware_Malware_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3598,NULL,1867,'video/webm',1777,'2014-05-10 13:27:02.951052','2014-06-28 22:22:12.931205','30c3-5494-en-Nerds_in_the_news_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3599,NULL,1867,'video/mp4',1777,'2014-05-10 13:27:02.956653','2014-06-28 22:22:12.997722','30c3-5494-en-Nerds_in_the_news_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3600,NULL,1849,'audio/mpeg',1777,'2014-05-10 13:27:02.962078','2014-06-28 22:22:13.038649','30c3-5494-en-Nerds_in_the_news_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3601,NULL,3503,'video/webm',1778,'2014-05-10 13:27:02.979938','2014-06-28 22:22:13.078341','30c3-5360-en-Script_Your_Car__webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3602,NULL,3503,'video/mp4',1778,'2014-05-10 13:27:02.985505','2014-06-28 22:22:13.14987','30c3-5360-en-Script_Your_Car__h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3603,NULL,3485,'audio/mpeg',1778,'2014-05-10 13:27:02.990893','2014-06-28 22:22:13.189222','30c3-5360-en-Script_Your_Car__mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3604,NULL,2939,'video/webm',1779,'2014-05-10 13:27:03.008642','2014-06-28 22:22:13.228466','30c3-5610-de-Seidenstrasse_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3605,NULL,2939,'video/mp4',1779,'2014-05-10 13:27:03.014228','2014-06-28 22:22:13.301993','30c3-5610-de-Seidenstrasse_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3606,NULL,2921,'audio/mpeg',1779,'2014-05-10 13:27:03.019658','2014-06-28 22:22:13.347705','30c3-5610-de-Seidenstrasse_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3607,NULL,2488,'video/webm',1780,'2014-05-10 13:27:03.037249','2014-06-28 22:22:13.388883','30c3-5417-en-Extracting_keys_from_FPGAs_OTP_Tokens_and_Door_Locks_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3608,NULL,2488,'video/mp4',1780,'2014-05-10 13:27:03.042809','2014-06-28 22:22:13.457487','30c3-5417-en-Extracting_keys_from_FPGAs_OTP_Tokens_and_Door_Locks_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3609,NULL,2470,'audio/mpeg',1780,'2014-05-10 13:27:03.048291','2014-06-28 22:22:13.503156','30c3-5417-en-Extracting_keys_from_FPGAs_OTP_Tokens_and_Door_Locks_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3610,NULL,1712,'video/webm',1781,'2014-05-10 13:27:03.193831','2014-06-28 22:22:13.548277','30c3-5509-de-en-IFGINT_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3611,NULL,1712,'video/mp4',1781,'2014-05-10 13:27:03.203318','2014-06-28 22:22:13.622299','30c3-5509-de-en-IFGINT_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3612,NULL,1694,'audio/mpeg',1781,'2014-05-10 13:27:03.20937','2014-06-28 22:22:13.669','30c3-5509-de-en-IFGINT_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3613,NULL,3561,'video/webm',1782,'2014-05-10 13:27:03.228462','2014-06-28 22:22:13.706243','30c3-5433-de-en-Recht_auf_Remix_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3614,NULL,3561,'video/mp4',1782,'2014-05-10 13:27:03.234381','2014-06-28 22:22:13.78342','30c3-5433-de-en-Recht_auf_Remix_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3615,NULL,3543,'audio/mpeg',1782,'2014-05-10 13:27:03.240194','2014-06-28 22:22:13.828178','30c3-5433-de-en-Recht_auf_Remix_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3616,NULL,2882,'video/webm',1783,'2014-05-10 13:27:03.258898','2014-06-28 22:22:13.867488','30c3-5497-en-10_Years_of_Fun_with_Embedded_Devices_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3617,NULL,2882,'video/mp4',1783,'2014-05-10 13:27:03.264821','2014-06-28 22:22:13.938465','30c3-5497-en-10_Years_of_Fun_with_Embedded_Devices_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3618,NULL,2864,'audio/mpeg',1783,'2014-05-10 13:27:03.270581','2014-06-28 22:22:13.983903','30c3-5497-en-10_Years_of_Fun_with_Embedded_Devices_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3619,NULL,3725,'video/webm',1784,'2014-05-10 13:27:03.289086','2014-06-28 22:22:14.023277','30c3-5538-en-The_Internet_Doesn_t_Need_Another_Security_Guide_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3620,NULL,3725,'video/mp4',1784,'2014-05-10 13:27:03.295059','2014-06-28 22:22:14.097495','30c3-5538-en-The_Internet_Doesn_t_Need_Another_Security_Guide_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3621,NULL,3707,'audio/mpeg',1784,'2014-05-10 13:27:03.30085','2014-06-28 22:22:14.140215','30c3-5538-en-The_Internet_Doesn_t_Need_Another_Security_Guide_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3622,NULL,3441,'video/webm',1785,'2014-05-10 13:27:03.319144','2014-06-28 22:22:14.184696','30c3-5337-de-en-Kryptographie_nach_Snowden_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3623,NULL,3441,'video/mp4',1785,'2014-05-10 13:27:03.324985','2014-06-28 22:22:14.264565','30c3-5337-de-en-Kryptographie_nach_Snowden_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3624,NULL,3423,'audio/mpeg',1785,'2014-05-10 13:27:03.330654','2014-06-28 22:22:14.30732','30c3-5337-de-en-Kryptographie_nach_Snowden_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3625,NULL,3333,'video/webm',1786,'2014-05-10 13:27:03.349152','2014-06-28 22:22:14.344261','30c3-5590-en-White-Box_Cryptography_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3626,NULL,3333,'video/mp4',1786,'2014-05-10 13:27:03.355015','2014-06-28 22:22:14.415925','30c3-5590-en-White-Box_Cryptography_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3627,NULL,3315,'audio/mpeg',1786,'2014-05-10 13:27:03.360727','2014-06-28 22:22:14.461409','30c3-5590-en-White-Box_Cryptography_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3628,NULL,2545,'video/webm',1787,'2014-05-10 13:27:03.378947','2014-06-28 22:22:14.497768','30c3-5356-en-Firmware_Fat_Camp_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3629,NULL,2545,'video/mp4',1787,'2014-05-10 13:27:03.384756','2014-06-28 22:22:14.566442','30c3-5356-en-Firmware_Fat_Camp_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3630,NULL,2527,'audio/mpeg',1787,'2014-05-10 13:27:03.390396','2014-06-28 22:22:14.609608','30c3-5356-en-Firmware_Fat_Camp_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3631,NULL,2822,'video/webm',1788,'2014-05-10 13:27:03.408419','2014-06-28 22:22:14.648694','30c3-5463-en-Hillbilly_Tracking_of_Low_Earth_Orbit_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3632,NULL,2822,'video/mp4',1788,'2014-05-10 13:27:03.414117','2014-06-28 22:22:14.723713','30c3-5463-en-Hillbilly_Tracking_of_Low_Earth_Orbit_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3633,NULL,2813,'audio/mpeg',1788,'2014-05-10 13:27:03.419665','2014-06-28 22:22:14.765252','30c3-5463-en-Hillbilly_Tracking_of_Low_Earth_Orbit_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3634,NULL,3922,'video/webm',1789,'2014-05-10 13:27:03.437546','2014-06-28 22:22:14.808141','30c3-5619-de-en-Mind-Hacking_mit_Psychedelika_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3635,NULL,3922,'video/mp4',1789,'2014-05-10 13:27:03.44333','2014-06-28 22:22:14.891008','30c3-5619-de-en-Mind-Hacking_mit_Psychedelika_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3636,NULL,3904,'audio/mpeg',1789,'2014-05-10 13:27:03.44886','2014-06-28 22:22:14.933437','30c3-5619-de-en-Mind-Hacking_mit_Psychedelika_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3637,NULL,3872,'video/webm',1790,'2014-05-10 13:27:03.466827','2014-06-28 22:22:14.973067','30c3-5468-en-We_only_have_one_earth_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3638,NULL,3872,'video/mp4',1790,'2014-05-10 13:27:03.472821','2014-06-28 22:22:15.04131','30c3-5468-en-We_only_have_one_earth_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3639,NULL,3854,'audio/mpeg',1790,'2014-05-10 13:27:03.478679','2014-06-28 22:22:15.083653','30c3-5468-en-We_only_have_one_earth_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3640,NULL,3553,'video/webm',1791,'2014-05-10 13:27:03.497477','2014-06-28 22:22:15.12076','30c3-5445-en-Virtually_Impossible_The_Reality_Of_Virtualization_Security_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3641,NULL,3553,'video/mp4',1791,'2014-05-10 13:27:03.5033','2014-06-28 22:22:15.190436','30c3-5445-en-Virtually_Impossible_The_Reality_Of_Virtualization_Security_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3642,NULL,3535,'audio/mpeg',1791,'2014-05-10 13:27:03.509186','2014-06-28 22:22:15.233652','30c3-5445-en-Virtually_Impossible_The_Reality_Of_Virtualization_Security_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3643,NULL,3063,'video/webm',1792,'2014-05-10 13:27:03.527334','2014-06-28 22:22:15.278787','30c3-5606-de-en-Closing_Event_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3644,NULL,3063,'video/mp4',1792,'2014-05-10 13:27:03.533097','2014-06-28 22:22:15.362414','30c3-5606-de-en-Closing_Event_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3645,NULL,3054,'audio/mpeg',1792,'2014-05-10 13:27:03.538574','2014-06-28 22:22:15.397434','30c3-5606-de-en-Closing_Event_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3646,NULL,6539,'video/webm',1793,'2014-05-10 13:27:03.556825','2014-06-28 22:22:15.432882','30c3-5608-de-en-Jahresrueckblick_des_CCC_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3647,NULL,6539,'video/mp4',1793,'2014-05-10 13:27:03.562498','2014-06-28 22:22:15.570554','30c3-5608-de-en-Jahresrueckblick_des_CCC_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3648,NULL,6530,'audio/mpeg',1793,'2014-05-10 13:27:03.568008','2014-06-28 22:22:15.615404','30c3-5608-de-en-Jahresrueckblick_des_CCC_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3649,NULL,1746,'video/webm',1794,'2014-05-10 13:27:03.585726','2014-06-28 22:22:23.02479','30c3-5614-en-Perfect_Paul_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3650,NULL,1746,'video/mp4',1794,'2014-05-10 13:27:03.591356','2014-06-28 22:22:23.08883','30c3-5614-en-Perfect_Paul_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3651,NULL,1728,'audio/mpeg',1794,'2014-05-10 13:27:03.596824','2014-06-28 22:22:23.137237','30c3-5614-en-Perfect_Paul_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3652,NULL,2765,'video/webm',1795,'2014-05-10 13:27:03.614505','2014-06-28 22:22:15.659048','30c3-5279-en-de-Even_More_Tamagotchis_Were_Harmed_in_the_Making_of_this_Presentation_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3653,NULL,2765,'video/mp4',1795,'2014-05-10 13:27:03.620121','2014-06-28 22:22:15.742285','30c3-5279-en-de-Even_More_Tamagotchis_Were_Harmed_in_the_Making_of_this_Presentation_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3654,NULL,2739,'audio/mpeg',1795,'2014-05-10 13:27:03.625554','2014-06-28 22:22:15.876633','30c3-5279-en-de-Even_More_Tamagotchis_Were_Harmed_in_the_Making_of_this_Presentation_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3655,NULL,2823,'video/webm',1796,'2014-05-10 13:27:03.643172','2014-06-28 22:22:15.910951','30c3-5412-en-Bug_class_genocide_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3656,NULL,2823,'video/mp4',1796,'2014-05-10 13:27:03.648708','2014-06-28 22:22:15.983965','30c3-5412-en-Bug_class_genocide_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3657,NULL,2814,'audio/mpeg',1796,'2014-05-10 13:27:03.654059','2014-06-28 22:22:16.025597','30c3-5412-en-Bug_class_genocide_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3658,NULL,2535,'video/webm',1797,'2014-05-10 13:27:03.671624','2014-06-28 22:22:16.070988','30c3-5426-de-en-Das_FlipDot-Projekt_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3659,NULL,2535,'video/mp4',1797,'2014-05-10 13:27:03.677154','2014-06-28 22:22:16.148645','30c3-5426-de-en-Das_FlipDot-Projekt_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3660,NULL,2517,'audio/mpeg',1797,'2014-05-10 13:27:03.682523','2014-06-28 22:22:16.192216','30c3-5426-de-en-Das_FlipDot-Projekt_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3661,NULL,5441,'video/webm',1798,'2014-05-10 13:27:03.700071','2014-06-28 22:22:16.236893','30c3-5413-de-en-Security_Nightmares_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3662,NULL,5441,'video/mp4',1798,'2014-05-10 13:27:03.705588','2014-06-28 22:22:16.336875','30c3-5413-de-en-Security_Nightmares_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3664,NULL,1897,'video/webm',1799,'2014-05-10 13:27:03.728751','2014-06-28 22:22:16.376805','30c3-5397-en-Sysadmins_of_the_world_unite__webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3665,NULL,1897,'video/mp4',1799,'2014-05-10 13:27:03.734467','2014-06-28 22:22:16.446239','30c3-5397-en-Sysadmins_of_the_world_unite__h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3666,NULL,1888,'audio/mpeg',1799,'2014-05-10 13:27:03.867874','2014-06-28 22:22:16.491794','30c3-5397-en-Sysadmins_of_the_world_unite__mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3667,NULL,3548,'video/webm',1800,'2014-05-10 13:27:03.888439','2014-06-28 22:22:16.53129','30c3-5290-en-Console_Hacking_2013_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3668,NULL,3548,'video/mp4',1800,'2014-05-10 13:27:03.894384','2014-06-28 22:21:48.411914','30c3-5290-en-Console_Hacking_2013_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3669,NULL,3529,'audio/mpeg',1800,'2014-05-10 13:27:03.900196','2014-06-28 22:22:16.574166','30c3-5290-en-Console_Hacking_2013_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3670,NULL,3439,'video/webm',1801,'2014-05-10 13:27:03.918774','2014-06-28 22:22:16.615738','30c3-5193-en-Hardware_Attacks_Advanced_ARM_Exploitation_and_Android_Hacking_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3671,NULL,3439,'video/mp4',1801,'2014-05-10 13:27:03.924788','2014-06-28 22:22:16.70179','30c3-5193-en-Hardware_Attacks_Advanced_ARM_Exploitation_and_Android_Hacking_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3672,NULL,3412,'audio/mpeg',1801,'2014-05-10 13:27:03.930602','2014-06-28 22:22:16.742101','30c3-5193-en-Hardware_Attacks_Advanced_ARM_Exploitation_and_Android_Hacking_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3673,NULL,3594,'video/webm',1802,'2014-05-10 13:27:03.949146','2014-06-28 22:22:16.782843','30c3-5339-en-de-The_Year_in_Crypto_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3674,NULL,3594,'video/mp4',1802,'2014-05-10 13:27:03.955024','2014-06-28 22:22:17.368736','30c3-5339-en-de-The_Year_in_Crypto_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3675,NULL,3585,'audio/mpeg',1802,'2014-05-10 13:27:03.960802','2014-06-28 22:22:16.821597','30c3-5339-en-de-The_Year_in_Crypto_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3676,NULL,3523,'video/webm',1803,'2014-05-10 13:27:03.979207','2014-06-28 22:22:16.856646','30c3-5618-en-Baseband_Exploitation_in_2013_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3677,NULL,3523,'video/mp4',1803,'2014-05-10 13:27:03.985128','2014-06-28 22:22:16.936689','30c3-5618-en-Baseband_Exploitation_in_2013_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3678,NULL,3514,'audio/mpeg',1803,'2014-05-10 13:27:03.990826','2014-06-28 22:22:16.982387','30c3-5618-en-Baseband_Exploitation_in_2013_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3679,NULL,2190,'video/webm',1804,'2014-05-10 13:27:04.009497','2014-06-28 22:22:17.029102','30c3-5544-de-en-Sim_Gishel_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3680,NULL,2190,'video/mp4',1804,'2014-05-10 13:27:04.015477','2014-06-28 22:22:17.09917','30c3-5544-de-en-Sim_Gishel_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3681,NULL,2172,'audio/mpeg',1804,'2014-05-10 13:27:04.021567','2014-06-28 22:22:17.133735','30c3-5544-de-en-Sim_Gishel_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3682,NULL,2378,'video/webm',1805,'2014-05-10 13:27:04.039816','2014-06-28 22:22:17.274346','30c3-5543-en-de-ID_Cards_in_China_Your_Worst_Nightmare_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3683,NULL,2378,'video/mp4',1805,'2014-05-10 13:27:04.045569','2014-06-28 22:21:48.058952','30c3-5543-en-de-ID_Cards_in_China_Your_Worst_Nightmare_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3684,NULL,2360,'audio/mpeg',1805,'2014-05-10 13:27:04.051199','2014-06-28 22:22:17.177056','30c3-5543-en-de-ID_Cards_in_China_Your_Worst_Nightmare_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3685,NULL,2411,'video/webm',1806,'2014-05-10 13:27:04.069315','2014-06-28 22:22:17.216457','30c3-5477-en-An_introduction_to_Firmware_Analysis_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3686,NULL,2411,'video/mp4',1806,'2014-05-10 13:27:04.075085','2014-06-28 22:22:17.43734','30c3-5477-en-An_introduction_to_Firmware_Analysis_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3687,NULL,2384,'audio/mpeg',1806,'2014-05-10 13:27:04.080702','2014-06-28 22:22:17.479519','30c3-5477-en-An_introduction_to_Firmware_Analysis_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3688,NULL,3282,'video/webm',1807,'2014-05-10 13:27:04.098739','2014-06-28 22:22:17.518499','30c3-5474-en-World_War_II_Hackers_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3689,NULL,3282,'video/mp4',1807,'2014-05-10 13:27:04.104472','2014-06-28 22:22:17.59226','30c3-5474-en-World_War_II_Hackers_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3690,NULL,3264,'audio/mpeg',1807,'2014-05-10 13:27:04.110121','2014-06-28 22:22:17.638307','30c3-5474-en-World_War_II_Hackers_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3691,NULL,3548,'video/webm',1808,'2014-05-10 13:27:04.128101','2014-06-28 22:22:17.681649','30c3-5459-en-de-Security_of_the_IC_Backside_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3692,NULL,3548,'video/mp4',1808,'2014-05-10 13:27:04.134022','2014-06-28 22:22:17.777385','30c3-5459-en-de-Security_of_the_IC_Backside_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3693,NULL,3538,'audio/mpeg',1808,'2014-05-10 13:27:04.13958','2014-06-28 22:22:17.823396','30c3-5459-en-de-Security_of_the_IC_Backside_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3694,NULL,1950,'video/webm',1809,'2014-05-10 13:27:04.158956','2014-06-28 22:22:17.863803','30c3-5539-en-Human_Rights_and_Technology_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3695,NULL,1950,'video/mp4',1809,'2014-05-10 13:27:04.164742','2014-06-28 22:22:17.930999','30c3-5539-en-Human_Rights_and_Technology_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3696,NULL,1932,'audio/mpeg',1809,'2014-05-10 13:27:04.170327','2014-06-28 22:22:17.969261','30c3-5539-en-Human_Rights_and_Technology_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3697,NULL,1617,'video/webm',1810,'2014-05-10 13:27:04.188501','2014-06-28 22:22:18.00137','30c3-5437-en-Plants_Machines_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3698,NULL,1617,'video/mp4',1810,'2014-05-10 13:27:04.194171','2014-06-28 22:22:18.061587','30c3-5437-en-Plants_Machines_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3699,NULL,1599,'audio/mpeg',1810,'2014-05-10 13:27:04.199868','2014-06-28 22:22:18.102381','30c3-5437-en-Plants_Machines_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3700,NULL,7410,'video/webm',1811,'2014-05-10 13:27:04.217735','2014-06-28 22:22:18.148946','30c3-5562-en-de-Lightning_Talks_Day_2_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3701,NULL,7410,'video/mp4',1811,'2014-05-10 13:27:04.223634','2014-06-28 22:22:18.267602','30c3-5562-en-de-Lightning_Talks_Day_2_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3702,NULL,7392,'audio/mpeg',1811,'2014-05-10 13:27:04.230852','2014-06-28 22:22:18.312448','30c3-5562-en-de-Lightning_Talks_Day_2_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3703,NULL,2679,'video/webm',1812,'2014-05-10 13:27:04.249229','2014-06-28 22:22:18.358673','30c3-5478-en-de-Backdoors_Government_Hacking_and_The_Next_Crypto_Wars_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3704,NULL,2679,'video/mp4',1812,'2014-05-10 13:27:04.25488','2014-06-28 22:22:18.439656','30c3-5478-en-de-Backdoors_Government_Hacking_and_The_Next_Crypto_Wars_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3705,NULL,2661,'audio/mpeg',1812,'2014-05-10 13:27:04.260388','2014-06-28 22:22:18.48428','30c3-5478-en-de-Backdoors_Government_Hacking_and_The_Next_Crypto_Wars_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3706,NULL,3490,'video/webm',1813,'2014-05-10 13:27:04.278144','2014-06-28 22:22:18.525506','30c3-5634-en-07KINGSTON25_JAMAICA_MALARIA_UPDATE_Dispatches_from_Fort_Meade_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3707,NULL,3490,'video/mp4',1813,'2014-05-10 13:27:04.283784','2014-06-28 22:22:18.605006','30c3-5634-en-07KINGSTON25_JAMAICA_MALARIA_UPDATE_Dispatches_from_Fort_Meade_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3708,NULL,3463,'audio/mpeg',1813,'2014-05-10 13:27:04.28928','2014-06-28 22:22:18.649665','30c3-5634-en-07KINGSTON25_JAMAICA_MALARIA_UPDATE_Dispatches_from_Fort_Meade_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3709,NULL,2945,'video/webm',1814,'2014-05-10 13:27:04.307291','2014-06-28 22:22:18.688254','30c3-5604-en-de-Seeing_The_Secret_State_Six_Landscapes_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3710,NULL,2945,'video/mp4',1814,'2014-05-10 13:27:04.312862','2014-06-28 22:22:18.765732','30c3-5604-en-de-Seeing_The_Secret_State_Six_Landscapes_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3711,NULL,2918,'audio/mpeg',1814,'2014-05-10 13:27:04.318267','2014-06-28 22:22:18.800863','30c3-5604-en-de-Seeing_The_Secret_State_Six_Landscapes_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3712,NULL,3539,'video/webm',1815,'2014-05-10 13:27:04.335979','2014-06-28 22:22:18.834706','30c3-5334-en-RFID_Treehouse_of_Horror_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3713,NULL,3539,'video/mp4',1815,'2014-05-10 13:27:04.341581','2014-06-28 22:21:48.174631','30c3-5334-en-RFID_Treehouse_of_Horror_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3714,NULL,3521,'audio/mpeg',1815,'2014-05-10 13:27:04.347007','2014-06-28 22:22:18.871296','30c3-5334-en-RFID_Treehouse_of_Horror_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3715,NULL,7050,'video/webm',1816,'2014-05-10 13:27:04.364688','2014-06-28 22:22:18.914984','30c3-5490-de-en-Fnord_News_Show_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3716,NULL,7050,'video/mp4',1816,'2014-05-10 13:27:04.370276','2014-06-28 22:22:19.032795','30c3-5490-de-en-Fnord_News_Show_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3718,NULL,3635,'video/webm',1817,'2014-05-10 13:27:04.393459','2014-06-28 22:22:19.074747','30c3-5542-en-Revisiting_Trusting_Trust_for_binary_toolchains_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3719,NULL,3635,'video/mp4',1817,'2014-05-10 13:27:04.399984','2014-06-28 22:22:19.157521','30c3-5542-en-Revisiting_Trusting_Trust_for_binary_toolchains_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3720,NULL,3617,'audio/mpeg',1817,'2014-05-10 13:27:04.405671','2014-06-28 22:22:19.202718','30c3-5542-en-Revisiting_Trusting_Trust_for_binary_toolchains_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3721,NULL,1919,'video/webm',1818,'2014-05-10 13:27:04.55105','2014-06-28 22:22:19.24621','30c3-5391-en-de-Y_U_NO_ISP_taking_back_the_Net_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3722,NULL,1919,'video/mp4',1818,'2014-05-10 13:27:04.556964','2014-06-28 22:22:19.316134','30c3-5391-en-de-Y_U_NO_ISP_taking_back_the_Net_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3723,NULL,1901,'audio/mpeg',1818,'2014-05-10 13:27:04.562779','2014-06-28 22:22:19.359656','30c3-5391-en-de-Y_U_NO_ISP_taking_back_the_Net_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3724,NULL,3755,'video/webm',1819,'2014-05-10 13:27:04.581602','2014-06-28 22:22:19.401291','30c3-5571-en-Calafou_postcapitalist_ecoindustrial_community_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3725,NULL,3755,'video/mp4',1819,'2014-05-10 13:27:04.587575','2014-06-28 22:22:19.473882','30c3-5571-en-Calafou_postcapitalist_ecoindustrial_community_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3726,NULL,3737,'audio/mpeg',1819,'2014-05-10 13:27:04.593416','2014-06-28 22:22:19.514347','30c3-5571-en-Calafou_postcapitalist_ecoindustrial_community_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3727,NULL,3967,'video/webm',1820,'2014-05-10 13:27:04.611944','2014-06-28 22:22:19.558632','30c3-5532-de-en-Die_Drohnenkriege_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3728,NULL,3967,'video/mp4',1820,'2014-05-10 13:27:04.617895','2014-06-28 22:22:19.646551','30c3-5532-de-en-Die_Drohnenkriege_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3729,NULL,3949,'audio/mpeg',1820,'2014-05-10 13:27:04.623849','2014-06-28 22:22:19.693483','30c3-5532-de-en-Die_Drohnenkriege_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3730,NULL,2802,'video/webm',1821,'2014-05-10 13:27:04.642474','2014-06-28 22:22:19.729833','30c3-5527-en-Basics_of_Digital_Wireless_Communication_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3731,NULL,2802,'video/mp4',1821,'2014-05-10 13:27:04.648369','2014-06-28 22:22:19.799797','30c3-5527-en-Basics_of_Digital_Wireless_Communication_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3732,NULL,2784,'audio/mpeg',1821,'2014-05-10 13:27:04.654107','2014-06-28 22:22:19.848543','30c3-5527-en-Basics_of_Digital_Wireless_Communication_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3733,NULL,660,'video/webm',1822,'2014-05-10 13:27:04.67319','2014-06-28 22:22:19.890189','30c3-5500-en-Anonymity_and_Privacy_in_Public_Space_and_on_the_Internet_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3734,NULL,660,'video/mp4',1822,'2014-05-10 13:27:04.67911','2014-06-28 22:22:19.951818','30c3-5500-en-Anonymity_and_Privacy_in_Public_Space_and_on_the_Internet_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3735,NULL,642,'audio/mpeg',1822,'2014-05-10 13:27:04.684841','2014-06-28 22:22:20.001749','30c3-5500-en-Anonymity_and_Privacy_in_Public_Space_and_on_the_Internet_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3736,NULL,3628,'video/webm',1823,'2014-05-10 13:27:04.70309','2014-06-28 22:22:17.242616','30c3-5495-en-Concepts_for_global_TSCM_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3737,NULL,3628,'video/mp4',1823,'2014-05-10 13:27:04.708829','2014-06-28 22:22:20.069418','30c3-5495-en-Concepts_for_global_TSCM_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3738,NULL,3610,'audio/mpeg',1823,'2014-05-10 13:27:04.714408','2014-06-28 22:22:20.115126','30c3-5495-en-Concepts_for_global_TSCM_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3739,NULL,1806,'video/webm',1824,'2014-05-10 13:27:04.732614','2014-06-28 22:22:20.156251','30c3-5595-en-The_ArduGuitar_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3740,NULL,1806,'video/mp4',1824,'2014-05-10 13:27:04.738939','2014-06-28 22:22:20.227659','30c3-5595-en-The_ArduGuitar_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3741,NULL,1788,'audio/mpeg',1824,'2014-05-10 13:27:04.744855','2014-06-28 22:22:20.272209','30c3-5595-en-The_ArduGuitar_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3742,NULL,3843,'video/webm',1825,'2014-05-10 13:27:04.762897','2014-06-28 22:22:20.313045','30c3-5554-en-Magic_Lantern_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3743,NULL,3843,'video/mp4',1825,'2014-05-10 13:27:04.768626','2014-06-28 22:22:22.654014','30c3-5554-en-Magic_Lantern_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3744,NULL,3825,'audio/mpeg',1825,'2014-05-10 13:27:04.774222','2014-06-28 22:22:20.354252','30c3-5554-en-Magic_Lantern_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3745,NULL,3287,'video/webm',1826,'2014-05-10 13:27:04.79233','2014-06-28 22:22:20.395638','30c3-5185-en-FPGA_101_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3746,NULL,3287,'video/mp4',1826,'2014-05-10 13:27:04.798197','2014-06-28 22:22:20.467634','30c3-5185-en-FPGA_101_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3747,NULL,3269,'audio/mpeg',1826,'2014-05-10 13:27:04.803756','2014-06-28 22:22:20.512336','30c3-5185-en-FPGA_101_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3748,NULL,3532,'video/webm',1827,'2014-05-10 13:27:04.821734','2014-06-28 22:22:20.553479','30c3-5142-en-Monitoring_the_Spectrum_Building_Your_Own_Distributed_RF_Scanner_Array_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3749,NULL,3532,'video/mp4',1827,'2014-05-10 13:27:04.827649','2014-06-28 22:22:20.62555','30c3-5142-en-Monitoring_the_Spectrum_Building_Your_Own_Distributed_RF_Scanner_Array_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3750,NULL,3514,'audio/mpeg',1827,'2014-05-10 13:27:04.833701','2014-06-28 22:22:20.665904','30c3-5142-en-Monitoring_the_Spectrum_Building_Your_Own_Distributed_RF_Scanner_Array_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3751,NULL,3767,'video/webm',1828,'2014-05-10 13:27:04.886158','2014-06-28 22:22:20.863257','30c3-5423-en-The_Tor_Network_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3752,NULL,3767,'video/mp4',1828,'2014-05-10 13:27:04.891762','2014-06-28 22:22:20.943434','30c3-5423-en-The_Tor_Network_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3753,NULL,3758,'audio/mpeg',1828,'2014-05-10 13:27:04.897194','2014-06-28 22:22:20.990403','30c3-5423-en-The_Tor_Network_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3754,NULL,3639,'video/webm',1829,'2014-05-10 13:27:04.914894','2014-06-28 22:22:21.033072','30c3-5305-en-Breaking_Baryons_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3755,NULL,3639,'video/mp4',1829,'2014-05-10 13:27:04.920516','2014-06-28 22:22:21.098832','30c3-5305-en-Breaking_Baryons_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3756,NULL,3621,'audio/mpeg',1829,'2014-05-10 13:27:04.925969','2014-06-28 22:22:21.140155','30c3-5305-en-Breaking_Baryons_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3757,NULL,3668,'video/webm',1830,'2014-05-10 13:27:04.944271','2014-06-28 22:22:21.178238','30c3-5499-en-X_Security_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3758,NULL,3668,'video/mp4',1830,'2014-05-10 13:27:04.949879','2014-06-28 22:22:21.25297','30c3-5499-en-X_Security_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3759,NULL,3659,'audio/mpeg',1830,'2014-05-10 13:27:04.955299','2014-06-28 22:22:21.294594','30c3-5499-en-X_Security_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3760,NULL,2364,'video/webm',1831,'2014-05-10 13:27:04.974176','2014-06-28 22:22:21.334224','30c3-5593-en-Hacking_the_Czech_Parliament_via_SMS_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3761,NULL,2364,'video/mp4',1831,'2014-05-10 13:27:04.979897','2014-06-28 22:22:21.407284','30c3-5593-en-Hacking_the_Czech_Parliament_via_SMS_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3762,NULL,2355,'audio/mpeg',1831,'2014-05-10 13:27:04.985363','2014-06-28 22:22:21.449862','30c3-5593-en-Hacking_the_Czech_Parliament_via_SMS_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3763,NULL,3362,'video/webm',1832,'2014-05-10 13:27:05.003105','2014-06-28 22:22:24.802477','30c3-5322-en-Reverse_engineering_the_Wii_U_Gamepad_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3764,NULL,3362,'video/mp4',1832,'2014-05-10 13:27:05.008713','2014-06-28 22:22:24.872946','30c3-5322-en-Reverse_engineering_the_Wii_U_Gamepad_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3765,NULL,3344,'audio/mpeg',1832,'2014-05-10 13:27:05.014235','2014-06-28 22:22:24.917338','30c3-5322-en-Reverse_engineering_the_Wii_U_Gamepad_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3766,NULL,2171,'video/webm',1833,'2014-05-10 13:27:05.031911','2014-06-28 22:22:22.692764','30c3-5588-en-de-My_journey_into_FM-RDS_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3767,NULL,2171,'video/mp4',1833,'2014-05-10 13:27:05.037496','2014-06-28 22:21:47.983225','30c3-5588-en-de-My_journey_into_FM-RDS_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3768,NULL,2153,'audio/mpeg',1833,'2014-05-10 13:27:05.043005','2014-06-28 22:22:21.494502','30c3-5588-en-de-My_journey_into_FM-RDS_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3769,NULL,3527,'video/webm',1834,'2014-05-10 13:27:05.060723','2014-06-28 22:22:21.540506','30c3-5377-de-en-UEberwachen_und_Sprache_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3770,NULL,3527,'video/mp4',1834,'2014-05-10 13:27:05.066246','2014-06-28 22:22:21.626015','30c3-5377-de-en-UEberwachen_und_Sprache_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3771,NULL,3509,'audio/mpeg',1834,'2014-05-10 13:27:05.071648','2014-06-28 22:22:21.661766','30c3-5377-de-en-UEberwachen_und_Sprache_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3772,NULL,2973,'video/webm',1835,'2014-05-10 13:27:05.089729','2014-06-28 22:22:21.690876','30c3-5449-en-Mobile_network_attack_evolution_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3773,NULL,2973,'video/mp4',1835,'2014-05-10 13:27:05.226928','2014-06-28 22:22:21.768216','30c3-5449-en-Mobile_network_attack_evolution_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3774,NULL,2946,'audio/mpeg',1835,'2014-05-10 13:27:05.233787','2014-06-28 22:22:21.810138','30c3-5449-en-Mobile_network_attack_evolution_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3775,NULL,2752,'video/webm',1836,'2014-05-10 13:27:05.253056','2014-06-28 22:22:21.850289','30c3-5224-en-Triggering_Deep_Vulnerabilities_Using_Symbolic_Execution_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3776,NULL,2752,'video/mp4',1836,'2014-05-10 13:27:05.259112','2014-06-28 22:22:21.919516','30c3-5224-en-Triggering_Deep_Vulnerabilities_Using_Symbolic_Execution_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3777,NULL,2734,'audio/mpeg',1836,'2014-05-10 13:27:05.264942','2014-06-28 22:22:21.963932','30c3-5224-en-Triggering_Deep_Vulnerabilities_Using_Symbolic_Execution_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3778,NULL,3507,'video/webm',1837,'2014-05-10 13:27:05.283846','2014-06-28 22:22:22.003807','30c3-5600-en-Thwarting_the_Evil_Maid_Attacks_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3779,NULL,3507,'video/mp4',1837,'2014-05-10 13:27:05.289841','2014-06-28 22:22:22.081947','30c3-5600-en-Thwarting_the_Evil_Maid_Attacks_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3780,NULL,3498,'audio/mpeg',1837,'2014-05-10 13:27:05.29569','2014-06-28 22:22:22.228081','30c3-5600-en-Thwarting_the_Evil_Maid_Attacks_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3781,NULL,3472,'video/webm',1838,'2014-05-10 13:27:05.314141','2014-06-28 22:22:22.268436','30c3-5611-en-Hello_World__webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3782,NULL,3472,'video/mp4',1838,'2014-05-10 13:27:05.320331','2014-06-28 22:22:22.33983','30c3-5611-en-Hello_World__h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3783,NULL,3454,'audio/mpeg',1838,'2014-05-10 13:27:05.326174','2014-06-28 22:22:22.37687','30c3-5611-en-Hello_World__mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3784,NULL,3710,'video/webm',1839,'2014-05-10 13:27:05.344505','2014-06-28 22:22:22.415394','30c3-5443-en-Introduction_to_Processor_Design_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3785,NULL,3710,'video/mp4',1839,'2014-05-10 13:27:05.350375','2014-06-28 22:22:22.493463','30c3-5443-en-Introduction_to_Processor_Design_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3786,NULL,3692,'audio/mpeg',1839,'2014-05-10 13:27:05.356105','2014-06-28 22:22:22.539588','30c3-5443-en-Introduction_to_Processor_Design_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3787,NULL,3362,'video/webm',1840,'2014-05-10 13:27:05.374505','2014-06-28 22:22:22.580224','30c3-5223-en-WarGames_in_memory_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3788,NULL,3362,'video/mp4',1840,'2014-05-10 13:27:05.380378','2014-06-28 22:22:22.768573','30c3-5223-en-WarGames_in_memory_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3789,NULL,3344,'audio/mpeg',1840,'2014-05-10 13:27:05.386065','2014-06-28 22:22:22.814957','30c3-5223-en-WarGames_in_memory_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3790,NULL,3525,'video/webm',1841,'2014-05-10 13:27:05.404033','2014-06-28 22:22:22.857735','30c3-5613-en-Forbidden_Fruit_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3791,NULL,3525,'video/mp4',1841,'2014-05-10 13:27:05.409731','2014-06-28 22:22:22.936011','30c3-5613-en-Forbidden_Fruit_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3792,NULL,3507,'audio/mpeg',1841,'2014-05-10 13:27:05.415312','2014-06-28 22:22:22.982607','30c3-5613-en-Forbidden_Fruit_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3793,NULL,2030,'video/webm',1842,'2014-05-10 13:27:05.468341','2014-06-28 22:22:23.17886','30c3-5547-en-Turing_Complete_User_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3794,NULL,2030,'video/mp4',1842,'2014-05-10 13:27:05.474044','2014-06-28 22:22:23.246108','30c3-5547-en-Turing_Complete_User_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3795,NULL,2012,'audio/mpeg',1842,'2014-05-10 13:27:05.479634','2014-06-28 22:22:23.293546','30c3-5547-en-Turing_Complete_User_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3796,NULL,1810,'video/webm',1843,'2014-05-10 13:27:05.497531','2014-06-28 22:22:23.329593','30c3-5278-en-The_philosophy_of_hacking_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3797,NULL,1810,'video/mp4',1843,'2014-05-10 13:27:05.503215','2014-06-28 22:22:23.392466','30c3-5278-en-The_philosophy_of_hacking_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3798,NULL,1792,'audio/mpeg',1843,'2014-05-10 13:27:05.508705','2014-06-28 22:22:23.43799','30c3-5278-en-The_philosophy_of_hacking_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3799,NULL,3559,'video/webm',1844,'2014-05-10 13:27:05.527392','2014-06-28 22:22:23.477747','30c3-5415-de-en-Der_tiefe_Staat_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3800,NULL,3559,'video/mp4',1844,'2014-05-10 13:27:05.533146','2014-06-28 22:22:23.562403','30c3-5415-de-en-Der_tiefe_Staat_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3801,NULL,3541,'audio/mpeg',1844,'2014-05-10 13:27:05.538644','2014-06-28 22:22:23.607667','30c3-5415-de-en-Der_tiefe_Staat_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3802,NULL,3813,'video/webm',1845,'2014-05-10 13:27:05.556558','2014-06-28 22:22:23.654245','30c3-5255-en-de-Through_a_PRISM_Darkly_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3803,NULL,3813,'video/mp4',1845,'2014-05-10 13:27:05.562208','2014-06-28 22:22:23.742628','30c3-5255-en-de-Through_a_PRISM_Darkly_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3804,NULL,3787,'audio/mpeg',1845,'2014-05-10 13:27:05.568646','2014-06-28 22:22:23.781245','30c3-5255-en-de-Through_a_PRISM_Darkly_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3805,NULL,2752,'video/webm',1846,'2014-05-10 13:27:05.58704','2014-06-28 22:22:23.817893','30c3-5439-en-To_Protect_And_Infect_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3806,NULL,2752,'video/mp4',1846,'2014-05-10 13:27:05.592718','2014-06-28 22:22:23.892731','30c3-5439-en-To_Protect_And_Infect_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3807,NULL,2734,'audio/mpeg',1846,'2014-05-10 13:27:05.598231','2014-06-28 22:22:23.941395','30c3-5439-en-To_Protect_And_Infect_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3808,NULL,3351,'video/webm',1847,'2014-05-10 13:27:05.615977','2014-06-28 22:22:23.979719','30c3-5622-en-de-30c3_Keynote_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3809,NULL,3351,'video/mp4',1847,'2014-05-10 13:27:05.62157','2014-06-28 22:22:24.071877','30c3-5622-en-de-30c3_Keynote_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3810,NULL,3342,'audio/mpeg',1847,'2014-05-10 13:27:05.626957','2014-06-28 22:22:24.120827','30c3-5622-en-de-30c3_Keynote_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3811,NULL,3643,'video/webm',1848,'2014-05-10 13:27:05.644782','2014-06-28 22:21:47.833027','30c3-5416-en-de-Desperately_Seeking_Susy_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3812,NULL,3643,'video/mp4',1848,'2014-05-10 13:27:05.650403','2014-06-28 22:22:24.203649','30c3-5416-en-de-Desperately_Seeking_Susy_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3813,NULL,3626,'audio/mpeg',1848,'2014-05-10 13:27:05.655872','2014-06-28 22:22:24.252044','30c3-5416-en-de-Desperately_Seeking_Susy_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3814,NULL,3665,'video/webm',1849,'2014-05-10 13:27:05.673836','2014-06-28 22:22:24.292112','30c3-5548-de-en-25_Jahre_Chipkarten-Angriffe_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3815,NULL,3665,'video/mp4',1849,'2014-05-10 13:27:05.6796','2014-06-28 22:22:24.385127','30c3-5548-de-en-25_Jahre_Chipkarten-Angriffe_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3816,NULL,3638,'audio/mpeg',1849,'2014-05-10 13:27:05.685268','2014-06-28 22:22:24.423471','30c3-5548-de-en-25_Jahre_Chipkarten-Angriffe_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3817,NULL,1721,'video/webm',1850,'2014-05-10 13:27:05.702879','2014-06-28 22:22:24.465586','30c3-5446-en-The_good_the_bad_and_the_ugly_-_Linux_Kernel_patches_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3818,NULL,1721,'video/mp4',1850,'2014-05-10 13:27:05.708438','2014-06-28 22:22:24.526436','30c3-5446-en-The_good_the_bad_and_the_ugly_-_Linux_Kernel_patches_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3819,NULL,1703,'audio/mpeg',1850,'2014-05-10 13:27:05.713814','2014-06-28 22:22:24.566436','30c3-5446-en-The_good_the_bad_and_the_ugly_-_Linux_Kernel_patches_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3820,NULL,4718,'video/webm',1851,'2014-05-10 13:27:05.731612','2014-06-28 22:22:24.610223','30c3-5623-de-en-Amtliche_Datenschuetzer_Kontrolleure_oder_Papiertiger__webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3821,NULL,4718,'video/mp4',1851,'2014-05-10 13:27:05.737179','2014-06-28 22:22:24.712912','30c3-5623-de-en-Amtliche_Datenschuetzer_Kontrolleure_oder_Papiertiger__h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3822,NULL,4709,'audio/mpeg',1851,'2014-05-10 13:27:05.742556','2014-06-28 22:22:24.759337','30c3-5623-de-en-Amtliche_Datenschuetzer_Kontrolleure_oder_Papiertiger__mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3823,NULL,2204,'video/webm',1852,'2014-05-10 13:27:05.925533','2014-06-28 22:22:24.957731','30c3-5536-en-Long_Distance_Quantum_Communication_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3824,NULL,2204,'video/mp4',1852,'2014-05-10 13:27:05.93143','2014-06-28 22:22:25.021445','30c3-5536-en-Long_Distance_Quantum_Communication_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3825,NULL,2186,'audio/mpeg',1852,'2014-05-10 13:27:05.937176','2014-06-28 22:22:25.069188','30c3-5536-en-Long_Distance_Quantum_Communication_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3826,NULL,2318,'video/webm',1853,'2014-05-10 13:27:05.955648','2014-06-28 22:22:25.10978','30c3-5447-en-Policing_the_Romantic_Crowd_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3827,NULL,2318,'video/mp4',1853,'2014-05-10 13:27:05.961559','2014-06-28 22:22:25.178312','30c3-5447-en-Policing_the_Romantic_Crowd_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3828,NULL,2300,'audio/mpeg',1853,'2014-05-10 13:27:05.967396','2014-06-28 22:22:25.219591','30c3-5447-en-Policing_the_Romantic_Crowd_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3829,NULL,3477,'video/webm',1854,'2014-05-10 13:27:05.986249','2014-06-28 22:22:25.259718','30c3-5395-en-Towards_an_affordable_brain-computer-interface_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3830,NULL,3477,'video/mp4',1854,'2014-05-10 13:27:05.9922','2014-06-28 22:22:25.329405','30c3-5395-en-Towards_an_affordable_brain-computer-interface_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3831,NULL,3459,'audio/mpeg',1854,'2014-05-10 13:27:05.998011','2014-06-28 22:22:25.366823','30c3-5395-en-Towards_an_affordable_brain-computer-interface_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3832,NULL,2814,'video/webm',1855,'2014-05-10 13:27:06.016459','2014-06-28 22:22:25.404325','30c3-5587-en-Making_machines_that_make_webm.webm',NULL,'downloaded','webm',640,360);
INSERT INTO "recordings" VALUES(3833,NULL,2814,'video/mp4',1855,'2014-05-10 13:27:06.022374','2014-06-28 22:22:25.484922','30c3-5587-en-Making_machines_that_make_h264-hq.mp4',NULL,'downloaded','mp4',640,360);
INSERT INTO "recordings" VALUES(3834,NULL,2787,'audio/mpeg',1855,'2014-05-10 13:27:06.028188','2014-06-28 22:22:25.526471','30c3-5587-en-Making_machines_that_make_mp3.mp3',NULL,'downloaded','mp3',640,360);
INSERT INTO "recordings" VALUES(3956,NULL,1502,'video/mp4',789,'2014-05-11 17:52:10.258414','2014-06-28 22:22:30.242977','20C3-531-NOC_Preview.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3957,NULL,5482,'video/mp4',788,'2014-05-11 17:52:10.425067','2014-06-28 22:22:30.313107','20C3-537-WSIS_Overview.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3958,NULL,4900,'video/mp4',766,'2014-05-11 17:52:10.434653','2014-06-28 22:22:30.377987','20C3-538-Practical_WIN32_and_Unicode_exploitation.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3959,NULL,7200,'video/mp4',790,'2014-05-11 17:52:10.537139','2014-06-28 22:22:30.456809','20C3-542-Trusted_or_Treacherous.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3960,NULL,3161,'video/mp4',783,'2014-05-11 17:52:10.575536','2014-06-28 22:22:30.517662','20C3-545-Abschlussveranstaltung_Lockpicking.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3961,NULL,3136,'video/mp4',776,'2014-05-11 17:52:10.584752','2014-06-28 22:22:30.576397','20C3-546-1024_bit_RSA_ist_unsicher.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3962,NULL,3102,'video/mp4',794,'2014-05-11 17:52:10.5938','2014-06-28 22:22:30.628164','20C3-550-ROCK-Linux_Das_Tool_zum_Erstellen_von_Distros.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3963,NULL,1331,'video/mp4',791,'2014-05-11 17:52:10.602937','2014-06-28 22:22:30.676553','20C3-555-Eroeffnung.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3964,NULL,2308,'video/mp4',797,'2014-05-11 17:52:10.612593','2014-06-28 22:22:30.733274','20C3-557-Ein_Rant_ueber_den_Missbrauch_von_Java_HTTP_und_XML.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3965,NULL,1727,'video/mp4',778,'2014-05-11 17:52:10.623054','2014-06-28 22:22:30.78275','20C3-560-Soziale_Software.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3966,NULL,3426,'video/mp4',779,'2014-05-11 17:52:10.633564','2014-06-28 22:22:30.838425','20C3-562-Der_Zettel_am_Bildschirm.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3967,NULL,6521,'video/mp4',775,'2014-05-11 17:52:10.674361','2014-06-28 22:22:30.904106','20C3-568-Data_mining_and_intelligence_software.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3968,NULL,3294,'video/mp4',771,'2014-05-11 17:52:10.683489','2014-06-28 22:22:30.966613','20C3-574-Fragen_an_eine_maschinenlesbare_Regierung.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3969,NULL,4233,'video/mp4',792,'2014-05-11 17:52:10.691875','2014-06-28 22:22:31.030146','20C3-576-Free_WLANs_for_the_masses.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3970,NULL,2752,'video/mp4',782,'2014-05-11 17:52:10.699931','2014-06-28 22:22:31.075504','20C3-577-Secure_Internet_live_conferencing_with_SILC.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3971,NULL,3810,'video/mp4',774,'2014-05-11 17:52:10.707768','2014-06-28 22:22:31.134838','20C3-581-Chaos-Rueckblick-2003.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3972,NULL,4264,'video/mp4',767,'2014-05-11 17:52:10.715688','2014-06-28 22:22:31.191248','20C3-588-Schummeln_in_oeffentlichen-Projekten.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3973,NULL,4835,'video/mp4',796,'2014-05-11 17:52:10.725638','2014-06-28 22:22:31.254467','20C3-591-Berichte_von_den_Big_Brother_Awards.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3974,NULL,3281,'video/mp4',765,'2014-05-11 17:52:10.733348','2014-06-28 22:22:31.306706','20C3-593-Weird_programming.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3975,NULL,4701,'video/mp4',798,'2014-05-11 17:52:10.740997','2014-06-28 22:22:31.38156','20C3-598-Trust_based_P2P_WYMIWYG_KnoBot_project.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3976,NULL,2585,'video/mp4',772,'2014-05-11 17:52:10.748623','2014-06-28 22:22:31.431677','20C3-599-Softwarepatente.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3977,NULL,6387,'video/mp4',786,'2014-05-11 17:52:10.756207','2014-06-28 22:22:31.497991','20C3-600-RFID.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3978,NULL,3668,'video/mp4',799,'2014-05-11 17:52:10.763955','2014-06-28 22:22:31.547761','20C3-603-Spam_Analyse.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3979,NULL,7127,'video/mp4',769,'2014-05-11 17:52:10.771588','2014-06-28 22:22:31.618366','20C3-609-Security_Nightmares_III.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3980,NULL,1422,'video/mp4',780,'2014-05-11 17:52:10.779224','2014-06-28 22:22:31.657697','20C3-610-Abschlussveranstaltung.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3981,NULL,7911,'video/mp4',781,'2014-05-11 17:52:10.786794','2014-06-28 22:22:31.742094','20C3-611-Hacker_Jeopardy.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3982,NULL,3239,'video/mp4',770,'2014-05-11 17:52:10.796426','2014-06-28 22:22:31.795126','20C3-624-Neue_Notrufnummern_fuer_die_Informationsgesellschaft.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3983,NULL,6093,'video/mp4',784,'2014-05-11 17:52:10.804047','2014-06-28 22:22:31.854871','20C3-630-The_Quintessenz_biometrics_doqubase1.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3984,NULL,5326,'video/mp4',787,'2014-05-11 17:52:10.812354','2014-06-28 22:22:31.929679','20C3-633-Fnord_Jahresrueckschau.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3985,NULL,2137,'video/mp4',795,'2014-05-11 17:52:10.820104','2014-06-28 22:22:31.979678','20C3-637-Distributed_Computing.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3986,NULL,2896,'video/mp4',773,'2014-05-11 17:52:10.827801','2014-06-28 22:22:32.028511','20C3-644-Gute-Antennen-selber-bauen.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(3987,NULL,5734,'video/mp4',768,'2014-05-11 17:52:10.835439','2014-06-28 22:22:32.099111','20C3-653-Device_hacking_with_JTAG.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(4068,NULL,6597,'video/mp4',785,'2014-05-11 20:12:03.469123','2014-06-28 22:22:36.924884','20C3-589-AN.ON_and_the_future_of_anonymizers.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(4069,NULL,2941,'video/mp4',777,'2014-05-11 20:12:08.055732','2014-06-28 22:22:36.980467','20C3-623-Softwarekunstprojekt_runme.org.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(4070,NULL,3030,'video/mp4',793,'2014-05-11 20:12:12.713482','2014-06-28 22:22:37.03604','20C3-SkoleLinux.mp4',NULL,'downloaded','mp4',320,240);
INSERT INTO "recordings" VALUES(4074,NULL,1437,'audio/ogg',789,'2014-05-11 20:12:31.156575','2014-06-28 22:22:37.191042','20c3_531_NOC-Preview_audio.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4075,NULL,5450,'audio/ogg',788,'2014-05-11 20:12:36.384218','2014-06-28 22:22:37.226599','20c3_537_WSIS-An-Overview.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4076,NULL,4661,'audio/ogg',766,'2014-05-11 20:12:40.944565','2014-06-28 22:22:37.262386','20c3_538_Practical-Win32-ans-Unicode-exploitation.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4077,NULL,6716,'audio/ogg',790,'2014-05-11 20:12:46.124379','2014-06-28 22:22:37.298241','20c3_542_Trusted-or-Treacherous.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4078,NULL,2855,'audio/ogg',783,'2014-05-11 20:12:50.879712','2014-06-28 22:22:37.33434','20c3_545_Abschlussveranstalltung-Lockpicking.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4079,NULL,2923,'audio/ogg',776,'2014-05-11 20:12:55.436889','2014-06-28 22:22:37.370704','20c3_546_1024bit-RSA-ist-unsicher.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4080,NULL,2997,'audio/ogg',794,'2014-05-11 20:13:00.707382','2014-06-28 22:22:37.401467','20c3_550_ROCK-Linux-Das-Tool-zum-erstellen-von-Distros.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4081,NULL,1302,'audio/ogg',791,'2014-05-11 20:13:05.33896','2014-06-28 22:22:37.432263','20c3_555_Eroeffnung.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4082,NULL,2299,'audio/ogg',797,'2014-05-11 20:13:10.5625','2014-06-28 22:22:37.466545','20c3_557_Ein-Rant-ueber-den-Missbrauch.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4083,NULL,1754,'audio/ogg',778,'2014-05-11 20:13:15.725474','2014-06-28 22:22:37.501733','20c3_560_Soziale-Software.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4084,NULL,3258,'audio/ogg',779,'2014-05-11 20:13:20.888959','2014-06-28 22:22:37.538016','20c3_562_Der-Zettel-am-Bildschirm.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4085,NULL,6521,'audio/ogg',775,'2014-05-11 20:13:25.608383','2014-06-28 22:22:37.574141','20c3_568_Data-Mining-und-intelligence-Software.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4086,NULL,3292,'audio/ogg',771,'2014-05-11 20:13:30.212561','2014-06-28 22:22:37.610345','20c3_574_Fragen-an-eine-maschienenlesbare-Regierung.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4087,NULL,4201,'audio/ogg',792,'2014-05-11 20:13:35.422471','2014-06-28 22:22:37.646329','20c3_576_Free-WLANs-for-the-masses.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4088,NULL,2735,'audio/ogg',782,'2014-05-11 20:13:40.602907','2014-06-28 22:22:37.682195','20c3_577_Secure-Internet-Live-Conferencing-with-SILC.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4089,NULL,3400,'audio/ogg',774,'2014-05-11 20:13:45.724637','2014-06-28 22:22:37.71833','20c3_581_CHAOS-Rueckblick-2003.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4090,NULL,4263,'audio/ogg',767,'2014-05-11 20:13:50.287512','2014-06-28 22:22:37.754494','20c3_588_Schummeln-in-oeffentlichen-Projekten.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4091,NULL,4578,'audio/ogg',796,'2014-05-11 20:13:59.922544','2014-06-28 22:22:37.78438','20c3_591_Berichte-von-den-BigBrother-Awards.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4092,NULL,3280,'audio/ogg',765,'2014-05-11 20:14:05.04931','2014-06-28 22:22:37.81795','20c3_593_Weird-Programming.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4093,NULL,4576,'audio/ogg',798,'2014-05-11 20:14:09.626275','2014-06-28 22:22:37.853003','20c3_598_trustbased-P2P-WYMIWYG-KnoBot-project.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4094,NULL,2504,'audio/ogg',772,'2014-05-11 20:14:14.137193','2014-06-28 22:22:37.888229','20c3_599_Software-Patente.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4095,NULL,5992,'audio/ogg',786,'2014-05-11 20:14:18.662195','2014-06-28 22:22:37.923276','20c3_600_RFID.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4096,NULL,3272,'audio/ogg',799,'2014-05-11 20:14:23.757433','2014-06-28 22:22:37.95296','20c3_603_Spam-Analyse.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4097,NULL,7130,'audio/ogg',769,'2014-05-11 20:14:28.918253','2014-06-28 22:22:37.989827','20c3_609_Security_Nightmares-III.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4098,NULL,1386,'audio/ogg',780,'2014-05-11 20:14:33.449548','2014-06-28 22:22:38.022805','20c3_610_Abschlussveranstaltung.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4099,NULL,7492,'audio/ogg',781,'2014-05-11 20:14:38.578676','2014-06-28 22:22:38.057323','20c3_611_Hacker-Jeopardy.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4100,NULL,1890,'audio/ogg',777,'2014-05-11 20:14:43.18911','2014-06-28 22:22:38.092185','20c3_623_Softwarekunst-Projekt-runme-org.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4101,NULL,3212,'audio/ogg',770,'2014-05-11 20:14:48.299096','2014-06-28 22:22:38.127424','20c3_624_Neue-Notrufnummern.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4102,NULL,6088,'audio/ogg',784,'2014-05-11 20:14:53.560711','2014-06-28 22:22:38.162698','20c3_630_The-Quintessenz-biometrics-doqubase1.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4103,NULL,2630,'audio/ogg',793,'2014-05-11 20:14:58.140066','2014-06-28 22:22:38.19859','20c3_631_SkoleLinux.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4104,NULL,5321,'audio/ogg',787,'2014-05-11 20:15:03.571562','2014-06-28 22:22:38.234541','20c3_633_Fnord-Jahresrueckschau.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4105,NULL,2100,'audio/ogg',795,'2014-05-11 20:15:09.477683','2014-06-28 22:22:38.270365','20c3_637_Distributed-Computing.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4106,NULL,2662,'audio/ogg',773,'2014-05-11 20:15:14.678865','2014-06-28 22:22:38.306276','20c3_644_Gute-Antennen-selber-bauen.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4107,NULL,3396,'audio/ogg',768,'2014-05-11 20:15:19.849611','2014-06-28 22:22:38.341961','20c3_653_Device-Hackling-with-JTAG.ogg',NULL,'downloaded','audio',NULL,NULL);
INSERT INTO "recordings" VALUES(4203,NULL,6592,'audio/ogg',785,'2014-05-11 20:25:47.216087','2014-06-28 22:22:44.849027','20c3_589_AN.ON-and-the-futureof-anonymziers.ogg',NULL,'downloaded','audio',NULL,NULL);
CREATE TABLE "schema_migrations" ("version" varchar(255) NOT NULL);
INSERT INTO "schema_migrations" VALUES('20140627185401');
INSERT INTO "schema_migrations" VALUES('20140615151738');
INSERT INTO "schema_migrations" VALUES('20130820233759');
INSERT INTO "schema_migrations" VALUES('20130821124234');
INSERT INTO "schema_migrations" VALUES('20140502223824');
INSERT INTO "schema_migrations" VALUES('20140101231325');
INSERT INTO "schema_migrations" VALUES('20140611215347');
INSERT INTO "schema_migrations" VALUES('20140120020012');
INSERT INTO "schema_migrations" VALUES('20140502191657');
INSERT INTO "schema_migrations" VALUES('20130820233237');
INSERT INTO "schema_migrations" VALUES('20130820221709');
INSERT INTO "schema_migrations" VALUES('20140622020440');
INSERT INTO "schema_migrations" VALUES('20140626220827');
INSERT INTO "schema_migrations" VALUES('20130820233230');
INSERT INTO "schema_migrations" VALUES('20130820182039');
INSERT INTO "schema_migrations" VALUES('20130826215505');
INSERT INTO "schema_migrations" VALUES('20130821121327');
INSERT INTO "schema_migrations" VALUES('20130824135552');
INSERT INTO "schema_migrations" VALUES('20140622085720');
INSERT INTO "schema_migrations" VALUES('20140101232111');
INSERT INTO "schema_migrations" VALUES('20130821123704');
INSERT INTO "schema_migrations" VALUES('20140103000033');
INSERT INTO "schema_migrations" VALUES('20130821000003');
INSERT INTO "schema_migrations" VALUES('20140101230549');
INSERT INTO "schema_migrations" VALUES('20130820210349');
INSERT INTO "schema_migrations" VALUES('20130820223153');
INSERT INTO "schema_migrations" VALUES('20130820222724');
INSERT INTO "schema_migrations" VALUES('20130820233659');
INSERT INTO "schema_migrations" VALUES('20140502222555');
INSERT INTO "schema_migrations" VALUES('20130822181227');
INSERT INTO "schema_migrations" VALUES('20130820182037');
INSERT INTO "schema_migrations" VALUES('20130820192118');
INSERT INTO "schema_migrations" VALUES('20140103000127');
INSERT INTO "schema_migrations" VALUES('20140609012419');
INSERT INTO "schema_migrations" VALUES('20140611215723');
INSERT INTO "schema_migrations" VALUES('20140626223140');
INSERT INTO "schema_migrations" VALUES('20140102031811');
INSERT INTO "schema_migrations" VALUES('20130820222430');
DELETE FROM sqlite_sequence;
INSERT INTO "sqlite_sequence" VALUES('admin_users',1);
INSERT INTO "sqlite_sequence" VALUES('events',1953);
INSERT INTO "sqlite_sequence" VALUES('recordings',4311);
INSERT INTO "sqlite_sequence" VALUES('recording_views',6633);
INSERT INTO "sqlite_sequence" VALUES('import_templates',1);
INSERT INTO "sqlite_sequence" VALUES('news',5);
INSERT INTO "sqlite_sequence" VALUES('conferences',42);
CREATE INDEX "index_active_admin_comments_on_author_type_and_author_id" ON "active_admin_comments" ("author_type", "author_id");
CREATE INDEX "index_active_admin_comments_on_namespace" ON "active_admin_comments" ("namespace");
CREATE INDEX "index_active_admin_comments_on_resource_type_and_resource_id" ON "active_admin_comments" ("resource_type", "resource_id");
CREATE UNIQUE INDEX "index_admin_users_on_email" ON "admin_users" ("email");
CREATE UNIQUE INDEX "index_admin_users_on_reset_password_token" ON "admin_users" ("reset_password_token");
CREATE INDEX "index_conferences_on_acronym" ON "conferences" ("acronym");
CREATE INDEX "delayed_jobs_priority" ON "delayed_jobs" ("priority", "run_at");
CREATE INDEX "index_events_on_conference_id" ON "events" ("conference_id");
CREATE INDEX "index_events_on_guid" ON "events" ("guid");
CREATE INDEX "index_events_on_title" ON "events" ("title");
CREATE INDEX "index_recording_views_on_recording_id" ON "recording_views" ("recording_id");
CREATE INDEX "index_recordings_on_event_id" ON "recordings" ("event_id");
CREATE INDEX "index_recordings_on_filename" ON "recordings" ("filename");
CREATE INDEX "index_recordings_on_mime_type" ON "recordings" ("mime_type");
CREATE INDEX "index_recordings_on_state" ON "recordings" ("state");
CREATE UNIQUE INDEX "unique_schema_migrations" ON "schema_migrations" ("version");
COMMIT;
